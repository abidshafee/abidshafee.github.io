<?php
/**
 * Single post template.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

get_header();

$defaults      = yusraah_blog_defaults();
$show_author   = (bool) get_theme_mod( 'yusraah_blog_show_author', $defaults['blog_show_author'] );
$show_date     = (bool) get_theme_mod( 'yusraah_blog_show_date', $defaults['blog_show_date'] );
$show_readtime = (bool) get_theme_mod( 'yusraah_blog_show_reading_time', $defaults['blog_show_reading_time'] );
$show_share    = (bool) get_theme_mod( 'yusraah_blog_share_buttons', $defaults['blog_share_buttons'] );
$show_toc      = (bool) get_theme_mod( 'yusraah_blog_table_of_contents', $defaults['blog_table_of_contents'] );
$show_progress = (bool) get_theme_mod( 'yusraah_blog_reading_progress', $defaults['blog_reading_progress'] );

$categories = get_the_category();
$tags       = get_the_tags();
$content    = apply_filters( 'the_content', get_the_content() );
$toc        = $show_toc ? yusraah_blog_toc_headings( $content ) : array();
$has_toc    = count( $toc ) >= 3;
$products   = yusraah_blog_post_products( get_the_ID() );
$related    = yusraah_blog_related_posts( get_the_ID() );
$author_id  = (int) get_the_author_meta( 'ID' );
$updated    = ( get_the_modified_time( 'U' ) - get_the_time( 'U' ) ) > DAY_IN_SECONDS;
?>
<main id="main-content" class="blog-single">
	<article <?php post_class( 'blog-article' ); ?>>
		<?php if ( $show_progress ) : ?>
			<div class="blog-progress" aria-hidden="true"><span class="blog-progress__bar" data-blog-progress></span></div>
		<?php endif; ?>

		<div class="blog-single__inner">
			<?php yusraah_blog_breadcrumbs_markup(); ?>

			<header class="blog-article__header">
				<?php if ( $categories ) : ?>
					<div class="blog-article__cats">
						<?php foreach ( $categories as $cat ) : ?>
							<a class="blog-chip" href="<?php echo esc_url( get_category_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

				<h1 class="blog-article__title"><?php the_title(); ?></h1>

				<?php $excerpt = trim( (string) get_post_field( 'post_excerpt', get_the_ID() ) ); ?>
				<?php if ( $excerpt ) : ?>
					<p class="blog-article__lead"><?php echo esc_html( $excerpt ); ?></p>
				<?php endif; ?>

				<div class="blog-article__meta">
					<?php if ( $show_author ) : ?>
						<?php
						$author_name = get_the_author_meta( 'display_name', $author_id );
						if ( empty( $author_name ) ) {
							$author_name = get_the_author();
						}
						?>
						<span class="blog-article__author">
							<?php echo yusraah_blog_avatar( $author_id, 36 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>"><?php echo esc_html( $author_name ); ?></a>
						</span>
					<?php endif; ?>
					<?php if ( $show_date ) : ?>
						<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
						<?php if ( $updated ) : ?>
							<span class="blog-article__updated"><?php printf( esc_html__( 'Updated %s', 'yusraah' ), esc_html( get_the_modified_date() ) ); ?></span>
						<?php endif; ?>
					<?php endif; ?>
					<?php if ( $show_readtime ) : ?>
						<span><?php printf( esc_html__( '%d min read', 'yusraah' ), (int) yusraah_blog_reading_time() ); ?></span>
					<?php endif; ?>
				</div>
			</header>

			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="blog-article__featured">
					<?php the_post_thumbnail( 'large', array( 'alt' => trim( wp_strip_all_tags( get_the_title() ) ), 'fetchpriority' => 'high', 'decoding' => 'async' ) ); ?>
					<?php $caption = wp_get_attachment_caption( get_post_thumbnail_id() ); ?>
					<?php if ( $caption ) : ?>
						<figcaption><?php echo esc_html( $caption ); ?></figcaption>
					<?php endif; ?>
				</figure>
			<?php endif; ?>

			<div class="blog-article__layout<?php echo $has_toc ? ' blog-article__layout--toc' : ''; ?>">
				<div class="blog-article__content">
					<?php if ( $has_toc ) : ?>
						<nav class="blog-toc blog-toc--mobile" aria-label="<?php esc_attr_e( 'Table of contents', 'yusraah' ); ?>" data-blog-toc>
							<button type="button" class="blog-toc__toggle" aria-expanded="false" aria-controls="blog-toc-list">
								<span><?php esc_html_e( 'Table of contents', 'yusraah' ); ?></span>
								<span class="blog-toc__chevron" aria-hidden="true"></span>
							</button>
							<ul class="blog-toc__list" id="blog-toc-list">
								<?php foreach ( $toc as $h ) : ?>
									<li class="blog-toc__item blog-toc__item--h<?php echo (int) $h['level']; ?>" data-toc-text="<?php echo esc_attr( $h['text'] ); ?>">
										<a href="#<?php echo esc_attr( sanitize_title( $h['text'] ) ); ?>"><?php echo esc_html( $h['text'] ); ?></a>
									</li>
								<?php endforeach; ?>
							</ul>
						</nav>
					<?php endif; ?>

					<div class="entry-content blog-content"><?php the_content(); ?></div>

					<?php if ( $tags ) : ?>
						<div class="blog-article__tags">
							<?php foreach ( $tags as $tag ) : ?>
								<a class="blog-chip blog-chip--tag" href="<?php echo esc_url( get_tag_link( $tag ) ); ?>">#<?php echo esc_html( $tag->name ); ?></a>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<?php if ( $show_share ) : ?>
						<div class="blog-share" role="group" aria-label="<?php esc_attr_e( 'Share this post', 'yusraah' ); ?>">
							<span class="blog-share__label"><?php esc_html_e( 'Share', 'yusraah' ); ?></span>
							<a href="https://wa.me/?text=<?php echo rawurlencode( get_the_title() . ' ' . get_permalink() ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Share on WhatsApp', 'yusraah' ); ?>">WhatsApp</a>
							<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo rawurlencode( get_permalink() ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Share on Facebook', 'yusraah' ); ?>">Facebook</a>
							<a href="https://twitter.com/intent/tweet?url=<?php echo rawurlencode( get_permalink() ); ?>&text=<?php echo rawurlencode( get_the_title() ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Share on X', 'yusraah' ); ?>">X</a>
							<a href="https://pinterest.com/pin/create/button/?url=<?php echo rawurlencode( get_permalink() ); ?>&description=<?php echo rawurlencode( get_the_title() ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Pin on Pinterest', 'yusraah' ); ?>">Pinterest</a>
							<a href="mailto:?subject=<?php echo rawurlencode( get_the_title() ); ?>&body=<?php echo rawurlencode( get_permalink() ); ?>" aria-label="<?php esc_attr_e( 'Share by email', 'yusraah' ); ?>"><?php esc_html_e( 'Email', 'yusraah' ); ?></a>
							<button type="button" class="blog-share__copy" data-blog-copy-link data-url="<?php echo esc_url( get_permalink() ); ?>" aria-live="polite"><?php esc_html_e( 'Copy link', 'yusraah' ); ?></button>
						</div>
					<?php endif; ?>

					<?php if ( $products ) : ?>
						<section class="blog-shop-post" aria-labelledby="blog-shop-post-title">
							<h2 id="blog-shop-post-title"><?php esc_html_e( 'Shop this post', 'yusraah' ); ?></h2>
							<ul class="products blog-shop-post__grid<?php echo 1 === count( $products ) ? ' blog-shop-post__grid--single' : ''; ?>">
								<?php
								global $product;
								foreach ( $products as $product ) :
									setup_postdata( $product->get_id() );
									wc_get_template_part( 'content', 'product' );
								endforeach;
								wp_reset_postdata();
								?>
							</ul>
						</section>
					<?php endif; ?>

					<?php if ( $show_author ) : ?>
						<?php
						$author_name = get_the_author_meta( 'display_name', $author_id );
						if ( empty( $author_name ) ) {
							$author_name = get_the_author();
						}
						?>
						<section class="blog-author" aria-labelledby="blog-author-title">
							<?php echo yusraah_blog_avatar( $author_id, 72 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<div>
								<h2 id="blog-author-title"><?php echo esc_html( $author_name ); ?></h2>
								<?php $bio = get_the_author_meta( 'description', $author_id ); ?>
								<?php if ( $bio ) : ?>
									<p><?php echo esc_html( $bio ); ?></p>
								<?php endif; ?>
								<a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>"><?php printf( esc_html__( 'All posts by %s', 'yusraah' ), esc_html( $author_name ) ); ?></a>
							</div>
						</section>
					<?php endif; ?>

					<?php
					$prev = get_previous_post();
					$next = get_next_post();
					if ( $prev || $next ) :
						?>
						<nav class="blog-prevnext" aria-label="<?php esc_attr_e( 'More posts', 'yusraah' ); ?>">
							<?php if ( $prev ) : ?>
								<a class="blog-prevnext__item blog-prevnext__item--prev" href="<?php echo esc_url( get_permalink( $prev ) ); ?>">
									<?php if ( has_post_thumbnail( $prev ) ) : ?>
										<span class="blog-prevnext__thumb"><?php echo get_the_post_thumbnail( $prev, 'thumbnail', array( 'alt' => '' ) ); ?></span>
									<?php endif; ?>
									<span class="blog-prevnext__text">
										<span class="blog-prevnext__label"><?php esc_html_e( 'Previous', 'yusraah' ); ?></span>
										<span class="blog-prevnext__title"><?php echo esc_html( get_the_title( $prev ) ); ?></span>
									</span>
								</a>
							<?php endif; ?>
							<?php if ( $next ) : ?>
								<a class="blog-prevnext__item blog-prevnext__item--next" href="<?php echo esc_url( get_permalink( $next ) ); ?>">
									<?php if ( has_post_thumbnail( $next ) ) : ?>
										<span class="blog-prevnext__thumb"><?php echo get_the_post_thumbnail( $next, 'thumbnail', array( 'alt' => '' ) ); ?></span>
									<?php endif; ?>
									<span class="blog-prevnext__text">
										<span class="blog-prevnext__label"><?php esc_html_e( 'Next', 'yusraah' ); ?></span>
										<span class="blog-prevnext__title"><?php echo esc_html( get_the_title( $next ) ); ?></span>
									</span>
								</a>
							<?php endif; ?>
						</nav>
					<?php endif; ?>

					<?php if ( $related ) : ?>
						<section class="blog-related" aria-labelledby="blog-related-title">
							<h2 id="blog-related-title"><?php esc_html_e( 'You may also like', 'yusraah' ); ?></h2>
							<div class="blog-grid blog-grid--related">
								<?php
								global $post;
								foreach ( $related as $rel_post ) :
									$post = $rel_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride -- scoped loop.
									setup_postdata( $rel_post );
									yusraah_blog_card();
								endforeach;
								wp_reset_postdata();
								$post = get_post(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
								?>
							</div>
						</section>
					<?php endif; ?>

					<?php
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
					?>
				</div>

				<?php if ( $has_toc ) : ?>
					<aside class="blog-toc blog-toc--desktop" aria-label="<?php esc_attr_e( 'Table of contents', 'yusraah' ); ?>">
						<h2 class="blog-toc__heading"><?php esc_html_e( 'On this page', 'yusraah' ); ?></h2>
						<ul class="blog-toc__list">
							<?php foreach ( $toc as $h ) : ?>
								<li class="blog-toc__item blog-toc__item--h<?php echo (int) $h['level']; ?>" data-toc-text="<?php echo esc_attr( $h['text'] ); ?>">
									<a href="#<?php echo esc_attr( sanitize_title( $h['text'] ) ); ?>"><?php echo esc_html( $h['text'] ); ?></a>
								</li>
							<?php endforeach; ?>
						</ul>
					</aside>
				<?php endif; ?>
			</div>
		</div>
	</article>
</main>
<?php get_footer(); ?>
