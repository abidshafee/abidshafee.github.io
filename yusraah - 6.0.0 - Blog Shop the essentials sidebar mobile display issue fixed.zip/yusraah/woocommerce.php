<?php
/**
 * WooCommerce page wrapper.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */
get_header();
?>
<main id="main-content" class="page-shell woocommerce-shell">
	<?php woocommerce_content(); ?>
</main>
<?php get_footer(); ?>
