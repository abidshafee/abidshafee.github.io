<?php
/**
 * Not found template.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */
get_header();
?>
<main id="main-content" class="page-shell not-found">
	<p class="eyebrow">404 · <?php esc_html_e( 'A small detour', 'yusraah' ); ?></p>
	<h1><?php esc_html_e( 'This page has wandered off.', 'yusraah' ); ?></h1>
	<p><?php esc_html_e( 'Let’s take you back to something worth finding.', 'yusraah' ); ?></p>
	<a class="button button--dark" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Return home', 'yusraah' ); ?> <?php echo yusraah_icon( 'arrow' ); ?></a>
</main>
<?php get_footer(); ?>
