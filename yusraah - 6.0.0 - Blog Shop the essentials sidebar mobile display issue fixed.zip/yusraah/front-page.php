<?php
/**
 * Editorial homepage.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */
get_header();
$shop_url  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
$hero_image = get_theme_mod( 'yusraah_hero_image', 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1800&q=88' );
$story_image = get_theme_mod( 'yusraah_story_image', 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=1200&q=85' );

// New hero settings
$hero_headline = get_theme_mod( 'yusraah_hero_headline', __( 'Everyday Essentials for Modern Living', 'yusraah' ) );
$hero_subtext = get_theme_mod( 'yusraah_hero_subtext', __( 'Quality products delivered to your doorstep. Fast, reliable, and convenient.', 'yusraah' ) );
$hero_cta_text = get_theme_mod( 'yusraah_hero_cta_text', __( 'Shop now', 'yusraah' ) );

// Trust bar items
$trust_items = array(
	get_theme_mod( 'yusraah_trust_bar_1', __( 'Fast delivery', 'yusraah' ) ),
	get_theme_mod( 'yusraah_trust_bar_2', __( 'Easy returns', 'yusraah' ) ),
	get_theme_mod( 'yusraah_trust_bar_3', __( 'Secure payment', 'yusraah' ) ),
	get_theme_mod( 'yusraah_trust_bar_4', __( 'Cash on delivery', 'yusraah' ) ),
	get_theme_mod( 'yusraah_trust_bar_5', __( '24/7 support', 'yusraah' ) ),
);
$trust_items = array_filter( $trust_items );

// Product categories
$categories = yusraah_get_product_categories();
$category_images = yusraah_get_category_image_urls_map();
$category_title = get_theme_mod( 'yusraah_category_title', __( 'Shop by Category', 'yusraah' ) );
$category_view_all = get_theme_mod( 'yusraah_category_view_all', __( 'View all categories', 'yusraah' ) );
$category_show_count = get_theme_mod( 'yusraah_category_show_count', true );
$category_columns = absint( get_theme_mod( 'yusraah_category_columns', 4 ) );

// Hero slider is now rendered by inc/hero-slider.php using cached WC_Product_Query.
$hero_slider_html = function_exists( 'yusraah_render_hero_slider' ) ? yusraah_render_hero_slider() : '';

// Story section slider
$story_slider_show = get_theme_mod( 'yusraah_story_slider_show', true );
$story_heading = get_theme_mod( 'yusraah_story_heading', __( 'Good things get', 'yusraah' ) );
$story_subtext = get_theme_mod( 'yusraah_story_subtext', __( 'We believe the best pieces earn their place. Each find is chosen for thoughtful construction, honest materials, and the feeling that it will still be loved years from now.', 'yusraah' ) );
$story_button_text = get_theme_mod( 'yusraah_story_button_text', __( 'Find your forever piece', 'yusraah' ) );
$story_button_link = get_theme_mod( 'yusraah_story_button_link', $shop_url );
$story_slider_html = $story_slider_show && function_exists( 'yusraah_render_quick_deal_panel' ) ? yusraah_render_quick_deal_panel() : '';
?>
<main id="main-content">
	<!-- Phase 1: Hero Section with Two-Column Layout -->
	<section class="home-hero hero--modern">
		<div class="home-hero__grid">
			<!-- Left Column: Slogan/Content -->
			<div class="home-hero__left">
				<span class="hero-badge"><?php esc_html_e( 'Welcome to Essential Shop BD', 'yusraah' ); ?></span>
				<h1><?php echo esc_html( $hero_headline ); ?></h1>
				<p class="home-hero__intro"><?php echo esc_html( $hero_subtext ); ?></p>
				<a class="button button--hero" href="<?php echo esc_url( $shop_url ); ?>"><?php echo esc_html( $hero_cta_text ); ?></a>
			</div>

			<!-- Right Column: Product Slider (contained — never overlaps headline) -->
			<?php if ( $hero_slider_html ) : ?>
			<div class="home-hero__right">
				<?php echo $hero_slider_html; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
			<?php endif; ?>
		</div>
	</section>

	<!-- Phase 1: Trust Bar -->
	<section class="trust-bar" aria-label="<?php esc_attr_e( 'Why shop with us', 'yusraah' ); ?>">
		<?php foreach ( $trust_items as $item ) : ?>
			<?php
			// Map the trust label to the footer's monoline icon set so the bar
			// reads like the footer trust row. Falls back to a check mark.
			$trust_icon = 'secure';
			$label      = function_exists( 'mb_strtolower' ) ? mb_strtolower( $item ) : strtolower( $item );
			if ( false !== strpos( $label, 'deliver' ) || false !== strpos( $label, 'ship' ) ) {
				$trust_icon = 'delivery';
			} elseif ( false !== strpos( $label, 'return' ) || false !== strpos( $label, 'exchange' ) ) {
				$trust_icon = 'returns';
			} elseif ( false !== strpos( $label, 'cod' ) || false !== strpos( $label, 'cash' ) ) {
				$trust_icon = 'cod';
			} elseif ( false !== strpos( $label, 'support' ) || false !== strpos( $label, 'hour' ) || false !== strpos( $label, '24' ) ) {
				$trust_icon = 'clock';
			}
			?>
			<div class="trust-item">
				<?php
				$icon_svg = function_exists( 'yusraah_footer_icon' ) ? yusraah_footer_icon( $trust_icon ) : '';
				if ( $icon_svg ) {
					echo $icon_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted inline SVG from theme icon set.
				} else {
					echo '<span class="trust-item__icon" aria-hidden="true">✓</span>';
				}
				?>
				<span><?php echo esc_html( $item ); ?></span>
			</div>
		<?php endforeach; ?>
	</section>

	<!-- Phase 1: Shop by Category -->
	<?php if ( ! empty( $categories ) ) : ?>
	<section class="shop-by-category products-section">
		<div class="section-heading">
			<h2><?php echo esc_html( $category_title ); ?></h2>
			<a class="text-arrow" href="<?php echo esc_url( $shop_url ); ?>"><?php echo esc_html( $category_view_all ); ?> <?php echo yusraah_icon( 'arrow' ); ?></a>
		</div>
		<div class="category-grid category-grid--<?php echo esc_attr( $category_columns ); ?>-col">
			<?php foreach ( $categories as $category ) : ?>
				<a class="category-tile" href="<?php echo esc_url( get_term_link( $category ) ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: category name */ __( 'Shop %s', 'yusraah' ), $category->name ) ); ?>" data-category-images="<?php echo esc_attr( wp_json_encode( isset( $category_images[ $category->term_id ] ) ? $category_images[ $category->term_id ] : array() ) ); ?>">
					<div class="category-tile__image-wrap">
						<?php
						// Use product images if available, otherwise fall back to category thumbnail or placeholder.
						$product_images = isset( $category_images[ $category->term_id ] ) ? $category_images[ $category->term_id ] : array();

						if ( ! empty( $product_images ) ) {
							// First product image as main. The wrapping element keeps
							// its 4:5 aspect ratio, so no width/height is needed.
							echo '<img src="' . esc_url( $product_images[0] ) . '" alt="' . esc_attr( $category->name ) . '" class="category-tile__image" loading="lazy" decoding="async">';
						} else {
							// Fall back to category thumbnail
							$thumbnail_id = get_term_meta( $category->term_id, 'thumbnail_id', true );
							if ( $thumbnail_id ) {
								$img_src = wp_get_attachment_image_url( $thumbnail_id, 'medium' );
								$img_srcset = wp_get_attachment_image_srcset( $thumbnail_id, 'medium' );
								$img_sizes = '(max-width: 640px) 100vw, 400px';
								$img_meta = wp_get_attachment_metadata( $thumbnail_id );
								$img_width = isset( $img_meta['width'] ) ? (int) $img_meta['width'] : 0;
								$img_height = isset( $img_meta['height'] ) ? (int) $img_meta['height'] : 0;
								$img_alt = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );
								if ( empty( $img_alt ) ) {
									$img_alt = $category->name;
								}

								$attrs = array(
									'src'   => esc_url( $img_src ),
									'alt'   => esc_attr( $img_alt ),
									'sizes' => esc_attr( $img_sizes ),
									'class' => 'category-tile__image',
								);
								if ( $img_width && $img_height ) {
									$attrs['width']  = $img_width;
									$attrs['height'] = $img_height;
								}
								if ( $img_srcset ) {
									$attrs['srcset'] = esc_attr( $img_srcset );
								}
								$attrs['loading'] = 'lazy';
								$attrs['decoding'] = 'async';

								$attr_str = '';
								foreach ( $attrs as $k => $v ) {
									$attr_str .= ' ' . esc_attr( $k ) . '="' . $v . '"';
								}
								echo '<img' . $attr_str . '>';
							} else {
								// Placeholder
								echo '<div class="category-tile__placeholder"><span>' . esc_html( mb_substr( $category->name, 0, 1 ) ) . '</span></div>';
							}
						}
						?>
						<div class="category-tile__overlay"></div>
					</div>
					<div class="category-tile__content">
						<h3><?php echo esc_html( $category->name ); ?></h3>
						<?php if ( $category_show_count ) : ?>
						<span class="category-tile__count">
							<?php
							/* translators: %s: number of products */
							echo esc_html( sprintf( _n( '%s product', '%s products', $category->count, 'yusraah' ), number_format_i18n( $category->count ) ) );
							?>
						</span>
						<?php endif; ?>
						<span class="category-tile__arrow" aria-hidden="true">→</span>
					</div>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
	<?php endif; ?>

	<script>
	// Category image cycling on hover.
	( function () {
		'use strict';

		var CYCLE_SPEED = 1500; // 1.5 seconds per image.
		var FADE_SPEED = 200; // 0.2 second cross fade.
		var reducedMotion = window.matchMedia ? window.matchMedia( '(prefers-reduced-motion: reduce)' ) : null;

		function initCategoryImageCycling() {
			var tiles = document.querySelectorAll( '.category-tile[data-category-images]' );

			Array.prototype.forEach.call( tiles, function ( tile ) {
				var imgElement = tile.querySelector( '.category-tile__image' );
				if ( ! imgElement ) {
					return;
				}

				var images;
				try {
					images = JSON.parse( tile.getAttribute( 'data-category-images' ) || '[]' );
				} catch ( error ) {
					return;
				}

				// Graceful degradation: nothing to cycle with fewer than 2 images.
				if ( ! Array.isArray( images ) || images.length < 2 ) {
					return;
				}

				var currentIndex = 0;
				var cycleTimer = null;
				var fadeTimer = null;

				function showImage( index ) {
					currentIndex = index;
					imgElement.style.opacity = '0';
					window.clearTimeout( fadeTimer );
					fadeTimer = window.setTimeout( function () {
						imgElement.src = images[ currentIndex ];
						imgElement.style.opacity = '1';
					}, FADE_SPEED );
				}

				function stopCycling() {
					window.clearInterval( cycleTimer );
					cycleTimer = null;
				}

				tile.addEventListener( 'mouseenter', function () {
					if ( reducedMotion && reducedMotion.matches ) {
						return;
					}

					// Warm the browser cache so each swap fades in smoothly.
					for ( var i = 1; i < images.length; i++ ) {
						var preload = new Image();
						preload.src = images[ i ];
					}

					stopCycling();
					cycleTimer = window.setInterval( function () {
						showImage( ( currentIndex + 1 ) % images.length );
					}, CYCLE_SPEED );
				} );

				tile.addEventListener( 'mouseleave', function () {
					stopCycling();
					// Auto-reset to the first image.
					if ( currentIndex !== 0 ) {
						showImage( 0 );
					}
				} );
			} );
		}

		if ( document.readyState === 'loading' ) {
			document.addEventListener( 'DOMContentLoaded', initCategoryImageCycling );
		} else {
			initCategoryImageCycling();
		}
	} )();
	</script>

	<!-- Buy Again Section (for logged-in users) -->
	<?php
	if ( is_user_logged_in() && function_exists( 'yusraah_render_buy_again' ) ) {
		yusraah_render_buy_again( 'home' );
	}
	?>

	<!-- Phase 2: Best Sellers -->
	<?php if ( class_exists( 'WooCommerce' ) ) : ?>
	<section class="products-section">
		<div class="section-heading">
			<h2><?php esc_html_e( 'Best Sellers', 'yusraah' ); ?></h2>
			<a class="text-arrow" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'View all', 'yusraah' ); ?> <?php echo yusraah_icon( 'arrow' ); ?></a>
		</div>
		<div class="home-products"><?php echo do_shortcode( '[products limit="4" columns="4" orderby="popularity" order="DESC" visibility="visible"]' ); ?></div>
	</section>
	<?php endif; ?>

	<!-- Story Section with Product Slider -->
	<?php if ( $story_slider_show ) : ?>
	<section class="story-section story-section--slider">
		<div class="story-section__grid">
			<!-- Left Column: Product Slider -->
			<?php if ( $story_slider_html ) : ?>
			<div class="story-section__slider">
				<?php echo $story_slider_html; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
			<?php endif; ?>

			<!-- Right Column: Text Content -->
			<div class="story-section__content">
				<p class="eyebrow"><?php esc_html_e( 'The Yusraah point of view', 'yusraah' ); ?></p>
				<h2><?php echo esc_html( $story_heading ); ?><br><em>better with time.</em></h2>
				<p><?php echo esc_html( $story_subtext ); ?></p>
				<?php if ( $story_button_text ) : ?>
				<a class="button button--outline" href="<?php echo esc_url( $story_button_link ); ?>"><?php echo esc_html( $story_button_text ); ?> <?php echo yusraah_icon( 'arrow' ); ?></a>
				<?php endif; ?>
				<div class="story-signature">A<span>M</span></div>
			</div>
		</div>
	</section>
	<?php else : ?>
	<!-- Fallback: Original Story Section (no slider) -->
	<section class="story-section">
		<div class="story-image"><img src="<?php echo esc_url( $story_image ); ?>" alt="<?php esc_attr_e( 'A timeless leather bag, selected for its character and craft', 'yusraah' ); ?>" loading="lazy"><span class="story-image__index">A little less, a little better.</span></div>
		<div class="story-copy">
			<p class="eyebrow"><?php esc_html_e( 'The Yusraah point of view', 'yusraah' ); ?></p>
			<h2><?php esc_html_e( 'Good things get', 'yusraah' ); ?><br><em>better with time.</em></h2>
			<p><?php esc_html_e( 'We believe the best pieces earn their place. Each find is chosen for thoughtful construction, honest materials, and the feeling that it will still be loved years from now.', 'yusraah' ); ?></p>
			<a class="button button--outline" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Find your forever piece', 'yusraah' ); ?> <?php echo yusraah_icon( 'arrow' ); ?></a>
			<div class="story-signature">A<span>M</span></div>
		</div>
	</section>
	<?php endif; ?>

	<!-- Phase 2: New Arrivals -->
	<?php if ( class_exists( 'WooCommerce' ) ) : ?>
	<section class="products-section">
		<div class="section-heading">
			<h2><?php esc_html_e( 'New Arrivals', 'yusraah' ); ?></h2>
			<a class="text-arrow" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'View all', 'yusraah' ); ?> <?php echo yusraah_icon( 'arrow' ); ?></a>
		</div>
		<div class="home-products"><?php echo do_shortcode( '[products limit="4" columns="4" orderby="date" order="DESC" visibility="visible"]' ); ?></div>
	</section>
	<?php endif; ?>

	<!-- Phase 2: Monthly Kits Banner -->
	<?php echo yusraah_monthly_kits_render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Rendered by the escaped banner renderer. ?>

	<!-- Phase 2: Why Choose Us -->
	<?php
	$why_title = get_theme_mod( 'yusraah_why_choose_title', __( 'Why Choose Us', 'yusraah' ) );
	$why_items = array(
		array(
			'title' => get_theme_mod( 'yusraah_why_item_1_title', __( 'Quality Guaranteed', 'yusraah' ) ),
			'desc' => get_theme_mod( 'yusraah_why_item_1_desc', __( 'We carefully select only the finest products for your daily needs.', 'yusraah' ) ),
		),
		array(
			'title' => get_theme_mod( 'yusraah_why_item_2_title', __( 'Fast Delivery', 'yusraah' ) ),
			'desc' => get_theme_mod( 'yusraah_why_item_2_desc', __( 'Get your essentials delivered to your doorstep within 24-48 hours.', 'yusraah' ) ),
		),
		array(
			'title' => get_theme_mod( 'yusraah_why_item_3_title', __( 'Customer Support', 'yusraah' ) ),
			'desc' => get_theme_mod( 'yusraah_why_item_3_desc', __( 'Our dedicated team is here to help you with any questions or concerns.', 'yusraah' ) ),
		),
		array(
			'title' => get_theme_mod( 'yusraah_why_item_4_title', __( 'Secure Payments', 'yusraah' ) ),
			'desc' => get_theme_mod( 'yusraah_why_item_4_desc', __( 'Shop with confidence using our secure payment options and cash on delivery.', 'yusraah' ) ),
		),
	);
	?>
	<section class="why-choose section-wrap">
		<div class="section-heading">
			<h2><?php echo esc_html( $why_title ); ?></h2>
		</div>
		<div class="why-choose__grid">
			<?php foreach ( $why_items as $item ) : ?>
			<div class="why-choose__item">
				<div class="why-choose__icon">
					<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
				</div>
				<h3><?php echo esc_html( $item['title'] ); ?></h3>
				<p><?php echo esc_html( $item['desc'] ); ?></p>
			</div>
			<?php endforeach; ?>
		</div>
	</section>

	<!-- Phase 2: Customer Reviews -->
	<?php yusraah_render_home_reviews(); ?>

	<?php if ( get_theme_mod( 'yusraah_home_newsletter_show', true ) ) : ?>
		<?php
		$newsletter_background = get_theme_mod( 'yusraah_home_newsletter_background', 'glow' );
		if ( ! in_array( $newsletter_background, array( 'glow', 'gradient', 'solid' ), true ) ) {
			$newsletter_background = 'glow';
		}
		$newsletter_consent = (bool) get_theme_mod( 'yusraah_home_newsletter_consent', false );
		$newsletter_notice  = isset( $_GET['newsletter'] ) && is_string( $_GET['newsletter'] ) ? sanitize_key( wp_unslash( $_GET['newsletter'] ) ) : '';
		?>
		<section class="newsletter-section section-wrap" data-background="<?php echo esc_attr( $newsletter_background ); ?>" aria-labelledby="home-newsletter-title">
			<div class="newsletter-section__content">
				<p class="newsletter-section__eyebrow"><?php echo esc_html( get_theme_mod( 'yusraah_home_newsletter_eyebrow', __( 'Newsletter', 'yusraah' ) ) ); ?></p>
				<h2 id="home-newsletter-title"><?php echo esc_html( get_theme_mod( 'yusraah_home_newsletter_title', __( 'Stay Updated', 'yusraah' ) ) ); ?></h2>
				<?php
				$newsletter_incentive = get_theme_mod( 'yusraah_home_newsletter_incentive', '' );
				if ( $newsletter_incentive ) :
					?>
					<p class="newsletter-section__incentive"><?php echo esc_html( $newsletter_incentive ); ?></p>
				<?php endif; ?>
				<p class="newsletter-section__intro"><?php echo esc_html( get_theme_mod( 'yusraah_home_newsletter_subtext', __( 'Thoughtful updates, new arrivals, and exclusive offers — delivered occasionally.', 'yusraah' ) ) ); ?></p>

				<form class="newsletter-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-newsletter-form data-newsletter-context="home">
					<input type="hidden" name="action" value="yusraah_newsletter_fallback">
					<input type="hidden" name="newsletter_nonce" value="<?php echo esc_attr( wp_create_nonce( 'yusraah_newsletter' ) ); ?>">
					<input type="hidden" name="context" value="home">
					<div class="newsletter-form__field">
						<label class="screen-reader-text" for="home-newsletter-email"><?php esc_html_e( 'Email address', 'yusraah' ); ?></label>
						<svg class="newsletter-form__mail" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg>
						<input type="email" id="home-newsletter-email" name="EMAIL" autocomplete="email" placeholder="<?php esc_attr_e( 'Your email address', 'yusraah' ); ?>" required>
					</div>
					<div class="newsletter-form__trap" aria-hidden="true">
						<label for="home-newsletter-website"><?php esc_html_e( 'Leave this field empty', 'yusraah' ); ?></label>
						<input type="text" id="home-newsletter-website" name="yusraah_website" tabindex="-1" autocomplete="off">
					</div>
					<button type="submit" class="newsletter-form__submit">
						<span><?php echo esc_html( get_theme_mod( 'yusraah_home_newsletter_button', __( 'Subscribe', 'yusraah' ) ) ); ?></span>
						<svg class="newsletter-form__arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
						<svg class="newsletter-form__spinner" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/></svg>
					</button>
					<?php if ( $newsletter_consent ) : ?>
						<div class="newsletter-form__consent">
							<input type="checkbox" id="home-newsletter-consent" name="consent" value="1" required>
							<label for="home-newsletter-consent"><?php echo esc_html( get_theme_mod( 'yusraah_home_newsletter_consent_text', __( 'I agree to receive occasional email updates.', 'yusraah' ) ) ); ?></label>
							<?php if ( get_privacy_policy_url() ) : ?>
								<a href="<?php echo esc_url( get_privacy_policy_url() ); ?>"><?php esc_html_e( 'Privacy policy', 'yusraah' ); ?></a>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</form>

				<?php
				$newsletter_status = '';
				$newsletter_error  = false;
				if ( 'success' === $newsletter_notice ) {
					$newsletter_status = get_theme_mod( 'yusraah_home_newsletter_success', __( 'Thanks for subscribing! Please check your inbox to confirm.', 'yusraah' ) );
				} elseif ( 'duplicate' === $newsletter_notice ) {
					$newsletter_status = __( 'This email is already subscribed.', 'yusraah' );
					$newsletter_error  = true;
				} elseif ( 'invalid' === $newsletter_notice ) {
					$newsletter_status = __( 'Please enter a valid email address.', 'yusraah' );
					$newsletter_error  = true;
				} elseif ( 'error' === $newsletter_notice ) {
					$newsletter_status = __( 'Something went wrong. Please try again in a moment.', 'yusraah' );
					$newsletter_error  = true;
				}
				?>
				<p class="newsletter__status<?php echo $newsletter_error ? ' is-error' : ''; ?>" data-newsletter-status role="status" aria-live="polite"><?php echo esc_html( $newsletter_status ); ?></p>
				<p class="newsletter-section__trust"><?php esc_html_e( 'No spam. Unsubscribe anytime.', 'yusraah' ); ?></p>

				<?php if ( get_theme_mod( 'yusraah_home_newsletter_benefits', true ) ) : ?>
					<ul class="newsletter-section__benefits" aria-label="<?php esc_attr_e( 'Newsletter benefits', 'yusraah' ); ?>">
						<li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 14.5 8.5 20.5 9l-4.5 4 1.3 6-5.3-3-5.3 3 1.3-6-4.5-4 6-.5z"/></svg><?php esc_html_e( 'Exclusive offers', 'yusraah' ); ?></li>
						<li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h16l-1 12H5L4 8Z"/><path d="M9 8a3 3 0 0 1 6 0"/></svg><?php esc_html_e( 'New arrivals', 'yusraah' ); ?></li>
						<li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v12H9l-5 3V5Z"/><path d="M8 9h8M8 13h5"/></svg><?php esc_html_e( 'Helpful tips', 'yusraah' ); ?></li>
					</ul>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="closing-note">
		<p class="eyebrow"><?php esc_html_e( 'A more considered wardrobe', 'yusraah' ); ?></p>
		<p class="closing-note__quote"><?php esc_html_e( 'The things we keep should make the everyday feel a little more extraordinary.', 'yusraah' ); ?></p>
		<a href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Find your next favourite', 'yusraah' ); ?> <span aria-hidden="true">↗</span></a>
	</section>
</main>
<?php get_footer(); ?>