<?php
/**
 * Comments template — clean threaded layout for single posts.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

if ( post_password_required() ) {
	return;
}

/**
 * Render one comment with theme markup, avatar fallback and author badge.
 * Walker_Comment calls this per comment (children are handled by the walker).
 *
 * @param WP_Comment $comment Comment object.
 * @param array      $args    Display arguments.
 * @param int        $depth   Nesting depth.
 */
function yusraah_blog_render_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment; // phpcs:ignore WordPress.WP.GlobalVariablesOverride -- required by comment_*() helpers.
	?>
	<li <?php comment_class( 'blog-comment' ); ?> id="comment-<?php comment_ID(); ?>">
		<article class="blog-comment__inner">
			<div class="blog-comment__avatar">
				<?php
				if ( $comment->user_id ) {
					echo yusraah_blog_avatar( $comment->user_id, 44 ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside helper.
				} else {
					$parts     = preg_split( '/\s+/', trim( (string) $comment->comment_author ) );
					$initials  = '';
					foreach ( array_slice( $parts, 0, 2 ) as $part ) {
						$initials .= mb_strtoupper( mb_substr( $part, 0, 1 ) );
					}
					?>
					<span class="blog-avatar-fallback" style="width:44px;height:44px;font-size:15px" aria-hidden="true"><?php echo esc_html( $initials ? $initials : '·' ); ?></span>
					<?php
				}
				?>
			</div>
			<div class="blog-comment__content">
				<header class="blog-comment__meta">
					<span class="blog-comment__author"><?php comment_author_link(); ?></span>
					<?php if ( $comment->user_id && get_post()->post_author == $comment->user_id ) : ?>
						<span class="blog-comment__badge"><?php esc_html_e( 'Author', 'yusraah' ); ?></span>
					<?php endif; ?>
					<a class="blog-comment__date" href="<?php echo esc_url( get_comment_link( $comment ) ); ?>">
						<time datetime="<?php comment_time( 'c' ); ?>"><?php comment_date(); ?></time>
					</a>
				</header>
				<?php if ( '0' === $comment->comment_approved ) : ?>
					<p class="blog-comment__awaiting"><?php esc_html_e( 'Your comment is awaiting moderation.', 'yusraah' ); ?></p>
				<?php endif; ?>
				<div class="blog-comment__text"><?php comment_text(); ?></div>
				<?php
				if ( comments_open() ) {
					comment_reply_link(
						array_merge(
							$args,
							array(
								'depth'     => $depth,
								'max_depth' => $args['max_depth'],
								'reply_text' => __( 'Reply', 'yusraah' ),
							)
						)
					);
				}
				?>
			</div>
		</article>
	</li>
	<?php
}
?>
<section id="comments" class="blog-comments">
	<?php if ( have_comments() ) : ?>
		<h2 class="blog-comments__title">
			<?php
			printf(
				/* translators: %s: comment count */
				esc_html( _nx( '%s comment', '%s comments', get_comments_number(), 'comments title', 'yusraah' ) ),
				esc_html( number_format_i18n( get_comments_number() ) )
			);
			?>
		</h2>
		<ol class="blog-comments__list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 44,
					'callback'    => 'yusraah_blog_render_comment',
				)
			);
			?>
		</ol>
		<?php the_comments_navigation(); ?>
	<?php endif; ?>

	<?php if ( comments_open() ) : ?>
		<div class="blog-comments__form">
			<?php
			comment_form(
				array(
					'title_reply'          => __( 'Leave a reply', 'yusraah' ),
					'title_reply_to'       => __( 'Leave a reply to %s', 'yusraah' ),
					'cancel_reply_link'    => __( 'Cancel reply', 'yusraah' ),
					'title_reply_before'   => '<h3 id="reply-title" class="blog-comments__form-title comment-reply-title">',
					'title_reply_after'    => '</h3>',
					'class_submit'         => 'button button--dark',
					'submit_button'        => '<input name="%1$s" type="submit" id="%2$s" class="%3$s" value="%4$s" />',
					'comment_field'        => '<p class="comment-form-comment"><label for="comment">' . esc_html__( 'Comment', 'yusraah' ) . ' <span class="required">*</span></label><textarea id="comment" name="comment" rows="5" required></textarea></p>',
					'fields'               => array(
						'author' => '<p class="comment-form-author"><label for="author">' . esc_html__( 'Name', 'yusraah' ) . ' <span class="required">*</span></label><input id="author" name="author" type="text" required></p>',
						'email'  => '<p class="comment-form-email"><label for="email">' . esc_html__( 'Email', 'yusraah' ) . ' <span class="required">*</span></label><input id="email" name="email" type="email" required></p>',
						'url'    => '<p class="comment-form-url"><label for="url">' . esc_html__( 'Website', 'yusraah' ) . '</label><input id="url" name="url" type="url"></p>',
					),
					'comment_notes_before' => '<p class="blog-comments__note">' . esc_html__( 'Your email address will not be published. Required fields are marked *', 'yusraah' ) . '</p>',
					'comment_notes_after'  => '',
					'logged_in_as'         => '',
				)
			);
			?>
		</div>
	<?php else : ?>
		<p class="blog-comments__closed"><?php esc_html_e( 'Comments are closed for this post.', 'yusraah' ); ?></p>
	<?php endif; ?>
</section>
