<?php
/**
 * Yusraah theme setup and WooCommerce integration.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WordPress functions stub for IDE support.
 * These functions are available when WordPress loads this theme.
 */
if ( ! function_exists( 'get_template_directory' ) ) {
	/**
	 * Retrieve template directory path.
	 *
	 * @return string
	 */
	function get_template_directory() {
		return '';
	}
}

define( 'YUSRAAH_VERSION', '2.3.0' );

require_once get_template_directory() . '/inc/grocery.php';
require_once get_template_directory() . '/inc/hero-slider.php';
require_once get_template_directory() . '/inc/quick-deal.php';
require_once get_template_directory() . '/inc/monthly-kits.php';
require_once get_template_directory() . '/inc/wishlist.php';
require_once get_template_directory() . '/inc/my-account.php';
require_once get_template_directory() . '/inc/single-product.php';
require_once get_template_directory() . '/inc/footer.php';
require_once get_template_directory() . '/inc/blog.php';
require_once get_template_directory() . '/inc/mobile-nav.php';
require_once get_template_directory() . '/inc/home-reviews.php';
require_once get_template_directory() . '/inc/migrate-from-atelier-maison.php';

function yusraah_setup() {
	load_theme_textdomain( 'yusraah', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 70,
		'width'       => 220,
		'flex-height' => true,
		'flex-width'  => true,
		'header-text' => array( 'site-title', 'site-description' ),
	) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/theme.css' );

	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	register_nav_menus( array(
		'primary'        => __( 'Main navigation', 'yusraah' ),
		'mobile'         => __( 'Mobile menu', 'yusraah' ),
		'categories'     => __( 'Product categories', 'yusraah' ),
		'footer'         => __( 'Footer navigation', 'yusraah' ),
		'footer-shop'    => __( 'Footer — Shop column', 'yusraah' ),
		'footer-help'    => __( 'Footer — Help column', 'yusraah' ),
		'footer-company' => __( 'Footer — Company column', 'yusraah' ),
	) );

	register_sidebar( array(
		'name'          => __( 'Shop Sidebar', 'yusraah' ),
		'id'            => 'shop-sidebar',
		'description'   => __( 'Widgets in this area will be shown on the shop page.', 'yusraah' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	add_image_size( 'yusraah-product-card', 760, 950, true );
	add_image_size( 'yusraah-editorial', 1200, 1450, true );

	// Use custom image size for product cards
	add_filter( 'single_product_archive_thumbnail_size', function() {
		return 'yusraah-product-card';
	} );

	// Add width and height attributes to product images to prevent layout shift
	add_filter( 'woocommerce_loop_product_thumbnail', function( $html, $product ) {
		$image_size = apply_filters( 'single_product_archive_thumbnail_size', 'woocommerce_thumbnail' );
		$image_id = $product->get_image_id();

		if ( ! $image_id ) {
			return $html;
		}

		$image = wp_get_attachment_image_src( $image_id, $image_size );
		if ( ! $image ) {
			return $html;
		}

		$width = $image[1];
		$height = $image[2];

		// Ensure alt text is present for accessibility
		$alt_text = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
		if ( empty( $alt_text ) ) {
			$alt_text = $product->get_name();
		}

		// Add width, height, and alt attributes to the img tag
		$html = preg_replace(
			'/<img([^>]*?)>/i',
			'<img$1 width="' . esc_attr( $width ) . '" height="' . esc_attr( $height ) . '" alt="' . esc_attr( $alt_text ) . '" loading="lazy">',
			$html
		);

		return $html;
	}, 10, 2 );
}
add_action( 'after_setup_theme', 'yusraah_setup' );

function yusraah_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'yusraah_content_width', 1200 );
}
add_action( 'after_setup_theme', 'yusraah_content_width', 0 );

function yusraah_assets() {
	$style_path = get_template_directory() . '/assets/css/theme.css';
	$script_path = get_template_directory() . '/assets/js/theme.js';
	wp_enqueue_style(
		'yusraah-style',
		get_template_directory_uri() . '/assets/css/theme.css',
		array(),
		file_exists( $style_path ) ? filemtime( $style_path ) : YUSRAAH_VERSION
	);
	wp_enqueue_script(
		'yusraah-script',
		get_template_directory_uri() . '/assets/js/theme.js',
		array(),
		file_exists( $script_path ) ? filemtime( $script_path ) : YUSRAAH_VERSION,
		true
	);
	wp_localize_script(
		'yusraah-script',
		'yusraahSearch',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'yusraah_product_search' ),
			'strings' => array(
				'searching'    => __( 'Searching products…', 'yusraah' ),
				'noResults'    => __( 'No products found.', 'yusraah' ),
				'failed'       => __( 'Product search is temporarily unavailable.', 'yusraah' ),
				'resultsFound' => __( '%d product suggestions available.', 'yusraah' ),
			),
		)
	);
	wp_localize_script(
		'yusraah-script',
		'yusraahStickyCart',
		array(
			'strings' => array(
				'available'     => __( 'Quick add to cart is available.', 'yusraah' ),
				'chooseOptions' => __( 'Choose product options before adding this item.', 'yusraah' ),
				'unavailable'   => __( 'This product option is unavailable.', 'yusraah' ),
				'adding'        => __( 'Adding…', 'yusraah' ),
				'addFailed'     => __( 'The item could not be added. Please try again.', 'yusraah' ),
			),
		)
	);
	wp_localize_script(
		'yusraah-script',
		'yusraahCheckout',
		array(
			'strings' => array(
				'required' => __( 'Please complete the %s field.', 'yusraah' ),
				'email'    => __( 'Enter a valid email address.', 'yusraah' ),
				'invalid'  => __( 'Please check this field and try again.', 'yusraah' ),
				'phone'    => __( 'Enter a valid Bangladeshi mobile number, e.g. 01712345678.', 'yusraah' ),
			),
		)
	);
	wp_localize_script(
		'yusraah-script',
		'yusraahQuickView',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'yusraah_product_search' ),
			'strings' => array(
				'loading' => __( 'Loading...', 'yusraah' ),
				'error'   => __( 'Could not load product. Please try again.', 'yusraah' ),
			),
		)
	);
	wp_localize_script(
		'yusraah-script',
		'yusraahWishlist',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( YUSRAAH_WISHLIST_NONCE ),
			'strings' => array(
				'add'          => __( 'Add to wishlist', 'yusraah' ),
				'remove'       => __( 'Remove from wishlist', 'yusraah' ),
				'failed'       => __( 'Your wishlist could not be updated. Please try again.', 'yusraah' ),
				'adding'       => __( 'Adding…', 'yusraah' ),
				'addAllFailed' => __( 'The items could not be added to your basket. Please try again.', 'yusraah' ),
			),
		)
	);

	if ( class_exists( 'WooCommerce' ) && get_theme_mod( 'yusraah_cart_toast_enabled', true ) ) {
		$toast_script_path = get_template_directory() . '/assets/js/cart-toast.js';
		$toast_config      = array(
			'enabled'      => true,
			'action'       => yusraah_sanitize_cart_toast_action( get_theme_mod( 'yusraah_cart_toast_action', 'toast' ) ),
			'position'     => yusraah_sanitize_cart_toast_position( get_theme_mod( 'yusraah_cart_toast_position', 'top-right' ) ),
			'duration'     => yusraah_sanitize_cart_toast_duration( get_theme_mod( 'yusraah_cart_toast_duration', 5 ) ),
			'showCheckout' => (bool) get_theme_mod( 'yusraah_cart_toast_checkout', true ),
			'cartUrl'      => wc_get_cart_url(),
			'checkoutUrl'  => wc_get_checkout_url(),
			'placeholder'  => wc_placeholder_img_src( 'thumbnail' ),
			'strings'      => array(
				/* translators: %s: product name */
				'added'        => __( '%s added to cart', 'yusraah' ),
				/* translators: %d: number of added products */
				'addedMany'    => __( 'Added %d items', 'yusraah' ),
				'viewCart'     => __( 'View cart', 'yusraah' ),
				'checkout'     => __( 'Checkout', 'yusraah' ),
				'close'        => __( 'Dismiss notification', 'yusraah' ),
				'notification'  => __( 'Cart notification', 'yusraah' ),
				'failed'        => __( 'Could not add item to basket.', 'yusraah' ),
				'chooseOptions' => __( 'Please choose product options before adding to cart.', 'yusraah' ),
			),
		);
		wp_enqueue_script(
			'yusraah-cart-toast',
			get_template_directory_uri() . '/assets/js/cart-toast.js',
			array( 'jquery' ),
			file_exists( $toast_script_path ) ? filemtime( $toast_script_path ) : YUSRAAH_VERSION,
			true
		);
		wp_localize_script( 'yusraah-cart-toast', 'yusraahCartToast', $toast_config );
	}
}
add_action( 'wp_enqueue_scripts', 'yusraah_assets' );

/**
 * Load the homepage newsletter presentation only where its section is shown.
 */
function yusraah_home_newsletter_assets() {
	if ( ! is_front_page() || ! get_theme_mod( 'yusraah_home_newsletter_show', true ) ) {
		return;
	}

	$style_path = get_template_directory() . '/assets/css/home-newsletter.css';
	wp_enqueue_style(
		'yusraah-home-newsletter',
		get_template_directory_uri() . '/assets/css/home-newsletter.css',
		array( 'yusraah-style' ),
		file_exists( $style_path ) ? filemtime( $style_path ) : YUSRAAH_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'yusraah_home_newsletter_assets', 20 );

/**
 * Account styles and scripts, loaded only on the WooCommerce account pages.
 */
function yusraah_account_assets() {
	if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
		return;
	}

	$style_path  = get_template_directory() . '/assets/css/account.css';
	$script_path = get_template_directory() . '/assets/js/account.js';

	wp_enqueue_style(
		'yusraah-account',
		get_template_directory_uri() . '/assets/css/account.css',
		array( 'yusraah-style' ),
		file_exists( $style_path ) ? filemtime( $style_path ) : YUSRAAH_VERSION
	);

	wp_enqueue_script(
		'yusraah-account',
		get_template_directory_uri() . '/assets/js/account.js',
		array(),
		file_exists( $script_path ) ? filemtime( $script_path ) : YUSRAAH_VERSION,
		true
	);

	wp_localize_script(
		'yusraah-account',
		'yusraahAccount',
		array(
			'strings' => array(
				'show'         => __( 'Show', 'yusraah' ),
				'hide'         => __( 'Hide', 'yusraah' ),
				'showPassword' => __( 'Show password', 'yusraah' ),
				'hidePassword' => __( 'Hide password', 'yusraah' ),
				'required'     => __( 'Please complete the %s field.', 'yusraah' ),
				'email'        => __( 'Enter a valid email address.', 'yusraah' ),
				'invalid'      => __( 'Please check this field and try again.', 'yusraah' ),
				'phone'        => __( 'Enter a valid Bangladeshi mobile number, e.g. 01712345678.', 'yusraah' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'yusraah_account_assets', 25 );

/**
 * Single product scripts, loaded only on product pages.
 *
 * The buy box enhancer (quantity stepper, variation swatches, Buy Now state
 * and the in-place price swap) is only needed on the product page, so it is
 * kept off the rest of the site.
 */
function yusraah_product_assets() {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}

	$script_path = get_template_directory() . '/assets/js/product.js';

	wp_enqueue_script( 'wc-single-product' );
	wp_enqueue_script(
		'yusraah-product',
		get_template_directory_uri() . '/assets/js/product.js',
		array( 'jquery', 'wc-single-product' ),
		file_exists( $script_path ) ? filemtime( $script_path ) : YUSRAAH_VERSION,
		true
	);

	wp_localize_script(
		'yusraah-product',
		'yusraahProduct',
		array(
			'strings' => array(
				'shareNative'     => __( 'Share this product', 'yusraah' ),
				'shareFailed'     => __( 'Sharing is not available on this device. Please copy the link instead.', 'yusraah' ),
				'galleryPrevious' => __( 'Previous image', 'yusraah' ),
				'galleryNext'     => __( 'Next image', 'yusraah' ),
				'galleryZoom'     => __( 'Zoom image', 'yusraah' ),
				/* translators: %s: discount percentage, e.g. "20%". */
				'off'              => __( '%s off', 'yusraah' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'yusraah_product_assets', 26 );

/**
 * Preload custom logo if it's an SVG for performance.
 */
function yusraah_preload_logo() {
	$custom_logo_id = get_theme_mod( 'custom_logo' );
	if ( ! $custom_logo_id ) {
		return;
	}

	$logo_url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
	if ( ! $logo_url ) {
		return;
	}

	// Check if it's an SVG
	$path = get_attached_file( $custom_logo_id );
	if ( $path && pathinfo( $path, PATHINFO_EXTENSION ) === 'svg' ) {
		echo '<link rel="preload" href="' . esc_url( $logo_url ) . '" as="image">';
	}
}
add_action( 'wp_head', 'yusraah_preload_logo', 1 );

/**
 * Return up to six WooCommerce products matching a title or product category.
 */
function yusraah_ajax_product_search() {
	if ( ! check_ajax_referer( 'yusraah_product_search', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Invalid search request.', 'yusraah' ) ), 403 );
	}

	if ( ! function_exists( 'wc_get_products' ) ) {
		wp_send_json_error( array( 'message' => __( 'Product search is unavailable.', 'yusraah' ) ), 503 );
	}

	$raw_search_term = isset( $_POST['term'] ) ? wp_unslash( $_POST['term'] ) : '';
	if ( ! is_string( $raw_search_term ) ) {
		$raw_search_term = '';
	}
	$search_term = sanitize_text_field( $raw_search_term );
	$search_term = trim( wp_html_excerpt( $search_term, 80, '' ) );

	if ( strlen( $search_term ) < 2 ) {
		wp_send_json_success( array( 'results' => array() ) );
	}

	$title_products = wc_get_products(
		array(
			'status'  => 'publish',
			'limit'   => 6,
			's'       => $search_term,
			'orderby' => 'title',
			'order'   => 'ASC',
			'return'  => 'objects',
		)
	);

	$categories = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => true,
			'name__like' => $search_term,
			'number'     => 6,
			'fields'     => 'slugs',
		)
	);

	$category_products = array();
	if ( ! is_wp_error( $categories ) && ! empty( $categories ) ) {
		$category_products = wc_get_products(
			array(
				'status'   => 'publish',
				'limit'    => 6,
				'category' => array_map( 'sanitize_title', $categories ),
				'orderby'  => 'title',
				'order'    => 'ASC',
				'return'   => 'objects',
			)
		);
	}

	$results = array();
	$seen    = array();
	foreach ( array_merge( $title_products, $category_products ) as $product ) {
		if ( ! $product instanceof WC_Product || ! $product->is_visible() ) {
			continue;
		}

		$product_id = $product->get_id();
		if ( isset( $seen[ $product_id ] ) ) {
			continue;
		}
		$seen[ $product_id ] = true;

		$image_url = wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' );
		if ( ! $image_url ) {
			$image_url = wc_placeholder_img_src( 'woocommerce_thumbnail' );
		}

		$price_text = wp_strip_all_tags( $product->get_price_html() );
		$price_text = html_entity_decode( $price_text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

		$results[] = array(
			'name'  => wp_strip_all_tags( $product->get_name() ),
			'url'   => esc_url_raw( $product->get_permalink() ),
			'image' => esc_url_raw( $image_url ),
			'price' => $price_text,
		);

		if ( count( $results ) >= 6 ) {
			break;
		}
	}

	wp_send_json_success( array( 'results' => $results ) );
}
add_action( 'wp_ajax_yusraah_product_search', 'yusraah_ajax_product_search' );
add_action( 'wp_ajax_nopriv_yusraah_product_search', 'yusraah_ajax_product_search' );

function yusraah_cart_drawer_assets() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	wp_enqueue_script( 'wc-cart-fragments' );
	if ( is_product() ) {
		wp_enqueue_script( 'wc-add-to-cart' );
	}

	$toast_enabled = (bool) get_theme_mod( 'yusraah_cart_toast_enabled', true );
	$toast_config  = array(
		'enabled'      => $toast_enabled,
		'action'       => yusraah_sanitize_cart_toast_action( get_theme_mod( 'yusraah_cart_toast_action', 'toast' ) ),
		'position'     => yusraah_sanitize_cart_toast_position( get_theme_mod( 'yusraah_cart_toast_position', 'top-right' ) ),
		'duration'     => yusraah_sanitize_cart_toast_duration( get_theme_mod( 'yusraah_cart_toast_duration', 5 ) ),
		'showCheckout' => (bool) get_theme_mod( 'yusraah_cart_toast_checkout', true ),
		'cartUrl'      => wc_get_cart_url(),
		'checkoutUrl'  => wc_get_checkout_url(),
		'placeholder'  => wc_placeholder_img_src( 'thumbnail' ),
		'strings'      => array(
			/* translators: %s: product name */
			'added'        => __( '%s added to cart', 'yusraah' ),
			/* translators: %d: number of added products */
			'addedMany'    => __( 'Added %d items', 'yusraah' ),
			'viewCart'     => __( 'View cart', 'yusraah' ),
			'checkout'     => __( 'Checkout', 'yusraah' ),
			'close'         => __( 'Dismiss notification', 'yusraah' ),
			'notification'  => __( 'Cart notification', 'yusraah' ),
			'failed'        => __( 'Could not add item to basket.', 'yusraah' ),
			'chooseOptions' => __( 'Please choose product options before adding to cart.', 'yusraah' ),
		),
	);

	$script_path = get_template_directory() . '/assets/js/cart-drawer.js';
	wp_enqueue_script(
		'yusraah-cart-drawer',
		get_template_directory_uri() . '/assets/js/cart-drawer.js',
		array( 'jquery' ),
		file_exists( $script_path ) ? filemtime( $script_path ) : YUSRAAH_VERSION,
		true
	);
	wp_localize_script( 'yusraah-cart-drawer', 'yusraahCartToast', $toast_config );

	if ( $toast_enabled ) {
		$toast_script_path = get_template_directory() . '/assets/js/cart-toast.js';
		wp_enqueue_script(
			'yusraah-cart-toast',
			get_template_directory_uri() . '/assets/js/cart-toast.js',
			array( 'jquery' ),
			file_exists( $toast_script_path ) ? filemtime( $toast_script_path ) : YUSRAAH_VERSION,
			true
		);
		wp_localize_script( 'yusraah-cart-toast', 'yusraahCartToast', $toast_config );
	}

	$stepper_path = get_template_directory() . '/assets/js/quantity-stepper.js';

	wp_enqueue_script(
		'yusraah-quantity-stepper',
		get_template_directory_uri() . '/assets/js/quantity-stepper.js',
		array( 'jquery' ),
		file_exists( $stepper_path ) ? filemtime( $stepper_path ) : YUSRAAH_VERSION,
		true
	);
	wp_localize_script(
		'yusraah-quantity-stepper',
		'yusraahQtyStepper',
		array(
			'endpoint' => WC_AJAX::get_endpoint( 'yusraah_set_cart_quantity' ),
			'strings'  => array(
				/* translators: 1: product name, 2: quantity */
				'inBasket' => __( '%1$s: %2$s in basket', 'yusraah' ),
				/* translators: %s: product name */
				'removed'  => __( '%s removed from basket', 'yusraah' ),
				'failed'   => __( 'The basket could not be updated. Please try again.', 'yusraah' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'yusraah_cart_drawer_assets', 20 );

function yusraah_render_cart_drawer() {
	if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'woocommerce_mini_cart' ) ) {
		return;
	}
	$shop_url = wc_get_page_permalink( 'shop' );
	?>
	<div id="yusraah-cart-drawer" class="cart-drawer" aria-hidden="true" hidden>
		<button class="cart-drawer__backdrop" type="button" data-cart-drawer-close aria-label="<?php esc_attr_e( 'Close basket', 'yusraah' ); ?>"></button>
		<section class="cart-drawer__panel" role="dialog" aria-modal="true" aria-labelledby="yusraah-cart-drawer-title" tabindex="-1">
			<header class="cart-drawer__header">
				<div>
					<p class="eyebrow"><?php esc_html_e( 'Your order', 'yusraah' ); ?></p>
					<h2 id="yusraah-cart-drawer-title"><?php esc_html_e( 'Your basket', 'yusraah' ); ?></h2>
				</div>
				<button class="icon-button cart-drawer__close" type="button" data-cart-drawer-close aria-label="<?php esc_attr_e( 'Close basket', 'yusraah' ); ?>"><?php echo yusraah_icon( 'close' ); ?></button>
			</header>
			<div class="cart-drawer__content" aria-live="polite" aria-relevant="additions text">
				<?php yusraah_free_delivery_bar(); ?>
				<div class="widget_shopping_cart_content"><?php woocommerce_mini_cart(); ?></div>
			</div>
			<a class="cart-drawer__continue" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Continue shopping', 'yusraah' ); ?> <?php echo yusraah_icon( 'arrow' ); ?></a>
		</section>
	</div>
	<?php if ( get_theme_mod( 'yusraah_cart_toast_enabled', true ) ) : ?>
		<div
			id="yusraah-cart-toast"
			class="yusraah-cart-toast-container"
			role="status"
			aria-live="polite"
			aria-relevant="additions text"
			aria-atomic="false"
			hidden
		></div>
	<?php endif; ?>
	<?php
}
// Before wp_print_footer_scripts (priority 20) so cart-drawer.js finds the markup.
add_action( 'wp_footer', 'yusraah_render_cart_drawer', 5 );

/**
 * Render floating toast container in footer.
 */
function yusraah_render_cart_toast() {
	if ( ! class_exists( 'WooCommerce' ) || ! get_theme_mod( 'yusraah_cart_toast_enabled', true ) ) {
		return;
	}
	?>
	<div
		id="yusraah-cart-toast"
		class="yusraah-cart-toast-container"
		role="status"
		aria-live="polite"
		aria-relevant="additions text"
		aria-atomic="false"
		hidden
	></div>
	<?php
}
add_action( 'wp_footer', 'yusraah_render_cart_toast', 2 );

/**
 * Render a mobile sticky purchase bar alongside the standard product form.
 */
function yusraah_render_sticky_product_cart() {
	if ( ! is_product() ) {
		return;
	}

	global $product;
	if (
		! $product instanceof WC_Product ||
		! $product->is_type( array( 'simple', 'variable' ) ) ||
		! $product->is_purchasable()
	) {
		return;
	}

	$quantity_args       = wc_get_quantity_input_args( array(), $product );
	$min_quantity        = isset( $quantity_args['min_value'] ) ? $quantity_args['min_value'] : 1;
	$max_quantity        = isset( $quantity_args['max_value'] ) ? $quantity_args['max_value'] : '';
	$quantity_step       = isset( $quantity_args['step'] ) ? $quantity_args['step'] : 1;
	$quantity_value      = isset( $quantity_args['input_value'] ) ? $quantity_args['input_value'] : 1;
	$sold_individually   = $product->is_sold_individually();

	if ( $sold_individually ) {
		$min_quantity   = 1;
		$max_quantity   = 1;
		$quantity_step  = 1;
		$quantity_value = 1;
	}

	$price_html = $product->get_price_html();
	?>
	<aside
		class="sticky-product-cart"
		data-sticky-product-cart
		role="region"
		aria-label="<?php esc_attr_e( 'Quick add to cart', 'yusraah' ); ?>"
		aria-hidden="true"
		inert
	>
		<div class="sticky-product-cart__product">
			<p class="sticky-product-cart__name"><?php echo esc_html( $product->get_name() ); ?></p>
			<div class="sticky-product-cart__price">
				<span class="screen-reader-text"><?php esc_html_e( 'Price', 'yusraah' ); ?></span>
				<span data-sticky-product-price><?php echo wp_kses_post( $price_html ); ?></span>
			</div>
		</div>
		<div class="sticky-product-cart__quantity">
			<label class="screen-reader-text" for="yusraah-sticky-product-quantity"><?php esc_html_e( 'Quantity', 'yusraah' ); ?></label>
			<input
				id="yusraah-sticky-product-quantity"
				type="number"
				inputmode="decimal"
				value="<?php echo esc_attr( $quantity_value ); ?>"
				min="<?php echo esc_attr( $min_quantity ); ?>"
				<?php if ( is_numeric( $max_quantity ) ) : ?>
					max="<?php echo esc_attr( $max_quantity ); ?>"
				<?php endif; ?>
				step="<?php echo esc_attr( $quantity_step ); ?>"
				aria-label="<?php esc_attr_e( 'Quantity', 'yusraah' ); ?>"
				data-sticky-quantity
				<?php if ( $sold_individually ) : ?>
					readonly aria-readonly="true"
				<?php endif; ?>
			>
		</div>
		<button
			class="sticky-product-cart__button"
			type="button"
			data-sticky-add-to-cart
		><?php esc_html_e( 'Add to cart', 'yusraah' ); ?></button>
		<p
			class="screen-reader-text"
			data-sticky-cart-status
			role="status"
			aria-live="polite"
			aria-atomic="true"
		></p>
	</aside>
	<?php
}
add_action( 'woocommerce_after_add_to_cart_form', 'yusraah_render_sticky_product_cart', 20 );

/**
 * Enable guest checkout on the frontend while leaving the admin setting editable.
 *
 * @param mixed $pre_option The pre-filtered option value.
 * @return mixed
 */
function yusraah_guest_checkout_option( $pre_option ) {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return $pre_option;
	}

	return 'yes';
}
add_filter( 'pre_option_woocommerce_enable_guest_checkout', 'yusraah_guest_checkout_option' );
add_filter( 'woocommerce_checkout_registration_required', '__return_false' );

/**
 * Offer account creation on the My Account page.
 *
 * Same pattern as the guest-checkout filter above: the frontend default is
 * "yes" so a new visitor can sign up and use the account area, while the real
 * WooCommerce setting stays untouched and editable in the admin screen.
 *
 * @param mixed $pre_option The pre-filtered option value.
 * @return mixed
 */
function yusraah_account_registration_option( $pre_option ) {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return $pre_option;
	}

	return 'yes';
}
add_filter( 'pre_option_woocommerce_enable_myaccount_registration', 'yusraah_account_registration_option' );

/**
 * Remove nonessential company fields at checkout (address line 2 is the Landmark field).
 *
 * @param array $fields Checkout fields.
 * @return array
 */
function yusraah_simplify_checkout_fields( $fields ) {
	$removed_fields = array(
		'billing_company',
		'shipping_company',
	);

	foreach ( $removed_fields as $field_key ) {
		foreach ( array( 'billing', 'shipping' ) as $field_group ) {
			if ( isset( $fields[ $field_group ][ $field_key ] ) ) {
				unset( $fields[ $field_group ][ $field_key ] );
			}
		}
	}

	return $fields;
}
add_filter( 'woocommerce_checkout_fields', 'yusraah_simplify_checkout_fields' );

/**
 * Clarify that WooCommerce's shipping row is shown before the payment choices.
 */
function yusraah_checkout_delivery_note() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart || ! WC()->cart->needs_shipping() ) {
		return;
	}
	?>
	<tr class="checkout-delivery-note">
		<td colspan="2"><?php esc_html_e( 'Delivery options and any fee are shown above the payment choices.', 'yusraah' ); ?></td>
	</tr>
	<?php
}
add_action( 'woocommerce_review_order_after_shipping', 'yusraah_checkout_delivery_note', 10 );

/**
 * Add gateway-neutral reassurance near the native place-order button.
 */
function yusraah_checkout_trust_badges() {
	?>
	<ul class="checkout-trust-badges" aria-label="<?php esc_attr_e( 'Checkout information', 'yusraah' ); ?>">
		<li><span aria-hidden="true">✓</span><?php esc_html_e( 'Secure checkout', 'yusraah' ); ?></li>
		<li><span aria-hidden="true">✓</span><?php esc_html_e( 'Payment handled by your selected method', 'yusraah' ); ?></li>
		<li><span aria-hidden="true">✓</span><?php esc_html_e( 'Delivery fee shown before payment', 'yusraah' ); ?></li>
	</ul>
	<?php
}
add_action( 'woocommerce_review_order_after_submit', 'yusraah_checkout_trust_badges', 10 );

/**
 * Two-letter monogram derived from the site name (not a hard-coded brand mark).
 *
 * @return string[] { 0: first letter, 1: second letter or empty }.
 */
function yusraah_brand_monogram() {
	$name = trim( wp_strip_all_tags( (string) get_bloginfo( 'name' ) ) );
	if ( '' === $name ) {
		$name = 'Yusraah';
	}

	$parts  = preg_split( '/\s+/', $name );
	$first  = function_exists( 'mb_substr' ) ? mb_substr( $parts[0], 0, 1 ) : substr( $parts[0], 0, 1 );
	$second = '';
	if ( ! empty( $parts[1] ) ) {
		$second = function_exists( 'mb_substr' ) ? mb_substr( $parts[1], 0, 1 ) : substr( $parts[1], 0, 1 );
	} elseif ( function_exists( 'mb_strlen' ) ? mb_strlen( $parts[0] ) > 1 : strlen( $parts[0] ) > 1 ) {
		$second = function_exists( 'mb_substr' ) ? mb_substr( $parts[0], 1, 1 ) : substr( $parts[0], 1, 1 );
	}

	return array( $first, $second );
}

/**
 * Markup for the story-section signature: first letter plus an accented second letter.
 *
 * @return string
 */
function yusraah_brand_monogram_html() {
	$letters = yusraah_brand_monogram();
	$html    = esc_html( $letters[0] );
	if ( '' !== $letters[1] ) {
		$html .= '<span>' . esc_html( $letters[1] ) . '</span>';
	}

	return $html;
}

/**
 * Return a small, decorative inline icon from the theme's fixed icon set.
 *
 * @param string $name Icon name.
 * @return string
 */
function yusraah_icon( $name ) {
	$icons = array(
		'search' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.6"/><path d="m16 16 4.2 4.2"/></svg>',
		'user'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.4"/><path d="M5.5 20c.4-3.5 2.7-5.5 6.5-5.5s6.1 2 6.5 5.5"/></svg>',
		'bag'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 8.5h15l-1 12h-13z"/><path d="M8.5 9V6a3.5 3.5 0 0 1 7 0v3"/></svg>',
		'heart'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.3 8.7c0 4.2-8.3 10-8.3 10s-8.3-5.8-8.3-10a4.4 4.4 0 0 1 8.3-1.9 4.4 4.4 0 0 1 8.3 1.9Z"/></svg>',
		'menu'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
		'arrow'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M12 5l7 7-7 7"/></svg>',
		'close'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>',
		'grid'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/></svg>',
		'box'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8.5 12 4l8 4.5v7L12 20l-8-4.5z"/><path d="m4 8.5 8 4.5 8-4.5M12 13v7"/></svg>',
		'pin'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.5s6-5.4 6-9.7a6 6 0 1 0-12 0c0 4.3 6 9.7 6 9.7Z"/><circle cx="12" cy="10.6" r="2.2"/></svg>',
		'card'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="6" width="17" height="12" rx="2"/><path d="M3.5 10h17"/></svg>',
		'logout' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 5H18a1.5 1.5 0 0 1 1.5 1.5v11A1.5 1.5 0 0 1 18 19h-3.5"/><path d="M8.5 8.5 12 12l-3.5 3.5M12 12H4"/></svg>',
	);

	return isset( $icons[ $name ] ) ? $icons[ $name ] : '';
}

function yusraah_cart_count() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return 0;
	}
	return WC()->cart->get_cart_contents_count();
}

function yusraah_cart_count_fragment( $fragments ) {
	ob_start();
	?>
	<span class="header-cart__count" data-cart-count><?php echo esc_html( yusraah_cart_count() ); ?></span>
	<?php
	$fragments['[data-cart-count]'] = ob_get_clean();
	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'yusraah_cart_count_fragment' );

function yusraah_shop_collection_filters() {
	if ( ! ( is_shop() || is_product_taxonomy() ) ) {
		return;
	}

	$terms = get_terms( array(
		'taxonomy'   => 'product_cat',
		'hide_empty' => true,
	) );
	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return;
	}

	$current_term = get_queried_object();
	$shop_url     = wc_get_page_permalink( 'shop' );
	?>
	<nav class="collection-filters" aria-label="<?php esc_attr_e( 'Shop by collection', 'yusraah' ); ?>">
		<a class="collection-filter<?php echo is_shop() ? ' is-active' : ''; ?>" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'All pieces', 'yusraah' ); ?></a>
		<?php foreach ( $terms as $term ) : ?>
			<a class="collection-filter<?php echo ( isset( $current_term->term_id ) && (int) $current_term->term_id === (int) $term->term_id ) ? ' is-active' : ''; ?>" href="<?php echo esc_url( get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a>
		<?php endforeach; ?>
	</nav>
	<?php
}
add_action( 'woocommerce_before_shop_loop', 'yusraah_shop_collection_filters', 5 );

/**
 * Allow data attributes and metadata elements through WooCommerce notice sanitization.
 *
 * @param array $allowed_tags Allowed HTML elements.
 * @return array
 */
function yusraah_allow_notice_data_attr( $allowed_tags ) {
	if ( ! isset( $allowed_tags['span'] ) || ! is_array( $allowed_tags['span'] ) ) {
		$allowed_tags['span'] = array();
	}
	$allowed_tags['span']['data-products'] = true;
	$allowed_tags['span']['class']         = true;
	$allowed_tags['span']['hidden']        = true;
	return $allowed_tags;
}
add_filter( 'woocommerce_kses_notice_allowed_tags', 'yusraah_allow_notice_data_attr' );

/**
 * Attach product metadata to native add-to-cart notices for JS enhancement.
 *
 * The original WooCommerce notice remains intact for no-JS users and is
 * enhanced into a floating toast only when JavaScript executes.
 *
 * @param string $message  WooCommerce notice HTML.
 * @param mixed  $products Products added to the cart.
 * @return string
 */
function yusraah_cart_toast_notice_metadata( $message, $products = null ) {
	if ( ! get_theme_mod( 'yusraah_cart_toast_enabled', true ) ) {
		return $message;
	}

	$product_list = is_array( $products ) ? $products : ( $products ? array( $products ) : array() );
	$items        = array();

	foreach ( $product_list as $key => $value ) {
		$product = false;

		if ( $value instanceof WC_Product ) {
			$product = $value;
		} elseif ( is_numeric( $value ) && absint( $value ) > 0 && ( ! is_numeric( $key ) || $key === 0 ) ) {
			$product = wc_get_product( absint( $value ) );
		} elseif ( is_numeric( $key ) && absint( $key ) > 0 ) {
			$product = wc_get_product( absint( $key ) );
		}

		if ( ! $product instanceof WC_Product && is_product() ) {
			global $product;
		}

		if ( $product instanceof WC_Product ) {
			$image_id = $product->get_image_id();
			$image    = $image_id ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : '';
			$items[]  = array(
				'name'  => $product->get_name(),
				'image' => $image ? $image : wc_placeholder_img_src( 'thumbnail' ),
			);
		}
	}

	$data_attr = ! empty( $items ) ? wp_json_encode( $items ) : '[]';

	return $message . '<span class="yusraah-cart-toast__notice-data" data-products="' . esc_attr( $data_attr ) . '" hidden></span>';
}
add_filter( 'woocommerce_add_to_cart_message_html', 'yusraah_cart_toast_notice_metadata', 10, 2 );

/**
 * Filter WooCommerce loop add to cart button text.
 *
 * Applies globally to all product loops (shop, category, search, related, shortcodes).
 * - Simple products: 'Buy Now' (or customizer value), adds to cart via AJAX side cart
 * - Variable products: Opens product page to select variation first
 * - Out of stock: 'Sold Out'
 *
 * @param string     $text    Default button text.
 * @param WC_Product $product WooCommerce product object.
 * @return string
 */
function yusraah_custom_add_to_cart_text( $text, $product ) {
	if ( ! $product instanceof WC_Product ) {
		return $text;
	}

	if ( ! $product->is_in_stock() ) {
		$sold_out_text = get_theme_mod( 'yusraah_sold_out_text', __( 'Sold Out', 'yusraah' ) );
		return ! empty( $sold_out_text ) ? esc_html( $sold_out_text ) : __( 'Sold Out', 'yusraah' );
	}

	if ( $product->is_type( 'variable' ) ) {
		$variable_text = get_theme_mod( 'yusraah_buy_now_variable_text', __( 'Buy Now', 'yusraah' ) );
		return ! empty( $variable_text ) ? esc_html( $variable_text ) : __( 'Buy Now', 'yusraah' );
	}

	if ( $product->is_type( 'simple' ) ) {
		$buy_now_text = get_theme_mod( 'yusraah_buy_now_text', __( 'Buy Now', 'yusraah' ) );
		return ! empty( $buy_now_text ) ? esc_html( $buy_now_text ) : __( 'Buy Now', 'yusraah' );
	}

	return $text;
}
add_filter( 'woocommerce_product_add_to_cart_text', 'yusraah_custom_add_to_cart_text', 20, 2 );

/**
 * Format variable product price in loops to clean 'From ৳X' format on one line.
 *
 * @param string     $price   Original price HTML.
 * @param WC_Product $product Product instance.
 * @return string
 */
function yusraah_variable_price_format( $price, $product ) {
	if ( $product instanceof WC_Product && $product->is_type( 'variable' ) && ! is_product() ) {
		$min_price = $product->get_variation_price( 'min', true );
		if ( '' !== $min_price && false !== $min_price ) {
			/* translators: %s: formatted minimum price */
			return '<span class="price"><span class="price-from">' . sprintf( esc_html__( 'From %s', 'yusraah' ), wc_price( $min_price ) ) . '</span></span>';
		}
	}
	return $price;
}
add_filter( 'woocommerce_get_price_html', 'yusraah_variable_price_format', 20, 2 );

/**
 * Replace WooCommerce core's round olive "Sale!" badge with the theme's
 * shared rectangular badge, so a single badge style is used site-wide.
 *
 * @param string     $html    Original sale flash HTML.
 * @param WP_Post    $post    Product post object.
 * @param WC_Product $product Product instance.
 * @return string
 */
function yusraah_sale_flash_badge( $html, $post, $product ) {
	if ( ! $product instanceof WC_Product ) {
		return $html;
	}

	return '<span class="onsale yusraah-badge yusraah-badge--sale">' . esc_html__( 'Sale', 'yusraah' ) . '</span>';
}
add_filter( 'woocommerce_sale_flash', 'yusraah_sale_flash_badge', 10, 3 );

function yusraah_customize_register( $wp_customize ) {
	$wp_customize->add_section( 'yusraah_homepage', array(
		'title'       => __( 'Yusraah homepage', 'yusraah' ),
		'description' => __( 'Personalize the announcement bar and editorial homepage imagery.', 'yusraah' ),
		'priority'    => 35,
	) );

	$settings = array(
		'announcement' => array(
			'label'   => __( 'Announcement bar text', 'yusraah' ),
			'default' => __( 'Complimentary shipping on orders over $250', 'yusraah' ),
			'type'    => 'text',
		),
		'hero_image' => array(
			'label'   => __( 'Hero image URL', 'yusraah' ),
			'default' => 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1800&q=88',
			'type'    => 'url',
		),
		'story_image' => array(
			'label'   => __( 'Story image URL', 'yusraah' ),
			'default' => 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=1200&q=85',
			'type'    => 'url',
		),
		'hero_headline' => array(
			'label'   => __( 'Hero headline', 'yusraah' ),
			'default' => __( 'Everyday Essentials for Modern Living', 'yusraah' ),
			'type'    => 'text',
		),
		'hero_subtext' => array(
			'label'   => __( 'Hero subtext', 'yusraah' ),
			'default' => __( 'Quality products delivered to your doorstep. Fast, reliable, and convenient.', 'yusraah' ),
			'type'    => 'textarea',
		),
		'hero_cta_text' => array(
			'label'   => __( 'Hero button text', 'yusraah' ),
			'default' => __( 'Shop now', 'yusraah' ),
			'type'    => 'text',
		),
	);

	$wp_customize->add_setting( 'yusraah_free_delivery_threshold', array(
		'default'           => 0,
		'sanitize_callback' => 'yusraah_sanitize_amount',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_free_delivery_threshold', array(
		'label'       => __( 'Free delivery minimum (৳)', 'yusraah' ),
		'description' => __( 'Leave at 0 to use the minimum order amount of the WooCommerce "Free shipping" method in the customer\'s shipping zone.', 'yusraah' ),
		'section'     => 'yusraah_homepage',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 0, 'step' => 1 ),
	) );

	foreach ( $settings as $key => $setting ) {
		$wp_customize->add_setting( 'yusraah_' . $key, array(
			'default'           => $setting['default'],
			'sanitize_callback' => 'text' === $setting['type'] || 'textarea' === $setting['type'] ? 'sanitize_text_field' : 'esc_url_raw',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( 'yusraah_' . $key, array(
			'label'   => $setting['label'],
			'section' => 'yusraah_homepage',
			'type'    => $setting['type'],
		) );
	}

	$newsletter_settings = array(
		'show' => array(
			'label'    => __( 'Show homepage newsletter section', 'yusraah' ),
			'default'  => true,
			'type'     => 'checkbox',
			'sanitize' => 'rest_sanitize_boolean',
		),
		'eyebrow' => array(
			'label'    => __( 'Newsletter eyebrow', 'yusraah' ),
			'default'  => __( 'Newsletter', 'yusraah' ),
			'type'     => 'text',
			'sanitize' => 'sanitize_text_field',
		),
		'title' => array(
			'label'    => __( 'Newsletter heading', 'yusraah' ),
			'default'  => __( 'Stay Updated', 'yusraah' ),
			'type'     => 'text',
			'sanitize' => 'sanitize_text_field',
		),
		'subtext' => array(
			'label'    => __( 'Newsletter supporting text', 'yusraah' ),
			'default'  => __( 'Thoughtful updates, new arrivals, and exclusive offers — delivered occasionally.', 'yusraah' ),
			'type'     => 'textarea',
			'sanitize' => 'sanitize_textarea_field',
		),
		'button' => array(
			'label'    => __( 'Newsletter button label', 'yusraah' ),
			'default'  => __( 'Subscribe', 'yusraah' ),
			'type'     => 'text',
			'sanitize' => 'sanitize_text_field',
		),
		'incentive' => array(
			'label'    => __( 'Newsletter incentive (optional)', 'yusraah' ),
			'default'  => '',
			'type'     => 'text',
			'sanitize' => 'sanitize_text_field',
		),
		'success' => array(
			'label'    => __( 'Newsletter success message', 'yusraah' ),
			'default'  => __( 'Thanks for subscribing! Please check your inbox to confirm.', 'yusraah' ),
			'type'     => 'text',
			'sanitize' => 'sanitize_text_field',
		),
		'benefits' => array(
			'label'    => __( 'Show newsletter benefit chips', 'yusraah' ),
			'default'  => true,
			'type'     => 'checkbox',
			'sanitize' => 'rest_sanitize_boolean',
		),
		'background' => array(
			'label'    => __( 'Newsletter background style', 'yusraah' ),
			'default'  => 'glow',
			'type'     => 'select',
			'sanitize' => 'sanitize_key',
			'choices'  => array(
				'glow'     => __( 'Soft radial glow', 'yusraah' ),
				'gradient' => __( 'Subtle gradient', 'yusraah' ),
				'solid'    => __( 'Solid dark green', 'yusraah' ),
			),
		),
		'consent' => array(
			'label'    => __( 'Require newsletter consent checkbox', 'yusraah' ),
			'default'  => false,
			'type'     => 'checkbox',
			'sanitize' => 'rest_sanitize_boolean',
		),
		'consent_text' => array(
			'label'    => __( 'Newsletter consent text', 'yusraah' ),
			'default'  => __( 'I agree to receive occasional email updates.', 'yusraah' ),
			'type'     => 'text',
			'sanitize' => 'sanitize_text_field',
		),
	);

	foreach ( $newsletter_settings as $key => $setting ) {
		$setting_id = 'yusraah_home_newsletter_' . $key;
		$wp_customize->add_setting( $setting_id, array(
			'default'           => $setting['default'],
			'sanitize_callback' => $setting['sanitize'],
			'transport'         => 'refresh',
		) );

		$control = array(
			'label'   => $setting['label'],
			'section' => 'yusraah_homepage',
			'type'    => $setting['type'],
		);
		if ( isset( $setting['choices'] ) ) {
			$control['choices'] = $setting['choices'];
		}
		$wp_customize->add_control( $setting_id, $control );
	}

	// Product card button text settings
	$wp_customize->add_setting( 'yusraah_buy_now_text', array(
		'default'           => __( 'Buy Now', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_buy_now_text', array(
		'label'       => __( 'Product card button text (Simple products)', 'yusraah' ),
		'description' => __( 'Applies to simple product cards in shop, archive, search, and slider loops.', 'yusraah' ),
		'section'     => 'yusraah_homepage',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_buy_now_variable_text', array(
		'default'           => __( 'Buy Now', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_buy_now_variable_text', array(
		'label'       => __( 'Product card button text (Variable products)', 'yusraah' ),
		'description' => __( 'Links to the product page so customer can select options before adding to cart.', 'yusraah' ),
		'section'     => 'yusraah_homepage',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_sold_out_text', array(
		'default'           => __( 'Sold Out', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_sold_out_text', array(
		'label'       => __( 'Product card button text (Out of stock)', 'yusraah' ),
		'section'     => 'yusraah_homepage',
		'type'        => 'text',
	) );

	// Trust bar settings
	$wp_customize->add_setting( 'yusraah_trust_bar_1', array(
		'default'           => __( 'Fast delivery', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_trust_bar_1', array(
		'label'   => __( 'Trust bar item 1', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_trust_bar_2', array(
		'default'           => __( 'Easy returns', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_trust_bar_2', array(
		'label'   => __( 'Trust bar item 2', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_trust_bar_3', array(
		'default'           => __( 'Secure payment', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_trust_bar_3', array(
		'label'   => __( 'Trust bar item 3', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_trust_bar_4', array(
		'default'           => __( 'Cash on delivery', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_trust_bar_4', array(
		'label'   => __( 'Trust bar item 4', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_trust_bar_5', array(
		'default'           => __( '24/7 support', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_trust_bar_5', array(
		'label'   => __( 'Trust bar item 5', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'text',
	) );

	$wp_customize->add_section( 'yusraah_product_page', array(
		'title'       => __( 'Yusraah product page', 'yusraah' ),
		'description' => __( 'Buy box button text, delivery notes and trust badges shown on single product pages.', 'yusraah' ),
		'priority'    => 36,
	) );

	// Buy box texts. Keys match the get_theme_mod() calls in inc/single-product.php.
	$product_settings = array(
		'yusraah_product_buy_now_text'  => array(
			'label'   => __( 'Buy Now button text', 'yusraah' ),
			'default' => __( 'Buy Now', 'yusraah' ),
		),
		'yusraah_product_delivery_text' => array(
			'label'   => __( 'Delivery note', 'yusraah' ),
			'default' => __( 'Delivery within 2–4 business days.', 'yusraah' ),
		),
		'yusraah_product_returns_text'  => array(
			'label'   => __( 'Returns note', 'yusraah' ),
			'default' => __( 'Free returns within 7 days of delivery.', 'yusraah' ),
		),
		'yusraah_product_trust_1'       => array(
			'label'   => __( 'Trust badge 1', 'yusraah' ),
			'default' => __( 'Fast delivery', 'yusraah' ),
		),
		'yusraah_product_trust_2'       => array(
			'label'   => __( 'Trust badge 2', 'yusraah' ),
			'default' => __( 'Easy returns', 'yusraah' ),
		),
		'yusraah_product_trust_3'       => array(
			'label'   => __( 'Trust badge 3', 'yusraah' ),
			'default' => __( 'Cash on delivery', 'yusraah' ),
		),
		'yusraah_product_trust_4'       => array(
			'label'   => __( 'Trust badge 4', 'yusraah' ),
			'default' => __( 'Secure payment', 'yusraah' ),
		),
	);

	foreach ( $product_settings as $key => $setting ) {
		$wp_customize->add_setting( $key, array(
			'default'           => $setting['default'],
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( $key, array(
			'label'   => $setting['label'],
			'section' => 'yusraah_product_page',
			'type'    => 'text',
		) );
	}

	$wp_customize->add_section( 'yusraah_footer', array(
		'title'       => __( 'Yusraah footer', 'yusraah' ),
		'description' => __( 'Footer settings and credits.', 'yusraah' ),
		'priority'    => 40,
	) );

	$wp_customize->add_setting( 'yusraah_show_author_credit', array(
		'default'           => true,
		'sanitize_callback' => 'rest_sanitize_boolean',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_show_author_credit', array(
		'label'       => __( 'Show theme author credit', 'yusraah' ),
		'description' => __( 'Display "Theme by Shafekul Abid" in the footer.', 'yusraah' ),
		'section'     => 'yusraah_footer',
		'type'        => 'checkbox',
	) );

	$wp_customize->add_setting( 'yusraah_show_category_nav', array(
		'default'           => true,
		'sanitize_callback' => 'rest_sanitize_boolean',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_show_category_nav', array(
		'label'       => __( 'Show category navigation', 'yusraah' ),
		'description' => __( 'Display the product categories navigation bar below the header.', 'yusraah' ),
		'section'     => 'yusraah_homepage',
		'type'        => 'checkbox',
	) );

	// Why choose us settings
	$wp_customize->add_setting( 'yusraah_why_choose_title', array(
		'default'           => __( 'Why Choose Us', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_why_choose_title', array(
		'label'   => __( 'Why choose us section title', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_why_item_1_title', array(
		'default'           => __( 'Quality Guaranteed', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_why_item_1_title', array(
		'label'   => __( 'Why choose item 1 title', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_why_item_1_desc', array(
		'default'           => __( 'We carefully select only the finest products for your daily needs.', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_why_item_1_desc', array(
		'label'   => __( 'Why choose item 1 description', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'textarea',
	) );

	$wp_customize->add_setting( 'yusraah_why_item_2_title', array(
		'default'           => __( 'Fast Delivery', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_why_item_2_title', array(
		'label'   => __( 'Why choose item 2 title', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_why_item_2_desc', array(
		'default'           => __( 'Get your essentials delivered to your doorstep within 24-48 hours.', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_why_item_2_desc', array(
		'label'   => __( 'Why choose item 2 description', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'textarea',
	) );

	$wp_customize->add_setting( 'yusraah_why_item_3_title', array(
		'default'           => __( 'Customer Support', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_why_item_3_title', array(
		'label'   => __( 'Why choose item 3 title', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_why_item_3_desc', array(
		'default'           => __( 'Our dedicated team is here to help you with any questions or concerns.', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_why_item_3_desc', array(
		'label'   => __( 'Why choose item 3 description', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'textarea',
	) );

	$wp_customize->add_setting( 'yusraah_why_item_4_title', array(
		'default'           => __( 'Secure Payments', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_why_item_4_title', array(
		'label'   => __( 'Why choose item 4 title', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_why_item_4_desc', array(
		'default'           => __( 'Shop with confidence using our secure payment options and cash on delivery.', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_why_item_4_desc', array(
		'label'   => __( 'Why choose item 4 description', 'yusraah' ),
		'section' => 'yusraah_homepage',
		'type'    => 'textarea',
	) );

	/* --------------------------------------------------------
	   SHOP BY CATEGORY SECTION
	   -------------------------------------------------------- */
	$wp_customize->add_section( 'yusraah_category_section', array(
		'title'       => __( 'Shop by Category', 'yusraah' ),
		'description' => __( 'Configure the homepage category section.', 'yusraah' ),
		'priority'    => 38,
	) );

	// Section title
	$wp_customize->add_setting( 'yusraah_category_title', array(
		'default'           => __( 'Shop by Category', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'yusraah_category_title', array(
		'label'   => __( 'Section title', 'yusraah' ),
		'section' => 'yusraah_category_section',
		'type'    => 'text',
	) );

	// View all link text
	$wp_customize->add_setting( 'yusraah_category_view_all', array(
		'default'           => __( 'View all categories', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'yusraah_category_view_all', array(
		'label'   => __( 'View all link text', 'yusraah' ),
		'section' => 'yusraah_category_section',
		'type'    => 'text',
	) );

	// Number of categories
	$wp_customize->add_setting( 'yusraah_category_number', array(
		'default'           => 6,
		'sanitize_callback' => 'absint',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_category_number', array(
		'label'       => __( 'Number of categories (2-12)', 'yusraah' ),
		'section'     => 'yusraah_category_section',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 2, 'max' => 12, 'step' => 1 ),
	) );

	// Order by
	$wp_customize->add_setting( 'yusraah_category_orderby', array(
		'default'           => 'count',
		'sanitize_callback' => 'yusraah_sanitize_category_orderby',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_category_orderby', array(
		'label'   => __( 'Order by', 'yusraah' ),
		'section' => 'yusraah_category_section',
		'type'    => 'select',
		'choices' => array(
			'name'  => __( 'Name', 'yusraah' ),
			'count' => __( 'Product count', 'yusraah' ),
			'slug'  => __( 'Slug', 'yusraah' ),
			'id'    => __( 'ID', 'yusraah' ),
		),
	) );

	// Order direction
	$wp_customize->add_setting( 'yusraah_category_order', array(
		'default'           => 'DESC',
		'sanitize_callback' => 'yusraah_sanitize_category_order',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_category_order', array(
		'label'   => __( 'Order direction', 'yusraah' ),
		'section' => 'yusraah_category_section',
		'type'    => 'select',
		'choices' => array(
			'ASC'  => __( 'Ascending', 'yusraah' ),
			'DESC' => __( 'Descending', 'yusraah' ),
		),
	) );

	// Show product count
	$wp_customize->add_setting( 'yusraah_category_show_count', array(
		'default'           => true,
		'sanitize_callback' => 'rest_sanitize_boolean',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_category_show_count', array(
		'label'   => __( 'Show product count', 'yusraah' ),
		'section' => 'yusraah_category_section',
		'type'    => 'checkbox',
	) );

	// Grid columns
	$wp_customize->add_setting( 'yusraah_category_columns', array(
		'default'           => 4,
		'sanitize_callback' => 'absint',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_category_columns', array(
		'label'       => __( 'Grid columns (2-4)', 'yusraah' ),
		'section'     => 'yusraah_category_section',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 2, 'max' => 4, 'step' => 1 ),
	) );
}
add_action( 'customize_register', 'yusraah_customize_register' );

/**
 * Sanitize category orderby value.
 *
 * @param string $value Raw value.
 * @return string
 */
function yusraah_sanitize_category_orderby( $value ) {
	$allowed = array( 'name', 'count', 'slug', 'id' );
	return in_array( $value, $allowed, true ) ? $value : 'count';
}

/**
 * Sanitize category order value.
 *
 * @param string $value Raw value.
 * @return string
 */
function yusraah_sanitize_category_order( $value ) {
	$allowed = array( 'ASC', 'DESC' );
	return in_array( $value, $allowed, true ) ? $value : 'DESC';
}

/**
 * Sanitize a non-negative amount.
 *
 * @param mixed $value Value.
 * @return float
 */
function yusraah_sanitize_amount( $value ) {
	return max( 0, (float) $value );
}

/**
 * Sanitize the after-add-to-cart action.
 *
 * @param string $value Raw action.
 * @return string
 */
function yusraah_sanitize_cart_toast_action( $value ) {
	$allowed = array( 'toast', 'drawer', 'both' );
	return in_array( $value, $allowed, true ) ? $value : 'toast';
}

/**
 * Sanitize the desktop cart toast position.
 *
 * @param string $value Raw position.
 * @return string
 */
function yusraah_sanitize_cart_toast_position( $value ) {
	$allowed = array( 'top-right', 'top-left' );
	return in_array( $value, $allowed, true ) ? $value : 'top-right';
}

/**
 * Sanitize cart toast duration in seconds.
 *
 * @param mixed $value Raw duration.
 * @return int
 */
function yusraah_sanitize_cart_toast_duration( $value ) {
	return min( 12, max( 3, absint( $value ) ) );
}

/**
 * Register Customizer settings for the Cart Toast notification.
 *
 * @param WP_Customize_Manager $wp_customize Customizer instance.
 * @return void
 */
function yusraah_cart_toast_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'yusraah_cart_toast',
		array(
			'title'       => __( 'Cart notification (Toast)', 'yusraah' ),
			'description' => __( 'Configure the floating notification when products are added to the basket.', 'yusraah' ),
			'priority'    => 45,
		)
	);

	$wp_customize->add_setting(
		'yusraah_cart_toast_enabled',
		array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'yusraah_cart_toast_enabled',
		array(
			'label'   => __( 'Enable toast notification', 'yusraah' ),
			'section' => 'yusraah_cart_toast',
			'type'    => 'checkbox',
		)
	);

	$wp_customize->add_setting(
		'yusraah_cart_toast_action',
		array(
			'default'           => 'toast',
			'sanitize_callback' => 'yusraah_sanitize_cart_toast_action',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'yusraah_cart_toast_action',
		array(
			'label'   => __( 'After add to cart', 'yusraah' ),
			'section' => 'yusraah_cart_toast',
			'type'    => 'select',
			'choices' => array(
				'toast'  => __( 'Show toast notification (less intrusive)', 'yusraah' ),
				'drawer' => __( 'Open side basket', 'yusraah' ),
				'both'   => __( 'Show toast and open basket', 'yusraah' ),
			),
		)
	);

	$wp_customize->add_setting(
		'yusraah_cart_toast_position',
		array(
			'default'           => 'top-right',
			'sanitize_callback' => 'yusraah_sanitize_cart_toast_position',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'yusraah_cart_toast_position',
		array(
			'label'   => __( 'Desktop position', 'yusraah' ),
			'section' => 'yusraah_cart_toast',
			'type'    => 'select',
			'choices' => array(
				'top-right' => __( 'Top right', 'yusraah' ),
				'top-left'  => __( 'Top left', 'yusraah' ),
			),
		)
	);

	$wp_customize->add_setting(
		'yusraah_cart_toast_duration',
		array(
			'default'           => 5,
			'sanitize_callback' => 'yusraah_sanitize_cart_toast_duration',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'yusraah_cart_toast_duration',
		array(
			'label'       => __( 'Display duration (seconds)', 'yusraah' ),
			'section'     => 'yusraah_cart_toast',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 3,
				'max'  => 12,
				'step' => 1,
			),
		)
	);

	$wp_customize->add_setting(
		'yusraah_cart_toast_checkout',
		array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'yusraah_cart_toast_checkout',
		array(
			'label'   => __( 'Show Checkout button', 'yusraah' ),
			'section' => 'yusraah_cart_toast',
			'type'    => 'checkbox',
		)
	);
}
add_action( 'customize_register', 'yusraah_cart_toast_customize_register', 20 );

function yusraah_body_classes( $classes ) {
	if ( function_exists( 'is_woocommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) ) {
		$classes[] = 'has-woocommerce';
	}
	return $classes;
}
add_filter( 'body_class', 'yusraah_body_classes' );

function yusraah_excerpt_more() {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'yusraah_excerpt_more' );

/**
 * AJAX: Get product data for quick view modal.
 */
function yusraah_quick_view_product() {
	if ( ! check_ajax_referer( 'yusraah_product_search', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Invalid request.', 'yusraah' ) ), 403 );
	}

	$product_id = isset( $_POST['product_id'] ) ? absint( wp_unslash( $_POST['product_id'] ) ) : 0;
	if ( ! $product_id ) {
		wp_send_json_error( array( 'message' => __( 'Product not found.', 'yusraah' ) ), 404 );
	}

	$product = wc_get_product( $product_id );
	if ( ! $product || ! $product->is_visible() ) {
		wp_send_json_error( array( 'message' => __( 'Product not available.', 'yusraah' ) ), 404 );
	}

	ob_start();
	?>
	<div class="quick-view-product">
		<div class="quick-view-product__image">
			<?php echo $product->get_image( 'woocommerce_single', array( 'loading' => 'eager' ) ); ?>
		</div>
		<div class="quick-view-product__details">
			<?php if ( $product->is_type( 'variable' ) ) : ?>
				<div class="quick-view-product__variations">
					<?php woocommerce_template_single_add_to_cart(); ?>
				</div>
			<?php else : ?>
				<div class="quick-view-product__price"><?php echo $product->get_price_html(); ?></div>
				<div class="quick-view-product__stock">
					<?php
					if ( $product->is_in_stock() ) {
						echo '<span class="in-stock">' . esc_html__( 'In stock', 'yusraah' ) . '</span>';
					} else {
						echo '<span class="out-of-stock">' . esc_html__( 'Out of stock', 'yusraah' ) . '</span>';
					}
					?>
				</div>
				<div class="quick-view-product__cart">
					<?php woocommerce_template_single_add_to_cart(); ?>
				</div>
			<?php endif; ?>
			<div class="quick-view-product__description">
				<?php echo wp_kses_post( wp_trim_words( $product->get_short_description(), 20, '...' ) ); ?>
			</div>
			<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="quick-view-product__link">
				<?php esc_html_e( 'View full details', 'yusraah' ); ?> <?php echo yusraah_icon( 'arrow' ); ?>
			</a>
		</div>
	</div>
	<?php
	$html = ob_get_clean();

	wp_send_json_success( array(
		'html' => $html,
		'title' => $product->get_name(),
	) );
}
add_action( 'wp_ajax_yusraah_quick_view', 'yusraah_quick_view_product' );
add_action( 'wp_ajax_nopriv_yusraah_quick_view', 'yusraah_quick_view_product' );

/**
 * Render quick view modal markup.
 */
function yusraah_render_quick_view_modal() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	?>
	<div id="yusraah-quick-view-modal" class="quick-view-modal" aria-hidden="true" hidden>
		<div class="quick-view-modal__backdrop" data-quick-view-close></div>
		<div class="quick-view-modal__panel" role="dialog" aria-modal="true" aria-labelledby="quick-view-title" tabindex="-1">
			<button class="quick-view-modal__close" type="button" data-quick-view-close aria-label="<?php esc_attr_e( 'Close quick view', 'yusraah' ); ?>">
				<?php echo yusraah_icon( 'close' ); ?>
			</button>
			<div class="quick-view-modal__content" id="quick-view-content">
				<div class="quick-view-modal__loading">
					<span><?php esc_html_e( 'Loading...', 'yusraah' ); ?></span>
				</div>
			</div>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'yusraah_render_quick_view_modal', 10 );

/**
 * Track recently viewed products using localStorage.
 */
function yusraah_track_recently_viewed() {
	if ( ! is_product() ) {
		return;
	}

	global $product;
	if ( ! $product ) {
		return;
	}

	$product_id = $product->get_id();
	?>
	<script>
	(function() {
		try {
			var storageKey = 'yusraah-recently-viewed';
			var recent = JSON.parse(localStorage.getItem(storageKey) || '[]');
			var productId = <?php echo wp_json_encode( $product_id ); ?>;
			var index = recent.indexOf(productId);
			if (index > -1) {
				recent.splice(index, 1);
			}
			recent.unshift(productId);
			if (recent.length > 8) {
				recent = recent.slice(0, 8);
			}
			localStorage.setItem(storageKey, JSON.stringify(recent));
		} catch (e) {}
	})();
	</script>
	<?php
}
add_action( 'wp_footer', 'yusraah_track_recently_viewed', 5 );

/**
 * Render recently viewed products section.
 */
function yusraah_render_recently_viewed() {
	if ( ! is_product() ) {
		return;
	}
	?>
	<div id="yusraah-recently-viewed" class="recently-viewed-section" hidden>
		<div class="section-wrap">
			<div class="section-heading">
				<div><p class="eyebrow"><?php esc_html_e( 'Continue browsing', 'yusraah' ); ?></p><h2><?php esc_html_e( 'Recently viewed', 'yusraah' ); ?></h2></div>
			</div>
			<div class="recently-viewed-products" id="recently-viewed-products">
				<div class="products-loading"><span><?php esc_html_e( 'Loading...', 'yusraah' ); ?></span></div>
			</div>
		</div>
	</div>
	<script>
	(function() {
		try {
			var storageKey = 'yusraah-recently-viewed';
			var recent = JSON.parse(localStorage.getItem(storageKey) || '[]');
			if (recent.length < 2) return;

			var currentProductId = <?php echo wp_json_encode( get_the_ID() ); ?>;
			var filtered = recent.filter(function(id) { return id !== currentProductId; });
			if (filtered.length === 0) return;

			var container = document.getElementById('recently-viewed-products');
			var section = document.getElementById('yusraah-recently-viewed');
			if (!container || !section) return;

			section.hidden = false;

			var formData = new FormData();
			formData.append('action', 'yusraah_recently_viewed_products');
			formData.append('product_ids', filtered.join(','));

			fetch('<?php echo admin_url( 'admin-ajax.php' ); ?>', {
				method: 'POST',
				credentials: 'same-origin',
				body: formData
			})
			.then(function(response) { return response.json(); })
			.then(function(response) {
				if (response.success && response.data) {
					container.innerHTML = response.data;
				}
			})
			.catch(function() {
				container.innerHTML = '';
			});
		} catch (e) {}
	})();
	</script>
	<?php
}
add_action( 'woocommerce_after_single_product', 'yusraah_render_recently_viewed', 20 );

/**
 * AJAX: Get recently viewed products HTML.
 */
function yusraah_recently_viewed_products_ajax() {
	$product_ids = isset( $_POST['product_ids'] ) ? sanitize_text_field( wp_unslash( $_POST['product_ids'] ) ) : '';
	if ( ! $product_ids ) {
		wp_send_json_error();
	}

	$ids = array_map( 'absint', explode( ',', $product_ids ) );
	if ( empty( $ids ) ) {
		wp_send_json_error();
	}

	$html = do_shortcode( '[products ids="' . esc_attr( implode( ',', $ids ) ) . '" columns="4" limit="' . count( $ids ) . '"]' );
	wp_send_json_success( $html );
}
add_action( 'wp_ajax_yusraah_recently_viewed_products', 'yusraah_recently_viewed_products_ajax' );
add_action( 'wp_ajax_nopriv_yusraah_recently_viewed_products', 'yusraah_recently_viewed_products_ajax' );

/**
 * Render product filter sidebar.
 */
function yusraah_product_filter_sidebar() {
	if ( ! ( is_shop() || is_product_taxonomy() ) ) {
		return;
	}

	$attributes = wc_get_attribute_taxonomies();
	if ( empty( $attributes ) ) {
		return;
	}

	$price_min = isset( $_GET['min_price'] ) ? floatval( $_GET['min_price'] ) : 0;
	$price_max = isset( $_GET['max_price'] ) ? floatval( $_GET['max_price'] ) : '';
	?>
	<aside class="product-filters" aria-label="<?php esc_attr_e( 'Product filters', 'yusraah' ); ?>">
		<div class="product-filters__header">
			<h2><?php esc_html_e( 'Filters', 'yusraah' ); ?></h2>
			<a href="<?php echo esc_url( remove_query_arg( array_keys( $_GET ) ) ); ?>" class="product-filters__clear">
				<?php esc_html_e( 'Clear all', 'yusraah' ); ?>
			</a>
		</div>

		<div class="product-filters__section">
			<h3><?php esc_html_e( 'Price range', 'yusraah' ); ?></h3>
			<form class="price-filter-form" method="get">
				<?php foreach ( $_GET as $key => $value ) : ?>
					<?php if ( $key !== 'min_price' && $key !== 'max_price' ) : ?>
						<input type="hidden" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>">
					<?php endif; ?>
				<?php endforeach; ?>
				<div class="price-filter__inputs">
					<input type="number" name="min_price" placeholder="<?php esc_attr_e( 'Min', 'yusraah' ); ?>" value="<?php echo esc_attr( $price_min > 0 ? $price_min : '' ); ?>" min="0" step="0.01">
					<span><?php esc_html_e( 'to', 'yusraah' ); ?></span>
					<input type="number" name="max_price" placeholder="<?php esc_attr_e( 'Max', 'yusraah' ); ?>" value="<?php echo esc_attr( $price_max ); ?>" min="0" step="0.01">
				</div>
				<button type="submit" class="button button--dark"><?php esc_html_e( 'Apply', 'yusraah' ); ?></button>
			</form>
		</div>

		<?php foreach ( $attributes as $attribute ) : ?>
			<?php
			$taxonomy = wc_attribute_taxonomy_name( $attribute->attribute_name );
			$terms = get_terms( array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => true,
			) );

			if ( empty( $terms ) || is_wp_error( $terms ) ) {
				continue;
			}

			$current_values = isset( $_GET[ 'filter_' . $attribute->attribute_name ] )
				? explode( ',', sanitize_text_field( wp_unslash( $_GET[ 'filter_' . $attribute->attribute_name ] ) ) )
				: array();
			?>
			<div class="product-filters__section">
				<h3><?php echo esc_html( $attribute->attribute_label ); ?></h3>
				<form class="attribute-filter-form" method="get">
					<?php foreach ( $_GET as $key => $value ) : ?>
						<?php if ( $key !== 'filter_' . $attribute->attribute_name ) : ?>
							<input type="hidden" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>">
						<?php endif; ?>
					<?php endforeach; ?>
					<div class="attribute-filter__terms">
						<?php foreach ( $terms as $term ) : ?>
							<?php $is_checked = in_array( $term->slug, $current_values, true ); ?>
							<label class="attribute-filter__term">
								<input
									type="checkbox"
									name="filter_<?php echo esc_attr( $attribute->attribute_name ); ?>"
									value="<?php echo esc_attr( $term->slug ); ?>"
									<?php checked( $is_checked ); ?>
								>
								<span><?php echo esc_html( $term->name ); ?></span>
								<span class="count"><?php echo esc_html( $term->count ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
					<button type="submit" class="button button--dark"><?php esc_html_e( 'Apply', 'yusraah' ); ?></button>
				</form>
			</div>
		<?php endforeach; ?>
	</aside>
	<?php
}
remove_action( 'woocommerce_before_shop_loop', 'yusraah_product_filter_sidebar', 15 );
add_action( 'woocommerce_get_sidebar', 'yusraah_product_filter_sidebar' );

/**
 * Render social sharing buttons for products.
 */
function yusraah_product_social_sharing() {
	if ( ! is_product() ) {
		return;
	}

	global $product;
	if ( ! $product ) {
		return;
	}

	$product_url = $product->get_permalink();
	$product_title = $product->get_name();
	$product_image = wp_get_attachment_image_url( $product->get_image_id(), 'full' );
	$encoded_url = rawurlencode( $product_url );
	$encoded_title = rawurlencode( $product_title );
	?>
	<div class="product-social-sharing" aria-label="<?php esc_attr_e( 'Share this product', 'yusraah' ); ?>">
		<p class="product-social-sharing__label"><?php esc_html_e( 'Share', 'yusraah' ); ?></p>
		<div class="product-social-sharing__buttons">
			<a
				href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_attr( $encoded_url ); ?>"
				target="_blank"
				rel="noopener noreferrer"
				class="social-share-button social-share-button--facebook"
				aria-label="<?php esc_attr_e( 'Share on Facebook', 'yusraah' ); ?>"
			>
				<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
			</a>
			<a
				href="https://twitter.com/intent/tweet?url=<?php echo esc_attr( $encoded_url ); ?>&text=<?php echo esc_attr( $encoded_title ); ?>"
				target="_blank"
				rel="noopener noreferrer"
				class="social-share-button social-share-button--twitter"
				aria-label="<?php esc_attr_e( 'Share on Twitter', 'yusraah' ); ?>"
			>
				<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg>
			</a>
			<a
				href="https://pinterest.com/pin/create/button/?url=<?php echo esc_attr( $encoded_url ); ?>&media=<?php echo esc_attr( $product_image ? rawurlencode( $product_image ) : '' ); ?>&description=<?php echo esc_attr( $encoded_title ); ?>"
				target="_blank"
				rel="noopener noreferrer"
				class="social-share-button social-share-button--pinterest"
				aria-label="<?php esc_attr_e( 'Share on Pinterest', 'yusraah' ); ?>"
			>
				<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 0a12 12 0 0 0-4.8 23a.5.5 0 0 0 .5-.2c.1-.4.3-1.3.4-1.7c0-.2.1-.2.2-.1c.6.4 1.2.6 1.9.6a5.5 5.5 0 0 0 5.5-5.5a6.5 6.5 0 0 0-6.5-6.5a6.5 6.5 0 0 0-6.5 6.5a6.5 6.5 0 0 0 2.7 5.3a.5.5 0 0 0 .4.1l.5-1.8a.5.5 0 0 0-.1-.4a3.5 3.5 0 0 1-1.2-2.7a4.5 4.5 0 0 1 4.5-4.5a4.5 4.5 0 0 1 4.5 4.5a3.5 3.5 0 0 1-3.5 3.5a2 2 0 0 1-2-2a1.5 1.5 0 0 1 1.5-1.5a1 1 0 0 1 1 1a.5.5 0 0 0 1 0a1.5 1.5 0 0 0-1.5-1.5a2.5 2.5 0 0 0-2.5 2.5a3 3 0 0 0 3 3a4.5 4.5 0 0 0 4.5-4.5a5.5 5.5 0 0 0-5.5-5.5Z"/></svg>
			</a>
			<a
				href="https://wa.me/?text=<?php echo esc_attr( $encoded_title . ' ' . $product_url ); ?>"
				target="_blank"
				rel="noopener noreferrer"
				class="social-share-button social-share-button--whatsapp"
				aria-label="<?php esc_attr_e( 'Share on WhatsApp', 'yusraah' ); ?>"
			>
				<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/></svg>
			</a>
			<button
				type="button"
				class="social-share-button social-share-button--copy"
				data-copy-url="<?php echo esc_attr( $product_url ); ?>"
				aria-label="<?php esc_attr_e( 'Copy link', 'yusraah' ); ?>"
			>
				<svg viewBox="0 0 24 24" aria-hidden="true"><rect width="14" height="14" x="5" y="5" rx="2" ry="2"/><path d="M16 2v4a2 2 0 0 0 2 2h4"/></svg>
			</button>
		</div>
	</div>
	<?php
}
add_action( 'woocommerce_single_product_summary', 'yusraah_product_social_sharing', 40 );

/**
 * Enhance related products section styling.
 */
function yusraah_related_products_args( $args ) {
	$args['columns'] = 4;
	$args['posts_per_page'] = 4;
	return $args;
}
add_filter( 'woocommerce_output_related_products_args', 'yusraah_related_products_args' );

/**
 * Check if a product is new (published within the last 30 days).
 *
 * @param int $product_id Product ID.
 * @return bool
 */
function yusraah_is_new_product( $product_id ) {
	$days_threshold = apply_filters( 'yusraah_new_product_days', 30 );
	$publish_date = get_the_date( 'U', $product_id );
	$threshold_date = strtotime( '-' . $days_threshold . ' days' );

	return $publish_date >= $threshold_date;
}

/**
 * Get homepage category data: the product categories plus a map of their
 * product image URLs, cached together in a single transient.
 *
 * Keeping the term objects untouched avoids adding dynamic properties to
 * WP_Term, which is deprecated in PHP 8.2+ and mutated WordPress' own cached
 * term objects. The cache signature contains the theme version and the
 * relevant Customizer settings, so a stale transient can never hide the
 * feature after the theme or the settings change.
 *
 * @return array {
 *     @type string    $signature Cache signature.
 *     @type WP_Term[] $terms     Product category terms.
 *     @type array     $images    Map of term ID => array of product image URLs.
 * }
 */
function yusraah_get_home_category_data() {
	$number  = absint( get_theme_mod( 'yusraah_category_number', 6 ) );
	$orderby = get_theme_mod( 'yusraah_category_orderby', 'count' );
	$order   = get_theme_mod( 'yusraah_category_order', 'DESC' );

	$signature = md5( wp_json_encode( array( YUSRAAH_VERSION, $number, $orderby, $order ) ) );

	$cached = get_transient( 'yusraah_home_category_data' );
	if (
		is_array( $cached )
		&& isset( $cached['signature'], $cached['terms'], $cached['images'] )
		&& $signature === $cached['signature']
	) {
		return $cached;
	}

	$data = array(
		'signature' => $signature,
		'terms'     => array(),
		'images'    => array(),
	);

	if ( ! taxonomy_exists( 'product_cat' ) ) {
		return $data;
	}

	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => true,
			'number'     => $number,
			'orderby'    => $orderby,
			'order'      => $order,
			'exclude'    => array( (int) get_option( 'default_product_cat' ) ), // Exclude "Uncategorized".
		)
	);

	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return $data;
	}

	$data['terms'] = $terms;

	foreach ( $terms as $term ) {
		$data['images'][ $term->term_id ] = yusraah_get_category_image_urls( $term );
	}

	// Cache for 6 hours.
	set_transient( 'yusraah_home_category_data', $data, 6 * HOUR_IN_SECONDS );

	return $data;
}

/**
 * Get the product categories shown in the homepage "Shop by Category" section.
 *
 * @return WP_Term[]
 */
function yusraah_get_product_categories() {
	$data = yusraah_get_home_category_data();

	return $data['terms'];
}

/**
 * Get the cached product image URLs for every homepage category.
 *
 * @return array Map of term ID => array of image URLs.
 */
function yusraah_get_category_image_urls_map() {
	$data = yusraah_get_home_category_data();

	return $data['images'];
}

/**
 * Fetch up to four product image URLs for a product category.
 *
 * Only published products assigned to the category (or one of its children)
 * are considered, so hidden or trashed products never leak into the tiles.
 *
 * @param WP_Term $term Product category term.
 * @return string[]
 */
function yusraah_get_category_image_urls( $term ) {
	$product_ids = get_posts(
		array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'posts_per_page'      => 4, // Up to 4 product images for the hover cycle.
			'orderby'             => 'menu_order',
			'order'               => 'ASC',
			'fields'              => 'ids',
			'no_found_rows'       => true,
			'ignore_sticky_posts' => true,
			'suppress_filters'    => false,
			'tax_query'           => array(
				array(
					'taxonomy'         => 'product_cat',
					'field'            => 'term_id',
					'terms'            => (int) $term->term_id,
					'include_children' => true,
				),
			),
		)
	);

	$image_urls = array();

	foreach ( $product_ids as $product_id ) {
		$image_id = get_post_thumbnail_id( $product_id );

		if ( ! $image_id ) {
			continue;
		}

		$image_url = wp_get_attachment_image_url( $image_id, 'medium' );

		if ( $image_url ) {
			$image_urls[] = $image_url;
		}
	}

	return $image_urls;
}

/**
 * Clear the homepage category cache when categories or products are updated.
 */
function yusraah_clear_category_cache() {
	delete_transient( 'yusraah_home_category_data' );
}
add_action( 'created_product_cat', 'yusraah_clear_category_cache' );
add_action( 'edited_product_cat', 'yusraah_clear_category_cache' );
add_action( 'delete_product_cat', 'yusraah_clear_category_cache' );
add_action( 'save_post_product', 'yusraah_clear_category_cache' ); // Clear when products are saved/updated

/**
 * Add cross-sells to cart page.
 */
function yusraah_cross_sells_display() {
	if ( ! is_cart() ) {
		return;
	}

	$cross_sells = WC()->cart->get_cross_sells();
	if ( empty( $cross_sells ) ) {
		return;
	}

	$ids = array();
	foreach ( $cross_sells as $cross_sell ) {
		$ids[] = $cross_sell->get_id();
	}

	if ( empty( $ids ) ) {
		return;
	}
	?>
	<section class="cross-sells-section section-wrap">
		<div class="section-heading">
			<div><p class="eyebrow"><?php esc_html_e( 'Complete your order', 'yusraah' ); ?></p><h2><?php esc_html_e( 'You may also like', 'yusraah' ); ?></h2></div>
		</div>
		<?php echo do_shortcode( '[products ids="' . esc_attr( implode( ',', $ids ) ) . '" columns="4" limit="' . count( $ids ) . '"]' ); ?>
	</section>
	<?php
}
add_action( 'woocommerce_after_cart', 'yusraah_cross_sells_display', 10 );

/**
 * Remove default cross-sells from cart.
 */
remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
