(function () {
	'use strict';

	var banners = document.querySelectorAll('[data-monthly-kits]');
	if (!banners.length) return;

	var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var strings = window.yusraahMonthlyKits || {};

	banners.forEach(function (banner) {
		if (!reducedMotion && 'IntersectionObserver' in window) {
			banner.classList.add('monthly-kits--animate');
			var observer = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) {
						banner.classList.add('is-visible');
						observer.unobserve(banner);
					}
				});
			}, { threshold: 0.12 });
			observer.observe(banner);
		} else {
			banner.classList.add('is-visible');
		}

		var countdown = banner.querySelector('.monthly-kits__countdown');
		if (!countdown) return;

		var start = parseInt(countdown.getAttribute('data-countdown-start'), 10) || 0;
		var end = parseInt(countdown.getAttribute('data-countdown-end'), 10) || 0;
		var value = countdown.querySelector('[data-countdown-value]');
		var label = countdown.querySelector('[data-countdown-label]');
		var timer = 0;
		if (!value || !end) return;

		function updateCountdown() {
			var now = Math.floor(Date.now() / 1000);
			if (now >= end) {
				countdown.hidden = true;
				window.clearInterval(timer);
				return;
			}

			var target = end;
			if (start && now < start) {
				target = start;
				if (label) label.textContent = strings.starts || '';
			} else if (label) {
				label.textContent = strings.ends || '';
			}

			var remaining = Math.max(0, target - now);
			var days = Math.floor(remaining / 86400);
			var hours = Math.floor((remaining % 86400) / 3600);
			var minutes = Math.floor((remaining % 3600) / 60);
			var seconds = remaining % 60;
			var parts = [];
			if (days) parts.push(days + (strings.days || 'd'));
			parts.push(hours + (strings.hours || 'h'));
			parts.push(minutes + (strings.minutes || 'm'));
			parts.push(seconds + (strings.seconds || 's'));
			value.textContent = parts.join(' ');
		}

		updateCountdown();
		timer = window.setInterval(updateCountdown, 1000);
	});
}());
