/**
 * Reusable Product Slider  (hero-slider.js)
 *
 * Vanilla JS. Features:
 *  - Multiple independent slider instances on the same page.
 *  - Auto-slides (configurable speed, on/off per slider).
 *  - Pauses on hover, focus, and when the tab is hidden (Page Visibility API).
 *  - Loops infinitely.
 *  - Respects prefers-reduced-motion (disables animation + autoplay).
 *  - Prev/next arrow keyboard navigation.
 *  - Dot (tab-list) navigation.
 *  - Touch/pointer swipe support (horizontal swipe, ignores vertical).
 *  - Updates ARIA attributes (aria-hidden, aria-selected, tabindex) per slide.
 *  - Integrates with WooCommerce AJAX add-to-cart (triggers jQuery events
 *    that the existing cart drawer listens to).
 *
 * Config from PHP: window.yusraahSliderConfig = { sliders: { hero: {...}, story: {...} }, ajaxUrl, nonce }
 */
(function () {
	'use strict';

	/* ------------------------------------------------------------------ */
	/* Helpers                                                              */
	/* ------------------------------------------------------------------ */

	var reducedMotion = window.matchMedia
		? window.matchMedia('(prefers-reduced-motion: reduce)').matches
		: false;

	function qs(el, sel) { return el.querySelector(sel); }
	function qsa(el, sel) { return Array.prototype.slice.call(el.querySelectorAll(sel)); }
	var sliderDestroyers = new WeakMap();

	/* ------------------------------------------------------------------ */
	/* Slider initialiser                                                   */
	/* ------------------------------------------------------------------ */

	function initSlider(wrapper, sliderId) {
		var previousDestroy = sliderDestroyers.get(wrapper);
		if (previousDestroy) {
			previousDestroy();
		}
		var config = (window.yusraahSliderConfig && window.yusraahSliderConfig.sliders && window.yusraahSliderConfig.sliders[sliderId])
			? window.yusraahSliderConfig.sliders[sliderId]
			: {};
		var wrapperAutoplay = wrapper.getAttribute('data-hcs-autoplay');
		var autoplayEnabled = !reducedMotion && (wrapperAutoplay ? wrapperAutoplay === 'true' : config.autoplay !== false);
		var speed = parseInt(wrapper.getAttribute('data-hcs-speed') || config.speed, 10) || 4500;
		if (isNaN(speed) || speed < 2000) speed = 2000;
		if (speed > 8000) speed = 8000;

		var track  = qs(wrapper, '[data-hcs-track]');
		var slides = qsa(wrapper, '[data-hcs-slide]');
		var prevBtn = qs(wrapper, '[data-hcs-prev]');
		var nextBtn = qs(wrapper, '[data-hcs-next]');
		var dots   = qsa(wrapper, '[data-hcs-dot]');
		var dotsWrap = qs(wrapper, '.hcs-dots');

		if (!track || slides.length < 1) return;
		wrapper.classList.add('is-enhanced');

		var total   = slides.length;
		var current = 0;
		var timer   = null;
		var paused  = false; /* external pause (hover/focus/vis) */
		var visible = 1;

		function visibleCount() {
			var breakpoint = window.innerWidth <= 640 ? 'mobile' : (window.innerWidth <= 1024 ? 'tablet' : 'desktop');
			var value = parseInt(wrapper.getAttribute('data-hcs-slides-' + breakpoint), 10) || 1;
			return Math.max(1, Math.min(total, value));
		}

		function maxStart() {
			return Math.max(0, total - visible);
		}

		/* ---- Slide transition ---------------------------------------- */

		function goTo(index) {
			var max = maxStart();
			current = max ? ((index % (max + 1)) + (max + 1)) % (max + 1) : 0;

			// Move track.
			track.style.transform = 'translateX(-' + (current * 100 / visible) + '%)';

			// Update slides.
			slides.forEach(function (slide, i) {
				var active = i >= current && i < current + visible;
				slide.setAttribute('aria-hidden', active ? 'false' : 'true');

				// Update focusable children inside non-active slides.
				var focusables = qsa(slide, 'a, button, input, select, textarea, [tabindex]');
				focusables.forEach(function (el) {
					el.setAttribute('tabindex', active ? '0' : '-1');
				});
			});

			// Update dots.
			dots.forEach(function (dot, i) {
				var available = i <= max;
				var active = (i === current);
				dot.hidden = !available;
				dot.style.display = available ? '' : 'none';
				dot.setAttribute('aria-selected', active ? 'true' : 'false');
				dot.setAttribute('tabindex', active ? '0' : '-1');
				dot.classList.toggle('hcs-dot--active', active);
			});
		}

		function updateLayout() {
			visible = visibleCount();
			wrapper.style.setProperty('--hcs-visible-slides', visible);
			var controlsHidden = maxStart() === 0;
			if (prevBtn) {
				prevBtn.hidden = controlsHidden;
				prevBtn.style.display = controlsHidden ? 'none' : '';
			}
			if (nextBtn) {
				nextBtn.hidden = controlsHidden;
				nextBtn.style.display = controlsHidden ? 'none' : '';
			}
			if (dotsWrap) {
				dotsWrap.hidden = controlsHidden;
				dotsWrap.style.display = controlsHidden ? 'none' : '';
			}
			goTo(Math.min(current, maxStart()));
		}

		function next() { goTo(current + 1); }
		function prev() { goTo(current - 1); }

		/* ---- Auto-play ------------------------------------------------ */

		function startTimer() {
			if (!autoplayEnabled || total < 2) return;
			stopTimer();
			timer = setInterval(next, speed);
		}

		function stopTimer() {
			if (timer) {
				clearInterval(timer);
				timer = null;
			}
		}

		function pause() {
			paused = true;
			stopTimer();
		}

		function resume() {
			paused = false;
			startTimer();
		}

		/* ---- Hover / focus pause ------------------------------------- */

		wrapper.addEventListener('mouseenter', pause);
		wrapper.addEventListener('mouseleave', function () {
			if (!paused) return; // already resumed by something else
			resume();
		});

		// Pause when any focusable child is focused.
		wrapper.addEventListener('focusin', pause);
		wrapper.addEventListener('focusout', function (e) {
			// Only resume if focus left the whole wrapper.
			if (!wrapper.contains(e.relatedTarget)) {
				resume();
			}
		});

		/* ---- Page Visibility API ------------------------------------- */
		function handleVisibilityChange() {
			if (document.hidden) {
				pause();
			} else {
				resume();
			}
		}
		document.addEventListener('visibilitychange', handleVisibilityChange);
		window.addEventListener('resize', updateLayout);

		/* ---- Arrow buttons ------------------------------------------- */

		if (prevBtn) {
			prevBtn.addEventListener('click', function () {
				stopTimer();
				prev();
				startTimer();
			});
		}

		if (nextBtn) {
			nextBtn.addEventListener('click', function () {
				stopTimer();
				next();
				startTimer();
			});
		}

		/* ---- Dot navigation ------------------------------------------ */

		dots.forEach(function (dot) {
			dot.addEventListener('click', function () {
				var idx = parseInt(dot.getAttribute('data-hcs-dot'), 10);
				stopTimer();
				goTo(idx);
				startTimer();
			});

			// Keyboard: arrow keys move between dots (roving tabindex).
			dot.addEventListener('keydown', function (e) {
				var idx = parseInt(dot.getAttribute('data-hcs-dot'), 10);
				if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
					e.preventDefault();
					var nextDot = dots[(idx + 1) % dots.length];
					if (nextDot) { nextDot.click(); nextDot.focus(); }
				} else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
					e.preventDefault();
					var prevDot = dots[((idx - 1) + dots.length) % dots.length];
					if (prevDot) { prevDot.click(); prevDot.focus(); }
				}
			});
		});

		/* ---- Keyboard navigation on slides (Left/Right arrows) ------- */

		wrapper.addEventListener('keydown', function (e) {
			if (e.target && e.target.closest('[data-hcs-dot]')) return; // handled above
			if (e.key === 'ArrowRight') {
				e.preventDefault();
				stopTimer(); next(); startTimer();
			} else if (e.key === 'ArrowLeft') {
				e.preventDefault();
				stopTimer(); prev(); startTimer();
			}
		});

		/* ---- Touch / pointer swipe ------------------------------------ */

		var touchStartX = null;
		var touchStartY = null;
		var SWIPE_THRESHOLD = 40; // px

		wrapper.addEventListener('touchstart', function (e) {
			if (e.touches.length !== 1) return;
			touchStartX = e.touches[0].clientX;
			touchStartY = e.touches[0].clientY;
		}, { passive: true });

		wrapper.addEventListener('touchend', function (e) {
			if (touchStartX === null) return;
			var dx = e.changedTouches[0].clientX - touchStartX;
			var dy = e.changedTouches[0].clientY - touchStartY;
			// Ignore if mostly vertical.
			if (Math.abs(dx) < SWIPE_THRESHOLD || Math.abs(dy) > Math.abs(dx)) {
				touchStartX = null;
				return;
			}
			stopTimer();
			if (dx < 0) next(); else prev();
			startTimer();
			touchStartX = null;
		}, { passive: true });

		/* ---- Pointer (mouse drag) swipe ------------------------------ */

		var pointerDown = false;
		var pointerStartX = null;
		var pointerStartY = null;

		wrapper.addEventListener('pointerdown', function (e) {
			if (e.pointerType === 'touch') return; // handled above
			pointerDown = true;
			pointerStartX = e.clientX;
			pointerStartY = e.clientY;
		});

		wrapper.addEventListener('pointerup', function (e) {
			if (!pointerDown || e.pointerType === 'touch') return;
			pointerDown = false;
			var dx = e.clientX - pointerStartX;
			var dy = e.clientY - pointerStartY;
			if (Math.abs(dx) < SWIPE_THRESHOLD || Math.abs(dy) > Math.abs(dx)) return;
			stopTimer();
			if (dx < 0) next(); else prev();
			startTimer();
		});

		wrapper.addEventListener('pointerleave', function () {
			pointerDown = false;
		});

		/* ---- WooCommerce AJAX add-to-cart integration --------------- */
		//
		// WC's own add-to-cart script handles .ajax_add_to_cart clicks
		// and fires jQuery(document.body).trigger('added_to_cart', [...]).
		// The existing cart-drawer.js already listens to that event, so
		// as long as the buttons have the right classes and data attrs
		// (added in PHP), it all works automatically.
		//
		// We add a small loading-state enhancer only:

		wrapper.addEventListener('click', function (e) {
			var btn = e.target.closest('.hcs-slide__atc.ajax_add_to_cart');
			if (!btn || btn.classList.contains('loading')) return;
			// Optimistic loading indicator.
			btn.classList.add('loading');
			// WC will re-enable after the fragment update.
			if (window.jQuery) {
				window.jQuery(document.body).one('added_to_cart removed_from_cart', function () {
					btn.classList.remove('loading');
				});
			} else {
				setTimeout(function () { btn.classList.remove('loading'); }, 3000);
			}
		});

		/* ---- Init ---------------------------------------------------- */

		updateLayout();
		startTimer();

		function destroy() {
			stopTimer();
			document.removeEventListener('visibilitychange', handleVisibilityChange);
			window.removeEventListener('resize', updateLayout);
			sliderDestroyers.delete(wrapper);
		}
		sliderDestroyers.set(wrapper, destroy);
		return destroy;
	}

	/* ------------------------------------------------------------------ */
	/* Quick Deal tabs                                                      */
	/* ------------------------------------------------------------------ */

	function initQuickDeal(root) {
		var tabs = qsa(root, '[data-quick-deal-tab]');
		var panel = qs(root, '[data-quick-deal-panel]');
		var status = qs(root, '[data-quick-deal-status]');
		var viewAll = qs(root, '[data-quick-deal-view-all]');
		var config = window.yusraahSliderConfig && window.yusraahSliderConfig.quickDeal;
		if (!tabs.length || !panel || !config) return;

		var activeTab = root.querySelector('[data-quick-deal-tab][aria-selected="true"]');
		var activeId = activeTab ? activeTab.getAttribute('data-category-id') : '';
		var cachedMarkup = Object.create(null);
		var pending = Object.create(null);
		var requestId = 0;
		if (activeTab) {
			cachedMarkup[activeId] = panel.innerHTML;
		}

		function setActive(tab) {
			tabs.forEach(function (item) {
				var active = item === tab;
				item.setAttribute('aria-selected', active ? 'true' : 'false');
				item.setAttribute('tabindex', active ? '0' : '-1');
				item.classList.toggle('is-active', active);
			});
			activeId = tab.getAttribute('data-category-id');
			root.setAttribute('data-active-category', activeId);
			panel.setAttribute('aria-labelledby', tab.id);
			if (viewAll) {
				viewAll.href = tab.getAttribute('data-category-url') || tab.href;
			}
		}

		function initPanelSlider() {
			var wrapper = qs(panel, '.hcs-wrapper[data-hcs-autoplay]');
			if (wrapper) {
				initSlider(wrapper, wrapper.id.replace('-product-slider', ''));
			}
		}

		function showLoading() {
			panel.setAttribute('aria-busy', 'true');
			panel.innerHTML = '<div class="quick-deal__loading" aria-hidden="true"><span></span><span></span><span></span></div>';
			if (status) {
				status.textContent = config.loading || '';
			}
		}

		function showMarkup(html) {
			panel.innerHTML = html;
			panel.setAttribute('data-quick-deal-loaded', 'true');
			panel.removeAttribute('aria-busy');
			if (status) status.textContent = '';
			initPanelSlider();
		}

		function showError(error) {
			panel.removeAttribute('aria-busy');
			panel.setAttribute('data-quick-deal-loaded', 'false');
			var message = document.createElement('p');
			message.className = 'quick-deal__empty';
			message.textContent = error.message || config.failed || '';
			panel.replaceChildren(message);
			if (status) status.textContent = message.textContent;
		}

		function loadTab(tab) {
			var categoryId = tab.getAttribute('data-category-id');
			if (categoryId === activeId && panel.getAttribute('data-quick-deal-loaded') === 'true') {
				return;
			}
			var oldSlider = qs(panel, '.hcs-wrapper[data-hcs-autoplay]');
			if (oldSlider) {
				var destroy = sliderDestroyers.get(oldSlider);
				if (destroy) destroy();
			}
			setActive(tab);
			panel.setAttribute('data-quick-deal-loaded', 'false');

			if (Object.prototype.hasOwnProperty.call(cachedMarkup, categoryId)) {
				showMarkup(cachedMarkup[categoryId]);
				return;
			}

			var requestToken = ++requestId;
			showLoading();
			if (pending[categoryId]) {
				pending[categoryId].then(function (html) {
					cachedMarkup[categoryId] = html;
					if (requestToken !== requestId || categoryId !== activeId) return;
					showMarkup(html);
				}).catch(function (error) {
					if (requestToken !== requestId || categoryId !== activeId) return;
					showError(error);
				});
				return;
			}

			var payload = new FormData();
			payload.append('action', 'yusraah_quick_deal_load');
			payload.append('nonce', config.nonce || '');
			payload.append('category_id', categoryId);

			pending[categoryId] = fetch(window.yusraahSliderConfig.ajaxUrl, {
				method: 'POST',
				body: payload,
				credentials: 'same-origin'
			})
				.then(function (response) {
					return response.json().then(function (result) {
						if (!response.ok || !result || !result.success) {
							throw new Error(result && result.data && result.data.message ? result.data.message : (config.failed || ''));
						}
						return result.data.html;
					});
				});
			pending[categoryId]
				.then(function (html) {
					delete pending[categoryId];
					cachedMarkup[categoryId] = html;
					if (requestToken !== requestId || categoryId !== activeId) return;
					showMarkup(html);
				})
				.catch(function (error) {
					delete pending[categoryId];
					if (requestToken !== requestId || categoryId !== activeId) return;
					showError(error);
				});
		}

		tabs.forEach(function (tab) {
			tab.addEventListener('click', function (event) {
				event.preventDefault();
				if (tab.getAttribute('data-category-id') !== activeId || panel.getAttribute('data-quick-deal-loaded') !== 'true') {
					loadTab(tab);
				}
			});
		});

		var tablist = qs(root, '[data-quick-deal-tabs]');
		if (tablist) {
			tablist.addEventListener('keydown', function (event) {
				var index = tabs.indexOf(document.activeElement);
				var nextIndex = index;
				if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
					nextIndex = (index + 1) % tabs.length;
				} else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
					nextIndex = (index - 1 + tabs.length) % tabs.length;
				} else if (event.key === 'Home') {
					nextIndex = 0;
				} else if (event.key === 'End') {
					nextIndex = tabs.length - 1;
				} else {
					return;
				}
				event.preventDefault();
				tabs[nextIndex].focus();
				tabs[nextIndex].click();
			});
		}
	}

	function initQuickDeals() {
		qsa(document, '[data-quick-deal]').forEach(initQuickDeal);
	}

	window.yusraahHomeSlider = {
		init: initSlider,
		destroy: function (wrapper) {
			var destroy = sliderDestroyers.get(wrapper);
			if (destroy) destroy();
		}
	};

	/* ------------------------------------------------------------------ */
	/* Boot - initialize all sliders on the page                           */
	/* ------------------------------------------------------------------ */

	function boot() {
		// Find all slider wrappers by looking for the data attributes
		var wrappers = document.querySelectorAll('.hcs-wrapper[data-hcs-autoplay]');
		wrappers.forEach(function (wrapper) {
			// Extract slider ID from the element ID (e.g., "hero-product-slider" -> "hero")
			var sliderId = wrapper.id.replace('-product-slider', '');
			if (sliderId) {
				initSlider(wrapper, sliderId);
			}
		});
		initQuickDeals();
	}

	function destroyWithin(container) {
		var wrappers = container.querySelectorAll('.hcs-wrapper[data-hcs-autoplay]');
		wrappers.forEach(function (wrapper) {
			var destroy = sliderDestroyers.get(wrapper);
			if (destroy) destroy();
		});
	}

	if (window.wp && window.wp.customize && window.wp.customize.selectiveRefresh) {
		window.wp.customize.selectiveRefresh.bind('partial-content-refresh', function (placement) {
			if (placement && placement.container && placement.container[0]) {
				destroyWithin(placement.container[0]);
			}
		});
		window.wp.customize.selectiveRefresh.bind('partial-content-rendered', function (placement) {
			if (!placement || !placement.container || !placement.container[0]) return;
			var container = placement.container[0];
			container.querySelectorAll('.hcs-wrapper[data-hcs-autoplay]').forEach(function (wrapper) {
				var sliderId = wrapper.id.replace('-product-slider', '');
				if (sliderId) initSlider(wrapper, sliderId);
			});
			container.querySelectorAll('[data-quick-deal]').forEach(initQuickDeal);
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}

}());
