(function (api) {
	'use strict';

	if (!api || !api.control) {
		return;
	}
	var strings = window.yusraahQuickDealCustomizer || {};

	api.control('yusraah_quick_deal_categories', function (control) {
		var inputs = Array.prototype.slice.call(control.container.querySelectorAll('[data-quick-deal-category]'));
		var list = control.container.querySelector('.yusraah-quick-deal-category-list');

		function renderOrder(ids) {
			if (!list) {
				return;
			}
			var oldOrder = list.querySelector('[data-quick-deal-order]');
			if (oldOrder) {
				oldOrder.remove();
			}
			var orderList = document.createElement('ol');
			orderList.setAttribute('data-quick-deal-order', '');
			orderList.setAttribute('aria-label', strings.order || '');

			ids.forEach(function (id, index) {
				var input = inputs.find(function (item) {
					return parseInt(item.getAttribute('data-quick-deal-category'), 10) === id;
				});
				if (!input) {
					return;
				}
				var row = document.createElement('li');
				var label = document.createElement('span');
				label.textContent = input.parentNode.textContent.trim();
				row.appendChild(label);

				['up', 'down'].forEach(function (direction) {
					var button = document.createElement('button');
					button.type = 'button';
					button.textContent = direction === 'up' ? '↑' : '↓';
					var labelTemplate = direction === 'up' ? strings.moveUp : strings.moveDown;
					button.setAttribute('aria-label', (labelTemplate || '%s').replace('%s', label.textContent));
					button.disabled = direction === 'up' ? index === 0 : index === ids.length - 1;
					button.addEventListener('click', function () {
						var next = ids.slice();
						var swap = direction === 'up' ? index - 1 : index + 1;
						var value = next[index];
						next[index] = next[swap];
						next[swap] = value;
						control.setting.set(next);
					});
					row.appendChild(button);
				});
				orderList.appendChild(row);
			});
			list.appendChild(orderList);
		}

		function setSelected(value) {
			var ids = Array.isArray(value) ? value.map(function (id) { return parseInt(id, 10); }).filter(Boolean).slice(0, 6) : [];
			inputs.forEach(function (input) {
				var id = parseInt(input.getAttribute('data-quick-deal-category'), 10);
				input.checked = ids.indexOf(id) !== -1;
			});
			renderOrder(ids);
		}

		inputs.forEach(function (input) {
			input.addEventListener('change', function () {
				var selected = Array.isArray(control.setting.get()) ? control.setting.get().map(Number) : [];
				var id = parseInt(input.getAttribute('data-quick-deal-category'), 10);
				if (input.checked && selected.indexOf(id) === -1) {
					if (selected.length >= 6) {
						input.checked = false;
						return;
					}
					selected.push(id);
				} else if (!input.checked) {
					selected = selected.filter(function (item) { return item !== id; });
				}
				control.setting.set(selected);
			});
		});

		control.setting.bind(setSelected);
		setSelected(control.setting.get());
	});

	api.control('yusraah_quick_deal_labels', function (control) {
		var textarea = control.container.querySelector('[data-quick-deal-labels]');
		if (!textarea) {
			return;
		}

		function serialize(value) {
			return Object.keys(value || {}).map(function (id) {
				return id + ' | ' + value[id];
			}).join('\n');
		}

		function parse(value) {
			var labels = {};
			value.split(/\r?\n/).forEach(function (line) {
				var match = line.match(/^\s*(\d+)\s*\|\s*(.+?)\s*$/);
				if (match) {
					labels[parseInt(match[1], 10)] = match[2];
				}
			});
			return labels;
		}

		textarea.addEventListener('input', function () {
			control.setting.set(parse(textarea.value));
		});
		control.setting.bind(function (value) {
			var next = serialize(value);
			if (textarea.value !== next) {
				textarea.value = next;
			}
		});
	});
}(window.wp && window.wp.customize));
