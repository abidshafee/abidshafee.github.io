/* Blog: progress bar, ToC anchors, copy link, load more. Vanilla JS. */
(function () {
	'use strict';

	var blog = window.yusraahBlog || {};

	/* Reading progress bar */
	var progressBar = document.querySelector('[data-blog-progress]');
	if (progressBar) {
		var updateProgress = function () {
			var article = document.querySelector('.blog-article');
			if (!article) return;
			var rect = article.getBoundingClientRect();
			var total = rect.height - window.innerHeight;
			var scrolled = Math.min(Math.max(-rect.top, 0), Math.max(total, 1));
			progressBar.style.width = (total > 0 ? (scrolled / total) * 100 : 0) + '%';
		};
		var ticking = false;
		window.addEventListener('scroll', function () {
			if (!ticking) {
				ticking = true;
				requestAnimationFrame(function () { updateProgress(); ticking = false; });
			}
		}, { passive: true });
		updateProgress();
	}

	/* Table of contents: assign ids to h2/h3, sync active item, mobile toggle. */
	var tocNavs = document.querySelectorAll('[data-blog-toc], .blog-toc--desktop');
	if (tocNavs.length) {
		var content = document.querySelector('.blog-content');
		if (content) {
			var used = {};
			content.querySelectorAll('h2, h3').forEach(function (heading, i) {
				if (!heading.id) {
					var base = heading.textContent.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'section';
					var slug = base;
					while (used[slug]) { slug = base + '-' + (++used[base] || 1); }
					used[slug] = 1;
					heading.id = slug;
				}
				heading.setAttribute('tabindex', '-1');
				heading.style.scrollMarginTop = 'calc(var(--yusraah-header-height) + 16px)';
			});
		}

		// Mobile accordion toggle.
		var tocToggle = document.querySelector('.blog-toc__toggle');
		var tocList = document.getElementById('blog-toc-list');
		if (tocToggle && tocList) {
			tocToggle.addEventListener('click', function () {
				var open = tocToggle.getAttribute('aria-expanded') === 'true';
				tocToggle.setAttribute('aria-expanded', String(!open));
				tocList.classList.toggle('is-open', !open);
			});
		}

		// Scrollspy: highlight the ToC item for the heading in view.
		var tocItems = document.querySelectorAll('.blog-toc__item a');
		if (tocItems.length && 'IntersectionObserver' in window) {
			var linksById = {};
			tocItems.forEach(function (a) { linksById[a.getAttribute('href').slice(1)] = a.parentNode; });
			var spy = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					var item = linksById[entry.target.id];
					if (!item) return;
					if (entry.isIntersecting) {
						tocItems.forEach(function (a) { a.parentNode.classList.remove('is-active'); });
						item.classList.add('is-active');
					}
				});
			}, { rootMargin: '-80px 0px -70% 0px' });
			content.querySelectorAll('h2[id], h3[id]').forEach(function (h) { spy.observe(h); });
		}
	}

	/* Copy link button. */
	var copyBtn = document.querySelector('[data-blog-copy-link]');
	if (copyBtn) {
		copyBtn.addEventListener('click', function () {
			var url = copyBtn.getAttribute('data-url') || window.location.href;
			var label = copyBtn.textContent;
			var done = function () {
				copyBtn.textContent = 'Copied';
				copyBtn.classList.add('is-copied');
				setTimeout(function () {
					copyBtn.textContent = label;
					copyBtn.classList.remove('is-copied');
				}, 1600);
			};
			if (navigator.clipboard && navigator.clipboard.writeText) {
				navigator.clipboard.writeText(url).then(done, done);
			} else {
				var tmp = document.createElement('textarea');
				tmp.value = url;
				document.body.appendChild(tmp);
				tmp.select();
				try { document.execCommand('copy'); } catch (e) {}
				document.body.removeChild(tmp);
				done();
			}
		});
	}

	/* Load more pagination. */
	var loadMore = document.querySelector('[data-blog-load-more]');
	var grid = document.querySelector('[data-blog-grid]');
	if (loadMore && grid && blog.ajaxUrl) {
		var paged = parseInt(loadMore.getAttribute('data-paged'), 10) || 2;
		var max = parseInt(loadMore.getAttribute('data-max'), 10) || 1;

		loadMore.addEventListener('click', function () {
			if (paged > max) return;
			loadMore.disabled = true;
			loadMore.textContent = (blog.strings && blog.strings.loading) || 'Loading…';

			var body = new URLSearchParams();
			body.set('action', 'yusraah_blog_load_more');
			body.set('nonce', blog.nonce || '');
			body.set('paged', String(paged));
			body.set('cat', loadMore.getAttribute('data-cat') || '0');
			body.set('s', loadMore.getAttribute('data-s') || '');
			body.set('blog_id', loadMore.getAttribute('data-blog-id') || '0');

			fetch(blog.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (res && res.success && res.data && res.data.html) {
						grid.insertAdjacentHTML('beforeend', res.data.html);
						paged++;
						if (res.data.has_more) {
							loadMore.disabled = false;
							loadMore.textContent = 'Load more';
						} else {
							loadMore.remove();
						}
					} else {
						loadMore.disabled = false;
						loadMore.textContent = 'Load more';
					}
				})
				.catch(function () {
					loadMore.disabled = false;
					loadMore.textContent = 'Load more';
				});
		});
	}
})();

	/* Shop strip slider: scroll-snap with prev/next arrows. */
	document.querySelectorAll('[data-blog-slider]').forEach(function (slider) {
		var track = slider.querySelector('.blog-shop-strip');
		var prev = slider.querySelector('[data-slider-prev]');
		var next = slider.querySelector('[data-slider-next]');
		if (!track || !prev || !next) return;

		var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		var step = function () { return Math.max(track.clientWidth * 0.8, 160); };

		function update() {
			var max = track.scrollWidth - track.clientWidth;
			slider.classList.toggle('is-scrollable', max > 8);
			prev.hidden = max <= 8;
			next.hidden = max <= 8;
			prev.disabled = track.scrollLeft <= 4;
			next.disabled = track.scrollLeft >= max - 4;
		}

		prev.addEventListener('click', function () {
			track.scrollBy({ left: -step(), behavior: reduced ? 'auto' : 'smooth' });
		});
		next.addEventListener('click', function () {
			track.scrollBy({ left: step(), behavior: reduced ? 'auto' : 'smooth' });
		});
		track.addEventListener('scroll', update, { passive: true });
		window.addEventListener('resize', update);
		update();
	});

/* Shop-the-essentials slider.
 * Vertical translateY in the desktop sidebar; native scroll-snap row below 1024px.
 * data-mode on the section is the single source of truth for CSS and JS. */
(function () {
	'use strict';
	var sliders = document.querySelectorAll('[data-shop-slider]');
	if (!sliders.length) return;
	var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var mq = window.matchMedia('(min-width: 1024px)');

	sliders.forEach(function (slider) {
		var viewport = slider.querySelector('[data-shop-viewport]');
		var track = slider.querySelector('[data-shop-track]');
		var slides = Array.prototype.slice.call(track.children);
		var dotsWrap = slider.querySelector('[data-shop-dots]');
		var prevBtn = slider.querySelector('[data-shop-prev]');
		var nextBtn = slider.querySelector('[data-shop-next]');
		var perView = parseInt(slider.getAttribute('data-per-view'), 10) || 3;
		var autoplay = slider.getAttribute('data-autoplay') === '1' && !reduced;
		var speed = parseInt(slider.getAttribute('data-speed'), 10) || 4500;
		var index = 0, timer = null, vertical = true, slideSize = 0, gap = 12;
		var lastUserScroll = 0;

		/* ---------- shared ---------- */
		function setDots(active) {
			if (!dotsWrap) return;
			dotsWrap.querySelectorAll('.blog-shop-slider__dot').forEach(function (d, di) {
				var on = di === active;
			d.classList.toggle('is-active', on);
			d.setAttribute('aria-current', on ? 'true' : 'false');
			});
		}
		function makeDot(i, onClick) {
			var b = document.createElement('button');
			b.type = 'button';
			b.className = 'blog-shop-slider__dot';
			b.setAttribute('aria-label', 'Slide ' + (i + 1));
			b.addEventListener('click', onClick);
			return b;
		}
		function clearTimer() { if (timer) { clearInterval(timer); timer = null; } }
		function pause() { clearTimer(); }
		function resume() { startTimer(); }

		/* ---------- vertical mode (unchanged behavior) ---------- */
		function vMaxIndex() { return Math.max(0, slides.length - perView); }
		function vGo(i, instant) {
			index = Math.max(0, Math.min(i, vMaxIndex()));
			var dist = index * (slideSize + gap);
			track.style.transition = instant ? 'none' : '';
			track.style.transform = 'translateY(' + (-dist) + 'px)';
			setDots(index);
		}
		function vBuildDots() {
			if (!dotsWrap) return;
			dotsWrap.innerHTML = '';
			for (var i = 0; i <= vMaxIndex(); i++) {
				(function (n) {
					dotsWrap.appendChild(makeDot(n, function () { vGo(n); startTimer(); }));
				})(i);
			}
		}
		function vMeasure() {
			if (!slides.length) return;
			var cs = window.getComputedStyle(track);
			gap = parseFloat(cs.rowGap || cs.gap) || 12;
			slideSize = 0;
			slides.slice(0, perView).forEach(function (s) {
				slideSize = Math.max(slideSize, s.offsetHeight);
			});
			var vpCs = window.getComputedStyle(viewport);
			var pad = (parseFloat(vpCs.paddingTop) || 0) + (parseFloat(vpCs.paddingBottom) || 0);
			viewport.style.height = (perView * slideSize + (perView - 1) * gap + pad) + 'px';
			vGo(index, true);
		}

		/* ---------- horizontal mode: native scroll-snap ---------- */
		var hSlideW = 0, hDots = 0;

		function hMetrics() {
			if (!slides.length) return;
			hSlideW = slides[0].getBoundingClientRect().width;
			var cs = window.getComputedStyle(track);
			hGap = parseFloat(cs.columnGap || cs.gap) || 12;
		}
		var hGap = 12;
		function hSnapCount() {
			// Tablet: two slides visible -> positions = slides - 1. Mobile peek: one per slide.
			var twoUp = window.innerWidth >= 600;
			return Math.max(1, slides.length - (twoUp ? 1 : 0));
		}
		function hIndexFromScroll() {
			if (!hSlideW) hMetrics();
			var pos = viewport.scrollLeft / (hSlideW + hGap);
			return Math.max(0, Math.min(hDots - 1, Math.round(pos)));
		}
		function hScrollTo(i, smooth) {
			var target = i * (hSlideW + hGap);
			var max = viewport.scrollWidth - viewport.clientWidth;
			target = Math.max(0, Math.min(target, max));
			viewport.scrollTo({ left: target, behavior: smooth && !reduced ? 'smooth' : 'auto' });
		}
		function hUpdateChrome() {
			var atStart = viewport.scrollLeft <= 2;
			var atEnd = viewport.scrollLeft >= viewport.scrollWidth - viewport.clientWidth - 2;
			if (prevBtn) prevBtn.disabled = atStart;
			if (nextBtn) nextBtn.disabled = atEnd;
			setDots(hIndexFromScroll());
		}
		var hTicking = false;
		function hOnScroll() {
			lastUserScroll = Date.now();
			if (hTicking) return;
			hTicking = true;
			requestAnimationFrame(function () { hTicking = false; hUpdateChrome(); });
		}
		function hBuildDots() {
			if (!dotsWrap) return;
			dotsWrap.innerHTML = '';
			hDots = hSnapCount();
			for (var i = 0; i < hDots; i++) {
				(function (n) {
					dotsWrap.appendChild(makeDot(n, function () { hScrollTo(n, true); startTimer(); }));
				})(i);
			}
		}
		function hInit() {
			track.style.transform = '';
			track.style.transition = '';
			viewport.style.height = '';
			viewport.scrollLeft = 0;
			hMetrics();
			hBuildDots();
			hUpdateChrome();
		}

		/* ---------- autoplay ---------- */
		function startTimer() {
			clearTimer();
			if (!autoplay) return;
			if (vertical) {
				if (vMaxIndex() <= 0) return;
				timer = setInterval(function () { vGo(index >= vMaxIndex() ? 0 : index + 1); }, speed);
			} else {
				if (hDots <= 1) return;
				timer = setInterval(function () {
					if (Date.now() - lastUserScroll < 1600) return; // user is scrolling
					var cur = hIndexFromScroll();
					hScrollTo(cur >= hDots - 1 ? 0 : cur + 1, true);
				}, speed);
			}
		}

		/* ---------- mode switching ---------- */
		function setMode() {
			var was = vertical;
			vertical = mq.matches;
			slider.dataset.mode = vertical ? 'vertical' : 'horizontal';
			slider.classList.toggle('is-horizontal', !vertical);
			clearTimer();
			if (was !== vertical) {
				index = 0;
				track.style.transform = '';
				track.style.transition = '';
				viewport.style.height = '';
				viewport.scrollLeft = 0;
				if (vertical) { vBuildDots(); vMeasure(); }
				else { hInit(); }
			} else if (vertical) {
				vMeasure();
			} else {
				hMetrics(); hBuildDots(); hUpdateChrome();
			}
			startTimer();
		}

		/* ---------- events ---------- */
		if (prevBtn) prevBtn.addEventListener('click', function () {
			if (vertical) { vGo(index - 1); startTimer(); }
			else { hScrollTo(hIndexFromScroll() - 1, true); startTimer(); }
		});
		if (nextBtn) nextBtn.addEventListener('click', function () {
			if (vertical) { vGo(index + 1); startTimer(); }
			else { hScrollTo(hIndexFromScroll() + 1, true); startTimer(); }
		});
		slider.addEventListener('mouseenter', pause);
		slider.addEventListener('mouseleave', startTimer);
		slider.addEventListener('focusin', pause);
		slider.addEventListener('focusout', startTimer);
		viewport.addEventListener('touchstart', function () { lastUserScroll = Date.now(); }, { passive: true });
		viewport.addEventListener('scroll', hOnScroll, { passive: true });

		if (mq.addEventListener) mq.addEventListener('change', setMode);
		else if (mq.addListener) mq.addListener(setMode);
		window.addEventListener('load', setMode);
		window.addEventListener('resize', function () {
			if (vertical) vMeasure(); else { hMetrics(); hBuildDots(); hUpdateChrome(); }
		});
		setMode();
		startTimer();
	});
})();
