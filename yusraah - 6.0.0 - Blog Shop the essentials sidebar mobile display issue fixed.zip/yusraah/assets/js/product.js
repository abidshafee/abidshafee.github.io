/**
 * Single product buy box enhancements.
 *
 * Progressive enhancement only: every control here has a working no-JS
 * fallback. The native `<select>` stays the single source of truth for the
 * variation form, and the native quantity input stays authoritative for the
 * cart, so WooCommerce's own scripts keep working untouched.
 *
 * @package Yusraah
 */
(function ($) {
	"use strict";

	var config = window.yusraahProduct || {};
	var strings = config.strings || {};
	var gallerySettings = window.wc_single_product_params;
	var touchGallery = window.matchMedia && window.matchMedia("(hover: none), (pointer: coarse)");
	var reducedGalleryMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)");

	// WooCommerce initializes its native gallery on DOM ready, so update its
	// options now while preserving FlexSlider and PhotoSwipe themselves.
	if (gallerySettings && touchGallery && touchGallery.matches) {
		gallerySettings.zoom_enabled = false;
	}
	if (gallerySettings && reducedGalleryMotion && reducedGalleryMotion.matches && gallerySettings.flexslider) {
		gallerySettings.flexslider.animationSpeed = 0;
	}

	function format(template, value) {
		return String(template || "").replace("%s", value);
	}

	function productForm() {
		return $(".woocommerce div.product form.cart");
	}

	/* ------------------------------------------------------------------ *
	 * 1. Quantity stepper
	 *
	 * The − / + buttons live inside `.quantity`, so they drive the native
	 * input (min, max and step stay authoritative) instead of posting
	 * anything themselves.
	 * ------------------------------------------------------------------ */

	function limits(input) {
		var min = parseFloat(input.getAttribute("min"));
		var max = parseFloat(input.getAttribute("max"));
		var step = parseFloat(input.getAttribute("step"));
		var value = parseFloat(input.value);

		return {
			min: isNaN(min) ? 1 : min,
			max: isNaN(max) ? Infinity : max,
			step: !isNaN(step) && step > 0 ? step : 1,
			value: isNaN(value) ? 1 : value
		};
	}

	function renderStepper(input) {
		var wrapper = input.closest(".quantity");

		if (!wrapper) {
			return;
		}

		var bounds = limits(input);
		var minus = wrapper.querySelector('[data-product-qty-step="-1"]');
		var plus = wrapper.querySelector('[data-product-qty-step="1"]');

		if (minus) {
			minus.disabled = bounds.value <= bounds.min;
		}
		if (plus) {
			plus.disabled = bounds.value >= bounds.max;
		}
	}

	function renderSteppers() {
		productForm()
			.find(".quantity input.qty")
			.each(function () {
				renderStepper(this);
			});
	}

	function enhanceGalleryThumbs() {
		$(".woocommerce-product-gallery").each(function () {
			var gallery = this;
			var thumbs = gallery.querySelector(".flex-control-thumbs");
			var zoom = gallery.querySelector(".woocommerce-product-gallery__trigger");
			var directions = gallery.querySelectorAll(".flex-direction-nav a");

			if (zoom && !zoom.querySelector("svg")) {
				zoom.setAttribute("aria-label", strings.galleryZoom || "Zoom image");
				zoom.setAttribute("title", strings.galleryZoom || "Zoom image");
				zoom.innerHTML = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><circle cx="8.5" cy="8.5" r="5.5"></circle><path d="m12.5 12.5 4 4"></path></svg>';
			}

			directions.forEach(function (control) {
				var isPrevious = control.classList.contains("flex-prev");
				control.setAttribute("role", "button");
				control.setAttribute("aria-label", isPrevious ? (strings.galleryPrevious || "Previous image") : (strings.galleryNext || "Next image"));
				control.innerHTML = isPrevious
					? '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m12 4-6 6 6 6"></path></svg>'
					: '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m8 4 6 6-6 6"></path></svg>';
				control.addEventListener("keydown", function (event) {
					if (event.key === " ") {
						event.preventDefault();
						control.click();
					}
				});
			});

			if (!thumbs) {
				return;
			}

			function syncActiveThumb() {
				thumbs.querySelectorAll("img").forEach(function (thumb) {
					thumb.setAttribute("aria-current", String(thumb.classList.contains("flex-active")));
				});
			}

			thumbs.querySelectorAll("img").forEach(function (thumb) {
				if (thumb.getAttribute("data-yusraah-gallery-keyboard")) {
					return;
				}

				thumb.setAttribute("data-yusraah-gallery-keyboard", "true");
				thumb.setAttribute("role", "button");
				thumb.setAttribute("tabindex", "0");
				thumb.setAttribute("aria-label", thumb.getAttribute("alt") || document.title);
				thumb.addEventListener("keydown", function (event) {
					if (event.key === "Enter" || event.key === " ") {
						event.preventDefault();
						thumb.click();
					}
				});
			});

			syncActiveThumb();
			if (window.MutationObserver) {
				var observer = new MutationObserver(syncActiveThumb);
				observer.observe(thumbs, { subtree: true, attributes: true, attributeFilter: ["class"] });
			}
		});
	}

	function stepQuantity(button) {
		var wrapper = button.closest(".quantity");
		var input = wrapper ? wrapper.querySelector("input.qty") : null;

		if (!input) {
			return;
		}

		var bounds = limits(input);
		var direction = parseFloat(button.getAttribute("data-product-qty-step")) || 0;
		var next = bounds.value + direction * bounds.step;

		next = Math.min(Math.max(next, bounds.min), bounds.max);
		next = Math.round(next * 1000) / 1000;

		if (next !== bounds.value) {
			input.value = next;
			$(input).trigger("change");
		}

		renderStepper(input);
	}

	$(document).on("click.yusraahProduct", ".woocommerce div.product form.cart [data-product-qty-step]", function (event) {
		event.preventDefault();
		stepQuantity(this);
	});

	$(document).on(
		"change.yusraahProduct input.yusraahProduct",
		".woocommerce div.product form.cart .quantity input.qty",
		function () {
			renderStepper(this);
		}
	);

	/* ------------------------------------------------------------------ *
	 * 2. Variation swatches
	 *
	 * Each swatch group is printed next to (and paired with) the real
	 * `<select>`. Clicking a swatch sets the select value and triggers its
	 * change event, so WooCommerce handles matching, the gallery swap and
	 * the add to cart state exactly as it does for the dropdown.
	 * ------------------------------------------------------------------ */

	function swatchGroups() {
		return $(".woocommerce div.product form.variations_form .yusraah-swatches");
	}

	function selectForGroup(group) {
		var sibling = group.previousElementSibling;

		if (sibling && sibling.tagName === "SELECT") {
			return sibling;
		}

		return group.parentNode ? group.parentNode.querySelector("select") : null;
	}

	function optionFor(select, value) {
		for (var i = 0; i < select.options.length; i++) {
			if (select.options[i].value === value) {
				return select.options[i];
			}
		}

		return null;
	}

	function syncSwatchGroup(group, select) {
		Array.prototype.forEach.call(group.querySelectorAll(".yusraah-swatch"), function (swatch) {
			var value = swatch.getAttribute("data-value") || "";
			var option = optionFor(select, value);
			var selected = value !== "" && select.value === value;
			var unavailable = !selected && (!option || option.disabled);

			swatch.classList.toggle("is-unavailable", unavailable);
			swatch.disabled = unavailable;
			swatch.setAttribute("aria-pressed", selected ? "true" : "false");
		});
	}

	function syncSwatches() {
		swatchGroups().each(function () {
			var select = selectForGroup(this);

			if (select) {
				syncSwatchGroup(this, select);
			}
		});
	}

	function revealSwatches() {
		swatchGroups().each(function () {
			var select = selectForGroup(this);

			// Without a paired select the dropdown stays the only control.
			if (!select) {
				return;
			}

			this.hidden = false;

			var cell = this.closest("td.value");

			if (cell) {
				cell.classList.add("yusraah-swatches-active");
			}
		});
	}

	$(document).on(
		"click.yusraahProduct",
		".woocommerce div.product form.variations_form .yusraah-swatch",
		function (event) {
			event.preventDefault();

			if (this.disabled) {
				return;
			}

			var group = this.closest(".yusraah-swatches");
			var select = group ? selectForGroup(group) : null;

			if (!select) {
				return;
			}

			var value = this.getAttribute("data-value") || "";
			var option = optionFor(select, value);

			if (option && option.disabled) {
				return;
			}

			$(select).val(value).trigger("change");
			syncSwatchGroup(group, select);
		}
	);

	/* ------------------------------------------------------------------ *
	 * 3. Variation state: price, Buy Now and the selection hint
	 * ------------------------------------------------------------------ */

	function basePriceNode() {
		return $(".woocommerce div.product .yusraah-price [data-yusraah-base-price]");
	}

	function selectedPriceNode() {
		return $(".woocommerce div.product .yusraah-price [data-yusraah-selected-price]");
	}

	function showRangePrice() {
		var $base = basePriceNode();
		var $selected = selectedPriceNode();

		$selected.attr("hidden", "hidden").empty();
		$base.removeAttr("hidden");
	}

	/**
	 * Replace the price range with the chosen variation's price.
	 *
	 * The variation price is read from the markup WooCommerce just rendered
	 * into `.single_variation` (which the theme hides) so both the old and
	 * the sale price stay core generated. The discount tag is rebuilt from
	 * the variation's display prices.
	 *
	 * @param {Object} variation Variation data passed by the variation script.
	 */
	function showVariationPrice(variation) {
		var $base = basePriceNode();
		var $selected = selectedPriceNode();

		if (!$base.length || !$selected.length) {
			return;
		}

		var html = String(
			productForm().find(".single_variation .woocommerce-variation-price").html() || ""
		).trim();

		if (!variation || !html) {
			showRangePrice();
			return;
		}

		var regular = parseFloat(variation.display_regular_price);
		var price = parseFloat(variation.display_price);

		if (!isNaN(regular) && !isNaN(price) && price > 0 && regular > price) {
			var percent = Math.round(((regular - price) / regular) * 100);

			if (percent > 0) {
				html +=
					'<span class="yusraah-badge yusraah-badge--sale yusraah-price__off">' +
					format(strings.off, percent + "%") +
					"</span>";
			}
		}

		$selected.html(html).removeAttr("hidden");
		$base.attr("hidden", "hidden");
	}

	function setBuyNowState(available) {
		$("[data-yusraah-buy-now]").each(function () {
			this.disabled = !available;

			if (available) {
				this.removeAttribute("aria-disabled");
			} else {
				this.setAttribute("aria-disabled", "true");
			}
		});
	}

	function toggleHint(visible) {
		$("[data-yusraah-variations-hint]").each(function () {
			if (visible) {
				this.removeAttribute("hidden");
			} else {
				this.setAttribute("hidden", "hidden");
			}
		});
	}

	function toggleQuantity(variation) {
		var wrapper = document.querySelector(".woocommerce div.product form.cart div.quantity");

		if (!wrapper) {
			return;
		}

		// WooCommerce hides the input for sold individually variations; hide
		// the wrapping stepper with it.
		wrapper.style.display = variation && "yes" === variation.is_sold_individually ? "none" : "";
	}

	/* ------------------------------------------------------------------ *
	 * 4. Share sheet
	 * ------------------------------------------------------------------ */

	function initNativeShare() {
		if (typeof navigator.share !== "function") {
			return;
		}

		var buttons = document.querySelector(".product-social-sharing__buttons");

		if (!buttons || buttons.querySelector("[data-yusraah-share]")) {
			return;
		}

		var status = document.createElement("span");

		status.className = "screen-reader-text";
		status.setAttribute("role", "status");
		status.setAttribute("aria-live", "polite");
		buttons.parentNode.appendChild(status);

		var button = document.createElement("button");

		button.type = "button";
		button.className = "social-share-button social-share-button--native";
		button.setAttribute("data-yusraah-share", "");
		button.setAttribute("aria-label", strings.shareNative || "Share this product");
		button.innerHTML =
			'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 10.7 15.4 6.3M8.6 13.3l6.8 4.4"/></svg>';

		button.addEventListener("click", function (event) {
			event.preventDefault();

			navigator
				.share({
					title: document.title,
					text: document.title,
					url: window.location.href
				})
				.catch(function (error) {
					if (error && "AbortError" === error.name) {
						return;
					}

					if (navigator.clipboard) {
						navigator.clipboard.writeText(window.location.href).catch(function () {});
					}

					status.textContent = strings.shareFailed || "";
				});
		});

		buttons.appendChild(button);
	}

	/* ------------------------------------------------------------------ *
	 * 5. Tabs: accordion below 1024px
	 *
	 * WooCommerce prints the tab list and all panels as siblings, so no
	 * panel ever sits next to its own header. Below 1024px each panel is
	 * moved inside its header's `<li>` so the list reads as an accordion;
	 * above it the panels go back into document order. Core's tab script
	 * looks panels up by id inside the wrapper, so both layouts keep
	 * working and the panels keep their hidden state.
	 * ------------------------------------------------------------------ */

	function initTabsAccordion() {
		var wrapper = document.querySelector(".woocommerce div.product .woocommerce-tabs");

		if (!wrapper) {
			return;
		}

		var list = wrapper.querySelector("ul.tabs");

		if (!list) {
			return;
		}

		var hadTabsClass = list.classList.contains("tabs");
		var hadWcTabsClass = list.classList.contains("wc-tabs");
		var originalListRole = list.getAttribute("role");

		// Matches the CSS accordion breakpoint in theme.css.
		var query = window.matchMedia("(max-width: 1023px)");

		function panelFor(item) {
			var link = item.querySelector("a[role='tab'], a");
			var id = link && (link.getAttribute("href") || "").split("#")[1];

			return id ? wrapper.querySelector("#" + id) : null;
		}

		function animatePanel(panel, expanded) {
			if (panel._yusraahTabFrame) {
				window.cancelAnimationFrame(panel._yusraahTabFrame);
				panel._yusraahTabFrame = null;
			}
			if (panel._yusraahTabTimer) {
				window.clearTimeout(panel._yusraahTabTimer);
				panel._yusraahTabTimer = null;
			}
			if (panel._yusraahTabTransitionEnd) {
				panel.removeEventListener("transitionend", panel._yusraahTabTransitionEnd);
				panel._yusraahTabTransitionEnd = null;
			}

			var finish = function () {
				if (panel._yusraahTabFrame) {
					window.cancelAnimationFrame(panel._yusraahTabFrame);
					panel._yusraahTabFrame = null;
				}
				if (panel._yusraahTabTimer) {
					window.clearTimeout(panel._yusraahTabTimer);
					panel._yusraahTabTimer = null;
				}
				if (panel._yusraahTabTransitionEnd) {
					panel.removeEventListener("transitionend", panel._yusraahTabTransitionEnd);
					panel._yusraahTabTransitionEnd = null;
				}

				if (panel.getAttribute("aria-hidden") === "true") {
					panel.style.display = "none";
					panel.style.maxHeight = "";
					panel.style.overflow = "";
				} else {
					panel.style.maxHeight = "none";
					panel.style.overflow = "";
				}
			};

			if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
				panel.style.display = expanded ? "block" : "none";
				panel.setAttribute("aria-hidden", String(!expanded));
				finish();
				return;
			}

			panel.style.display = "block";
			panel.style.overflow = "hidden";
			if (expanded) {
				panel.style.maxHeight = "0px";
				panel.getBoundingClientRect();
			} else {
				panel.style.maxHeight = panel.getBoundingClientRect().height + "px";
			}

			panel._yusraahTabFrame = window.requestAnimationFrame(function () {
				panel._yusraahTabFrame = null;
				panel.style.maxHeight = (expanded ? panel.scrollHeight : 0) + "px";
			});

			panel._yusraahTabTransitionEnd = function (event) {
				if (event.target === panel && event.propertyName === "max-height") {
					finish();
				}
			};
			panel.addEventListener("transitionend", panel._yusraahTabTransitionEnd);
			panel._yusraahTabTimer = window.setTimeout(finish, 350);
		}

		function setExpanded(item, expanded, animate) {
			var link = item.querySelector("a[role='tab'], a");
			var panel = panelFor(item);

			if (!link || !panel) {
				return;
			}

			var wasExpanded = link.getAttribute("aria-expanded") === "true";
			item.classList.toggle("active", expanded);
			link.setAttribute("role", "button");
			link.setAttribute("aria-expanded", String(expanded));
			link.setAttribute("aria-controls", panel.id);
			link.removeAttribute("aria-selected");
			link.removeAttribute("tabindex");
			panel.classList.toggle("active", expanded);
			panel.setAttribute("aria-hidden", String(!expanded));

			if (animate && wasExpanded !== expanded) {
				animatePanel(panel, expanded);
			} else if (!animate) {
				panel.style.display = expanded ? "block" : "none";
				panel.style.maxHeight = expanded ? "none" : "";
				panel.style.overflow = "";
			}
		}

		function toggleItem(item) {
			var link = item.querySelector("a[role='tab'], a");
			var expanded = link && link.getAttribute("aria-expanded") === "true";

			Array.prototype.forEach.call(list.children, function (otherItem) {
				setExpanded(otherItem, otherItem === item && !expanded, true);
			});
		}

		function place(accordion) {
			var cursor = list;

			if (!accordion && !list.querySelector("li.active") && list.firstElementChild) {
				list.firstElementChild.classList.add("active");
			}

			if (accordion) {
				list.classList.remove("tabs", "wc-tabs");
				list.classList.add("yusraah-mobile-tabs");
				list.setAttribute("role", "group");
			} else {
				list.classList.remove("yusraah-mobile-tabs");
				if (hadTabsClass) {
					list.classList.add("tabs");
				}
				if (hadWcTabsClass) {
					list.classList.add("wc-tabs");
				}
				if (originalListRole) {
					list.setAttribute("role", originalListRole);
				} else {
					list.removeAttribute("role");
				}
			}

			Array.prototype.forEach.call(list.children, function (item) {
				var link = item.querySelector("a[role='tab'], a");

				if (!link) {
					return;
				}

				var id = (link.getAttribute("href") || "").split("#")[1];

				if (!id) {
					return;
				}

				var panel = wrapper.querySelector("#" + id);

				if (!panel) {
					return;
				}

				if (accordion) {
					if (panel.parentNode !== item) {
						item.appendChild(panel);
					}

					setExpanded(item, item.classList.contains("active"), false);
					return;
				}

				if (panel._yusraahTabFrame) {
					window.cancelAnimationFrame(panel._yusraahTabFrame);
					panel._yusraahTabFrame = null;
				}
				if (panel._yusraahTabTimer) {
					window.clearTimeout(panel._yusraahTabTimer);
					panel._yusraahTabTimer = null;
				}
				if (panel._yusraahTabTransitionEnd) {
					panel.removeEventListener("transitionend", panel._yusraahTabTransitionEnd);
					panel._yusraahTabTransitionEnd = null;
				}
				panel.removeAttribute("aria-hidden");
				panel.style.display = item.classList.contains("active") ? "block" : "none";
				panel.style.removeProperty("max-height");
				panel.style.removeProperty("overflow");
				link.setAttribute("role", "tab");
				link.removeAttribute("aria-expanded");
				link.removeAttribute("aria-controls");
				link.setAttribute("aria-selected", String(item.classList.contains("active")));
				link.setAttribute("tabindex", item.classList.contains("active") ? "0" : "-1");
				wrapper.insertBefore(panel, cursor.nextSibling);
				cursor = panel;
			});
		}

		list.addEventListener("click", function (event) {
			if (!query.matches) {
				return;
			}

			var link = event.target.closest("a");
			var item = link && link.closest("li");

			if (!item || item.parentNode !== list || link.parentNode !== item) {
				return;
			}

			event.preventDefault();
			event.stopPropagation();
			toggleItem(item);
		}, true);

		list.addEventListener("keydown", function (event) {
			if (query.matches && (event.key === " " || event.key === "Spacebar")) {
				var link = event.target.closest("a");
				var item = link && link.closest("li");

				if (item && item.parentNode === list && link.parentNode === item) {
					event.preventDefault();
					toggleItem(item);
				}
			}
		}, true);

		function sync() {
			place(query.matches);
		}

		sync();

		if (typeof query.addEventListener === "function") {
			query.addEventListener("change", sync);
		} else if (typeof query.addListener === "function") {
			query.addListener(sync);
		}
	}

	/* ------------------------------------------------------------------ *
	 * Init
	 * ------------------------------------------------------------------ */

	$(function () {
		enhanceGalleryThumbs();
		revealSwatches();
		syncSwatches();
		renderSteppers();
		initNativeShare();
		initTabsAccordion();

		var $form = productForm();

		if (!$form.hasClass("variations_form")) {
			return;
		}

		$form.on("show_variation.yusraahProduct", function (event, variation, purchasable) {
			setBuyNowState(Boolean(purchasable));
			showVariationPrice(variation);
			toggleHint(false);
			toggleQuantity(variation);

			// Core rewrites the quantity limits and the select options first.
			window.setTimeout(function () {
				syncSwatches();
				renderSteppers();
			}, 0);
		});

		$form.on("hide_variation.yusraahProduct reset_data.yusraahProduct", function () {
			setBuyNowState(false);
			showRangePrice();
			toggleHint(true);
			toggleQuantity(null);
			window.setTimeout(syncSwatches, 0);
		});

		$form.on("update_variation_values.yusraahProduct check_variations.yusraahProduct", function () {
			window.setTimeout(syncSwatches, 0);
		});
	});
})(jQuery);
