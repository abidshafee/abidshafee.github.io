(function (api) {
	'use strict';

	if (!api || !api.control) return;

	api.control('yusraah_monthly_kits_slider_categories', function (control) {
		var inputs = Array.prototype.slice.call(control.container.querySelectorAll('[data-quick-deal-category]'));

		function normalizeCategories(value) {
			if (typeof value === 'string') {
				try {
					var parsed = JSON.parse(value);
					value = Array.isArray(parsed) ? parsed : value.split(',');
				} catch (error) {
					value = value.split(',');
				}
			}
			if (!Array.isArray(value)) {
				return [];
			}

			var ids = [];
			value.forEach(function (item) {
				var id = parseInt(item, 10);
				if (id > 0 && ids.indexOf(id) === -1 && ids.length < 6) {
					ids.push(id);
				}
			});
			return ids;
		}

		function setSelected(value) {
			var ids = normalizeCategories(value);
			inputs.forEach(function (input) {
				var id = parseInt(input.getAttribute('data-quick-deal-category'), 10);
				input.checked = ids.indexOf(id) !== -1;
			});
		}

		inputs.forEach(function (input) {
			input.addEventListener('change', function () {
				var selected = normalizeCategories(control.setting.get());
				var id = parseInt(input.getAttribute('data-quick-deal-category'), 10);
				if (input.checked && selected.indexOf(id) === -1) {
					if (selected.length >= 6) {
						input.checked = false;
						return;
					}
					selected.push(id);
				} else if (!input.checked) {
					selected = selected.filter(function (item) { return item !== id; });
				}
				control.setting.set(selected);
			});
		});

		control.setting.bind(setSelected);
		setSelected(control.setting.get());
	});
}(window.wp && window.wp.customize));
