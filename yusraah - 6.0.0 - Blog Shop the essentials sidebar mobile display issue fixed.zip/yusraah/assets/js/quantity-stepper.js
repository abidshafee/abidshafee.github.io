(function ($) {
  "use strict";

  var config = window.yusraahQtyStepper || {};
  if (!config.endpoint) return;

  var strings = config.strings || {};
  var fragmentParams = window.wc_cart_fragments_params || {};
  var pending = {};

  function format(template, name, quantity) {
    return String(template || "")
      .replace("%1$s", name)
      .replace("%2$s", quantity)
      .replace("%s", name);
  }

  function announce(message) {
    var status = document.getElementById("yusraah-cart-status");
    if (!status || !message) return;
    status.textContent = "";
    window.setTimeout(function () {
      status.textContent = message;
    }, 60);
  }

  function steppersFor(productId) {
    return document.querySelectorAll('[data-qty-stepper][data-product-id="' + productId + '"]');
  }

  function render(stepper, quantity) {
    var add = stepper.querySelector("[data-qty-add]");
    var controls = stepper.querySelector(".qty-stepper__controls");
    var value = stepper.querySelector("[data-qty-value]");
    var plus = stepper.querySelector('[data-qty-step="1"]');
    var max = parseFloat(stepper.getAttribute("data-max"));

    stepper.setAttribute("data-quantity", quantity);
    stepper.classList.toggle("is-active", quantity > 0);
    if (add) add.hidden = quantity > 0;
    if (controls) controls.hidden = quantity <= 0;
    if (value) value.textContent = quantity;
    if (plus) plus.disabled = max > 0 && quantity >= max;
  }

  function renderAll(productId, quantity) {
    Array.prototype.forEach.call(steppersFor(productId), function (stepper) {
      render(stepper, quantity);
    });
  }

  function applyFragments(response) {
    if (!response.fragments) return;
    $.each(response.fragments, function (selector, html) {
      $(selector).replaceWith(html);
    });

    try {
      if (fragmentParams.fragment_name) {
        window.sessionStorage.setItem(fragmentParams.fragment_name, JSON.stringify(response.fragments));
      }
      if (fragmentParams.cart_hash_key) {
        window.sessionStorage.setItem(fragmentParams.cart_hash_key, response.cart_hash || "");
        window.localStorage.setItem(fragmentParams.cart_hash_key, response.cart_hash || "");
      }
    } catch (error) {
      // Storage can be unavailable (private mode); fragments are already on the page.
    }

    $(document.body).trigger("wc_fragments_loaded");
    $(document.body).trigger("yusraah_cart_quantity_updated", [response]);
  }

  function send(productId, name) {
    var state = pending[productId];
    if (!state || state.request) return;

    var target = state.target;
    state.request = $.ajax({
      url: config.endpoint,
      type: "POST",
      dataType: "json",
      data: { product_id: productId, quantity: target }
    })
      .done(function (response) {
        if (!response || typeof response.quantity === "undefined") {
          state.request = null;
          fail(productId);
          return;
        }

        state.request = null;
        state.confirmed = response.quantity;
        applyFragments(response);

        if (state.target !== target && !response.message) {
          send(productId, name);
          return;
        }

        delete pending[productId];
        renderAll(productId, response.quantity);
        announce(
          response.message ||
            (response.quantity > 0
              ? format(strings.inBasket, name, response.quantity)
              : format(strings.removed, name))
        );
      })
      .fail(function () {
        state.request = null;
        fail(productId);
      });
  }

  function fail(productId) {
    var state = pending[productId];
    delete pending[productId];
    renderAll(productId, state ? state.confirmed : 0);
    announce(strings.failed);
  }

  document.addEventListener("click", function (event) {
    var stepper = event.target.closest && event.target.closest("[data-qty-stepper]");
    if (!stepper) return;

    var add = event.target.closest("[data-qty-add]");
    var step = event.target.closest("[data-qty-step]");
    if (!add && !step) return;
    if (add) {
      if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
    }

    var productId = stepper.getAttribute("data-product-id");
    var name = stepper.getAttribute("data-product-name") || "";
    var min = parseFloat(stepper.getAttribute("data-min")) || 1;
    var max = parseFloat(stepper.getAttribute("data-max"));
    var current = pending[productId]
      ? pending[productId].target
      : parseFloat(stepper.getAttribute("data-quantity")) || 0;
    var next;

    if (add) {
      next = Math.max(min, 1);
    } else {
      var direction = parseInt(step.getAttribute("data-qty-step"), 10);
      next = current + direction;
      if (direction < 0 && next < min) next = 0;
      if (direction > 0 && next < min) next = min;
    }
    if (max > 0 && next > max) next = max;
    if (next === current) return;

    if (!pending[productId]) {
      pending[productId] = { confirmed: current, target: current, request: null, timer: null };
    }
    pending[productId].target = next;
    renderAll(productId, next);

    if (add) {
      var plus = stepper.querySelector('[data-qty-step="1"]');
      var minus = stepper.querySelector('[data-qty-step="-1"]');
      (plus && !plus.disabled ? plus : minus).focus();
    } else if (next === 0) {
      var addButton = stepper.querySelector("[data-qty-add]");
      if (addButton) addButton.focus();
    }

    window.clearTimeout(pending[productId].timer);
    pending[productId].timer = window.setTimeout(function () {
      send(productId, name);
    }, add ? 0 : 350);
  });

  function syncFromCart() {
    var source = document.getElementById("yusraah-cart-quantities");
    if (!source) return;

    var quantities;
    try {
      quantities = JSON.parse(source.getAttribute("data-quantities") || "{}");
    } catch (error) {
      return;
    }

    Array.prototype.forEach.call(document.querySelectorAll("[data-qty-stepper]"), function (stepper) {
      var productId = stepper.getAttribute("data-product-id");
      if (pending[productId]) return;
      render(stepper, quantities[productId] ? parseFloat(quantities[productId]) : 0);
    });
  }

  $(document.body).on("wc_fragments_loaded wc_fragments_refreshed added_to_cart removed_from_cart", function () {
    window.setTimeout(syncFromCart, 0);
  });
})(jQuery);
