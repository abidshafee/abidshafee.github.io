(function ($) {
  "use strict";

  var drawer = document.getElementById("yusraah-cart-drawer");
  var trigger = document.querySelector("[data-cart-drawer-toggle]");
  if (!drawer || !trigger) return;

  var panel = drawer.querySelector(".cart-drawer__panel");
  var closeButton = drawer.querySelector(".cart-drawer__close");
  var previousFocus = null;
  var closeTimer = null;

  function getFocusableItems() {
    return panel.querySelectorAll(
      'a[href]:not([tabindex="-1"]), button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    );
  }

  function openDrawer() {
    if (closeTimer) {
      window.clearTimeout(closeTimer);
      closeTimer = null;
    }
    if (!drawer.hidden && drawer.classList.contains("is-open")) return;

    previousFocus = document.activeElement;
    drawer.hidden = false;
    drawer.setAttribute("aria-hidden", "false");
    trigger.setAttribute("aria-expanded", "true");
    document.body.classList.add("cart-drawer-open");

    window.requestAnimationFrame(function () {
      drawer.classList.add("is-open");
      if (closeButton) closeButton.focus();
    });
  }

  function closeDrawer() {
    if (drawer.hidden) return;
    drawer.classList.remove("is-open");
    drawer.setAttribute("aria-hidden", "true");
    trigger.setAttribute("aria-expanded", "false");
    document.body.classList.remove("cart-drawer-open");

    closeTimer = window.setTimeout(function () {
      drawer.hidden = true;
      closeTimer = null;
    }, 240);

    if (previousFocus && typeof previousFocus.focus === "function") {
      previousFocus.focus();
    } else {
      trigger.focus();
    }
  }

  trigger.addEventListener("click", function (event) {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    openDrawer();
  });

  drawer.addEventListener("click", function (event) {
    if (event.target.closest("[data-cart-drawer-close]")) closeDrawer();
  });

  document.addEventListener("keydown", function (event) {
    if (drawer.hidden) return;

    if (event.key === "Escape") {
      event.preventDefault();
      closeDrawer();
      return;
    }

    if (event.key !== "Tab") return;
    var items = getFocusableItems();
    if (!items.length) {
      event.preventDefault();
      panel.focus();
      return;
    }

    var first = items[0];
    var last = items[items.length - 1];
    if (event.shiftKey && (document.activeElement === first || document.activeElement === panel)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  function shouldOpenOnAdd() {
    var toast = window.yusraahCartToast;
    if (!toast || !toast.enabled) return true;
    return toast.action === "drawer" || toast.action === "both";
  }

  $(document.body).on("added_to_cart", function () {
    if (shouldOpenOnAdd()) {
      openDrawer();
    }
  });

  document.body.addEventListener("wc-blocks_added_to_cart", function () {
    if (shouldOpenOnAdd()) {
      openDrawer();
    }
  });
})(jQuery);
