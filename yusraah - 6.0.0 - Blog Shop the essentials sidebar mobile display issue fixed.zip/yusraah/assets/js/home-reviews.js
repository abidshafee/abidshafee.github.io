/**
 * Accessible homepage customer review carousel.
 */
(function () {
	'use strict';

	function initCarousel(root) {
		var viewport = root.querySelector('.reviews-carousel__viewport');
		var track = root.querySelector('[data-reviews-track]');
		var controls = root.querySelector('[data-reviews-controls]');
		var dotsContainer = root.querySelector('[data-reviews-dots]');
		var previous = root.querySelector('[data-reviews-prev]');
		var next = root.querySelector('[data-reviews-next]');
		var slides = Array.prototype.slice.call(root.querySelectorAll('[data-review-slide]'));

		if (!viewport || !track || !slides.length) {
			return;
		}

		var autoplay = root.getAttribute('data-autoplay') === 'true';
		var speed = parseInt(root.getAttribute('data-speed'), 10) || 4500;
		var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
		var timer = null;
		var current = 0;
		var visible = 1;
		var hovered = false;
		var focused = false;
		var pageVisible = !document.hidden;
		var pointerStart = null;
		var suppressClick = false;
		var prefixClones = [];
		var tailClones = [];

		function visibleCount() {
			var count = parseInt(window.getComputedStyle(root).getPropertyValue('--review-visible'), 10);
			return Math.max(1, Math.min(slides.length, count || 1));
		}

		function updateAccessibility() {
			var prefixCount = prefixClones.length;
			var position = prefixCount + current;

			slides.forEach(function (slide, index) {
				var physicalIndex = prefixCount + index;
				var isVisible = physicalIndex >= position && physicalIndex < position + visible;

				slide.setAttribute('aria-hidden', String(!isVisible));
				setInert(slide, !isVisible);
			});

			prefixClones.concat(tailClones).forEach(function (entry) {
				var physicalIndex = entry.position;
				var isVisible = physicalIndex >= position && physicalIndex < position + visible;

				entry.slide.setAttribute('aria-hidden', String(!isVisible));
				setInert(entry.slide, !isVisible);
			});
		}

		function setInert(slide, isInert) {
			if ('inert' in slide) {
				slide.inert = isInert;
				return;
			}

			slide.querySelectorAll('a, button, input, select, textarea, [tabindex]').forEach(function (element) {
				if (isInert) {
					if (!element.hasAttribute('data-review-tabindex')) {
						element.setAttribute('data-review-tabindex', element.getAttribute('tabindex') || '');
					}
					element.setAttribute('tabindex', '-1');
				} else if (element.hasAttribute('data-review-tabindex')) {
					var originalTabindex = element.getAttribute('data-review-tabindex');
					if (originalTabindex) {
						element.setAttribute('tabindex', originalTabindex);
					} else {
						element.removeAttribute('tabindex');
					}
					element.removeAttribute('data-review-tabindex');
				}
			});
		}

		function updateDots() {
			var dots = dotsContainer.querySelectorAll('[data-review-dot]');
			var activeIndex = ((current % slides.length) + slides.length) % slides.length;
			dots.forEach(function (dot, index) {
				var active = index === activeIndex;
				dot.setAttribute('aria-current', String(active));
				dot.tabIndex = active ? 0 : -1;
			});
		}

		function stepSize() {
			var slide = track.querySelector('[data-review-slide]');
			var styles = window.getComputedStyle(track);
			var gap = parseFloat(styles.columnGap || styles.gap) || 0;

			return slide ? slide.getBoundingClientRect().width + gap : 0;
		}

		function move(animate) {
			if (!animate) {
				track.style.transition = 'none';
			}

			track.style.transform = 'translate3d(-' + (stepSize() * (prefixClones.length + current)) + 'px, 0, 0)';
			updateAccessibility();
			updateDots();

			if (!animate) {
				track.offsetWidth;
				track.style.removeProperty('transition');
			}
		}

		function clearClones() {
			prefixClones.concat(tailClones).forEach(function (entry) {
				entry.slide.remove();
			});
			prefixClones = [];
			tailClones = [];
		}

		function buildDots() {
			dotsContainer.textContent = '';

			slides.forEach(function (_, index) {
				var dot = document.createElement('button');
				dot.className = 'reviews-carousel__dot';
				dot.type = 'button';
				dot.setAttribute('data-review-dot', String(index));
				dot.setAttribute('aria-label', root.getAttribute('data-dot-label') + ' ' + (index + 1));
				dot.setAttribute('aria-current', 'false');
				dot.tabIndex = -1;
				dot.addEventListener('click', function () {
					stop();
					settleLoop();
					current = index;
					move(true);
					setLiveMode('polite');
					schedule();
				});
				dot.addEventListener('keydown', function (event) {
					if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') {
						return;
					}

					event.preventDefault();
					event.stopPropagation();
					var nextIndex = (index + (event.key === 'ArrowRight' ? 1 : -1) + slides.length) % slides.length;
					var nextDot = dotsContainer.querySelector('[data-review-dot="' + nextIndex + '"]');
					if (nextDot) {
						nextDot.click();
						nextDot.focus();
					}
				});
				dotsContainer.appendChild(dot);
			});
		}

		function setLiveMode(mode) {
			track.setAttribute('aria-live', mode);
		}

		function stop() {
			if (timer) {
				window.clearInterval(timer);
				timer = null;
			}
		}

		function canAutoPlay() {
			return autoplay && slides.length > visible && !reducedMotion.matches &&
				!hovered && !focused && pageVisible;
		}

		function schedule() {
			stop();
			if (canAutoPlay()) {
				setLiveMode('off');
				timer = window.setInterval(advance, speed);
			} else {
				setLiveMode('polite');
			}
		}

		function advance() {
			current += 1;
			move(true);
		}

		function settleLoop() {
			if (current >= slides.length) {
				current = 0;
				move(false);
			} else if (current < 0) {
				current = slides.length - 1;
				move(false);
			}
		}

		function previousSlide() {
			stop();
			settleLoop();
			current = current > 0 ? current - 1 : (reducedMotion.matches ? slides.length - 1 : -1);
			move(true);
			setLiveMode('polite');
			schedule();
		}

		function nextSlide() {
			stop();
			settleLoop();
			current = reducedMotion.matches ? (current + 1) % slides.length : current + 1;
			move(true);
			setLiveMode('polite');
			schedule();
		}

		function onTransitionEnd(event) {
			if (event.target !== track || event.propertyName !== 'transform' || (current >= 0 && current < slides.length)) {
				return;
			}

			current = current < 0 ? slides.length - 1 : 0;
			move(false);
		}

		function setUpClones() {
			clearClones();
			visible = visibleCount();

			if (slides.length > visible) {
				var prefixFragment = document.createDocumentFragment();
				slides.slice(-visible).forEach(function (slide, index) {
					var clone = slide.cloneNode(true);
					clone.removeAttribute('id');
					clone.setAttribute('data-review-clone', '');
					clone.setAttribute('aria-hidden', 'true');
					setInert(clone, true);
					prefixClones.push({ slide: clone, position: index });
					prefixFragment.appendChild(clone);
				});
				track.insertBefore(prefixFragment, track.firstChild);

				var tailFragment = document.createDocumentFragment();
				slides.slice(0, visible).forEach(function (slide, index) {
					var clone = slide.cloneNode(true);
					clone.removeAttribute('id');
					clone.setAttribute('data-review-clone', '');
					clone.setAttribute('aria-hidden', 'true');
					setInert(clone, true);
					tailClones.push({ slide: clone, position: visible + slides.length + index });
					tailFragment.appendChild(clone);
				});
				track.appendChild(tailFragment);
			}

			current = ((current % slides.length) + slides.length) % slides.length;
			controls.hidden = slides.length <= visible;
			move(false);
			schedule();
		}

		function checkTextOverflow() {
			root.querySelectorAll('[data-review-text]').forEach(function (text) {
				var button = text.parentNode.querySelector('[data-review-more]');
				if (button && !text.classList.contains('is-expanded')) {
					button.hidden = text.scrollHeight <= text.clientHeight + 1;
				}
			});
		}

		root.addEventListener('click', function (event) {
			if (suppressClick) {
				event.preventDefault();
				event.stopPropagation();
				suppressClick = false;
				return;
			}

			var more = event.target.closest('[data-review-more]');
			if (!more) {
				return;
			}

			var text = more.parentNode.querySelector('[data-review-text]');
			var expanded = more.getAttribute('aria-expanded') === 'true';
			text.classList.toggle('is-expanded', !expanded);
			more.setAttribute('aria-expanded', String(!expanded));
			more.textContent = expanded ? more.getAttribute('data-more-label') : more.getAttribute('data-less-label');
		});

		root.addEventListener('error', function (event) {
			if (event.target.matches('.review-card__avatar-image')) {
				event.target.remove();
			}
		}, true);

		root.addEventListener('mouseenter', function () {
			hovered = true;
			stop();
		});
		root.addEventListener('mouseleave', function () {
			hovered = false;
			schedule();
		});
		root.addEventListener('focusin', function () {
			focused = true;
			stop();
		});
		root.addEventListener('focusout', function (event) {
			if (!root.contains(event.relatedTarget)) {
				focused = false;
				schedule();
			}
		});
		root.addEventListener('keydown', function (event) {
			if (event.key === 'ArrowLeft') {
				event.preventDefault();
				previousSlide();
			} else if (event.key === 'ArrowRight') {
				event.preventDefault();
				nextSlide();
			}
		});

		root.addEventListener('pointerdown', function (event) {
			if (event.pointerType === 'mouse' && event.button !== 0) {
				return;
			}
			pointerStart = { x: event.clientX, y: event.clientY };
		});
		root.addEventListener('pointerup', function (event) {
			if (!pointerStart) {
				return;
			}
			var deltaX = event.clientX - pointerStart.x;
			var deltaY = event.clientY - pointerStart.y;
			pointerStart = null;

			if (Math.abs(deltaX) < 40 || Math.abs(deltaX) < Math.abs(deltaY)) {
				return;
			}

			suppressClick = true;
			window.setTimeout(function () {
				suppressClick = false;
			}, 0);
			if (deltaX < 0) {
				nextSlide();
			} else {
				previousSlide();
			}
		});
		root.addEventListener('pointercancel', function () {
			pointerStart = null;
		});

		previous.addEventListener('click', previousSlide);
		next.addEventListener('click', nextSlide);
		track.addEventListener('transitionend', onTransitionEnd);
		document.addEventListener('visibilitychange', function () {
			pageVisible = !document.hidden;
			schedule();
		});

		if (typeof reducedMotion.addEventListener === 'function') {
			reducedMotion.addEventListener('change', schedule);
		} else if (typeof reducedMotion.addListener === 'function') {
			reducedMotion.addListener(schedule);
		}

		var resizeTimer = null;
		window.addEventListener('resize', function () {
			window.clearTimeout(resizeTimer);
			resizeTimer = window.setTimeout(function () {
				setUpClones();
				checkTextOverflow();
			}, 120);
		});

		root.classList.add('is-ready');
		buildDots();
		setUpClones();
		checkTextOverflow();
	}

	function boot() {
		document.querySelectorAll('[data-home-reviews]').forEach(initCarousel);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
