(function () {
  "use strict";

  // Hero Product Carousel
  var heroCarousel = document.getElementById("hero-product-carousel");
  if (heroCarousel) {
    var carouselItems = heroCarousel.querySelectorAll(".hero-carousel-item");
    var currentIndex = 0;
    var autoSlideInterval;
    var slideDelay = 4000; // 4 seconds per slide

    function showSlide(index) {
      if (index < 0) index = carouselItems.length - 1;
      if (index >= carouselItems.length) index = 0;
      currentIndex = index;

      var offset = -currentIndex * 100;
      heroCarousel.style.transform = "translateX(" + offset + "%)";

      // Re-trigger animation
      carouselItems.forEach(function(item, i) {
        item.style.animation = "none";
        if (i === currentIndex) {
          item.offsetHeight; // Trigger reflow
          item.style.animation = "slideIn 0.5s ease-in-out";
        }
      });
    }

    function nextSlide() {
      showSlide(currentIndex + 1);
    }

    function prevSlide() {
      showSlide(currentIndex - 1);
    }

    function startAutoSlide() {
      autoSlideInterval = setInterval(nextSlide, slideDelay);
    }

    function stopAutoSlide() {
      clearInterval(autoSlideInterval);
    }

    // Navigation buttons
    var prevBtn = document.querySelector(".hero-carousel-nav__prev");
    var nextBtn = document.querySelector(".hero-carousel-nav__next");

    if (prevBtn) {
      prevBtn.addEventListener("click", function() {
        stopAutoSlide();
        prevSlide();
        startAutoSlide();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener("click", function() {
        stopAutoSlide();
        nextSlide();
        startAutoSlide();
      });
    }

    // Pause on hover
    heroCarousel.addEventListener("mouseenter", stopAutoSlide);
    heroCarousel.addEventListener("mouseleave", startAutoSlide);

    // Start auto-slide
    if (carouselItems.length > 1) {
      startAutoSlide();
    }
  }

  // Sticky header
  var siteHeader = document.querySelector("#site-header");
  var lastScrollTop = 0;
  var scrollThreshold = 50;

  if (siteHeader) {
    window.addEventListener("scroll", function () {
      var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      if (scrollTop > scrollThreshold) {
        siteHeader.classList.add("is-scrolled");
      } else {
        siteHeader.classList.remove("is-scrolled");
      }
      lastScrollTop = scrollTop;
    }, { passive: true });
  }

  var productGrid = document.querySelector(".single-product .yusraah-product-grid");
  var productSummary = productGrid && productGrid.querySelector(".yusraah-product-summary-column .summary");
  var desktopProductViewport = window.matchMedia("(min-width: 1024px)");

  if (productSummary) {
    var productMetricsObserver = null;

    function updateProductStickyMetrics() {
      if (!desktopProductViewport.matches) return;

      productSummary.style.setProperty(
        "--yusraah-buybox-height",
        Math.ceil(productSummary.getBoundingClientRect().height) + "px"
      );
      if (siteHeader) {
        document.documentElement.style.setProperty(
          "--yusraah-header-height",
          Math.ceil(siteHeader.getBoundingClientRect().height) + "px"
        );
      }
    }

    function observeProductStickyMetrics() {
      if (productMetricsObserver) {
        productMetricsObserver.disconnect();
        productMetricsObserver = null;
      }

      if (!desktopProductViewport.matches) {
        productSummary.style.removeProperty("--yusraah-buybox-height");
        return;
      }

      updateProductStickyMetrics();
      if (window.ResizeObserver) {
        productMetricsObserver = new ResizeObserver(updateProductStickyMetrics);
        productMetricsObserver.observe(productSummary);
        if (siteHeader) productMetricsObserver.observe(siteHeader);
      }
    }

    observeProductStickyMetrics();
    if (typeof desktopProductViewport.addEventListener === "function") {
      desktopProductViewport.addEventListener("change", observeProductStickyMetrics);
    } else if (typeof desktopProductViewport.addListener === "function") {
      desktopProductViewport.addListener(observeProductStickyMetrics);
    }

    if (!window.ResizeObserver) {
      window.addEventListener("resize", updateProductStickyMetrics, { passive: true });
      window.addEventListener("scroll", updateProductStickyMetrics, { passive: true });
    }
  }

  var searchToggle = document.querySelector(".search-toggle");
  var searchPanel = document.querySelector("#site-search-panel");
  if (searchToggle && searchPanel) {
    searchToggle.addEventListener("click", function () {
      var isOpen = searchToggle.getAttribute("aria-expanded") === "true";
      searchToggle.setAttribute("aria-expanded", String(!isOpen));
      searchPanel.hidden = isOpen;
      if (isOpen) {
        cancelProductSearch();
        closeProductSuggestions();
      }
      if (!isOpen) {
        var field = searchPanel.querySelector('input[type="search"]');
        if (field) field.focus();
      }
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && !searchPanel.hidden) {
        searchPanel.hidden = true;
        searchToggle.setAttribute("aria-expanded", "false");
        searchToggle.focus();
      }
    });
  }

  var productSearch = document.querySelector("[data-product-search]");
  var suggestionList = document.querySelector("#yusraah-search-suggestions");
  var searchStatus = document.querySelector("#yusraah-search-status");
  var searchConfig = window.yusraahSearch || {};
  var searchTimer = null;
  var searchRequest = null;
  var activeSuggestion = -1;
  var requestNumber = 0;

  function closeProductSuggestions() {
    if (!productSearch || !suggestionList) return;
    suggestionList.hidden = true;
    productSearch.setAttribute("aria-expanded", "false");
    productSearch.removeAttribute("aria-activedescendant");
    activeSuggestion = -1;
    Array.prototype.forEach.call(suggestionList.querySelectorAll('[role="option"]'), function (option) {
      option.setAttribute("aria-selected", "false");
    });
  }

  function cancelProductSearch() {
    window.clearTimeout(searchTimer);
    if (searchRequest) searchRequest.abort();
    requestNumber += 1;
  }

  function setActiveSuggestion(index) {
    var options = suggestionList.querySelectorAll('[role="option"]');
    if (!options.length) return;

    activeSuggestion = (index + options.length) % options.length;
    Array.prototype.forEach.call(options, function (option, optionIndex) {
      var isActive = optionIndex === activeSuggestion;
      option.setAttribute("aria-selected", String(isActive));
      if (isActive) {
        productSearch.setAttribute("aria-activedescendant", option.id);
        option.scrollIntoView({ block: "nearest" });
      }
    });
  }

  function safeSearchUrl(value) {
    try {
      var url = new URL(value, window.location.href);
      return url.protocol === "http:" || url.protocol === "https:" ? url.href : "";
    } catch (error) {
      return "";
    }
  }

  function showProductSuggestions(results) {
    suggestionList.replaceChildren();
    activeSuggestion = -1;
    productSearch.removeAttribute("aria-activedescendant");

    results.slice(0, 6).forEach(function (product, index) {
      var url = safeSearchUrl(product.url);
      if (!url || typeof product.name !== "string") return;

      var option = document.createElement("a");
      option.className = "search-suggestion";
      option.href = url;
      option.id = "yusraah-search-option-" + index;
      option.setAttribute("role", "option");
      option.setAttribute("aria-selected", "false");
      option.tabIndex = -1;

      var imageUrl = safeSearchUrl(product.image);
      if (imageUrl) {
        var image = document.createElement("img");
        image.src = imageUrl;
        image.alt = "";
        image.loading = "lazy";
        option.appendChild(image);
      }

      var name = document.createElement("span");
      name.className = "search-suggestion__name";
      name.textContent = product.name;
      option.appendChild(name);

      var price = document.createElement("span");
      price.className = "search-suggestion__price";
      price.textContent = typeof product.price === "string" ? product.price : "";
      option.appendChild(price);

      suggestionList.appendChild(option);
    });

    if (!suggestionList.children.length) {
      closeProductSuggestions();
      searchStatus.textContent = searchConfig.strings.noResults;
      return;
    }

    suggestionList.hidden = false;
    productSearch.setAttribute("aria-expanded", "true");
    searchStatus.textContent = searchConfig.strings.resultsFound.replace("%d", String(suggestionList.children.length));
  }

  if (productSearch && suggestionList && searchStatus && searchConfig.ajaxUrl) {
    productSearch.addEventListener("input", function () {
      window.clearTimeout(searchTimer);
      if (searchRequest) searchRequest.abort();
      var currentRequest = ++requestNumber;

      var term = productSearch.value.trim();
      if (term.length < 2) {
        closeProductSuggestions();
        searchStatus.textContent = "";
        return;
      }

      closeProductSuggestions();
      searchStatus.textContent = searchConfig.strings.searching;

      searchTimer = window.setTimeout(function () {
        searchRequest = new AbortController();
        var formData = new FormData();
        formData.append("action", "yusraah_product_search");
        formData.append("nonce", searchConfig.nonce || "");
        formData.append("term", term);

        fetch(searchConfig.ajaxUrl, {
          method: "POST",
          credentials: "same-origin",
          body: formData,
          signal: searchRequest.signal
        })
          .then(function (response) {
            if (!response.ok) throw new Error("Product search request failed");
            return response.json();
          })
          .then(function (response) {
            if (currentRequest !== requestNumber) return;
            if (!response.success || !response.data || !Array.isArray(response.data.results)) {
              throw new Error("Invalid product search response");
            }
            if (response.data.results.length) {
              showProductSuggestions(response.data.results);
            } else {
              closeProductSuggestions();
              searchStatus.textContent = searchConfig.strings.noResults;
            }
          })
          .catch(function (error) {
            if (error.name === "AbortError" || currentRequest !== requestNumber) return;
            closeProductSuggestions();
            searchStatus.textContent = searchConfig.strings.failed;
          });
      }, 250);
    });

    productSearch.addEventListener("keydown", function (event) {
      var options = suggestionList.querySelectorAll('[role="option"]');
      if (event.key === "ArrowDown" && !suggestionList.hidden) {
        event.preventDefault();
        setActiveSuggestion(activeSuggestion + 1);
      } else if (event.key === "ArrowUp" && !suggestionList.hidden) {
        event.preventDefault();
        setActiveSuggestion(activeSuggestion < 0 ? options.length - 1 : activeSuggestion - 1);
      } else if (event.key === "Enter" && activeSuggestion >= 0 && options[activeSuggestion]) {
        event.preventDefault();
        options[activeSuggestion].click();
      } else if (event.key === "Escape" && !suggestionList.hidden) {
        event.preventDefault();
        event.stopPropagation();
        cancelProductSearch();
        closeProductSuggestions();
        searchStatus.textContent = "";
      }
    });
  }

  var stickyProductCart = document.querySelector("[data-sticky-product-cart]");
  if (stickyProductCart) {
    var productRoot = stickyProductCart.closest(".product");
    var productForm = productRoot && productRoot.querySelector(".summary form.cart");
    var mainAddButton = productForm && productForm.querySelector(".single_add_to_cart_button");
    var stickyAddButton = stickyProductCart.querySelector("[data-sticky-add-to-cart]");
    var stickyQuantity = stickyProductCart.querySelector("[data-sticky-quantity]");
    var mainQuantity = productForm && productForm.querySelector(".quantity input.qty");
    var stickyStatus = stickyProductCart.querySelector("[data-sticky-cart-status]");
    var stickyPrice = stickyProductCart.querySelector("[data-sticky-product-price]");
    var defaultPriceMarkup = stickyPrice ? stickyPrice.innerHTML : "";
    var stickyCartStrings = (window.yusraahStickyCart && window.yusraahStickyCart.strings) || {};
    var mobileViewport = window.matchMedia("(max-width: 767px)");
    var stickyObserver = null;
    var mainButtonWasVisible = false;

    function setStickyCartVisible(isVisible) {
      var visible = isVisible && mobileViewport.matches;
      var wasVisible = stickyProductCart.classList.contains("is-visible");
      if (!visible && wasVisible && stickyProductCart.contains(document.activeElement) && mainAddButton) {
        var focusTarget = mainAddButton;
        if (mainAddButton.disabled) {
          focusTarget = productForm.querySelector(".variations select:not(:disabled)") || productForm;
          if (focusTarget === productForm) productForm.setAttribute("tabindex", "-1");
        }
        focusTarget.focus({ preventScroll: true });
      }
      stickyProductCart.classList.toggle("is-visible", visible);
      stickyProductCart.setAttribute("aria-hidden", String(!visible));
      stickyProductCart.inert = !visible;
      if (visible && !wasVisible && stickyStatus) {
        stickyStatus.textContent = stickyCartStrings.available || "";
      }
    }

    function syncQuantityFromMain() {
      if (!mainQuantity || !stickyQuantity) return;
      stickyQuantity.value = mainQuantity.value;
    }

    function syncQuantityToMain() {
      if (!mainQuantity || !stickyQuantity) return;
      mainQuantity.value = stickyQuantity.value;
      mainQuantity.dispatchEvent(new Event("input", { bubbles: true }));
      mainQuantity.dispatchEvent(new Event("change", { bubbles: true }));
    }

    function syncQuantityConstraints() {
      if (!mainQuantity || !stickyQuantity) return;
      ["min", "max", "step"].forEach(function (attribute) {
        if (mainQuantity.hasAttribute(attribute)) {
          stickyQuantity.setAttribute(attribute, mainQuantity.getAttribute(attribute));
        } else {
          stickyQuantity.removeAttribute(attribute);
        }
      });
      syncQuantityFromMain();
    }

    function setVariationPrice() {
      if (!productForm || !stickyPrice) return;
      var selectedPrice = productForm.querySelector(".woocommerce-variation-price .price, .single_variation .price");
      if (selectedPrice && selectedPrice.textContent.trim()) {
        stickyPrice.textContent = selectedPrice.textContent.trim();
      }
    }

    function resetVariationPrice() {
      if (stickyPrice) stickyPrice.innerHTML = defaultPriceMarkup;
    }

    function initializeStickyObserver() {
      if (stickyObserver) {
        stickyObserver.disconnect();
        stickyObserver = null;
      }
      mainButtonWasVisible = false;
      setStickyCartVisible(false);

      if (!mobileViewport.matches || !mainAddButton || !window.IntersectionObserver) return;

      if (mainAddButton.getBoundingClientRect().bottom <= 0) {
        mainButtonWasVisible = true;
        setStickyCartVisible(true);
      }

      stickyObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            mainButtonWasVisible = true;
            setStickyCartVisible(false);
          } else if (mainButtonWasVisible && entry.boundingClientRect.bottom <= 0) {
            setStickyCartVisible(true);
          } else {
            setStickyCartVisible(false);
          }
        });
      }, { threshold: 0 });
      stickyObserver.observe(mainAddButton);
    }

    if (productForm && mainAddButton && stickyAddButton) {
      initializeStickyObserver();
      if (typeof mobileViewport.addEventListener === "function") {
        mobileViewport.addEventListener("change", initializeStickyObserver);
      } else if (typeof mobileViewport.addListener === "function") {
        mobileViewport.addListener(initializeStickyObserver);
      }

      if (mainQuantity && stickyQuantity) {
        mainQuantity.addEventListener("input", syncQuantityFromMain);
        mainQuantity.addEventListener("change", syncQuantityFromMain);
        stickyQuantity.addEventListener("input", syncQuantityToMain);
        stickyQuantity.addEventListener("change", syncQuantityToMain);
        syncQuantityConstraints();
      }

      if (window.jQuery && productForm.classList.contains("variations_form")) {
        window.jQuery(productForm).on("show_variation", function () {
          setVariationPrice();
          syncQuantityConstraints();
          if (stickyStatus) stickyStatus.textContent = "";
        });
        window.jQuery(productForm).on("hide_variation reset_data", function () {
          resetVariationPrice();
          syncQuantityConstraints();
          if (stickyStatus) stickyStatus.textContent = "";
        });
      }

      function addProductFromStickyBar() {
        var wcParams = window.wc_add_to_cart_params || {};
        var endpoint = wcParams.wc_ajax_url ? String(wcParams.wc_ajax_url).replace("%%endpoint%%", "add_to_cart") : "";
        var productIdField = productForm.querySelector('[name="product_id"]');
        var productId = productIdField ? productIdField.value : "";
        if (!productId) {
          productId = mainAddButton.value || mainAddButton.getAttribute("data-product_id") || "";
        }
        if (!endpoint || !productId) {
          mainAddButton.click();
          return;
        }

        var formData = new FormData(productForm);
        // Do NOT send add-to-cart: WC_Form_Handler::add_to_cart_action also
        // processes it on wp_loaded and would add the item a second time.
        // The wc-ajax endpoint only needs product_id and quantity.
        formData.delete("add-to-cart");
        formData.set("product_id", productId);
        formData.set("quantity", mainQuantity ? mainQuantity.value : "1");

        var originalLabel = stickyAddButton.textContent;
        stickyAddButton.disabled = true;
        stickyAddButton.setAttribute("aria-busy", "true");
        stickyAddButton.textContent = stickyCartStrings.adding || originalLabel;

        fetch(endpoint, {
          method: "POST",
          credentials: "same-origin",
          body: formData
        })
          .then(function (response) {
            if (!response.ok) throw new Error("Add to cart request failed");
            return response.json();
          })
          .then(function (response) {
            if (response.error) {
              mainAddButton.click();
              return;
            }
            if (!response.fragments || !window.jQuery) {
              throw new Error("Add to cart response was incomplete");
            }
            window.jQuery(document.body).trigger("added_to_cart", [
              response.fragments,
              response.cart_hash,
              window.jQuery(stickyAddButton)
            ]);
          })
          .catch(function () {
            if (stickyStatus) stickyStatus.textContent = stickyCartStrings.addFailed || "";
          })
          .finally(function () {
            stickyAddButton.disabled = false;
            stickyAddButton.removeAttribute("aria-busy");
            stickyAddButton.textContent = originalLabel;
          });
      }

      stickyAddButton.addEventListener("click", function () {
        if (stickyQuantity && !stickyQuantity.checkValidity()) {
          stickyQuantity.reportValidity();
          return;
        }
        syncQuantityToMain();

        if (mainAddButton.disabled) {
          var unselectedOption = null;
          var selects = productForm.querySelectorAll(".variations select:not(:disabled)");
          for (var index = 0; index < selects.length; index += 1) {
            if (!selects[index].value) {
              unselectedOption = selects[index];
              break;
            }
          }

          if (unselectedOption) {
            if (stickyStatus) stickyStatus.textContent = stickyCartStrings.chooseOptions || "";
            unselectedOption.focus();
            unselectedOption.scrollIntoView({ block: "center" });
          } else if (stickyStatus) {
            stickyStatus.textContent = stickyCartStrings.unavailable || "";
          }
          return;
        }

        if (stickyStatus) stickyStatus.textContent = "";
        addProductFromStickyBar();
      });
    }
  }

  var checkoutForm = document.querySelector(".woocommerce-checkout form.checkout");
  var checkoutStrings = (window.yusraahCheckout && window.yusraahCheckout.strings) || {};
  if (checkoutForm) {
    var inlineErrorCounter = 0;

    function isBangladeshCheckout() {
      var country = checkoutForm.querySelector("#billing_country");
      return !country || !country.value || country.value === "BD";
    }

    function isBdMobile(value) {
      var digits = String(value)
        .replace(/[\u09E6-\u09EF]/g, function (digit) {
          return String(digit.charCodeAt(0) - 0x09E6);
        })
        .replace(/\D+/g, "");
      if (digits.indexOf("880") === 0) digits = digits.slice(3);
      if (digits.length === 10 && digits.charAt(0) === "1") digits = "0" + digits;
      return /^01[3-9]\d{8}$/.test(digits);
    }

    function checkoutFieldMessage(field) {
      var row = field.closest(".form-row");
      if (
        field.disabled ||
        field.type === "hidden" ||
        !field.getClientRects().length
      ) {
        return "";
      }

      var required = field.required ||
        field.getAttribute("aria-required") === "true" ||
        (row && row.classList.contains("validate-required"));
      var value = field.type === "checkbox" ? field.checked : String(field.value || "").trim();
      var isMissing = field.type === "checkbox"
        ? !field.checked
        : field.type === "radio"
          ? !(row && row.querySelector('input[type="radio"]:checked'))
          : !value;
      if (required && isMissing) {
        var label = row && row.querySelector("label");
        var labelText = label ? label.textContent.replace(/\*/g, "").trim() : "";
        var requiredMessage = checkoutStrings.required || "Please complete the %s field.";
        return requiredMessage.indexOf("%s") !== -1
          ? requiredMessage.replace("%s", labelText || "this")
          : requiredMessage;
      }

      var isEmail = field.type === "email" || (row && row.classList.contains("validate-email"));
      if (isEmail && value && field.validity && (field.validity.typeMismatch || field.validity.patternMismatch)) {
        return checkoutStrings.email || "Enter a valid email address.";
      }
      if (isEmail && value && field.type !== "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        return checkoutStrings.email || "Enter a valid email address.";
      }

      if (field.id === "billing_phone" && value && isBangladeshCheckout() && !isBdMobile(value)) {
        return checkoutStrings.phone || "Enter a valid Bangladeshi mobile number.";
      }

      if (field.validity && !field.validity.valid) {
        return checkoutStrings.invalid || "Please check this field and try again.";
      }
      return "";
    }

    function setCheckoutFieldError(field, message) {
      var row = field.closest(".form-row");
      if (!row) return;

      if (!Object.prototype.hasOwnProperty.call(field.dataset, "checkoutErrorId")) {
        inlineErrorCounter += 1;
        field.dataset.checkoutErrorId = field.id
          ? "yusraah-checkout-error-" + field.id
          : "yusraah-checkout-error-" + inlineErrorCounter;
        field.dataset.checkoutOriginalDescribedby = field.getAttribute("aria-describedby") || "";
        field.dataset.checkoutOriginalAriaInvalid = field.getAttribute("aria-invalid") || "";
      }

      var error = document.getElementById(field.dataset.checkoutErrorId);
      if (!error) {
        error = document.createElement("span");
        error.className = "checkout-inline-error";
        error.id = field.dataset.checkoutErrorId;
        error.setAttribute("role", "status");
        error.setAttribute("aria-live", "polite");
        error.setAttribute("data-checkout-inline-error", "");
        var wrapper = row.querySelector(".woocommerce-input-wrapper");
        if (wrapper) wrapper.insertAdjacentElement("afterend", error);
        else row.appendChild(error);
      }

      error.textContent = message;
      row.classList.add("checkout-field-invalid");
      field.setAttribute("aria-invalid", "true");
      var descriptions = [field.dataset.checkoutOriginalDescribedby, error.id].filter(Boolean);
      field.setAttribute("aria-describedby", descriptions.join(" "));
    }

    function clearCheckoutFieldError(field) {
      var row = field.closest(".form-row");
      if (row) row.classList.remove("checkout-field-invalid");

      if (field.dataset.checkoutErrorId) {
        var error = document.getElementById(field.dataset.checkoutErrorId);
        if (error) error.remove();
        if (field.dataset.checkoutOriginalDescribedby) {
          field.setAttribute("aria-describedby", field.dataset.checkoutOriginalDescribedby);
        } else {
          field.removeAttribute("aria-describedby");
        }
        if (field.dataset.checkoutOriginalAriaInvalid) {
          field.setAttribute("aria-invalid", field.dataset.checkoutOriginalAriaInvalid);
        } else {
          field.removeAttribute("aria-invalid");
        }
        delete field.dataset.checkoutErrorId;
        delete field.dataset.checkoutOriginalDescribedby;
        delete field.dataset.checkoutOriginalAriaInvalid;
      }
    }

    function validateCheckoutField(field) {
      var message = checkoutFieldMessage(field);
      if (message) setCheckoutFieldError(field, message);
      else clearCheckoutFieldError(field);
      return message;
    }

    function isCheckoutField(target) {
      return target && target.matches && target.matches(".form-row input, .form-row select, .form-row textarea");
    }

    checkoutForm.addEventListener("focusout", function (event) {
      if (isCheckoutField(event.target)) validateCheckoutField(event.target);
    });
    checkoutForm.addEventListener("invalid", function (event) {
      if (isCheckoutField(event.target)) validateCheckoutField(event.target);
    }, true);

    ["input", "change"].forEach(function (eventName) {
      checkoutForm.addEventListener(eventName, function (event) {
        if (isCheckoutField(event.target) && event.target.closest(".form-row").classList.contains("checkout-field-invalid")) {
          validateCheckoutField(event.target);
        }
      });
    });

    checkoutForm.addEventListener("submit", function (event) {
      var fields = checkoutForm.querySelectorAll(".form-row input, .form-row select, .form-row textarea");
      var firstInvalidField = null;
      Array.prototype.forEach.call(fields, function (field) {
        if (validateCheckoutField(field) && !firstInvalidField) firstInvalidField = field;
      });

      if (firstInvalidField) {
        event.preventDefault();
        event.stopImmediatePropagation();
        var focusTarget = firstInvalidField;
        if (firstInvalidField.classList.contains("select2-hidden-accessible")) {
          focusTarget = firstInvalidField.closest(".form-row").querySelector(".select2-selection") || firstInvalidField;
        }
        firstInvalidField.scrollIntoView({ block: "center" });
        focusTarget.focus({ preventScroll: true });
      }
    }, true);

    if (window.jQuery) {
      window.jQuery(document.body).on("checkout_error", function () {
        checkoutForm.querySelectorAll(".form-row.woocommerce-invalid").forEach(function (row) {
          var field = row.querySelector("input:not([type='hidden']), select, textarea");
          if (!field || !field.getClientRects().length) return;
          setCheckoutFieldError(field, checkoutFieldMessage(field) || checkoutStrings.invalid || "Please check this field and try again.");
        });
      });
    }
  }

  // Wishlist. The server owns the list; the heart only reflects it.
  var wishlistConfig = window.yusraahWishlist || {};
  var wishlistStrings = wishlistConfig.strings || {};
  var wishlistPending = {};

  function wishlistLabel(isSaved) {
    return isSaved
      ? wishlistStrings.remove || "Remove from wishlist"
      : wishlistStrings.add || "Add to wishlist";
  }

  function setWishlistButtons(productId, isSaved) {
    document.querySelectorAll('[data-wishlist="' + productId + '"]').forEach(function (button) {
      button.setAttribute("aria-pressed", String(isSaved));
      button.setAttribute("aria-label", wishlistLabel(isSaved));
    });
  }

  function setWishlistCount(count) {
    document.querySelectorAll("[data-wishlist-count]").forEach(function (node) {
      node.textContent = count;
      node.classList.toggle("is-empty", !count);
    });
  }

  function announceWishlist(message) {
    if (!message) return;
    var status = document.getElementById("yusraah-wishlist-status");
    if (!status) return;
    status.textContent = "";
    window.setTimeout(function () {
      status.textContent = message;
    }, 60);
  }

  function removeWishlistCard(button) {
    var page = document.querySelector("[data-wishlist-page]");
    if (!page) return;

    var card = button.closest(".yusraah-product");
    if (!card) return;

    card.classList.add("is-removing");
    window.setTimeout(function () {
      var grid = card.parentNode;
      card.remove();
      if (grid && grid.querySelector(".yusraah-product")) return;

      var items = page.querySelector("[data-wishlist-items]");
      var empty = page.querySelector("[data-wishlist-empty]");
      if (items) items.hidden = true;
      if (empty) empty.hidden = false;
    }, 220);
  }

  function toggleWishlist(button) {
    var productId = button.getAttribute("data-wishlist");
    if (!productId || wishlistPending[productId]) return;

    var wasSaved = button.getAttribute("aria-pressed") === "true";

    wishlistPending[productId] = true;
    button.setAttribute("aria-busy", "true");
    setWishlistButtons(productId, !wasSaved);

    var formData = new FormData();
    formData.append("action", "yusraah_wishlist_toggle");
    formData.append("nonce", wishlistConfig.nonce || "");
    formData.append("product_id", productId);

    window
      .fetch(wishlistConfig.ajaxUrl, { method: "POST", credentials: "same-origin", body: formData })
      .then(function (response) {
        return response.json().catch(function () {
          return null;
        });
      })
      .then(function (payload) {
        var data = payload && payload.success ? payload.data || {} : null;

        if (!data) {
          setWishlistButtons(productId, wasSaved);
          announceWishlist((payload && payload.data && payload.data.message) || wishlistStrings.failed);
          return;
        }

        setWishlistButtons(productId, !!data.added);
        if (typeof data.count !== "undefined") setWishlistCount(data.count);
        if (!data.added) removeWishlistCard(button);
        announceWishlist(data.message);
      })
      .catch(function () {
        setWishlistButtons(productId, wasSaved);
        announceWishlist(wishlistStrings.failed);
      })
      .finally(function () {
        button.removeAttribute("aria-busy");
        delete wishlistPending[productId];
      });
  }

  document.addEventListener("click", function (event) {
    var button = event.target.closest && event.target.closest("[data-wishlist]");
    if (!button) return;
    event.preventDefault();
    toggleWishlist(button);
  });

  // Reconcile hearts and the header count on pages that show them, so cached
  // product grids still reflect the visitor's real list.
  function reconcileWishlist() {
    if (!wishlistConfig.ajaxUrl) return;

    var formData = new FormData();
    formData.append("action", "yusraah_wishlist_list");

    window
      .fetch(wishlistConfig.ajaxUrl, { method: "POST", credentials: "same-origin", body: formData })
      .then(function (response) {
        return response.json();
      })
      .then(function (payload) {
        if (!payload || !payload.success || !payload.data) return;

        var ids = (payload.data.ids || []).map(String);

        document.querySelectorAll("[data-wishlist]").forEach(function (button) {
          var id = String(button.getAttribute("data-wishlist"));
          setWishlistButtons(id, ids.indexOf(id) !== -1);
        });

        setWishlistCount(payload.data.count);
      })
      .catch(function () {});
  }

  if (document.querySelector("[data-wishlist], [data-wishlist-page]")) {
    reconcileWishlist();
  }

  // Quick View Modal
  var quickViewModal = document.querySelector("#yusraah-quick-view-modal");
  var quickViewConfig = window.yusraahQuickView || {};
  var quickViewRequest = null;

  function openQuickView(productId) {
    if (!quickViewModal) return;

    quickViewModal.hidden = false;
    quickViewModal.classList.add("is-open");
    quickViewModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("quick-view-open");

    var content = document.getElementById("quick-view-content");
    if (content) {
      content.innerHTML = '<div class="quick-view-modal__loading"><span>' + (quickViewConfig.strings.loading || "Loading...") + '</span></div>';
    }

    if (quickViewRequest) quickViewRequest.abort();

    var formData = new FormData();
    formData.append("action", "yusraah_quick_view");
    formData.append("nonce", quickViewConfig.nonce || "");
    formData.append("product_id", productId);

    quickViewRequest = new AbortController();
    fetch(quickViewConfig.ajaxUrl, {
      method: "POST",
      credentials: "same-origin",
      body: formData,
      signal: quickViewRequest.signal
    })
      .then(function (response) {
        if (!response.ok) throw new Error("Quick view request failed");
        return response.json();
      })
      .then(function (response) {
        if (!response.success || !response.data || !response.data.html) {
          throw new Error("Invalid quick view response");
        }
        if (content) {
          content.innerHTML = response.data.html;
          var panel = quickViewModal.querySelector(".quick-view-modal__panel");
          if (panel) panel.focus();
        }
      })
      .catch(function (error) {
        if (error.name === "AbortError") return;
        if (content) {
          content.innerHTML = '<div class="quick-view-modal__error"><span>' + (quickViewConfig.strings.error || "Could not load product. Please try again.") + '</span></div>';
        }
      });
  }

  function closeQuickView() {
    if (!quickViewModal) return;

    if (quickViewRequest) quickViewRequest.abort();

    quickViewModal.hidden = true;
    quickViewModal.classList.remove("is-open");
    quickViewModal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("quick-view-open");

    var content = document.getElementById("quick-view-content");
    if (content) {
      content.innerHTML = '<div class="quick-view-modal__loading"><span>' + (quickViewConfig.strings.loading || "Loading...") + '</span></div>';
    }
  }

  document.addEventListener("click", function (event) {
    var button = event.target.closest("[data-quick-view]");
    if (!button) return;
    event.preventDefault();
    var productId = button.getAttribute("data-quick-view");
    if (productId) openQuickView(productId);
  });

  document.addEventListener("click", function (event) {
    var target = event.target.closest("[data-quick-view-close]");
    if (!target && !event.target.closest(".quick-view-modal__panel")) return;
    if (target || event.target === quickViewModal || event.target.closest(".quick-view-modal__backdrop")) {
      closeQuickView();
    }
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && !quickViewModal.hidden) {
      closeQuickView();
    }
  });

  // Social Sharing Copy Link
  document.addEventListener("click", function (event) {
    var button = event.target.closest("[data-copy-url]");
    if (!button) return;
    event.preventDefault();

    var url = button.getAttribute("data-copy-url");
    if (!url) return;

    navigator.clipboard.writeText(url).then(function () {
      var originalLabel = button.getAttribute("aria-label");
      button.setAttribute("aria-label", "Link copied!");
      button.classList.add("is-copied");
      setTimeout(function () {
        button.setAttribute("aria-label", originalLabel || "Copy link");
        button.classList.remove("is-copied");
      }, 2000);
    }).catch(function () {
      // Fallback for browsers that don't support clipboard API
      var textArea = document.createElement("textarea");
      textArea.value = url;
      textArea.style.position = "fixed";
      textArea.style.left = "-9999px";
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand("copy");
        var originalLabel = button.getAttribute("aria-label");
        button.setAttribute("aria-label", "Link copied!");
        button.classList.add("is-copied");
        setTimeout(function () {
          button.setAttribute("aria-label", originalLabel || "Copy link");
          button.classList.remove("is-copied");
        }, 2000);
      } catch (err) {}
      document.body.removeChild(textArea);
    });
  });

  // Footer link columns: accordion below 640px, static headings above it.
  var footerToggles = document.querySelectorAll(".site-footer .footer-column__toggle");
  if (footerToggles.length) {
    var footerMedia = window.matchMedia("(max-width: 640px)");

    var setFooterColumnState = function (toggle, expanded) {
      toggle.setAttribute("aria-expanded", String(expanded));
      var column = toggle.closest(".footer-column");
      if (column) column.classList.toggle("is-collapsed", !expanded);
    };

    var syncFooterColumns = function () {
      footerToggles.forEach(function (toggle) {
        setFooterColumnState(toggle, !footerMedia.matches);
      });
    };

    footerToggles.forEach(function (toggle) {
      toggle.addEventListener("click", function () {
        if (!footerMedia.matches) return;
        setFooterColumnState(toggle, toggle.getAttribute("aria-expanded") !== "true");
      });
    });

    syncFooterColumns();

    if (footerMedia.addEventListener) {
      footerMedia.addEventListener("change", syncFooterColumns);
    } else if (footerMedia.addListener) {
      footerMedia.addListener(syncFooterColumns);
    }
  }

  // Newsletter forms use the configured provider and submit without a reload.
  var newsletterForms = document.querySelectorAll("[data-newsletter-form]");
  if (newsletterForms.length && window.yusraahNewsletter) {
    var newsletterConfig = window.yusraahNewsletter;
    var newsletterStrings = newsletterConfig.strings || {};
    newsletterForms.forEach(function (newsletterForm) {
      var newsletterStatus = newsletterForm.parentNode.querySelector("[data-newsletter-status], .footer-newsletter__status");
      var newsletterButton = newsletterForm.querySelector('button[type="submit"]');
      var newsletterEmail = newsletterForm.querySelector('input[type="email"]');
      var newsletterSending = false;

      var setNewsletterStatus = function (message, isError) {
        if (!newsletterStatus) return;
        newsletterStatus.textContent = message || "";
        newsletterStatus.classList.toggle("is-error", !!isError);
      };

      newsletterForm.addEventListener("submit", function (event) {
        event.preventDefault();
        if (newsletterSending) return;

        var email = newsletterEmail ? newsletterEmail.value.trim() : "";
        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          setNewsletterStatus(newsletterStrings.invalid || "", true);
          if (newsletterEmail) newsletterEmail.focus();
          return;
        }

        var payload = new FormData(newsletterForm);
        payload.set("action", "yusraah_newsletter_subscribe");
        payload.set("nonce", newsletterConfig.nonce);
        payload.set("EMAIL", email);
        newsletterSending = true;

        if (newsletterButton) {
          newsletterButton.disabled = true;
          newsletterButton.setAttribute("aria-busy", "true");
          newsletterButton.classList.add("is-loading");
        }
        setNewsletterStatus(newsletterStrings.sending || "", false);

        fetch(newsletterConfig.ajaxUrl, {
          method: "POST",
          body: payload,
          credentials: "same-origin"
        })
          .then(function (response) { return response.json(); })
          .then(function (result) {
            if (result && result.success) {
              setNewsletterStatus(result.data && result.data.message ? result.data.message : "", false);
              newsletterForm.reset();
            } else {
              setNewsletterStatus(
                result && result.data && result.data.message ? result.data.message : (newsletterStrings.failed || ""),
                true
              );
            }
          })
          .catch(function () {
            setNewsletterStatus(newsletterStrings.failed || "", true);
          })
          .finally(function () {
            newsletterSending = false;
            if (newsletterButton) {
              newsletterButton.disabled = false;
              newsletterButton.removeAttribute("aria-busy");
              newsletterButton.classList.remove("is-loading");
            }
          });
        });
    });
  }

  // Back to top.
  document.addEventListener("click", function (event) {
    var button = event.target.closest("[data-footer-top]");
    if (!button) return;
    event.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth"
    });
  });
})();
