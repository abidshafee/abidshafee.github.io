(function ($) {
  "use strict";

  var config = window.yusraahCartToast || {};
  var container = document.getElementById("yusraah-cart-toast");
  if (!config.enabled || !container) return;

  var toast = null;
  var messageEl = null;
  var imageEl = null;
  var dismissTimer = null;
  var batchTimer = null;
  var pendingItems = [];
  var paused = false;
  var duration = Math.max(3000, (parseInt(config.duration, 10) || 5) * 1000);
  var strings = config.strings || {};

  var positionClass = config.position === "top-left" ? "yusraah-cart-toast-container--top-left" : "yusraah-cart-toast-container--top-right";
  container.classList.add(positionClass);

  function prefersReducedMotion() {
    return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  function syncMobileOffset() {
    if (window.innerWidth > 767) {
      container.style.removeProperty("--yusraah-toast-bottom-offset");
      return;
    }
    var stickyCart = document.querySelector(".sticky-product-cart.is-visible");
    if (stickyCart) {
      var rect = stickyCart.getBoundingClientRect();
      var offset = Math.max(0, window.innerHeight - rect.top) + 12;
      container.style.setProperty("--yusraah-toast-bottom-offset", offset + "px");
    } else {
      container.style.removeProperty("--yusraah-toast-bottom-offset");
    }
  }

  function makeButton(label, href, className) {
    var link = document.createElement("a");
    link.className = className;
    link.href = href;
    link.textContent = label;
    return link;
  }

  function createToast(isError) {
    if (toast) {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
      toast = null;
    }

    toast = document.createElement("aside");
    toast.className = "yusraah-cart-toast" + (isError ? " yusraah-cart-toast--error" : "");
    toast.setAttribute("role", isError ? "alert" : "status");
    toast.setAttribute("aria-live", isError ? "assertive" : "polite");

    var body = document.createElement("div");
    body.className = "yusraah-cart-toast__body";

    if (!isError) {
      var media = document.createElement("div");
      media.className = "yusraah-cart-toast__media";

      var thumbnail = document.createElement("img");
      thumbnail.className = "yusraah-cart-toast__image";
      thumbnail.alt = "";
      thumbnail.width = 52;
      thumbnail.height = 52;
      thumbnail.src = config.placeholder || "";
      imageEl = thumbnail;

      media.appendChild(thumbnail);
      body.appendChild(media);
    }

    var main = document.createElement("div");
    main.className = "yusraah-cart-toast__main";

    var header = document.createElement("div");
    header.className = "yusraah-cart-toast__header";

    var icon = document.createElement("span");
    icon.className = "yusraah-cart-toast__icon";
    icon.setAttribute("aria-hidden", "true");
    if (isError) {
      icon.innerHTML = '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><circle cx="10" cy="10" r="8"/><line x1="10" y1="6" x2="10" y2="10"/><line x1="10" y1="14" x2="10.01" y2="14"/></svg>';
    } else {
      icon.innerHTML = '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><path d="M4 10.5l4 4 8-9"/></svg>';
    }

    messageEl = document.createElement("p");
    messageEl.className = "yusraah-cart-toast__message";

    header.appendChild(icon);
    header.appendChild(messageEl);
    main.appendChild(header);

    if (!isError) {
      var actions = document.createElement("div");
      actions.className = "yusraah-cart-toast__actions";
      actions.appendChild(makeButton(strings.viewCart || "View cart", config.cartUrl || "/", "yusraah-cart-toast__button yusraah-cart-toast__button--secondary"));
      if (config.showCheckout) {
        actions.appendChild(makeButton(strings.checkout || "Checkout", config.checkoutUrl || "/", "yusraah-cart-toast__button yusraah-cart-toast__button--primary"));
      }
      main.appendChild(actions);
    }

    var closeBtn = document.createElement("button");
    closeBtn.className = "yusraah-cart-toast__close";
    closeBtn.type = "button";
    closeBtn.setAttribute("aria-label", strings.close || "Dismiss notification");
    closeBtn.innerHTML = '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14" aria-hidden="true"><line x1="15" y1="5" x2="5" y2="15"/><line x1="5" y1="5" x2="15" y2="15"/></svg>';
    closeBtn.addEventListener("click", dismiss);

    body.appendChild(main);
    body.appendChild(closeBtn);
    toast.appendChild(body);

    toast.addEventListener("mouseenter", pauseDismiss);
    toast.addEventListener("mouseleave", resumeDismiss);
    toast.addEventListener("focusin", pauseDismiss);
    toast.addEventListener("focusout", function (event) {
      if (toast && !toast.contains(event.relatedTarget)) resumeDismiss();
    });

    syncMobileOffset();
    container.hidden = false;
    container.replaceChildren(toast);

    window.requestAnimationFrame(function () {
      if (toast) toast.classList.add("is-visible");
    });
  }

  function renderMessageContent(items) {
    if (!messageEl) return;
    messageEl.innerHTML = "";

    if (items.length > 1) {
      var text = (strings.addedMany || "Added %d items").replace("%d", items.length);
      var span = document.createElement("span");
      span.className = "yusraah-cart-toast__batch-title";
      span.textContent = text;
      messageEl.appendChild(span);
      messageEl.title = text;
    } else {
      var item = items[0] || {};
      var name = item.name || "";
      var template = strings.added || "%s added to cart";

      if (template.indexOf("%s") !== -1) {
        var parts = template.split("%s");
        if (parts[0]) {
          messageEl.appendChild(document.createTextNode(parts[0]));
        }
        var nameSpan = document.createElement("span");
        nameSpan.className = "yusraah-cart-toast__product-name";
        nameSpan.textContent = name;
        messageEl.appendChild(nameSpan);
        if (parts[1]) {
          messageEl.appendChild(document.createTextNode(parts[1]));
        }
      } else {
        var fallbackSpan = document.createElement("span");
        fallbackSpan.className = "yusraah-cart-toast__product-name";
        fallbackSpan.textContent = name;
        messageEl.appendChild(fallbackSpan);
        messageEl.appendChild(document.createTextNode(" " + template));
      }
      messageEl.title = name + " added to cart";
    }
  }

  function updateToast(items) {
    if (!items.length) return;
    createToast(false);

    var latest = items[items.length - 1];
    renderMessageContent(items);

    if (imageEl) {
      imageEl.src = latest.image || config.placeholder || "";
      imageEl.alt = "";
    }

    if (dismissTimer) window.clearTimeout(dismissTimer);
    dismissTimer = null;
    if (!paused) {
      dismissTimer = window.setTimeout(dismiss, duration);
    }
  }

  function showErrorToast(errorText) {
    if (!errorText) return;
    createToast(true);
    messageEl.textContent = errorText;
    messageEl.title = errorText;

    if (dismissTimer) window.clearTimeout(dismissTimer);
    dismissTimer = null;
    if (!paused) {
      dismissTimer = window.setTimeout(dismiss, duration);
    }
  }

  function dismiss() {
    if (!toast) return;
    if (dismissTimer) window.clearTimeout(dismissTimer);
    if (batchTimer) window.clearTimeout(batchTimer);
    dismissTimer = null;
    batchTimer = null;
    pendingItems = [];

    var closingToast = toast;
    toast = null;
    closingToast.classList.remove("is-visible");

    var delay = prefersReducedMotion() ? 0 : 250;
    window.setTimeout(function () {
      if (closingToast.parentNode) {
        closingToast.parentNode.removeChild(closingToast);
      }
      if (!container.firstElementChild) {
        container.hidden = true;
      }
      messageEl = null;
      imageEl = null;
    }, delay);
  }

  function pauseDismiss() {
    paused = true;
    if (dismissTimer) {
      window.clearTimeout(dismissTimer);
      dismissTimer = null;
    }
  }

  function resumeDismiss() {
    paused = false;
    if (toast && !dismissTimer) {
      dismissTimer = window.setTimeout(dismiss, duration);
    }
  }

  function normalizeItem(item) {
    return {
      name: item && item.name ? String(item.name).trim() : "",
      image: item && item.image ? String(item.image).trim() : (config.placeholder || "")
    };
  }

  function itemFromButton(btn) {
    var button = btn && btn.jquery ? btn[0] : btn;
    var context = button && button.closest ? button.closest(".quick-view-product, .product-card, .hcs-slide, .sticky-product-cart, .product") : null;
    if (!context) context = document;

    var title = context.querySelector(".quick-view-product__title, .product_title, .woocommerce-loop-product__title, .hcs-slide__title");
    var name = context.getAttribute && context.getAttribute("data-product-name");
    if (!name && title) {
      name = title.textContent.trim();
    }
    if (!name && button) {
      var label = button.getAttribute("aria-label") || "";
      var match = label.match(/^(?:Add\s+|Add\s+“)(.+?)(?:”\s+to\s+cart|\s+to\s+cart|\s+to\s+your\s+cart)$/i);
      if (match) name = match[1];
      if (!name) {
        var dataName = button.getAttribute("data-product_name");
        if (dataName) name = dataName;
      }
    }

    var productImage = context.querySelector(".quick-view-product__image img, .product-card__image img, .hcs-slide__image img, .woocommerce-product-gallery__image img");
    var imgSrc = productImage ? (productImage.currentSrc || productImage.src) : config.placeholder;

    return normalizeItem({
      name: name,
      image: imgSrc
    });
  }

  function showAddedItems(items) {
    items = (items || []).map(normalizeItem).filter(function (item) { return item.name; });
    if (!items.length) return;

    pendingItems = pendingItems.concat(items);
    updateToast(pendingItems);

    if (batchTimer) window.clearTimeout(batchTimer);
    batchTimer = window.setTimeout(function () {
      pendingItems = [];
      batchTimer = null;
    }, 1800);
  }

  function shouldShowToastOnAdd() {
    if (!config.enabled) return false;
    return config.action === "toast" || config.action === "both";
  }

  function handleAddedToCart(event, fragments, cartHash, button) {
    if (!shouldShowToastOnAdd()) return;

    var item = itemFromButton(button);

    if (!item.name && fragments) {
      Object.keys(fragments).some(function (selector) {
        if (selector.indexOf("widget_shopping_cart_content") === -1) return false;
        var tpl = document.createElement("div");
        tpl.innerHTML = fragments[selector];
        var cartItem = tpl.querySelector(".woocommerce-mini-cart-item");
        if (!cartItem) return false;

        var nameLink = cartItem.querySelector("a:not(.remove)");
        if (nameLink) {
          item.name = nameLink.textContent.trim();
        }
        var cartImg = cartItem.querySelector("img");
        if (cartImg) {
          item.image = cartImg.currentSrc || cartImg.src;
        }
        return true;
      });
    }

    if (!item.name) {
      var fallbackTitle = document.querySelector(".product_title, .woocommerce-loop-product__title");
      if (fallbackTitle) item.name = fallbackTitle.textContent.trim();
    }

    showAddedItems([item]);
  }

  function enhanceNativeNotices() {
    // 1. Success add-to-cart messages
    var nativeNotices = document.querySelectorAll(".woocommerce-message");
    if (nativeNotices && nativeNotices.length) {
      nativeNotices.forEach(function (nativeNotice) {
        var marker = nativeNotice.querySelector(".yusraah-cart-toast__notice-data");
        var noticeText = (nativeNotice.textContent || "").trim();
        var isAddToCartNotice = marker || /added to (?:your )?cart/i.test(noticeText);

        if (!isAddToCartNotice) {
          return; // Preserve coupon, account, and stock notices!
        }

        var items = [];
        if (marker) {
          try {
            items = JSON.parse(marker.getAttribute("data-products") || "[]");
          } catch (error) {
            items = [];
          }
        }

        if (!items || !items.length) {
          var name = "";
          var match = noticeText.match(/[“"']([^”"']+)[”"']/);
          if (match && match[1]) {
            name = match[1].trim();
          } else {
            var titleEl = document.querySelector(".product_title, .woocommerce-loop-product__title");
            if (titleEl) name = titleEl.textContent.trim();
          }

          var productImg = document.querySelector(".woocommerce-product-gallery__image img, .product-card__image img, .product img");
          var imgSrc = productImg ? (productImg.currentSrc || productImg.src) : (config.placeholder || "");

          items = [{
            name: name || "Item",
            image: imgSrc
          }];
        }

        if (shouldShowToastOnAdd()) {
          showAddedItems(items);
          nativeNotice.classList.add("is-toast-enhanced");
          nativeNotice.style.display = "none";
          nativeNotice.remove();
        }
      });
    }

    // 2. Error notices (missing variation, out of stock, etc.)
    var errorNotices = document.querySelectorAll(".woocommerce-error");
    if (errorNotices && errorNotices.length) {
      errorNotices.forEach(function (errorNotice) {
        var errorItems = errorNotice.querySelectorAll("li");
        var errorMessages = [];
        if (errorItems && errorItems.length) {
          errorItems.forEach(function (li) {
            var text = (li.textContent || "").trim().replace(/\s+/g, " ");
            if (text) errorMessages.push(text);
          });
        } else {
          var rawText = (errorNotice.textContent || "").trim().replace(/\s+/g, " ");
          if (rawText) errorMessages.push(rawText);
        }

        if (errorMessages.length && config.enabled) {
          showErrorToast(errorMessages.join(" "));
          errorNotice.classList.add("is-toast-enhanced");
          errorNotice.style.display = "none";
          errorNotice.remove();
        }
      });
    }

    // Hide empty notice wrappers so no empty boxes or borders remain
    document.querySelectorAll(".woocommerce-notices-wrapper").forEach(function (wrapper) {
      if (!wrapper.children.length || !wrapper.textContent.trim()) {
        wrapper.style.display = "none";
      }
    });
  }

  function handleCartError(event, button, response) {
    if (!config.enabled) return;
    var msg = (response && response.error_message) || (strings.failed || "Could not add item to basket.");
    showErrorToast(msg);
  }

  /* Single-product AJAX add to cart & validation */
  //
  // This is the only add-to-cart submit handler on the page. It runs in the
  // capture phase so it claims the submit before any other handler (theme,
  // plugin or WooCommerce) can process it as well — one click, one request,
  // one cart addition. preventDefault alone only stops the native POST; it
  // does not stop other JavaScript submit handlers, which is what caused the
  // double quantity. Visitors without JavaScript keep the normal form POST.
  function submitCartFormNatively(form, productId) {
    var injected = null;
    if (productId && !form.querySelector('input[type="hidden"][name="add-to-cart"]')) {
      injected = document.createElement("input");
      injected.type = "hidden";
      injected.name = "add-to-cart";
      injected.value = productId;
      form.appendChild(injected);
    }
    // form.submit() fires no submit event, so our capture listener is bypassed
    // and the browser performs exactly one normal POST.
    if (typeof form.submit === "function") {
      form.submit();
    }
    if (injected && injected.parentNode) {
      injected.parentNode.removeChild(injected);
    }
  }

  function handleCartFormSubmit(event) {
    var form = event.target;
    if (!form || !form.classList || !form.classList.contains("cart")) return;

    var submitBtn = form.querySelector(".single_add_to_cart_button");
    if (!submitBtn) return;

    // If Buy Now button was clicked, let it submit normally to redirect to checkout
    var submitter = event.submitter;
    if (!submitter) {
      var active = document.activeElement;
      if (active && active.form === form && (active.name === "yusraah_buy_now" || active.hasAttribute("data-yusraah-buy-now"))) {
        submitter = active;
      }
    }
    if (submitter && (submitter.name === "yusraah_buy_now" || submitter.hasAttribute("data-yusraah-buy-now"))) {
      return;
    }

    // A request is already in flight for this form: swallow repeat submits.
    if (form.getAttribute("data-yusraah-cart-submitting") === "1") {
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }

    // Check variations: if variable product and options are not chosen
    var isVariable = form.classList.contains("variations_form") || form.querySelector('input[name="variation_id"]') !== null;
    if (isVariable) {
      var variationIdField = form.querySelector('input[name="variation_id"]');
      var varId = variationIdField ? variationIdField.value : "";

      if (!varId || varId === "0" || submitBtn.classList.contains("disabled") || submitBtn.classList.contains("wc-variation-selection-needed")) {
        event.preventDefault();
        event.stopImmediatePropagation();

        // Highlight and focus first unselected variation dropdown
        var selects = form.querySelectorAll(".variations select");
        for (var index = 0; index < selects.length; index += 1) {
          if (!selects[index].value) {
            selects[index].focus();
            if (selects[index].scrollIntoView) {
              selects[index].scrollIntoView({ behavior: "smooth", block: "center" });
            }
            break;
          }
        }

        showErrorToast(strings.chooseOptions || "Please choose product options before adding to cart.");
        return;
      }
    }

    if (submitBtn.classList.contains("disabled") || submitBtn.disabled) {
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }

    // Standard HTML5 validity check: let the browser report invalid fields.
    if (typeof form.checkValidity === "function" && !form.checkValidity()) {
      return;
    }

    event.preventDefault();
    event.stopImmediatePropagation();

    if (submitBtn.classList.contains("loading")) return;
    form.setAttribute("data-yusraah-cart-submitting", "1");
    submitBtn.classList.add("loading");
    submitBtn.disabled = true;

    var formData = new FormData(form);
    var nativeProductId = "";
    var variationInput = form.querySelector('input[name="variation_id"]');
    var variationId = variationInput ? variationInput.value : "";

    // Remove add-to-cart from FormData to prevent WC_Form_Handler::add_to_cart_action
    // from also processing it on wp_loaded (which would add the item twice).
    // The AJAX endpoint only needs product_id and quantity.
    formData.delete("add-to-cart");

    // For variable products, ensure variation_id is properly passed as product_id for wc-ajax endpoint
    if (variationId && variationId !== "0") {
      formData.set("product_id", variationId);
      formData.set("variation_id", variationId);
      var parentIdField = form.querySelector('input[type="hidden"][name="product_id"]');
      nativeProductId = parentIdField ? parentIdField.value : "";
    } else {
      var addToCartField = form.querySelector('[name="add-to-cart"]');
      var productId = (addToCartField && addToCartField.value) || submitBtn.value || "";
      nativeProductId = productId;
      if (productId) {
        formData.set("product_id", productId);
      }
    }

    var wcParams = window.wc_add_to_cart_params || {};
    var ajaxUrl = wcParams.wc_ajax_url
      ? String(wcParams.wc_ajax_url).replace("%%endpoint%%", "add_to_cart")
      : (window.location.pathname + window.location.search);

    fetch(ajaxUrl, {
      method: "POST",
      body: formData,
      headers: {
        "X-Requested-With": "XMLHttpRequest"
      }
    })
    .then(function (res) {
      // A malformed/empty response must never reach the native fallback:
      // the server may already have added the item and a second POST would
      // double the quantity.
      return res.json().catch(function () {
        return { __yusraah_invalid_response: true };
      });
    })
    .then(function (data) {
      if (data && data.__yusraah_invalid_response) {
        showErrorToast(strings.failed || "Could not add item to basket.");
        return;
      }
      if (data && data.error) {
        var errorMsg = data.error_message || (strings.failed || "Could not add item to basket.");
        showErrorToast(errorMsg);
        return;
      }
      if (window.jQuery) {
        window.jQuery(document.body).trigger("added_to_cart", [
          data ? data.fragments : null,
          data ? data.cart_hash : null,
          window.jQuery(submitBtn)
        ]);
      }
    })
    .catch(function () {
      // Only a network-level failure lands here, where the request never
      // reached the server — safe to retry with a normal form POST.
      submitCartFormNatively(form, nativeProductId);
    })
    .finally(function () {
      form.removeAttribute("data-yusraah-cart-submitting");
      submitBtn.classList.remove("loading");
      submitBtn.disabled = false;
    });
  }

  document.addEventListener("submit", handleCartFormSubmit, true);

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && toast) {
      dismiss();
    }
  });

  window.addEventListener("resize", syncMobileOffset, { passive: true });
  window.addEventListener("scroll", syncMobileOffset, { passive: true });

  $(document.body).on("added_to_cart", handleAddedToCart);
  $(document.body).on("wc_cart_button_error", handleCartError);

  document.body.addEventListener("wc-blocks_added_to_cart", function () {
    if (shouldShowToastOnAdd()) {
      showAddedItems([itemFromButton(null)]);
    }
  });

  enhanceNativeNotices();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", enhanceNativeNotices);
  }
  window.addEventListener("load", enhanceNativeNotices);
})(window.jQuery);
