/**
 * Mobile navigation drawer (below 1024px).
 *
 * Vanilla JavaScript, no jQuery. Mirrors the behaviour of cart-drawer.js:
 * `hidden` + `.is-open` + a close timer, a body scroll lock, a focus trap,
 * Escape to close and focus returned to the hamburger.
 *
 * The markup ships with every submenu expanded so the link list still works
 * without JavaScript; this script collapses the accordions while the drawer is
 * hidden, so no visible jump is introduced.
 */
(function () {
  "use strict";

  var drawer = document.getElementById("yusraah-mobile-drawer");
  var trigger = document.querySelector(".mobile-menu-toggle");

  if (!drawer || !trigger) {
    return;
  }

  var panel = drawer.querySelector(".mobile-drawer__panel");
  var config = window.yusraahMobileNav || {};
  var singleOpen = config.singleOpen !== false;
  var toggles = Array.prototype.slice.call(drawer.querySelectorAll(".mobile-nav__toggle"));
  var closeTimer = null;
  var previousFocus = null;
  var backgroundNodes = [];
  var supportsInert = "inert" in HTMLElement.prototype;

  ["#site-header", "#main-content", ".site-footer", ".announcement-bar"].forEach(function (selector) {
    var node = document.querySelector(selector);
    if (node) {
      backgroundNodes.push(node);
    }
  });

  /* ------------------------------------------------------------ Accordions */

  function panelFor(toggle) {
    var list = document.getElementById(toggle.getAttribute("aria-controls") || "");
    var wrap = list ? list.parentNode : null;

    return wrap && wrap.classList && wrap.classList.contains("mobile-nav__panel-wrap") ? wrap : null;
  }

  function updateToggleLabel(toggle, expanded) {
    var strings = config.strings || {};
    var label = toggle.querySelector(".screen-reader-text");
    var item = toggle.closest(".mobile-nav__item");
    var link = item ? item.querySelector(".mobile-nav__link") : null;
    var template = expanded ? strings.expanded : strings.collapsed;

    if (!label || !link || !template) {
      return;
    }

    var name = (link.querySelector("span") || link).textContent.replace(/\s+/g, " ").trim();

    label.textContent = template.replace("%s", name);
  }

  function setExpanded(toggle, expanded) {
    var wrap = panelFor(toggle);

    toggle.setAttribute("aria-expanded", String(expanded));

    if (wrap) {
      wrap.classList.toggle("is-expanded", expanded);
    }

    updateToggleLabel(toggle, expanded);
  }

  function collapseAll(except) {
    toggles.forEach(function (toggle) {
      if (toggle !== except) {
        setExpanded(toggle, false);
      }
    });
  }

  toggles.forEach(function (toggle) {
    setExpanded(toggle, false);
  });

  /* ---------------------------------------------------------- Open / close */

  function setBackgroundInert(isInert) {
    backgroundNodes.forEach(function (node) {
      if (supportsInert) {
        node.inert = isInert;
      } else if (isInert) {
        node.setAttribute("aria-hidden", "true");
      } else {
        node.removeAttribute("aria-hidden");
      }
    });
  }

  function getFocusableItems() {
    return panel.querySelectorAll(
      'a[href]:not([tabindex="-1"]), button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    );
  }

  function openDrawer() {
    if (closeTimer) {
      window.clearTimeout(closeTimer);
      closeTimer = null;
    }

    if (!drawer.hidden && drawer.classList.contains("is-open")) {
      return;
    }

    previousFocus = document.activeElement;
    drawer.hidden = false;
    drawer.setAttribute("aria-hidden", "false");
    trigger.setAttribute("aria-expanded", "true");
    trigger.setAttribute("aria-label", (config.strings && config.strings.close) || "Close menu");
    document.body.classList.add("menu-is-open");
    setBackgroundInert(true);

    window.requestAnimationFrame(function () {
      drawer.classList.add("is-open");

      var first = drawer.querySelector(".mobile-drawer__close");
      if (first) {
        first.focus();
      } else {
        panel.focus();
      }
    });
  }

  function closeDrawer() {
    if (drawer.hidden) {
      return;
    }

    drawer.classList.remove("is-open");
    drawer.setAttribute("aria-hidden", "true");
    trigger.setAttribute("aria-expanded", "false");
    trigger.setAttribute("aria-label", (config.strings && config.strings.open) || "Open menu");
    document.body.classList.remove("menu-is-open");
    setBackgroundInert(false);

    closeTimer = window.setTimeout(function () {
      drawer.hidden = true;
      closeTimer = null;
    }, 260);

    // getClientRects() is empty for a display:none node, so a resize into the
    // desktop layout never tries to focus the hidden hamburger.
    if (previousFocus && typeof previousFocus.focus === "function" && previousFocus.getClientRects().length) {
      previousFocus.focus();
    } else if (trigger.getClientRects().length) {
      trigger.focus();
    }
  }

  /* ------------------------------------------------------------- Listeners */

  trigger.addEventListener("click", function (event) {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
      return;
    }

    event.preventDefault();
    openDrawer();
  });

  drawer.addEventListener("click", function (event) {
    var toggle = event.target.closest(".mobile-nav__toggle");

    if (toggle) {
      event.preventDefault();

      var expanded = toggle.getAttribute("aria-expanded") === "true";

      if (singleOpen && !expanded) {
        collapseAll(toggle);
      }

      setExpanded(toggle, !expanded);
      return;
    }

    if (event.target.closest("[data-mobile-drawer-close]")) {
      closeDrawer();
    }
  });

  document.addEventListener("keydown", function (event) {
    if (drawer.hidden) {
      return;
    }

    if (event.key === "Escape") {
      event.preventDefault();
      closeDrawer();
      return;
    }

    if (event.key !== "Tab") {
      return;
    }

    var items = getFocusableItems();

    if (!items.length) {
      event.preventDefault();
      panel.focus();
      return;
    }

    var first = items[0];
    var last = items[items.length - 1];

    if (event.shiftKey && (document.activeElement === first || document.activeElement === panel)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  // Never leave the drawer open (and the page scroll-locked) after a resize
  // into the desktop layout.
  var desktopQuery = window.matchMedia("(min-width: 1024px)");
  var onViewportChange = function (event) {
    if (event.matches) {
      closeDrawer();
    }
  };

  if (typeof desktopQuery.addEventListener === "function") {
    desktopQuery.addEventListener("change", onViewportChange);
  } else if (typeof desktopQuery.addListener === "function") {
    desktopQuery.addListener(onViewportChange);
  }
})();
