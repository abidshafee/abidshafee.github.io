/**
 * My Account: form polish.
 *
 * Adds password visibility toggles and inline validation to the account
 * details and address forms. Loaded only on WooCommerce account pages
 * (see yusraah_account_assets()).
 *
 * @package Yusraah
 */
(function () {
  "use strict";

  var accountArea = document.querySelector(".woocommerce-account");

  if (!accountArea) {
    return;
  }

  var strings = (window.yusraahAccount && window.yusraahAccount.strings) || {};

  function text(key, fallback) {
    return strings[key] || fallback;
  }

  /*
   * -----------------------------------------------------------------------
   * Password visibility toggles
   * -----------------------------------------------------------------------
   */
  Array.prototype.forEach.call(
    accountArea.querySelectorAll('form input[type="password"]'),
    function (field) {
      var row = field.closest(".form-row");

      if (!row || field.closest(".password-field")) {
        return;
      }

      var wrapper = document.createElement("span");
      wrapper.className = "password-field";
      field.parentNode.insertBefore(wrapper, field);
      wrapper.appendChild(field);

      var button = document.createElement("button");
      button.type = "button";
      button.className = "password-toggle";
      button.setAttribute("data-password-toggle", "");
      button.setAttribute("aria-pressed", "false");
      button.setAttribute("aria-label", text("showPassword", "Show password"));

      if (field.id) {
        button.setAttribute("aria-controls", field.id);
      }

      var label = document.createElement("span");
      label.className = "password-toggle__label";
      label.textContent = text("show", "Show");
      button.appendChild(label);

      button.addEventListener("click", function () {
        var isVisible = field.type === "text";

        field.type = isVisible ? "password" : "text";
        button.setAttribute("aria-pressed", String(!isVisible));
        button.setAttribute(
          "aria-label",
          isVisible ? text("showPassword", "Show password") : text("hidePassword", "Hide password")
        );
        button.classList.toggle("is-visible", !isVisible);
        label.textContent = isVisible ? text("show", "Show") : text("hide", "Hide");
      });

      wrapper.appendChild(button);
    }
  );

  /*
   * -----------------------------------------------------------------------
   * Inline validation
   *
   * Same accessible pattern as the checkout form: a polite live-region error
   * message tied to the field through aria-describedby.
   * -----------------------------------------------------------------------
   */
  var errorCount = 0;

  function isBangladesh(form) {
    var country = form.querySelector("#billing_country");

    return !country || !country.value || country.value === "BD";
  }

  function isBdMobile(value) {
    var digits = String(value)
      .replace(/[\u09E6-\u09EF]/g, function (digit) {
        return String(digit.charCodeAt(0) - 0x09e6);
      })
      .replace(/\D+/g, "");

    if (digits.indexOf("880") === 0) {
      digits = digits.slice(3);
    }
    if (digits.length === 10 && digits.charAt(0) === "1") {
      digits = "0" + digits;
    }

    return /^01[3-9]\d{8}$/.test(digits);
  }

  function fieldMessage(form, field) {
    var row = field.closest(".form-row");

    if (field.disabled || field.type === "hidden" || !field.getClientRects().length) {
      return "";
    }

    var required =
      field.required ||
      field.getAttribute("aria-required") === "true" ||
      (row && row.classList.contains("validate-required")) ||
      // WooCommerce marks required fields with a "*" in the label only, and
      // does not always add the attribute or the row class (login, register).
      (row && !!row.querySelector("label .required"));
    var value = field.type === "checkbox" ? field.checked : String(field.value || "").trim();
    var missing =
      field.type === "checkbox"
        ? !field.checked
        : field.type === "radio"
        ? !(row && row.querySelector('input[type="radio"]:checked'))
        : !value;

    if (required && missing) {
      var label = row && row.querySelector("label");
      var labelText = label ? label.textContent.replace(/\*/g, "").trim() : "";
      var requiredMessage = text("required", "Please complete the %s field.");

      return requiredMessage.indexOf("%s") !== -1
        ? requiredMessage.replace("%s", labelText || "this")
        : requiredMessage;
    }

    var isEmail = field.type === "email" || (row && row.classList.contains("validate-email"));

    if (isEmail && value && field.validity && (field.validity.typeMismatch || field.validity.patternMismatch)) {
      return text("email", "Enter a valid email address.");
    }
    if (isEmail && value && field.type !== "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      return text("email", "Enter a valid email address.");
    }

    if (field.id === "billing_phone" && value && isBangladesh(form) && !isBdMobile(value)) {
      return text("phone", "Enter a valid Bangladeshi mobile number, e.g. 01712345678.");
    }

    if (field.validity && !field.validity.valid) {
      return text("invalid", "Please check this field and try again.");
    }

    return "";
  }

  function setError(field, message) {
    var row = field.closest(".form-row");

    if (!row) {
      return;
    }

    if (!Object.prototype.hasOwnProperty.call(field.dataset, "accountErrorId")) {
      errorCount += 1;
      field.dataset.accountErrorId = field.id
        ? "yusraah-account-error-" + field.id
        : "yusraah-account-error-" + errorCount;
      field.dataset.accountOriginalDescribedby = field.getAttribute("aria-describedby") || "";
      field.dataset.accountOriginalAriaInvalid = field.getAttribute("aria-invalid") || "";
    }

    var error = document.getElementById(field.dataset.accountErrorId);

    if (!error) {
      error = document.createElement("span");
      error.className = "account-inline-error";
      error.id = field.dataset.accountErrorId;
      error.setAttribute("role", "status");
      error.setAttribute("aria-live", "polite");
      row.appendChild(error);
    }

    error.textContent = message;
    row.classList.add("account-field-invalid");
    field.setAttribute("aria-invalid", "true");

    var described = [field.dataset.accountOriginalDescribedby, error.id].filter(Boolean);
    field.setAttribute("aria-describedby", described.join(" "));
  }

  function clearError(field) {
    var row = field.closest(".form-row");

    if (row) {
      row.classList.remove("account-field-invalid");
    }

    if (field.dataset.accountErrorId) {
      var error = document.getElementById(field.dataset.accountErrorId);

      if (error) {
        error.remove();
      }
      if (field.dataset.accountOriginalDescribedby) {
        field.setAttribute("aria-describedby", field.dataset.accountOriginalDescribedby);
      } else {
        field.removeAttribute("aria-describedby");
      }
      if (field.dataset.accountOriginalAriaInvalid) {
        field.setAttribute("aria-invalid", field.dataset.accountOriginalAriaInvalid);
      } else {
        field.removeAttribute("aria-invalid");
      }

      delete field.dataset.accountErrorId;
      delete field.dataset.accountOriginalDescribedby;
      delete field.dataset.accountOriginalAriaInvalid;
    }
  }

  function validate(form, field) {
    var message = fieldMessage(form, field);

    if (message) {
      setError(field, message);
    } else {
      clearError(field);
    }

    return message;
  }

  function isField(target) {
    return target && target.matches && target.matches(".form-row input, .form-row select, .form-row textarea");
  }

  Array.prototype.forEach.call(accountArea.querySelectorAll("form"), function (form) {
    if (!form.querySelector(".form-row")) {
      return;
    }

    form.addEventListener("focusout", function (event) {
      if (isField(event.target)) {
        validate(form, event.target);
      }
    });

    form.addEventListener(
      "invalid",
      function (event) {
        if (isField(event.target)) {
          validate(form, event.target);
        }
      },
      true
    );

    ["input", "change"].forEach(function (eventName) {
      form.addEventListener(eventName, function (event) {
        var row = event.target.closest ? event.target.closest(".form-row") : null;

        if (isField(event.target) && row && row.classList.contains("account-field-invalid")) {
          validate(form, event.target);
        }
      });
    });

    form.addEventListener(
      "submit",
      function (event) {
        var firstInvalid = null;

        Array.prototype.forEach.call(
          form.querySelectorAll(".form-row input, .form-row select, .form-row textarea"),
          function (field) {
            if (validate(form, field) && !firstInvalid) {
              firstInvalid = field;
            }
          }
        );

        if (firstInvalid) {
          event.preventDefault();
          event.stopImmediatePropagation();
          firstInvalid.scrollIntoView({ block: "center" });
          firstInvalid.focus({ preventScroll: true });
        }
      },
      true
    );
  });

  /*
   * -----------------------------------------------------------------------
   * Sign in / Create account
   *
   * One card, one form at a time. Both panels stay in the markup and the
   * inactive one is hidden with the `hidden` attribute; without JavaScript the
   * <noscript> styles in form-login.php keep both of them visible.
   * -----------------------------------------------------------------------
   */
  var auth = accountArea.querySelector(".yusraah-auth");

  if (auth) {
    var showAuthPanel = function (name, moveFocus) {
      var visible = null;

      Array.prototype.forEach.call(
        auth.querySelectorAll("[data-auth-panel]"),
        function (panel) {
          panel.hidden = panel.getAttribute("data-auth-panel") !== name;

          if (!panel.hidden) {
            visible = panel;
          }
        }
      );

      Array.prototype.forEach.call(
        auth.querySelectorAll("[data-auth-switch]"),
        function (button) {
          button.setAttribute(
            "aria-expanded",
            String(button.getAttribute("data-auth-switch") === name)
          );
        }
      );

      if (moveFocus && visible) {
        var field = visible.querySelector(
          'input:not([type="hidden"]):not([type="checkbox"]):not([disabled]), select, textarea'
        );

        if (field) {
          field.focus({ preventScroll: true });
        }
      }
    };

    Array.prototype.forEach.call(
      auth.querySelectorAll("[data-auth-switch]"),
      function (button) {
        button.addEventListener("click", function () {
          showAuthPanel(button.getAttribute("data-auth-switch"), true);
        });
      }
    );

    /* `#register` and `#login` links can point straight at one of the panels. */
    var panelFromHash = function () {
      var name = window.location.hash.replace("#", "");

      return name && auth.querySelector('[data-auth-panel="' + name + '"]') ? name : "";
    };

    window.addEventListener("hashchange", function () {
      var name = panelFromHash();

      if (name) {
        showAuthPanel(name, true);
      }
    });

    var initialPanel = panelFromHash();

    if (initialPanel) {
      showAuthPanel(initialPanel, true);
    }
  }

  /*
   * -----------------------------------------------------------------------
   * Wishlist: add every available item to the basket
   * -----------------------------------------------------------------------
   */
  var wishlistConfig = window.yusraahWishlist || {};
  var wishlistStatus = document.getElementById("yusraah-wishlist-status");

  function announceWishlist(message) {
    if (!wishlistStatus || !message) return;
    wishlistStatus.textContent = "";
    window.setTimeout(function () {
      wishlistStatus.textContent = message;
    }, 60);
  }

  function applyFragments(fragments) {
    if (!fragments) return;

    Object.keys(fragments).forEach(function (selector) {
      var current = document.querySelector(selector);
      if (!current) return;

      var template = document.createElement("template");
      template.innerHTML = String(fragments[selector]).trim();

      var replacement = template.content.firstElementChild;
      if (replacement) current.replaceWith(replacement);
    });

    if (window.jQuery) {
      window.jQuery(document.body).trigger("wc_fragments_loaded");
    }
  }

  Array.prototype.forEach.call(
    document.querySelectorAll("[data-wishlist-add-all]"),
    function (button) {
      button.addEventListener("click", function () {
        if (button.disabled || !wishlistConfig.ajaxUrl) {
          return;
        }

        var originalLabel = button.textContent;
        button.disabled = true;
        button.setAttribute("aria-busy", "true");
        button.textContent = (wishlistConfig.strings && wishlistConfig.strings.adding) || originalLabel;

        var formData = new FormData();
        formData.append("action", "yusraah_wishlist_add_all");
        formData.append("nonce", wishlistConfig.nonce || "");

        window
          .fetch(wishlistConfig.ajaxUrl, { method: "POST", credentials: "same-origin", body: formData })
          .then(function (response) {
            return response.json().catch(function () {
              return null;
            });
          })
          .then(function (payload) {
            if (!payload || !payload.success || !payload.data) {
              announceWishlist(
                (payload && payload.data && payload.data.message) ||
                  (wishlistConfig.strings && wishlistConfig.strings.addAllFailed)
              );
              return;
            }

            applyFragments(payload.data.fragments);
            announceWishlist(payload.data.message);

            if (window.jQuery) {
              window.jQuery(document.body).trigger("added_to_cart", [
                payload.data.fragments,
                payload.data.cart_hash,
                window.jQuery(button),
              ]);
            }
          })
          .catch(function () {
            announceWishlist(wishlistConfig.strings && wishlistConfig.strings.addAllFailed);
          })
          .finally(function () {
            button.disabled = false;
            button.removeAttribute("aria-busy");
            button.textContent = originalLabel;
          });
      });
    }
  );
})();
