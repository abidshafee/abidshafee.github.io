<?php
/**
 * My Account navigation
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/navigation.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.3.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Icons are keyed by endpoint so custom account items fall back gracefully.
 * The icon helper only returns markup from a fixed, safe set.
 */
$yusraah_account_icons = array(
	'dashboard'       => 'grid',
	'orders'          => 'box',
	'downloads'       => 'box',
	'wishlist'        => 'heart',
	'edit-address'    => 'pin',
	'payment-methods' => 'card',
	'edit-account'    => 'user',
	'customer-logout' => 'logout',
);
?>
<nav class="woocommerce-MyAccount-navigation account-nav" aria-label="<?php esc_attr_e( 'Account pages', 'yusraah' ); ?>">
	<ul class="account-nav__list">
		<?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
			<?php
			$yusraah_icon     = isset( $yusraah_account_icons[ $endpoint ] ) ? $yusraah_account_icons[ $endpoint ] : 'arrow';
			$yusraah_classes  = wc_get_account_menu_item_classes( $endpoint );
			$yusraah_classes .= ' account-nav__item account-nav__item--' . sanitize_html_class( $endpoint );

			// WooCommerce 9.3.0+ exposes a helper; older versions mark the class instead.
			$yusraah_is_current = function_exists( 'wc_is_current_account_menu_item' )
				? (bool) wc_is_current_account_menu_item( $endpoint )
				: (bool) preg_match( '/\bis-active\b/', $yusraah_classes );
			?>
			<li class="<?php echo esc_attr( $yusraah_classes ); ?>">
				<a
					href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>"
					class="account-nav__link"
					<?php echo $yusraah_is_current ? ' aria-current="page"' : ''; ?>
				>
					<span class="account-nav__icon" aria-hidden="true"><?php echo yusraah_icon( $yusraah_icon ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed inline SVG set. ?></span>
					<span class="account-nav__label"><?php echo esc_html( $label ); ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>
