<?php
/**
 * Wishlist
 *
 * Shows the products a customer has saved, reusing the standard product card.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

$yusraah_products = function_exists( 'yusraah_wishlist_products' ) ? yusraah_wishlist_products() : array();
$yusraah_count    = count( $yusraah_products );
$yusraah_addable  = 0;

foreach ( $yusraah_products as $yusraah_product ) {
	if ( $yusraah_product->is_type( 'simple' ) && $yusraah_product->is_purchasable() && $yusraah_product->is_in_stock() ) {
		++$yusraah_addable;
	}
}
?>
<section class="account-wishlist" aria-labelledby="account-wishlist-title" data-wishlist-page>
	<div class="account-panel__header account-wishlist__header">
		<h2 class="account-panel__title" id="account-wishlist-title"><?php esc_html_e( 'Wishlist', 'yusraah' ); ?></h2>
		<?php if ( $yusraah_count ) : ?>
			<p class="account-wishlist__count">
				<?php
				printf(
					/* translators: %s: number of saved products */
					esc_html( _n( '%s saved item', '%s saved items', $yusraah_count, 'yusraah' ) ),
					esc_html( number_format_i18n( $yusraah_count ) )
				);
				?>
			</p>
		<?php endif; ?>
	</div>

	<div id="yusraah-wishlist-status" class="screen-reader-text" role="status" aria-live="polite"></div>

	<div class="account-wishlist__empty" data-wishlist-empty<?php echo $yusraah_count ? ' hidden' : ''; ?>>
		<div class="account-empty">
			<span class="account-empty__icon" aria-hidden="true"><?php echo yusraah_icon( 'heart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed inline SVG set. ?></span>
			<p class="account-empty__text"><?php esc_html_e( 'You have not saved any pieces yet. Tap the heart on a product to keep it here.', 'yusraah' ); ?></p>
			<a class="account-empty__cta" href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>"><?php esc_html_e( 'Browse the collection', 'yusraah' ); ?></a>
		</div>
	</div>

	<div class="account-wishlist__items" data-wishlist-items<?php echo $yusraah_count ? '' : ' hidden'; ?>>
		<?php if ( $yusraah_addable ) : ?>
			<div class="account-wishlist__toolbar">
				<button class="account-wishlist__add-all" type="button" data-wishlist-add-all>
					<?php
					printf(
						/* translators: %s: number of items that can be added */
						esc_html__( 'Add all to basket (%s)', 'yusraah' ),
						esc_html( number_format_i18n( $yusraah_addable ) )
					);
					?>
				</button>
			</div>
		<?php endif; ?>

		<?php
		woocommerce_product_loop_start();

		foreach ( $yusraah_products as $yusraah_product ) {
			$yusraah_post = get_post( $yusraah_product->get_id() );

			if ( ! $yusraah_post ) {
				continue;
			}

			$GLOBALS['post']    = $yusraah_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			$GLOBALS['product'] = $yusraah_product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			setup_postdata( $yusraah_post );

			wc_get_template_part( 'content', 'product' );
		}

		wp_reset_postdata();
		woocommerce_product_loop_end();
		?>
	</div>
</section>
