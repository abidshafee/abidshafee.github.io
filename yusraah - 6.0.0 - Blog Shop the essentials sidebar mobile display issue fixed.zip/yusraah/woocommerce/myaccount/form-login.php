<?php
/**
 * Login form
 *
 * Overrides the WooCommerce template so that the login and register forms
 * share one centered card and only one of them is shown at a time. Both forms
 * stay in the markup: account.js hides the inactive panel, while the
 * <noscript> styles below keep both of them visible without JavaScript.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/form-login.php.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package Yusraah
 * @author  Shafekul Abid
 * @version 9.9.0
 */

defined( 'ABSPATH' ) || exit;

$yusraah_registration_enabled = 'yes' === get_option( 'woocommerce_enable_myaccount_registration' );

/*
 * WooCommerce re-renders this template when a login or registration attempt
 * fails, so the panel that was submitted has to stay open. Plain requests fall
 * back to the login panel; `#register` links are handled by account.js.
 */
$yusraah_open_register = $yusraah_registration_enabled && isset( $_POST['register'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- read only; WooCommerce verifies the nonce.
?>
<?php do_action( 'woocommerce_before_customer_login_form' ); ?>

<div class="u-columns col2-set yusraah-auth" id="customer_login">

	<?php /* Progressive enhancement: no JavaScript means no toggle, so show both forms. */ ?>
	<noscript>
		<style>
			.woocommerce-account #customer_login .yusraah-auth__panel[hidden] { display: block; }
			.woocommerce-account #customer_login .yusraah-auth__switch { display: none; }
		</style>
	</noscript>

	<div class="u-column1 col-1 yusraah-auth__panel" id="yusraah-panel-login" data-auth-panel="login"<?php echo $yusraah_open_register ? ' hidden' : ''; ?>>

		<h2 class="yusraah-auth__title"><?php esc_html_e( 'Welcome back', 'yusraah' ); ?></h2>
		<p class="yusraah-auth__intro"><?php esc_html_e( 'Sign in to track your orders, saved addresses and wishlist.', 'yusraah' ); ?></p>

		<form class="woocommerce-form woocommerce-form-login login" method="post" novalidate>

			<?php do_action( 'woocommerce_login_form_start' ); ?>

			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username"><?php esc_html_e( 'Username or email address', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
				<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="username" autocomplete="username"<?php echo $yusraah_open_register ? '' : ' autofocus'; ?> value="<?php echo ( ! empty( $_POST['username'] ) && is_string( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" required aria-required="true" /><?php // @codingStandardsIgnoreLine ?>
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="password"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
				<input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password" required aria-required="true" />
			</p>

			<?php do_action( 'woocommerce_login_form' ); ?>

			<p class="form-row">
				<label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
					<input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span><?php esc_html_e( 'Remember me', 'woocommerce' ); ?></span>
				</label>
				<?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
				<button type="submit" class="woocommerce-button button woocommerce-form-login__submit<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="login" value="<?php esc_attr_e( 'Log in', 'woocommerce' ); ?>"><?php esc_html_e( 'Log in', 'woocommerce' ); ?></button>
			</p>

			<p class="woocommerce-LostPassword lost_password">
				<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Lost your password?', 'woocommerce' ); ?></a>
			</p>

			<?php do_action( 'woocommerce_login_form_end' ); ?>

		</form>

		<?php if ( $yusraah_registration_enabled ) : ?>
			<p class="yusraah-auth__switch">
				<button type="button" class="yusraah-auth__switch-button" data-auth-switch="register" aria-controls="yusraah-panel-register" aria-expanded="<?php echo $yusraah_open_register ? 'true' : 'false'; ?>">
					<?php esc_html_e( "Don't have an account?", 'yusraah' ); ?>
					<span class="yusraah-auth__switch-action"><?php esc_html_e( 'Register', 'yusraah' ); ?></span>
				</button>
			</p>
		<?php endif; ?>

	</div>

	<?php if ( $yusraah_registration_enabled ) : ?>

		<div class="u-column2 col-2 yusraah-auth__panel" id="yusraah-panel-register" data-auth-panel="register"<?php echo $yusraah_open_register ? '' : ' hidden'; ?>>

			<h2 class="yusraah-auth__title"><?php esc_html_e( 'Create your account', 'yusraah' ); ?></h2>
			<p class="yusraah-auth__intro"><?php esc_html_e( 'Create an account to track orders, save addresses and keep a wishlist.', 'yusraah' ); ?></p>

			<form method="post" class="woocommerce-form woocommerce-form-register register" novalidate <?php do_action( 'woocommerce_register_form_tag' ); ?> >

				<?php do_action( 'woocommerce_register_form_start' ); ?>

				<?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>

					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
						<label for="reg_username"><?php esc_html_e( 'Username', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
						<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username"<?php echo $yusraah_open_register ? ' autofocus' : ''; ?> value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" required aria-required="true" /><?php // @codingStandardsIgnoreLine ?>
					</p>

				<?php endif; ?>

				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
					<label for="reg_email"><?php esc_html_e( 'Email address', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
					<input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email"<?php echo ( $yusraah_open_register && 'no' !== get_option( 'woocommerce_registration_generate_username' ) ) ? ' autofocus' : ''; ?> value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" required aria-required="true" /><?php // @codingStandardsIgnoreLine ?>
				</p>

				<?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>

					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
						<label for="reg_password"><?php esc_html_e( 'Password', 'woocommerce' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span><span class="screen-reader-text"><?php esc_html_e( 'Required', 'woocommerce' ); ?></span></label>
						<input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" required aria-required="true" />
					</p>

				<?php else : ?>

					<p><?php esc_html_e( 'A link to set a new password will be sent to your email address.', 'woocommerce' ); ?></p>

				<?php endif; ?>

				<?php do_action( 'woocommerce_register_form' ); ?>

				<p class="woocommerce-form-row form-row">
					<?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
					<button type="submit" class="woocommerce-Button woocommerce-button button<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?> woocommerce-form-register__submit" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce' ); ?>"><?php esc_html_e( 'Register', 'woocommerce' ); ?></button>
				</p>

				<?php do_action( 'woocommerce_register_form_end' ); ?>

			</form>

			<p class="yusraah-auth__switch">
				<button type="button" class="yusraah-auth__switch-button" data-auth-switch="login" aria-controls="yusraah-panel-login" aria-expanded="<?php echo $yusraah_open_register ? 'false' : 'true'; ?>">
					<?php esc_html_e( 'Already have an account?', 'yusraah' ); ?>
					<span class="yusraah-auth__switch-action"><?php esc_html_e( 'Log in', 'yusraah' ); ?></span>
				</button>
			</p>

		</div>

	<?php endif; ?>

</div>

<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
