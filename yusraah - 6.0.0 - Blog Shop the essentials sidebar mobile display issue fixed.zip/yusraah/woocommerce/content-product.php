<?php
/**
 * Product card in the shop loop.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */
defined( 'ABSPATH' ) || exit;
global $product;

if ( ! $product || ! $product->is_visible() ) {
	return;
}

// Get product categories - get the main category (lowest level)
$categories = get_the_terms( $product->get_id(), 'product_cat' );
$category_name = '';
$category_link = '';
if ( $categories && ! is_wp_error( $categories ) ) {
	// Find the lowest level category
	$main_category = $categories[0];
	foreach ( $categories as $category ) {
		if ( $category->parent > 0 && $category->parent !== $main_category->term_id ) {
			$main_category = $category;
		}
	}
	$category_name = $main_category->name;
	$category_link = get_term_link( $main_category );
}

// Check if product is on sale
$on_sale = $product->is_on_sale();
$sale_percentage = '';
if ( $on_sale ) {
	if ( $product->is_type( 'variable' ) ) {
		$regular_price = $product->get_variation_regular_price( 'min' );
		$sale_price = $product->get_variation_sale_price( 'min' );
	} else {
		$regular_price = $product->get_regular_price();
		$sale_price = $product->get_sale_price();
	}
	if ( $regular_price && $sale_price && $regular_price > 0 ) {
		$sale_percentage = round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 ) . '%';
	}
}

// Check stock status
$is_out_of_stock = ! $product->is_in_stock();
$stock_status = $product->get_stock_status();
$low_stock = false;

// Check low stock for products that manage stock
if ( $product->managing_stock() ) {
	$stock_quantity = $product->get_stock_quantity();
	$low_stock_amount = get_option( 'woocommerce_notify_low_stock_amount', 2 );
	$low_stock = $stock_quantity <= $low_stock_amount;
}

// Check if product is featured or new
$is_featured = $product->is_featured();
$is_new = yusraah_is_new_product( $product->get_id() );

$product_permalink = $product->get_permalink();

// Saved state is rendered server-side so the heart is correct before JS runs.
$wishlist_saved = function_exists( 'yusraah_wishlist_has' ) && yusraah_wishlist_has( $product->get_id() );
?>
<li <?php wc_product_class( 'yusraah-product', $product ); ?>>
	<div class="product-card <?php echo $is_out_of_stock ? 'product-card--sold-out' : ''; ?> <?php echo $is_featured ? 'product-card--featured' : ''; ?> <?php echo $is_new ? 'product-card--new' : ''; ?>" itemscope itemtype="https://schema.org/Product">
		<div class="product-card__media">
			<a class="woocommerce-LoopProduct-link woocommerce-loop-product__link" href="<?php echo esc_url( $product_permalink ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name */ __( 'View %s', 'yusraah' ), $product->get_name() ) ); ?>">
				<div class="product-card__image">
					<?php woocommerce_template_loop_product_thumbnail(); ?>
					<div class="product-card__badges">
						<?php
						// Sale badge markup comes from the woocommerce_sale_flash filter.
						woocommerce_show_product_loop_sale_flash();

						// One secondary badge only, so the stack never exceeds 2 badges.
						if ( $is_out_of_stock ) :
							?>
							<span class="yusraah-badge yusraah-badge--sold-out"><?php esc_html_e( 'Sold out', 'yusraah' ); ?></span>
						<?php elseif ( $is_new ) : ?>
							<span class="yusraah-badge yusraah-badge--new"><?php esc_html_e( 'New', 'yusraah' ); ?></span>
						<?php elseif ( $is_featured ) : ?>
							<span class="yusraah-badge yusraah-badge--featured"><?php esc_html_e( 'Featured', 'yusraah' ); ?></span>
						<?php endif; ?>
					</div>
					<?php if ( ! $is_out_of_stock && $low_stock ) : ?>
						<span class="product-card__low-stock" aria-label="<?php esc_attr_e( 'Low stock', 'yusraah' ); ?>"><?php esc_html_e( 'Low stock', 'yusraah' ); ?></span>
					<?php endif; ?>
				</div>
			</a>
			<div class="product-card__actions" role="group" aria-label="<?php esc_attr_e( 'Product actions', 'yusraah' ); ?>">
				<button class="wishlist-toggle" type="button" aria-label="<?php echo esc_attr( $wishlist_saved ? __( 'Remove from wishlist', 'yusraah' ) : __( 'Add to wishlist', 'yusraah' ) ); ?>" aria-pressed="<?php echo $wishlist_saved ? 'true' : 'false'; ?>" data-wishlist="<?php echo esc_attr( $product->get_id() ); ?>"><?php echo yusraah_icon( 'heart' ); ?></button>
				<button class="quick-view-toggle" type="button" aria-label="<?php esc_attr_e( 'Quick view', 'yusraah' ); ?>" data-quick-view="<?php echo esc_attr( $product->get_id() ); ?>">
					<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"/><path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7Z"/></svg>
				</button>
			</div>
		</div>
		<div class="product-card__details">
			<?php if ( $category_name ) : ?>
				<div class="product-card__category">
					<?php if ( $category_link && ! is_wp_error( $category_link ) ) : ?>
						<a href="<?php echo esc_url( $category_link ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: category name */ __( 'View products in %s', 'yusraah' ), $category_name ) ); ?>"><?php echo esc_html( $category_name ); ?></a>
					<?php else : ?>
						<span><?php echo esc_html( $category_name ); ?></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<div class="product-card__name">
				<h2 class="woocommerce-loop-product__title" itemprop="name">
					<a href="<?php echo esc_url( $product_permalink ); ?>" itemprop="url"><?php echo esc_html( $product->get_name() ); ?></a>
				</h2>
			</div>
			<div class="product-card__rating" itemprop="aggregateRating" itemscope itemtype="https://schema.org/AggregateRating">
				<meta itemprop="ratingValue" content="<?php echo esc_attr( $product->get_average_rating() ); ?>">
				<meta itemprop="reviewCount" content="<?php echo esc_attr( $product->get_review_count() ); ?>">
				<?php woocommerce_template_loop_rating(); ?>
				<?php if ( $product->get_review_count() > 0 ) : ?>
					<span class="review-count">
						<a href="<?php echo esc_url( $product_permalink ); ?>#reviews">
							<?php
							/* translators: %s: review count */
							printf( _n( '(%s review)', '(%s reviews)', $product->get_review_count(), 'yusraah' ), number_format_i18n( $product->get_review_count() ) );
							?>
						</a>
					</span>
				<?php endif; ?>
			</div>
			<div class="product-card__meta">
				<?php woocommerce_template_loop_price(); ?>
				<?php if ( $on_sale && $sale_percentage ) : ?>
					<span class="product-card__sale-badge" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: percentage */ __( '%s discount', 'yusraah' ), $sale_percentage ) ); ?>"><?php echo esc_html( $sale_percentage ); ?> <?php esc_html_e( 'off', 'yusraah' ); ?></span>
				<?php endif; ?>
			</div>
			<div class="product-card__cart"><?php yusraah_render_card_stepper( $product ); ?></div>
		</div>
	</div>
</li>
