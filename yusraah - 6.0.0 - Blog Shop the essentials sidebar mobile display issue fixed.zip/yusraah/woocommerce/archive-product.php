<?php
/**
 * WooCommerce archive product template with filter sidebar.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );

?>
<div class="woocommerce-shop-layout">
	<aside class="widget-area">
		<?php
		/**
		 * Hook: woocommerce_sidebar.
		 *
		 * @hooked woocommerce_get_sidebar - 10
		 */
		do_action( 'woocommerce_sidebar' );
		?>
	</aside>

	<div class="woocommerce-shop-content">
		<?php
		if ( apply_filters( 'woocommerce_show_page_title', true ) ) {
			?>
			<div class="archive-heading">
				<?php if ( is_product_category() ) : ?>
					<p class="eyebrow"><?php esc_html_e( 'Collection', 'yusraah' ); ?></p>
				<?php else : ?>
					<p class="eyebrow"><?php esc_html_e( 'Shop', 'yusraah' ); ?></p>
				<?php endif; ?>
				<h1 class="page-title"><?php woocommerce_page_title(); ?></h1>
			</div>
			<?php
		}

		/**
		 * Hook: woocommerce_archive_description.
		 *
		 * @hooked woocommerce_taxonomy_archive_description - 10
		 * @hooked woocommerce_product_archive_description - 10
		 */
		do_action( 'woocommerce_archive_description' );

		if ( woocommerce_product_loop() ) {

			/**
			 * Hook: woocommerce_before_shop_loop.
			 *
			 * @hooked woocommerce_output_all_notices - 10
			 * @hooked woocommerce_result_count - 20
			 * @hooked woocommerce_catalog_ordering - 30
			 */
			do_action( 'woocommerce_before_shop_loop' );

			woocommerce_product_loop_start();

			if ( wc_get_loop_prop( 'total' ) ) {
				while ( have_posts() ) {
					the_post();

					/**
					 * Hook: woocommerce_shop_loop.
					 *
					 * @hooked WC_Structured_Data::generate_product_data() - 10
					 */
					do_action( 'woocommerce_shop_loop' );

					wc_get_template_part( 'content', 'product' );
				}
			}

			woocommerce_product_loop_end();

			/**
			 * Hook: woocommerce_after_shop_loop.
			 *
			 * @hooked woocommerce_pagination - 10
			 */
			do_action( 'woocommerce_after_shop_loop' );
		} else {
			/**
			 * Hook: woocommerce_no_products_found.
			 *
			 * @hooked wc_no_products_found - 10
			 */
			do_action( 'woocommerce_no_products_found' );
		}
		?>
	</div>
</div>

<?php get_footer( 'shop' );
