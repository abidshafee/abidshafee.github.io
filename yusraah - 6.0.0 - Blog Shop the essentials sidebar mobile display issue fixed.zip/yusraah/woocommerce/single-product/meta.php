<?php
/**
 * Single Product Meta
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/meta.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     Yusraah
 * @version     11.2.0
 */

defined( 'ABSPATH' ) || exit;

global $product;
?>
<div class="product_meta">

	<?php do_action( 'woocommerce_product_meta_start' ); ?>

	<?php
	/*
	 * Core also prints the SKU block for a variable product that has no SKU, which
	 * renders an empty "SKU: N/A" row. The theme only prints the row when the
	 * product actually has a SKU.
	 */
	$yusraah_sku = $product->get_sku();
	?>
	<?php if ( wc_product_sku_enabled() && '' !== (string) $yusraah_sku ) : ?>

		<span class="sku_wrapper"><?php esc_html_e( 'SKU:', 'woocommerce' ); ?> <span class="sku"><?php echo esc_html( $yusraah_sku ); ?></span></span>

	<?php endif; ?>

	<?php
	/**
	 * Filters the ordering mode for product categories in the single product meta.
	 *
	 * @param string     $orderby Ordering mode passed to wc_get_product_category_list().
	 * @param WC_Product $product Product object.
	 *
	 * @since 11.2.0
	 */
	$product_category_orderby = apply_filters( 'woocommerce_product_meta_category_orderby', 'breadcrumb', $product );

	$product_category_list = wc_get_product_category_list(
		$product->get_id(),
		', ',
		'<span class="posted_in">' . _n( 'Category:', 'Categories:', count( $product->get_category_ids() ), 'woocommerce' ) . ' ',
		'</span>',
		is_string( $product_category_orderby ) ? $product_category_orderby : ''
	);
	echo is_string( $product_category_list ) ? $product_category_list : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	?>

	<?php echo wc_get_product_tag_list( $product->get_id(), ', ', '<span class="tagged_as">' . _n( 'Tag:', 'Tags:', count( $product->get_tag_ids() ), 'woocommerce' ) . ' ', '</span>' ); ?>

	<?php do_action( 'woocommerce_product_meta_end' ); ?>

</div>
