<?php
/**
 * Single product description tab.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/tabs/description.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package Yusraah
 * @version 2.0.0
 */

defined( 'ABSPATH' ) || exit;

global $post;

$heading = apply_filters( 'woocommerce_product_description_heading', __( 'Description', 'woocommerce' ) );

// The theme keeps the tab even when the product has no body copy, so the tab
// panel explains the state instead of rendering blank.
$yusraah_description = trim( (string) get_the_content() );

?>

<?php if ( $heading ) : ?>
	<h2 class="yusraah-tab-panel-heading"><?php echo esc_html( $heading ); ?></h2>
<?php endif; ?>

<?php if ( '' !== $yusraah_description ) : ?>
	<?php the_content(); ?>
<?php else : ?>
	<p class="yusraah-tab-empty"><?php esc_html_e( 'This product does not have a written description yet. Get in touch with us if you would like more details.', 'yusraah' ); ?></p>
<?php endif; ?>
