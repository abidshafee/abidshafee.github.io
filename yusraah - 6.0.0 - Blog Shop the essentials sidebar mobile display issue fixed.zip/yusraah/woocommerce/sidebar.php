<?php
/**
 * WooCommerce sidebar with custom filters.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_active_sidebar( 'shop-sidebar' ) ) {
	yusraah_product_filter_sidebar();
	return;
}

dynamic_sidebar( 'shop-sidebar' );
