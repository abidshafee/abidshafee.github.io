<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package Yusraah
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

/**
 * Hook: woocommerce_before_single_product.
 *
 * @hooked woocommerce_output_all_notices - 10
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- get_the_password_form() returns WordPress-generated form markup.
	return;
}
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( '', $product ); ?>>

	<?php
	/**
	 * The two columns of the single product layout. Only these two elements take
	 * part in the grid, so anything printed afterwards — upsells, related
	 * products and the cross-sells — is a normal full-width block underneath,
	 * with no `grid-column` override needed to keep it out of the columns.
	 *
	 * Left column: the gallery, then the tabs. WooCommerce prints the tabs on
	 * `woocommerce_after_single_product_summary`, which would make them a
	 * sibling of the buy box; the theme moves that hook onto
	 * `yusraah_product_primary` so the tabs stay in the same column as
	 * the gallery.
	 */
	?>
	<div class="yusraah-product-grid">

		<div class="yusraah-product-primary">
			<?php
			/**
			 * Hook: woocommerce_before_single_product_summary.
			 *
			 * @hooked woocommerce_show_product_images - 20
			 */
			do_action( 'woocommerce_before_single_product_summary' );

			/**
			 * Hook: yusraah_product_primary.
			 *
			 * Fires inside the left column, directly under the gallery.
			 *
			 * @hooked woocommerce_output_product_data_tabs - 20
			 */
			do_action( 'yusraah_product_primary' );
			?>
		</div>

		<div class="yusraah-product-summary-column">
			<div class="summary entry-summary">
				<?php
				/**
				 * Hook: woocommerce_single_product_summary.
				 *
				 * @hooked yusraah_single_product_breadcrumb - 2
				 * @hooked yusraah_single_product_category - 4
				 * @hooked woocommerce_template_single_title - 5
				 * @hooked woocommerce_template_single_rating - 10
				 * @hooked yusraah_single_product_price - 11
				 * @hooked woocommerce_template_single_excerpt - 20
				 * @hooked woocommerce_template_single_add_to_cart - 30
				 * @hooked yusraah_single_product_stock - 35
				 * @hooked yusraah_single_product_reassurance - 36
				 * @hooked woocommerce_template_single_meta - 38
				 * @hooked yusraah_single_product_wishlist - 39
				 * @hooked yusraah_product_social_sharing - 40
				 * @hooked WC_Structured_Data::generate_product_data() - 60
				 */
				do_action( 'woocommerce_single_product_summary' );
				?>
			</div>
		</div>

	</div>

	<?php
	/**
	 * Hook: woocommerce_after_single_product_summary.
	 *
	 * Upsells and related products are printed after the two-column wrapper, so
	 * they are full-width blocks under the grid instead of grid items.
	 *
	 * @hooked woocommerce_upsell_display - 15
	 * @hooked woocommerce_output_related_products - 20
	 */
	do_action( 'woocommerce_after_single_product_summary' );
	?>
</div>

<?php do_action( 'woocommerce_after_single_product' ); ?>
