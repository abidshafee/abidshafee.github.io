<?php
/**
 * Blog archive: posts index, categories, tags, authors.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

get_header();

$defaults       = yusraah_blog_defaults();
$hero_title     = get_theme_mod( 'yusraah_blog_hero_title', $defaults['blog_hero_title'] );
$hero_subtitle  = get_theme_mod( 'yusraah_blog_hero_subtitle', $defaults['blog_hero_subtitle'] );
$featured_on    = (bool) get_theme_mod( 'yusraah_blog_featured_post', $defaults['blog_featured_post'] );
$columns        = get_theme_mod( 'yusraah_blog_columns', $defaults['blog_columns'] );
$pagination     = get_theme_mod( 'yusraah_blog_pagination', $defaults['blog_pagination'] );
$blog_id        = (int) get_option( 'page_for_posts' );

// Category chips: All + post categories.
$chips = array_merge(
	array( array( 'label' => __( 'All', 'yusraah' ), 'url' => $blog_id ? get_permalink( $blog_id ) : home_url( '/' ), 'current' => is_home() ) ),
	array_map(
		static function ( $cat ) {
			return array(
				'label'   => $cat->name,
				'url'     => get_category_link( $cat ),
				'current' => is_category( $cat->term_id ),
			);
		},
		get_categories( array( 'hide_empty' => true, 'number' => 12 ) )
	)
);
?>
<main id="main-content" class="blog-archive">
	<header class="blog-hero">
		<div class="blog-hero__inner">
			<h1><?php echo esc_html( is_search() ? sprintf( __( 'Results for “%s”', 'yusraah' ), get_search_query() ) : ( is_category() || is_tag() || is_author() ? wp_strip_all_tags( get_the_archive_title() ) : $hero_title ) ); ?></h1>
			<?php if ( ! is_search() && ! is_category() && ! is_tag() && ! is_author() && $hero_subtitle ) : ?>
				<p><?php echo esc_html( $hero_subtitle ); ?></p>
			<?php endif; ?>
			<form class="blog-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<label class="screen-reader-text" for="blog-search-input"><?php esc_html_e( 'Search the journal', 'yusraah' ); ?></label>
				<input type="search" id="blog-search-input" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search the journal…', 'yusraah' ); ?>">
				<button type="submit" aria-label="<?php esc_attr_e( 'Search', 'yusraah' ); ?>"><?php echo yusraah_icon( 'search' ); ?></button>
			</form>
		</div>
	</header>

	<nav class="blog-chips" aria-label="<?php esc_attr_e( 'Filter by category', 'yusraah' ); ?>">
		<?php foreach ( $chips as $chip ) : ?>
			<a class="blog-chip<?php echo $chip['current'] ? ' is-current' : ''; ?>" href="<?php echo esc_url( $chip['url'] ); ?>"<?php echo $chip['current'] ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $chip['label'] ); ?></a>
		<?php endforeach; ?>
	</nav>

	<div class="blog-layout blog-layout--<?php echo esc_attr( $columns ); ?>-col">
		<div class="blog-main">
			<?php if ( have_posts() ) : ?>
				<?php
				// Featured post: first post on the first page only.
				$featured_shown = false;
				if ( $featured_on && ! is_paged() && ! is_search() && ! is_author() ) {
					$featured_post = $wp_query->posts[0];
					if ( $featured_post ) {
						setup_postdata( $featured_post );
						$featured_cat = yusraah_blog_first_category( $featured_post->ID );
						?>
						<article class="blog-featured">
							<a class="blog-featured__media" href="<?php echo esc_url( get_permalink( $featured_post ) ); ?>">
								<?php
								if ( has_post_thumbnail( $featured_post ) ) {
									echo get_the_post_thumbnail( $featured_post, 'yusraah-blog-card', array( 'alt' => trim( wp_strip_all_tags( get_the_title( $featured_post ) ) ) ) );
								} else {
									echo yusraah_blog_placeholder( $featured_post->ID ); // phpcs:ignore WordPress.Security.EscapeOutput
								}
								?>
							</a>
							<div class="blog-featured__body">
								<?php if ( $featured_cat[0] ) : ?>
									<a class="blog-card__category" href="<?php echo esc_url( $featured_cat[1] ); ?>"><?php echo esc_html( $featured_cat[0] ); ?></a>
								<?php endif; ?>
								<h2 class="blog-featured__title"><a href="<?php echo esc_url( get_permalink( $featured_post ) ); ?>"><?php echo esc_html( get_the_title( $featured_post ) ); ?></a></h2>
								<p class="blog-featured__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt( $featured_post ), 30, '…' ) ); ?></p>
								<div class="blog-card__meta">
									<span><?php echo esc_html( get_the_author_meta( 'display_name', $featured_post->post_author ) ); ?></span>
									<span aria-hidden="true">·</span>
									<time datetime="<?php echo esc_attr( get_the_date( 'c', $featured_post ) ); ?>"><?php echo esc_html( get_the_date( '', $featured_post ) ); ?></time>
									<span aria-hidden="true">·</span>
									<span><?php printf( esc_html__( '%d min read', 'yusraah' ), (int) yusraah_blog_reading_time( $featured_post->post_content ) ); ?></span>
								</div>
							</div>
						</article>
						<?php
						$featured_shown = true;
						wp_reset_postdata();
					}
				}
				?>

				<div class="blog-grid" data-blog-grid>
					<?php
					$card_index = 0;
					while ( have_posts() ) :
						the_post();
						if ( $featured_shown && 0 === $card_index && ! is_search() ) {
							// Skip the post already rendered as featured (first page only).
							++$card_index;
							continue;
						}
						++$card_index;
						yusraah_blog_card();
					endwhile;
					?>
				</div>

				<?php if ( 'load-more' === $pagination && $wp_query->max_num_pages > 1 ) : ?>
					<div class="blog-pagination">
						<button type="button" class="button button--dark blog-load-more" data-blog-load-more
							data-paged="2" data-max="<?php echo esc_attr( $wp_query->max_num_pages ); ?>"
							data-cat="<?php echo esc_attr( is_category() ? get_queried_object_id() : 0 ); ?>"
							data-s="<?php echo esc_attr( get_search_query() ); ?>"
							data-blog-id="<?php echo esc_attr( $blog_id ); ?>">
							<?php esc_html_e( 'Load more', 'yusraah' ); ?>
						</button>
						<noscript>
							<div class="blog-pagination__fallback"><?php the_posts_pagination(); ?></div>
						</noscript>
					</div>
				<?php elseif ( $wp_query->max_num_pages > 1 ) : ?>
					<div class="blog-pagination"><?php the_posts_pagination(); ?></div>
				<?php endif; ?>
			<?php else : ?>
				<div class="blog-empty">
					<h2><?php echo is_search() ? esc_html__( 'Nothing found.', 'yusraah' ) : esc_html__( 'No posts yet.', 'yusraah' ); ?></h2>
					<p><?php esc_html_e( 'Try another search or browse the collection while we prepare new stories.', 'yusraah' ); ?></p>
					<a class="button button--dark" href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' ) ); ?>"><?php esc_html_e( 'Browse the collection', 'yusraah' ); ?></a>
				</div>
			<?php endif; ?>
		</div>

		<?php yusraah_blog_sidebar(); ?>
	</div>
</main>
<?php get_footer(); ?>
