<?php
/**
 * Search results — reuses the blog card grid.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

get_header();
?>
<main id="main-content" class="blog-archive">
	<header class="blog-hero">
		<div class="blog-hero__inner">
			<h1><?php printf( esc_html__( 'Results for “%s”', 'yusraah' ), esc_html( get_search_query() ) ); ?></h1>
			<p><?php echo esc_html( sprintf( _n( '%s result found', '%s results found', $wp_query->found_posts, 'yusraah' ), number_format_i18n( $wp_query->found_posts ) ) ); ?></p>
			<form class="blog-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<label class="screen-reader-text" for="blog-search-input"><?php esc_html_e( 'Search', 'yusraah' ); ?></label>
				<input type="search" id="blog-search-input" name="s" value="<?php echo esc_attr( get_search_query() ); ?>">
				<button type="submit" aria-label="<?php esc_attr_e( 'Search', 'yusraah' ); ?>"><?php echo yusraah_icon( 'search' ); ?></button>
			</form>
		</div>
	</header>
	<div class="blog-layout blog-layout--3-col">
		<div class="blog-main">
			<?php if ( have_posts() ) : ?>
				<div class="blog-grid">
					<?php while ( have_posts() ) : the_post(); yusraah_blog_card(); endwhile; ?>
				</div>
				<?php if ( $wp_query->max_num_pages > 1 ) : ?>
					<div class="blog-pagination"><?php the_posts_pagination(); ?></div>
				<?php endif; ?>
			<?php else : ?>
				<div class="blog-empty">
					<h2><?php esc_html_e( 'Nothing found.', 'yusraah' ); ?></h2>
					<p><?php esc_html_e( 'Try another search, or browse the full collection.', 'yusraah' ); ?></p>
					<a class="button button--dark" href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' ) ); ?>"><?php esc_html_e( 'Browse the collection', 'yusraah' ); ?></a>
				</div>
			<?php endif; ?>
		</div>
	</div>
</main>
<?php get_footer(); ?>
