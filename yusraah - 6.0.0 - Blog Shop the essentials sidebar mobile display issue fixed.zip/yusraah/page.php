<?php
/**
 * Standard page template.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */
get_header();
?>
<main id="main-content" class="page-shell page-content">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class(); ?>>
			<header class="page-title"><p class="eyebrow"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p><h1><?php the_title(); ?></h1></header>
			<div class="entry-content"><?php the_content(); ?></div>
		</article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
