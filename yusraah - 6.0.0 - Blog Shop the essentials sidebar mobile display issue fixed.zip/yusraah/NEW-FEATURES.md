# Yusraah Theme - New Features Documentation

## Version 2.3.0

This document describes the new user experience features added to the Yusraah WooCommerce theme.

**Theme Author:** Shafekul Abid  
**Author URI:** https://abidshafee.github.io/

### What's New in 1.5.0
- **Header Improvements**: Enhanced header with category navigation, sticky behavior, and better accessibility
- **Product Card Redesign**: Complete overhaul of product cards with improved layout, spacing, and accessibility
- **Single Product Page Layout Fixes**: Fixed overlapping issues with related products
- **Bug Fixes**: Resolved sale badge clipping, image aspect ratio issues, and button layout problems

This document describes the new user experience features added to the Yusraah WooCommerce theme.

### What's New in 1.4.0
- **Product Card Redesign**: Complete overhaul of product cards with improved layout, spacing, and accessibility
- **Single Product Page Layout Fixes**: Fixed overlapping issues with related products
- **Bug Fixes**: Resolved sale badge clipping, image aspect ratio issues, and button layout problems

### Hotfix 1.4.1
- **Fixed Sale Badge Overlapping**: Sale badge now has max-width and word-wrap to prevent overlapping with action buttons
- **Fixed Variable Product Price Calculation**: Sale percentage now correctly calculates for variable products using min prices
- **Fixed Quantity Stepper Styling**: Updated CSS class names to match PHP output (`qty-stepper__btn` instead of `qty-stepper__minus/plus`)
- **Fixed Price Display Flexbox**: Added flex-wrap to price meta to prevent layout issues with long prices
- **Mobile Adjustments**: Reduced sale badge and button sizes on mobile for better fit

### Hotfix 1.4.2
- **Fixed Sale Badge Positioning**: Added !important to left/right positioning to override WooCommerce default CSS
- **Fixed Related Products Card Width**: Added minimum width and auto-fit grid layout for better responsive behavior
- **Fixed Product Image Layout Shift**: Added width/height attributes to product images following WordPress best practices
- **Fixed Image Empty Space**: Updated CSS to ensure images fill their containers properly with aspect-ratio

### Hotfix 1.4.3
- **Fixed Product Card Button Height**: Increased minimum height to 48px (WCAG AA compliant) for better touch targets
- **Fixed Button Text Alignment**: Added proper centering with flexbox and text-align
- **Fixed Button Padding**: Increased padding to 12px 20px for better spacing
- **Fixed Button Focus States**: Added focus-visible for better keyboard navigation support
- **Fixed Quantity Stepper Height**: Updated to match button height (48px) for consistency
- **Added Box-Sizing**: Ensures padding doesn't affect width calculation
- **Responsive Adjustments**: Reduced heights on mobile (44px) for smaller screens

### Hotfix 1.4.4 - Best Practices Improvements
- **Added Schema.org Structured Data**: Added Product and AggregateRating microdata for SEO
- **Improved Category Linking**: Categories are now clickable links with proper ARIA labels
- **Enhanced Accessibility**: Added comprehensive ARIA labels throughout product card
- **Fixed Category Selection**: Now selects the lowest-level (most specific) category
- **Added Focus States**: Improved keyboard navigation with focus outlines on links
- **Added Focus-within**: Card shows focus outline when any child element is focused
- **Reduced Motion Support**: Added prefers-reduced-motion media query for accessibility
- **Improved Alt Text**: Ensures all product images have proper alt text for screen readers
- **Better ARIA Labels**: Added descriptive labels for action buttons and links
- **Semantically Improved**: Used proper semantic HTML structure throughout

### Hotfix 1.4.5 - Enhanced UI/UX Improvements
- **Added New Product Badge**: Automatically displays "New" badge for products published within 30 days
- **Added Featured Product Badge**: Displays "Featured" badge for featured products with golden color
- **Added Low Stock Indicator**: Shows "Low stock" badge for products with low inventory
- **Improved Badge Positioning**: Smart positioning handles multiple badges without overlap
- **Enhanced Rating Display**: Added review count link to jump to product reviews
- **Improved Star Rating Styling**: Added empty star state for better visual feedback
- **Added Loading Animation**: Shimmer effect for lazy-loaded images
- **Enhanced Card Hover Effects**: Added border color change on hover for better feedback
- **Featured Product Highlighting**: Special border color and shadow for featured products
- **Better Stock Status Indication**: More comprehensive stock status messaging
- **Filterable New Product Threshold**: Hook to customize "new" product time period (default 30 days)

**Theme Author:** Shafekul Abid  
**Author URI:** https://abidshafee.github.io/

---

## 1. Product Quick View Modal

### Overview
Allows customers to view product details without leaving the shop page, improving conversion rates and user experience.

### Features
- AJAX-powered quick view modal
- Displays product image, price, stock status, and description
- Supports variable products with variation selection
- Accessible with keyboard navigation (Escape to close)
- Responsive design for mobile devices

### How It Works
- A quick view button (eye icon) appears on each product card
- Clicking the button opens a modal with product details
- Customers can add products to cart directly from the modal
- Modal closes when clicking outside or pressing Escape

### Files Modified
- `functions.php` - Added AJAX handler and modal markup
- `woocommerce/content-product.php` - Added quick view button
- `assets/js/theme.js` - Added modal open/close logic
- `assets/css/theme.css` - Added modal styling

---

## 2. Recently Viewed Products

### Overview
Tracks and displays products the customer has recently viewed, encouraging return visits and increasing engagement.

### Features
- Uses localStorage to track up to 8 recently viewed products
- Displays recently viewed section on single product pages
- Automatically excludes current product from the list
- Persists across browser sessions
- Only shows when at least 2 products have been viewed

### How It Works
- When a customer visits a product page, it's added to localStorage
- On subsequent product page visits, a "Recently viewed" section appears
- Products are loaded via AJAX to ensure they're still available
- Section is hidden if no products are available

### Files Modified
- `functions.php` - Added tracking, rendering, and AJAX handler
- `assets/css/theme.css` - Added section styling

---

## 3. Product Filter Sidebar

### Overview
Advanced filtering options for the shop page, allowing customers to filter products by price and custom attributes.

### Features
- Price range filter (min/max input)
- Attribute filters (checkboxes for product attributes)
- Clear all filters button
- Responsive design (collapses on mobile)
- Integrates with WooCommerce's native filtering
- Custom shop sidebar widget area

### How It Works
- Sidebar appears on shop and category pages
- Customers can set price range and select attribute values
- Filters are applied via form submission
- "Clear all" link removes all active filters
- Sidebar can be customized via Widgets panel (Shop Sidebar)

### Files Modified
- `functions.php` - Added filter sidebar function and shop sidebar
- `woocommerce/archive-product.php` - Created custom archive template
- `woocommerce/sidebar.php` - Created custom sidebar template
- `assets/css/theme.css` - Added sidebar and layout styling

### Usage
1. Create product attributes in WooCommerce > Products > Attributes
2. Add terms to attributes
3. Assign attributes to products
4. Filters will automatically appear in the sidebar

---

## 4. Social Sharing Buttons

### Overview
Allows customers to share products on social media platforms, increasing brand visibility and organic traffic.

### Features
- Share on Facebook
- Share on Twitter/X
- Share on Pinterest
- Share on WhatsApp
- Copy link to clipboard
- Visual feedback when link is copied
- Accessible with proper ARIA labels

### How It Works
- Sharing buttons appear on single product pages
- Each button opens the respective platform's share dialog
- Copy button copies the product URL to clipboard
- Visual confirmation when link is successfully copied

### Files Modified
- `functions.php` - Added sharing buttons markup
- `assets/js/theme.js` - Added copy-to-clipboard functionality
- `assets/css/theme.css` - Added button styling

---

## 5. Product Card Redesign

### Overview
Complete redesign of the WooCommerce product card (loop item) used on shop, category, search, and related-products grids following WordPress and WooCommerce best practices.

### Features
- Clean card design with consistent padding and subtle border
- Fixed aspect ratio (4:5) with `object-fit: cover` to prevent layout shift
- Sale badge positioned top-left inside the image
- Wishlist and quick-view icons stacked vertically top-right with consistent spacing
- Icons appear on hover on desktop, always visible on mobile
- Product category displayed above title (small, uppercase)
- Title truncated to max 2 lines with ellipsis
- Star rating display enabled
- Price with old price struck through, sale price emphasized
- Percentage off label for sale items
- Full-width add-to-cart button with centered text
- Minimum 44px tap height for accessibility
- Clear hover and focus states
- Sold out state for out-of-stock products
- Gentle hover effect (image zoom)
- AJAX side cart integration maintained

### Bug Fixes
- Fixed sale badge clipping/overlapping with action icons
- Fixed empty space below images with proper aspect ratio
- Fixed cut-off add-to-cart button with full-width design
- Fixed misaligned button text with proper centering
- Fixed button tap height for mobile accessibility

### How It Works
- Uses properly versioned `content-product.php` override
- Follows WooCommerce hooks and template hierarchy
- Category, sale percentage, and stock status calculated in PHP
- CSS handles all positioning and visual effects
- Responsive behavior adapts to screen size

### Files Modified
- `woocommerce/content-product.php` - Complete redesign with new structure
- `functions.php` - Updated image size to 4:5 aspect ratio, added filter for thumbnail size
- `assets/css/theme.css` - Complete card styling rewrite with proper spacing and responsiveness

### Design Details
- Card padding: 16px (12px on mobile)
- Border: 1px solid with subtle shadow on hover
- Image aspect ratio: 4:5 (760x950px)
- Action buttons: 38px circular, stacked with 8px gap
- Button tap height: 44px minimum
- Title: Max 2 lines with ellipsis
- Price: Larger, emphasized sale price
- Sale badge: Green, top-left, small uppercase
- Sold out badge: Centered overlay, semi-transparent background

### Responsive Behavior
- Desktop (4 columns): Action buttons on hover
- Tablet (3 columns): Action buttons on hover
- Mobile (2 columns): Action buttons always visible
- Mobile adjustments: Smaller padding, fonts, and spacing

---

## 6. Single Product Page Layout Fixes

### Overview
Fixed layout issues on single product pages to prevent related products from overlapping the product description area during scrolling.

### Features
- Added proper spacing between product content and related products
- Z-index layering to prevent overlapping
- Overflow handling for sticky product summary
- Responsive adjustments for mobile devices
- Proper spacing for WooCommerce tabs

### Bug Fixes
- Fixed related products overlapping product description on scroll
- Fixed sticky summary covering gallery when scrolling
- Added proper spacing before related products section
- Improved mobile layout with single-column product view

### Files Modified
- `assets/css/theme.css` - Added spacing, z-index, and overflow handling

---

## 7. Header Improvements

### Overview
Enhanced the theme header following WordPress and WooCommerce best practices with improved layout, accessibility, and sticky behavior.

### Features
- **Category Navigation**: Added secondary navigation bar for product categories
- **Sticky Header**: Header becomes sticky on scroll with smooth transitions
- **Improved Icon Buttons**: Increased tap targets to 44px (WCAG AA compliant)
- **Enhanced Accessibility**: Added ID to header for skip-link targeting
- **Better Mobile Experience**: Centered logo on mobile, category nav hidden
- **Menu Location**: Added 'categories' menu location for WordPress menu editor
- **Smooth Transitions**: Header shrinks gracefully on scroll without layout shift
- **Focus States**: Improved focus indicators for keyboard navigation

### How It Works
- Desktop: Logo left, main menu center, icons right, category nav below
- Mobile: Hamburger menu, centered logo, search and cart icons
- Scroll behavior: Header becomes sticky after 50px scroll, shrinks smoothly
- Category navigation: Uses WordPress menu system for easy editing

### Files Modified
- `header.php` - Added category navigation and header ID
- `functions.php` - Added 'categories' menu location, improved custom logo support
- `assets/css/theme.css` - Added sticky header, category nav, improved icon sizing
- `assets/js/theme.js` - Added sticky header JavaScript with passive scroll listener

### Configuration
- Manage menus in Appearance > Menus
- Primary menu: Main navigation
- Categories menu: Product categories
- Edit announcement bar in Customizer (Appearance > Customize)
- Toggle category navigation in Customizer (Appearance > Customize > Yusraah homepage)

### Accessibility
- Skip-link targets header ID
- All buttons 44px minimum (WCAG AA)
- Proper ARIA labels maintained
- Focus states with visible outlines
- Keyboard navigation preserved

## 8. Homepage Redesign (Phase 1)

### Overview
Redesigned the homepage to be conversion-focused for daily-use essentials while preserving the elegant editorial style, fonts, and colors.

### Phase 1 Features (Implemented)
- **Modern Hero Section**: Clean headline about everyday essentials with prominent CTA button
- **Trust Bar**: 5 customizable trust indicators (Fast delivery, Easy returns, Secure payment, Cash on delivery, 24/7 support)
- **Shop by Category**: Image tiles from WooCommerce product categories with product counts
- **Customizable Content**: All hero text, trust items editable via Customizer

### How It Works
- Hero uses Customizer settings for headline, subtext, and CTA text
- Trust bar items are fully customizable in Customizer
- Categories are fetched dynamically from WooCommerce
- Category tiles use WooCommerce category thumbnails or fallback to first letter
- Responsive design adapts to all screen sizes

### Files Modified
- `front-page.php` - Added modern hero, trust bar, and category sections
- `functions.php` - Added Customizer settings and category fetch function
- `assets/css/theme.css` - Added modern hero, trust bar, and category grid styling

### Configuration
- Edit hero content in Customizer > Yusraah homepage
- Customize trust bar items in Customizer
- Set category thumbnails in WooCommerce > Products > Categories
- All features preserve existing functionality (side cart, AJAX search, etc.)

### WordPress/WooCommerce Best Practices
- Uses WooCommerce term queries for categories
- Customizer settings for easy content management
- Escaped output throughout
- Responsive and accessible
- Preserves existing features

## 9. Homepage Redesign (Phase 2)

### Overview
Extended the homepage redesign with conversion-focused sections: Best sellers, New arrivals, Offers banner, Why choose us, Reviews, Newsletter signup, and enhanced footer.

### Phase 2 Features (Implemented)
- **Best Sellers Section**: WooCommerce query for most popular products (4 columns)
- **New Arrivals Section**: WooCommerce query for latest products (4 columns)
- **Offers Banner**: Customizable promotional banner with CTA button
- **Why Choose Us**: 4 customizable benefit items with icons
- **Customer Reviews**: Displays latest WooCommerce product reviews with star ratings
- **Newsletter Signup**: Email subscription form with elegant styling
- **Enhanced Footer**: 4-column layout with contact, quick links, policies, newsletter, social links, and payment icons

### How It Works
- Best sellers and new arrivals use WooCommerce shortcodes
- Offers banner fully customizable via Customizer
- Why choose us items editable in Customizer
- Reviews fetched from WooCommerce comments
- Newsletter form ready for integration
- Footer includes Bangladesh-specific payment methods (bKash, Nagad, COD)

### Files Modified
- `front-page.php` - Added 6 new sections
- `footer.php` - Enhanced with 4-column layout, contact, social, payment icons
- `functions.php` - Added Customizer settings for offers and why choose us
- `assets/css/theme.css` - Added styling for all new sections and footer enhancements

### Configuration
- Edit offers banner in Customizer > Yusraah homepage
- Customize why choose us items in Customizer
- All sections use WooCommerce queries for dynamic content
- Footer links can be edited in WordPress menus
- Payment icons are styled for Bangladesh market

### WordPress/WooCommerce Best Practices
- Uses WooCommerce shortcodes for product queries
- Customizer settings for easy content management
- Proper comment queries for reviews (filtered by post_type and type)
- Escaped output throughout
- Responsive and accessible
- Preserves all existing features

## 10. Product Review Query Fix

### Issue Identified
The homepage reviews section was using `get_comments()` without proper filters, fetching ALL approved comments from the entire site instead of only WooCommerce product reviews. This caused regular post comments to appear in the product reviews section, and product reviews might not display correctly.

### Solution Applied
Updated the comment query to properly filter for WooCommerce product reviews:
- Added `'type' => 'review'` to filter for review comment type
- Added `'post_type' => 'product'` to only fetch product comments
- Added `'post_status' => 'publish'` to only fetch from published products
- Added product name link to each review for better context

### Files Modified
- `front-page.php` - Fixed comment query parameters, added product name display

### WooCommerce Best Practices Followed
- Uses proper comment type filtering (`type => 'review'`)
- Filters by post type to ensure only product reviews
- Displays product context for each review
- Maintains WordPress comment approval workflow
- Reviews still require admin approval in WordPress Admin (Settings > Discussion)

### Note
- Product reviews submitted by customers will appear in WordPress Admin > Comments for approval
- Once approved, they will display on the homepage reviews section
- The theme does not alter the core WordPress comment submission or approval process

## 11. Hero Section UX/UI Improvements

### Overview
Redesigned the homepage hero section to grab buyer attention with featured products, improved visual hierarchy, and better interactivity.

### Improvements Implemented
- **Featured Products Display**: Shows 3 featured WooCommerce products in hero with quick buy buttons
- **Visual Hierarchy**: Added "Featured Collection" badge with accent color
- **Gradient Background**: Subtle gradient from paper to light cream for depth
- **Image Interactivity**: Smooth zoom effect on hover (1.05x scale)
- **Product Cards**: Compact cards with image, name, price, and add-to-cart button
- **Sale Badges**: Green "Sale" badge on products with discounted prices
- **Hover Effects**: Cards lift and highlight on hover with accent border
- **Responsive Design**: Featured products scroll horizontally on mobile/tablet
- **Shadows**: Soft shadows for depth and professionalism

### How It Works
- Fetches 3 featured WooCommerce products automatically
- Products display in vertical stack on desktop, horizontal scroll on mobile
- Each card has direct add-to-cart functionality
- Uses WooCommerce's featured product flag
- Maintains existing hero content (headline, subtext, CTA)

### Files Modified
- `front-page.php` - Added featured products display with product cards
- `assets/css/theme.css` - Fixed grid layout, added hero improvements, product cards, hover effects, responsive behavior

### Layout Fix
- Changed from absolute positioning to proper 3-column grid layout
- Grid: Text (1.2fr) | Image (0.8fr) | Featured Products (280px)
- Fixed headline size (reduced from 64px to 52px)
- Fixed price wrapping with `white-space: nowrap`
- Proper containment with no empty gaps

## 12. Hero Product Carousel

### Overview
Implemented an auto-sliding featured products carousel in the hero section that displays products automatically every 4 seconds, with manual navigation controls.

### Features Implemented
- **Two-Column Layout**: Left column with slogan, right column with carousel
- **Auto-Sliding**: Products automatically rotate every 4 seconds
- **Manual Navigation**: Previous/Next buttons for user control
- **Smooth Transitions**: CSS animations for slide effects
- **Pause on Hover**: Carousel pauses when user hovers over it
- **4 Products**: Shows up to 4 featured/popular products
- **Fallback**: Uses popular products if no featured products exist
- **Sale Badges**: Green "Sale" badge on discounted products
- **Product Cards**: Clean design with image, name, price, and add-to-cart button
- **Responsive**: Single column on mobile/tablet with carousel first

### How It Works
- Two-column layout: Left (slogan) | Right (carousel)
- Fetches 4 featured WooCommerce products
- Auto-slides through products with smooth animation
- Navigation buttons allow manual control
- Respects WCAG preferences (prefers-reduced-motion)
- Uses WooCommerce product methods for price and cart

### Files Modified
- `front-page.php` - Added carousel HTML with product cards and navigation
- `assets/css/theme.css` - Added carousel styling, animations, responsive behavior
- `assets/js/theme.js` - Added carousel JavaScript with auto-slide and navigation

### WordPress/WooCommerce Best Practices
- Uses `wc_get_products()` for featured product queries
- Uses WooCommerce methods for price and add-to-cart
- Proper escaping throughout
- Accessible navigation buttons with ARIA labels
- Pause on hover for better UX
- Responsive and accessible
- Preserves all existing functionality

### WordPress/WooCommerce Best Practices
- Uses `wc_get_products()` for featured product queries
- Uses WooCommerce methods for price and add-to-cart
- Proper escaping throughout
- Responsive and accessible
- Preserves all existing functionality
- Uses WooCommerce's featured product flag

## 13. Homepage Section Spacing Consistency

### Overview
Standardized vertical spacing between homepage sections for a consistent, professional layout following WordPress design standards.

### Spacing System Applied
- **Desktop (900px+)**: 70px padding for all sections
- **Tablet (640-900px)**: 50px padding for all sections
- **Mobile (<640px)**: 50px padding for all sections
- Consistent spacing for: Shop by Category, Best Sellers, New Arrivals, Offers Banner, Why Choose Us, Reviews, Newsletter

### Files Modified
- `front-page.php` - Removed `.section-wrap` class from Best Sellers and New Arrivals
- `assets/css/theme.css` - Added width, margin, and horizontal padding to `.products-section` class

### WordPress Best Practices
- Consistent vertical rhythm for better UX
- Responsive spacing that adapts to screen size
- Removed conflicting CSS classes causing spacing issues
- Added horizontal padding to match main container width
- Maintains visual hierarchy
- Follows WordPress design patterns

## 15. Shop by Category Redesign

### Overview
Completely redesigned the "Shop by Category" section to be polished, consistent, and conversion-friendly following WordPress and WooCommerce best practices.

### Bugs Fixed

#### Image Issues
- **Fixed blank strip on right**: Images now fill the full card width with proper `object-fit: cover`
- **Fixed inconsistent heights**: All tiles now use a fixed 4:5 aspect ratio with equal-height cards
- **Fixed layout shift**: Added `width` and `height` attributes to prevent CLS

#### Text Issues
- **Fixed pluralization**: Now uses `_n()` for proper "1 product" / "2 products" translation
- **Improved fallback**: Uses `mb_substr()` for better multi-character support in placeholder

### Design Improvements

#### Modern Category Tiles
- **Gradient overlay**: Subtle gradient from dark at bottom to transparent at top
- **White text**: Category name and count appear in white over the overlay
- **Shop arrow**: Circular arrow icon that slides on hover
- **Whole card clickable**: Single link wrapper (no nested links)
- **Rounded corners**: 8px border-radius for modern look

#### Hover Effects
- **Image zoom**: 1.05x scale on hover (smooth 0.35s transition)
- **Card lift**: 4px upward movement with shadow
- **Arrow slide**: Arrow moves right and changes color
- **Reduced motion**: Disabled when `prefers-reduced-motion` is set

#### Focus States
- **Visible focus**: 2px accent color outline with offset
- **WCAG AA compliant**: Minimum 44px tap targets
- **Keyboard accessible**: Proper tab order and focus management

### Responsive Grid

#### Desktop (900px+)
- Configurable columns (2-4) via Customizer
- Default: 4 columns
- Consistent 20px gaps

#### Tablet (640-900px)
- 3 columns
- 15px gaps

#### Mobile (<640px)
- 2 columns
- 12px gaps
- Full container width

### Dynamic Features

#### Category Query
- Uses `get_terms( 'product_cat' )` with proper filtering
- **Hides "Uncategorized"**: Excluded via term ID
- **Hides empty categories**: `hide_empty => true`
- **Cached in transient**: 6-hour cache for performance
- **Cache invalidation**: Clears on category create/edit/delete

#### Customizer Settings
New section: **Shop by Category**

Settings include:
- **Section title**: Editable heading (default: "Shop by Category")
- **View all link text**: Editable button text
- **Number of categories**: 2-12 categories
- **Order by**: Name / Product count / Slug / ID
- **Order direction**: Ascending / Descending
- **Show product count**: Toggle to show/hide product counts
- **Grid columns**: 2-4 columns (responsive)

### Technical Implementation

#### PHP (functions.php)
- Enhanced `yusraah_get_product_categories()` with Customizer integration
- Added transient caching (6 hours)
- Added cache invalidation hooks
- Added Customizer section with 7 settings
- Sanitization callbacks for all inputs

#### Template (front-page.php)
- Updated to use Customizer settings
- Fixed pluralization with `_n()`
- Added proper image attributes (srcset, sizes, width, height)
- Added lazy loading for images
- Fixed placeholder with `mb_substr()`
- Added gradient overlay div
- Added arrow icon

#### CSS (theme.css)
- Complete redesign of category tiles
- 4:5 aspect ratio with `aspect-ratio` property
- Gradient overlay from bottom
- White text on overlay
- Responsive grid with column variants
- Hover effects with transitions
- Reduced motion support
- Focus states for accessibility

### WordPress/WooCommerce Best Practices
- ✅ `get_terms()` for category queries
- ✅ Transient caching for performance
- ✅ Cache invalidation on category changes
- ✅ `_n()` for proper pluralization
- ✅ Customizer API with sanitization
- ✅ Lazy-loaded images with `srcset`
- ✅ `width` and `height` attributes (no CLS)
- ✅ `object-fit: cover` for consistent aspect ratio
- ✅ Accessible ARIA labels
- ✅ Visible focus states
- ✅ WCAG AA contrast ratios
- ✅ `prefers-reduced-motion` support
- ✅ Mobile-first responsive design
- ✅ Escaped output throughout
- ✅ Excludes "Uncategorized" category
- ✅ Hides empty categories

### Files Modified
- `functions.php` - Enhanced category function, added Customizer section, caching
- `front-page.php` - Updated HTML with new design and Customizer settings
- `assets/css/theme.css` - Complete redesign of category tiles
- `style.css` - Updated version to 2.2.0
- `NEW-FEATURES.md` - Added documentation

### Usage
1. Go to **Appearance > Customize**
2. Navigate to **Shop by Category**
3. Configure settings (title, columns, order, etc.)
4. Click **Publish** to save changes

The "Shop by Category" section is now polished, conversion-friendly, and fully customizable with proper WordPress/WooCommerce best practices!

## 16. Category Image Cycling on Hover

### Overview
Enhanced category cards to use product images instead of category thumbnails, with sequential image cycling on hover for a dynamic, engaging user experience.

### Features

#### Product Images
- **Primary source**: Fetches up to 4 product images from each category
- **Smart fallback**: Falls back to category thumbnail if no products
- **Fallback to placeholder**: First letter of category name if no image available
- **Cached query**: Product images cached with category transient (6 hours)

#### Image Cycling on Hover
- **Sequential display**: Cycles through product images every 1.5 seconds on hover
- **Smooth transitions**: 0.2s opacity fade between images
- **Auto-reset**: Returns to first image when mouse leaves
- **Reduced motion**: Disabled when `prefers-reduced-motion` is set
- **Graceful degradation**: No cycling if fewer than 2 images available

#### Technical Implementation
- **PHP**: Modified `yusraah_get_product_categories()` to fetch product images
- **Data attributes**: Product image URLs passed via `data-category-images` JSON attribute
- **JavaScript**: Inline script handles hover detection and image cycling
- **Performance**: Minimal overhead, only cycles on hover
- **Accessibility**: Respects user motion preferences

### Technical Implementation

#### PHP (functions.php)
- Enhanced category query to fetch product images (up to 4 per category)
- Added `product_images` property to category objects
- Added cache invalidation on product save/update

#### Template (front-page.php)
- Updated to use product images as primary source
- Added JSON data attribute for image URLs
- Added inline JavaScript for image cycling
- Fallback chain: product images → category thumbnail → placeholder

#### JavaScript
- Vanilla JS with no dependencies
- Detects `prefers-reduced-motion` preference
- Cycles images on mouseenter
- Resets on mouseleave
- Smooth opacity transitions

### WordPress/WooCommerce Best Practices
- ✅ Uses `get_posts()` for product queries
- ✅ Proper JSON encoding/decoding
- ✅ Escaped output throughout
- ✅ Lazy-loaded images
- ✅ Respects `prefers-reduced-motion`
- ✅ Graceful fallbacks
- ✅ Cache invalidation on product changes
- ✅ No external dependencies

### Files Modified
- `functions.php` - Enhanced category function with product images
- `front-page.php` - Updated HTML and added JavaScript
- `style.css` - Updated version to 2.3.0
- `functions.php` - Updated version to 2.3.0
- `NEW-FEATURES.md` - Added documentation

### Usage
The feature works automatically:
1. Ensure categories have products with featured images
2. Products will be automatically fetched and displayed
3. Hover over category cards to see image cycling
4. Clear cache if new products are added (transient auto-clears on product save)

The category cards now showcase your actual products with dynamic image cycling on hover!

## 14. Reusable Product Slider Component

### Overview
Refactored the hero slider into a reusable component that can be used in multiple sections on the same page. Added a product slider to the story section ("Good things get better with time") with a two-column layout (slider on left, text on right).

### Features

#### Reusable Component
- **Multi-instance support**: Multiple independent sliders can exist on the same page
- **Shared codebase**: Single PHP, CSS, and JS file for all slider instances
- **Unique IDs**: Each slider has a unique ID (e.g., `hero-product-slider`, `story-product-slider`)
- **Independent configuration**: Each slider has its own Customizer settings
- **No conflicts**: Sliders operate independently with separate timers and state

#### Story Section Slider
- **Two-column layout**: Product slider on left, story text on right
- **Equal columns**: `grid-template-columns: repeat(2, minmax(0, 1fr))` for balanced layout
- **Mobile stacking**: Text first, slider below on mobile devices (<768px)
- **Contained layout**: Slider stays within its column with no overflow
- **Consistent spacing**: Matches homepage section spacing (70px desktop, 50px tablet/mobile)
- **Natural text wrapping**: Headline and paragraph have `max-width` for comfortable reading

#### Customizer Settings
New section: **Homepage Product Slider (Story Section)**

Settings include:
- **Show/hide section**: Toggle to enable/disable the slider
- **Section heading**: Editable heading text (default: "Good things get")
- **Section subtext**: Editable subtext/description
- **Button text**: Editable button text (default: "Find your forever piece")
- **Button link**: Editable button URL
- **Product source**: Featured / Best sellers / On sale / Newest / Specific category
- **Product category**: Category dropdown (when source is "Specific category")
- **Number of products**: 4-12 products
- **Autoplay on/off**: Enable/disable auto-sliding
- **Autoplay speed**: 2000-8000ms

#### Hero Slider Customizer
Existing hero slider settings preserved and work independently.

### Technical Implementation

#### PHP (inc/hero-slider.php)
- Refactored to support multiple slider instances via `yusraah_render_slider($slider_id)`
- Added `yusraah_render_story_slider()` wrapper function
- Customizer settings for both hero and story sliders
- Independent transient caching per slider
- Shared product query and rendering logic
- Backward compatible with existing hero slider

#### JavaScript (assets/js/hero-slider.js)
- Refactored to auto-detect and initialize all sliders on the page
- Each slider instance has independent state and timer
- Configuration per slider passed from PHP via `yusraahSliderConfig`
- Maintains all existing features: auto-slide, pause on hover/focus, touch swipe, keyboard navigation, ARIA updates

#### CSS (assets/css/hero-slider.css)
- Added story section slider layout styles
- Two-column grid: slider left, text right
- Equal column widths with `repeat(2, minmax(0, 1fr))`
- Mobile responsive: stacks text first, slider below (<768px)
- Consistent spacing with homepage sections
- No overflow or layout shift
- Text has `max-width` for natural wrapping

#### Template (front-page.php)
- Updated story section to use product slider when enabled
- Slider on left, text on right in HTML order
- Fallback to original image layout when slider disabled
- Customizer-controlled content (heading, subtext, button)

### WordPress/WooCommerce Best Practices
- ✅ Reusable component architecture (DRY principle)
- ✅ Multiple independent instances on same page
- ✅ Customizer API with proper sanitization
- ✅ `wc_get_products()` for product queries
- ✅ Transient caching (6 hours) with cache invalidation
- ✅ Lazy-loaded images with `srcset` and dimensions
- ✅ No layout shift (width/height attributes)
- ✅ Accessible carousel markup (ARIA roles, keyboard support)
- ✅ Respects `prefers-reduced-motion`
- ✅ WooCommerce AJAX add-to-cart integration
- ✅ Hides out-of-stock products
- ✅ Escaped output throughout
- ✅ Backward compatible with existing hero slider
- ✅ Responsive design (desktop/tablet/mobile)
- ✅ Proper HTML order for accessibility
- ✅ CSS Grid for layout

### Files Modified
- `inc/hero-slider.php` - Refactored for multi-instance support, added story slider Customizer
- `assets/js/hero-slider.js` - Updated to handle multiple independent sliders
- `assets/css/hero-slider.css` - Added story section slider layout
- `front-page.php` - Updated story section to use product slider
- `style.css` - Updated version to 2.1.0
- `functions.php` - Updated version to 2.1.0
- `NEW-FEATURES.md` - Added documentation

### Usage
1. Go to **Appearance > Customize**
2. Navigate to **Homepage Product Slider (Story Section)**
3. Configure slider settings (products, autoplay, content)
4. Toggle "Show product slider in story section" to enable
5. Click **Publish** to save changes

The story section now features a live WooCommerce product slider matching the hero section's design and behavior, with full Customizer control and independent operation.

### Overview
Enhanced product recommendations to increase average order value and cross-sell opportunities.

### Features
- Related products section on single product pages (4 products, 4 columns)
- Cross-sells section on cart page (styled section above checkout)
- Improved styling to match theme design
- Responsive grid layout
- Uses redesigned product card
- Fixed spacing to prevent overlapping with product description

### How It Works
- Related products are based on WooCommerce's built-in related product logic
- Cross-sells are configured per product in WooCommerce
- Both sections use the theme's product card design
- Cross-sells appear in a styled section on the cart page
- Proper spacing ensures no overlap with product description area

### Files Modified
- `functions.php` - Added cross-sells display and related products configuration
- `assets/css/theme.css` - Added cross-sells section styling

### Configuration
- Set related products in WooCommerce > Products > Edit Product > Linked Products
- Set cross-sells in the same section
- Use the "Upsells" section for checkout page recommendations

---

## Technical Notes

### Performance
- All AJAX requests include proper error handling
- Quick view modal uses AbortController to cancel pending requests
- Recently viewed products uses localStorage (no server load)
- Social sharing uses platform APIs (no additional dependencies)

### Accessibility
- All modals are keyboard accessible
- Proper ARIA labels on all interactive elements
- Focus management for modals
- Screen reader support for all features

### Browser Support
- Modern browsers (Chrome, Firefox, Safari, Edge)
- localStorage support required for recently viewed
- Clipboard API with fallback for older browsers
- Responsive design works on all screen sizes

### Customization
- Filter sidebar can be replaced with widgets
- Social platforms can be added/removed in functions.php
- Quick view modal styling can be customized in CSS
- Recently viewed product limit can be changed in functions.php

---

## Installation & Setup

1. Copy all modified files to your theme directory
2. Ensure WooCommerce is active and configured
3. Add product attributes for filter sidebar
4. Configure related products and cross-sells in WooCommerce
5. Test all features on a staging environment first

---

## Troubleshooting

### Quick View Not Working
- Check that AJAX nonce is being passed correctly
- Verify WooCommerce AJAX endpoints are accessible
- Check browser console for JavaScript errors

### Recently Viewed Not Showing
- Ensure localStorage is enabled in browser
- Visit at least 2 different product pages
- Check that products are still published and visible

### Filter Sidebar Not Appearing
- Ensure product attributes are created and have terms
- Check that attributes are assigned to products
- Verify sidebar is enabled in WooCommerce settings

### Social Sharing Not Working
- Check that product URLs are correct
- Verify platform share URLs are accessible
- Test in an incognito window to rule out caching

---

## Future Enhancements

Potential improvements for future versions:
- Wishlist integration with user accounts
- Advanced filtering with AJAX (no page reload)
- Product comparison feature
- Dark mode toggle
- Multi-currency support
- Advanced analytics for feature usage

---

## Support

For issues or questions about these features:
1. Check this documentation first
2. Review WordPress debug logs
3. Test with default theme to isolate issues
4. Contact theme developer for support

---

*Documentation last updated: October 2026*
