<?php
/**
 * The footer for Yusraah.
 *
 * Every colour comes from the `--footer-*` custom properties in theme.css, the
 * link columns are real menu locations (Appearance > Menus), and every text /
 * contact / social / payment value is editable in the Customizer.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

$yusraah_footer_defaults = yusraah_footer_defaults();

$yusraah_trust = array(
	'delivery' => get_theme_mod( 'yusraah_footer_trust_delivery', $yusraah_footer_defaults['footer_trust_delivery'] ),
	'returns'  => get_theme_mod( 'yusraah_footer_trust_returns', $yusraah_footer_defaults['footer_trust_returns'] ),
	'cod'      => get_theme_mod( 'yusraah_footer_trust_cod', $yusraah_footer_defaults['footer_trust_cod'] ),
	'secure'   => get_theme_mod( 'yusraah_footer_trust_secure', $yusraah_footer_defaults['footer_trust_secure'] ),
);
$yusraah_trust = array_filter( $yusraah_trust, 'strlen' );

$yusraah_socials = array(
	'facebook'  => array( __( 'Facebook', 'yusraah' ), get_theme_mod( 'yusraah_social_facebook', '' ) ),
	'instagram' => array( __( 'Instagram', 'yusraah' ), get_theme_mod( 'yusraah_social_instagram', '' ) ),
	'youtube'   => array( __( 'YouTube', 'yusraah' ), get_theme_mod( 'yusraah_social_youtube', '' ) ),
	'whatsapp'  => array( __( 'WhatsApp', 'yusraah' ), get_theme_mod( 'yusraah_social_whatsapp', '' ) ),
	'x'         => array( __( 'X', 'yusraah' ), get_theme_mod( 'yusraah_social_x', '' ) ),
);

$yusraah_payments = array(
	'cod'        => array( 'COD', __( 'Cash on delivery', 'yusraah' ) ),
	'bkash'      => array( 'bKash', __( 'bKash', 'yusraah' ) ),
	'nagad'      => array( 'Nagad', __( 'Nagad', 'yusraah' ) ),
	'visa'       => array( 'VISA', __( 'Visa', 'yusraah' ) ),
	'mastercard' => array( 'MC', __( 'Mastercard', 'yusraah' ) ),
);

// Brand block: footer logo > Custom Logo > text name.
$yusraah_footer_brand_name = get_theme_mod( 'yusraah_footer_brand_name', '' );
if ( ! $yusraah_footer_brand_name ) {
	$yusraah_footer_brand_name = get_bloginfo( 'name' );
}
$yusraah_site_name          = explode( ' ', $yusraah_footer_brand_name, 2 );
$yusraah_footer_brand_mode  = get_theme_mod( 'yusraah_footer_brand_mode', 'auto' );
$yusraah_footer_logo_url    = get_theme_mod( 'yusraah_footer_logo', '' );
$yusraah_footer_logo_width  = max( 40, min( 400, absint( get_theme_mod( 'yusraah_footer_logo_width', 180 ) ) ) );
$yusraah_custom_logo_id     = (int) get_theme_mod( 'custom_logo', 0 );

$yusraah_brand_logo = '';
if ( 'text' !== $yusraah_footer_brand_mode ) {
	if ( $yusraah_footer_logo_url ) {
		$yusraah_brand_logo = sprintf(
			'<img class="footer-brand__logo-img" src="%s" alt="%s" style="max-width:%dpx">',
			esc_url( $yusraah_footer_logo_url ),
			esc_attr( $yusraah_footer_brand_name ),
			(int) $yusraah_footer_logo_width
		);
	} elseif ( $yusraah_custom_logo_id ) {
		$yusraah_brand_logo = wp_get_attachment_image(
			$yusraah_custom_logo_id,
			'full',
			false,
			array(
				'class' => 'footer-brand__logo-img',
				'style' => 'max-width:' . (int) $yusraah_footer_logo_width . 'px',
			)
		);
	}
}
?>
<footer class="site-footer">
	<?php if ( $yusraah_trust ) : ?>
		<div class="footer-trust">
			<?php foreach ( $yusraah_trust as $yusraah_trust_key => $yusraah_trust_label ) : ?>
				<p class="footer-trust__item">
					<?php echo yusraah_footer_icon( $yusraah_trust_key ); ?>
					<span><?php echo esc_html( $yusraah_trust_label ); ?></span>
				</p>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<section class="footer-newsletter-band" aria-labelledby="footer-newsletter-title">
		<div class="footer-newsletter-band__inner">
			<h2 id="footer-newsletter-title"><?php echo esc_html( get_theme_mod( 'yusraah_footer_newsletter_title', $yusraah_footer_defaults['footer_newsletter_title'] ) ); ?></h2>

			<?php $yusraah_newsletter_intro = get_theme_mod( 'yusraah_footer_newsletter_intro', $yusraah_footer_defaults['footer_newsletter_intro'] ); ?>
			<?php if ( $yusraah_newsletter_intro ) : ?>
				<p class="footer-newsletter-band__intro"><?php echo esc_html( $yusraah_newsletter_intro ); ?></p>
			<?php endif; ?>

			<form class="footer-newsletter-form" method="post" action="<?php echo esc_url( home_url( add_query_arg( array() ) ) ); ?>" data-newsletter-form>
				<label class="screen-reader-text" for="footer-newsletter-email"><?php esc_html_e( 'Email address', 'yusraah' ); ?></label>
				<input type="email" id="footer-newsletter-email" name="EMAIL" autocomplete="email" placeholder="<?php esc_attr_e( 'Your email address', 'yusraah' ); ?>" required>
				<button type="submit"><?php echo esc_html( get_theme_mod( 'yusraah_footer_newsletter_button', $yusraah_footer_defaults['footer_newsletter_button'] ) ); ?></button>
			</form>

			<p class="footer-newsletter__status" role="status" aria-live="polite"></p>

			<?php $yusraah_newsletter_privacy = get_theme_mod( 'yusraah_footer_newsletter_privacy', $yusraah_footer_defaults['footer_newsletter_privacy'] ); ?>
			<?php if ( $yusraah_newsletter_privacy ) : ?>
				<p class="footer-newsletter__privacy"><?php echo esc_html( $yusraah_newsletter_privacy ); ?></p>
			<?php endif; ?>

			<?php $yusraah_social_links = array_filter( $yusraah_socials, static function ( $social ) { return '' !== $social[1]; } ); ?>
			<?php if ( $yusraah_social_links ) : ?>
				<div class="footer-social">
					<?php foreach ( $yusraah_social_links as $yusraah_social_key => $yusraah_social ) : ?>
						<a href="<?php echo esc_url( $yusraah_social[1] ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $yusraah_social[0] ); ?>">
							<?php echo yusraah_footer_icon( $yusraah_social_key ); ?>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</section>

	<div class="footer-main">
		<div class="footer-brand">
			<a class="<?php echo $yusraah_brand_logo ? 'footer-brand__link' : 'wordmark wordmark--light'; ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php if ( $yusraah_brand_logo ) : ?>
					<?php echo $yusraah_brand_logo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above / core image function. ?>
				<?php else : ?>
					<?php echo esc_html( $yusraah_site_name[0] ); ?><?php if ( ! empty( $yusraah_site_name[1] ) ) : ?> <span><?php echo esc_html( $yusraah_site_name[1] ); ?></span><?php endif; ?>
				<?php endif; ?>
			</a>

			<?php $yusraah_footer_tagline = get_theme_mod( 'yusraah_footer_tagline', $yusraah_footer_defaults['footer_tagline'] ); ?>
			<?php if ( $yusraah_footer_tagline ) : ?>
				<p class="footer-brand__tagline"><?php echo esc_html( $yusraah_footer_tagline ); ?></p>
			<?php endif; ?>
		</div>

		<?php
		$yusraah_contact_first = 'contact-first' === get_theme_mod( 'yusraah_footer_column_order', 'contact-first' );

		$yusraah_column_count = yusraah_footer_contact_is_visible() ? 1 : 0;
		foreach ( array( 'footer-shop', 'footer-help', 'footer-company' ) as $yusraah_column_location ) {
			if ( yusraah_footer_menu_is_visible( $yusraah_column_location ) ) {
				++$yusraah_column_count;
			}
		}
		?>
		<?php if ( $yusraah_column_count ) : ?>
		<div class="footer-columns" style="--footer-cols: <?php echo (int) $yusraah_column_count; ?>">
			<?php
			if ( $yusraah_contact_first ) {
				yusraah_footer_contact();
			}
			yusraah_footer_menu( 'footer-shop' );
			yusraah_footer_menu( 'footer-help' );
			yusraah_footer_menu( 'footer-company' );
			if ( ! $yusraah_contact_first ) {
				yusraah_footer_contact();
			}
			?>
		</div>
		<?php endif; ?>
	</div>

	<div class="footer-bottom">
		<div class="footer-bottom__left">
			<p>
				&copy; <?php echo esc_html( date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?><?php $yusraah_footer_copyright = get_theme_mod( 'yusraah_footer_copyright', $yusraah_footer_defaults['footer_copyright'] ); ?><?php if ( $yusraah_footer_copyright ) : ?>. <?php echo esc_html( $yusraah_footer_copyright ); ?><?php endif; ?>
			</p>
			<?php $yusraah_footer_claim = get_theme_mod( 'yusraah_footer_claim', $yusraah_footer_defaults['footer_claim'] ); ?>
			<?php if ( $yusraah_footer_claim ) : ?>
				<p><?php echo esc_html( $yusraah_footer_claim ); ?></p>
			<?php endif; ?>
		</div>

		<div class="footer-bottom__right">
			<?php $yusraah_active_payments = array_filter( $yusraah_payments, static function ( $key ) { return get_theme_mod( 'yusraah_payment_' . $key, true ); }, ARRAY_FILTER_USE_KEY ); ?>
			<?php if ( $yusraah_active_payments ) : ?>
				<ul class="payment-methods">
					<?php foreach ( $yusraah_active_payments as $yusraah_payment_key => $yusraah_payment ) : ?>
						<li class="payment-mark">
							<?php echo yusraah_footer_icon( $yusraah_payment_key ); ?>
							<span aria-hidden="true"><?php echo esc_html( $yusraah_payment[0] ); ?></span>
							<span class="screen-reader-text"><?php echo esc_html( $yusraah_payment[1] ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>

			<?php if ( get_theme_mod( 'yusraah_show_author_credit', true ) ) : ?>
				<p class="footer-credit">
					<?php
					printf(
						/* translators: %1$s: Author name, %2$s: Author URL */
						esc_html__( 'Theme by %1$s', 'yusraah' ),
						sprintf(
							'<a href="%s" rel="author noopener noreferrer" target="_blank">%s</a>',
							esc_url( 'https://abidshafee.github.io/' ),
							esc_html__( 'Shafekul Abid', 'yusraah' )
						)
					);
					?>
				</p>
			<?php endif; ?>

			<button class="footer-top" type="button" data-footer-top>
				<?php echo yusraah_footer_icon( 'up' ); ?>
				<span><?php esc_html_e( 'Back to top', 'yusraah' ); ?></span>
			</button>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
