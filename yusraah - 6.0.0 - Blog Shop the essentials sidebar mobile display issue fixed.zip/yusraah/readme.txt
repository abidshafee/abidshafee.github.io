YUSRAAH — WOOCOMMERCE THEME
==================================

An editorial storefront theme for WordPress and WooCommerce. Built around a considered fashion and accessories collection with a responsive layout, product catalog, and customizable homepage imagery.

INSTALL
-------
1. In your WordPress dashboard, open Appearance > Themes > Add New > Upload Theme.
2. Upload yusraah.zip and select Install Now, then Activate.
3. Install and activate WooCommerce. Complete its store setup and add products.
4. In Appearance > Menus, assign menus to Main navigation and Footer navigation.
5. In Appearance > Customize > Yusraah homepage, edit the announcement and image URLs.
6. In Appearance > Customize > Site Identity, set your logo and site title.

WHAT'S INCLUDED
---------------
- Editorial homepage with a hero, live WooCommerce products, brand story, and collection links.
- Responsive WooCommerce shop, category, single-product, cart, checkout, and account styling.
- Debounced AJAX product search with product images, names, and prices (up to six suggestions; title and category matching).
- Accessible side cart using WooCommerce cart fragments.
- Mobile sticky add-to-cart bar for simple and variable products.
- Simplified classic checkout with guest checkout, fewer address fields, inline validation, shipping summary, and gateway-neutral reassurance.
- Browser-local favourites on product cards (does not require an additional plugin).
- Keyboard-accessible mobile navigation and search controls.
- Custom logo, WordPress menus, featured images, responsive embeds, and theme customizer options.

NOTES
-----
- Product grids use the actual WooCommerce catalog; add products and product images in Products > Add New.
- The homepage default photography is loaded from Unsplash. Replace it in the Customizer for your store.
- Set up your shipping, taxes, payment methods, privacy policy, and legal pages in WordPress/WooCommerce before taking real orders.
- Checkout enhancements target WooCommerce's classic checkout form. Checkout Block pages require a separate block-specific integration.
- Favourites are stored in the shopper's browser and are not synced between devices or customer accounts.
- Free-shipping progress, side-cart upsells, product bundles, and a custom reorder flow are not included.
- The newsletter/contact area uses a mailto link; connect your preferred email or newsletter service if needed.

REQUIREMENTS
------------
- WordPress 6.2 or later
- PHP 7.4 or later
- WooCommerce 8.0 or later recommended

LICENSE
-------
GNU General Public License v2 or later. See https://www.gnu.org/licenses/gpl-2.0.html
