<?php
/**
 * The header for Yusraah.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */
?><!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script>document.documentElement.classList.replace('no-js', 'js');</script>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#main-content"><?php esc_html_e( 'Skip to content', 'yusraah' ); ?></a>
<?php $announcement = get_theme_mod( 'yusraah_announcement', __( 'Complimentary shipping on orders over $250', 'yusraah' ) ); ?>
<?php if ( $announcement ) : ?>
	<div class="announcement-bar"><span><?php echo esc_html( $announcement ); ?></span><a href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' ) ); ?>"><?php esc_html_e( 'Discover the collection', 'yusraah' ); ?> <span aria-hidden="true">↗</span></a></div>
<?php endif; ?>
<header class="site-header" id="site-header">
	<div class="site-header__inner">
		<button class="icon-button mobile-menu-toggle" type="button" aria-expanded="false" aria-controls="yusraah-mobile-drawer" aria-label="<?php esc_attr_e( 'Open menu', 'yusraah' ); ?>">
			<?php echo yusraah_icon( 'menu' ); ?>
		</button>
		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<?php $yusraah_site_name = explode( ' ', get_bloginfo( 'name' ), 2 ); ?>
				<a class="wordmark" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php echo esc_html( $yusraah_site_name[0] ); ?><?php if ( ! empty( $yusraah_site_name[1] ) ) : ?> <span><?php echo esc_html( $yusraah_site_name[1] ); ?></span><?php endif; ?></a>
			<?php endif; ?>
			<p class="site-tagline"><?php bloginfo( 'description' ); ?></p>
		</div>
		<nav id="primary-navigation" class="primary-navigation" aria-label="<?php esc_attr_e( 'Main navigation', 'yusraah' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'primary-menu',
				'fallback_cb'    => 'yusraah_fallback_menu',
			) );
			?>
		</nav>
		<div class="header-actions">
			<button class="icon-button search-toggle" type="button" aria-expanded="false" aria-controls="site-search-panel" aria-label="<?php esc_attr_e( 'Open search', 'yusraah' ); ?>"><?php echo yusraah_icon( 'search' ); ?></button>
			<?php $yusraah_wishlist_count = function_exists( 'yusraah_wishlist_count' ) ? yusraah_wishlist_count() : 0; ?>
			<a class="icon-button header-wishlist" href="<?php echo esc_url( function_exists( 'yusraah_wishlist_url' ) ? yusraah_wishlist_url() : home_url( '/' ) ); ?>" aria-label="<?php
				printf(
					/* translators: %s: number of saved products */
					esc_attr__( 'Wishlist, %s saved', 'yusraah' ),
					esc_attr( number_format_i18n( $yusraah_wishlist_count ) )
				);
			?>"><?php echo yusraah_icon( 'heart' ); ?><span class="header-wishlist__count<?php echo $yusraah_wishlist_count ? '' : ' is-empty'; ?>" data-wishlist-count><?php echo esc_html( number_format_i18n( $yusraah_wishlist_count ) ); ?></span></a>
			<a class="icon-button account-link" href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_login_url() ); ?>" aria-label="<?php esc_attr_e( 'My account', 'yusraah' ); ?>"><?php echo yusraah_icon( 'user' ); ?></a>
			<a class="icon-button header-cart" href="<?php echo esc_url( function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' ) ); ?>" aria-label="<?php esc_attr_e( 'Open basket', 'yusraah' ); ?>" aria-controls="yusraah-cart-drawer" aria-expanded="false" data-cart-drawer-toggle><?php echo yusraah_icon( 'bag' ); ?><span class="header-cart__count" data-cart-count><?php echo esc_html( yusraah_cart_count() ); ?></span></a>
		</div>
	</div>
	<?php if ( get_theme_mod( 'yusraah_show_category_nav', true ) ) : ?>
	<nav class="category-navigation" aria-label="<?php esc_attr_e( 'Product categories', 'yusraah' ); ?>">
		<?php
		wp_nav_menu( array(
			'theme_location' => 'categories',
			'container'      => false,
			'menu_class'     => 'category-menu',
			'fallback_cb'    => false,
		) );
		?>
	</nav>
	<?php endif; ?>
	<div id="site-search-panel" class="search-panel" hidden>
		<form role="search" method="get" class="search-panel__form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="yusraah-search"><?php esc_html_e( 'Search products', 'yusraah' ); ?></label>
			<input id="yusraah-search" type="search" name="s" placeholder="<?php esc_attr_e( 'Search the collection…', 'yusraah' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" role="combobox" aria-autocomplete="list" aria-haspopup="listbox" aria-expanded="false" aria-controls="yusraah-search-suggestions" aria-describedby="yusraah-search-status" autocomplete="off" data-product-search>
			<input type="hidden" name="post_type" value="product">
			<button class="text-arrow" type="submit"><?php esc_html_e( 'Search', 'yusraah' ); ?> <?php echo yusraah_icon( 'arrow' ); ?></button>
		</form>
		<div id="yusraah-search-suggestions" class="search-suggestions" role="listbox" aria-label="<?php esc_attr_e( 'Product suggestions', 'yusraah' ); ?>" hidden></div>
		<p id="yusraah-search-status" class="screen-reader-text" role="status" aria-live="polite" aria-atomic="true"></p>
	</div>
</header>
<?php yusraah_mobile_nav(); ?>
<?php
function yusraah_fallback_menu() {
	$shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
	?>
	<ul class="primary-menu">
		<li><a href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Shop all', 'yusraah' ); ?></a></li>
		<li><a href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'New arrivals', 'yusraah' ); ?></a></li>
		<li><a href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'The journal', 'yusraah' ); ?></a></li>
	</ul>
	<?php
}
?>
