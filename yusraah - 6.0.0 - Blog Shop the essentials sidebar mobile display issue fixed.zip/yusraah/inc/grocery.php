<?php
/**
 * Grocery features: card quantity stepper, free-delivery bar,
 * Bangladesh checkout fields and re-order.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * -------------------------------------------------------------------------
 * Card quantity stepper
 * -------------------------------------------------------------------------
 */

/**
 * Whether a product card can show the inline − qty + stepper.
 *
 * Variable, grouped and external products keep WooCommerce's default button.
 *
 * @param WC_Product|false $product Product.
 * @return bool
 */
function yusraah_card_supports_stepper( $product ) {
	$supported = $product instanceof WC_Product
		&& $product->is_type( 'simple' )
		&& $product->is_purchasable()
		&& $product->is_in_stock()
		&& $product->supports( 'ajax_add_to_cart' );

	return (bool) apply_filters( 'yusraah_card_supports_stepper', $supported, $product );
}

/**
 * Quantities of simple products currently in the cart, keyed by product ID.
 *
 * @return array<int,float>
 */
function yusraah_cart_quantities() {
	$quantities = array();

	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return $quantities;
	}

	foreach ( WC()->cart->get_cart() as $item ) {
		if ( ! empty( $item['variation_id'] ) ) {
			continue;
		}
		$product_id                = (int) $item['product_id'];
		$quantities[ $product_id ] = ( isset( $quantities[ $product_id ] ) ? $quantities[ $product_id ] : 0 ) + (float) $item['quantity'];
	}

	return $quantities;
}

/**
 * Find the cart item key for a simple product.
 *
 * @param int $product_id Product ID.
 * @return string Empty string when the product is not in the cart.
 */
function yusraah_find_cart_item_key( $product_id ) {
	foreach ( WC()->cart->get_cart() as $key => $item ) {
		if ( (int) $item['product_id'] === (int) $product_id && empty( $item['variation_id'] ) ) {
			return $key;
		}
	}

	return '';
}

/**
 * Output the add button / quantity stepper on a product card.
 *
 * @param WC_Product $product Product.
 */
function yusraah_render_card_stepper( $product ) {
	if ( ! yusraah_card_supports_stepper( $product ) ) {
		woocommerce_template_loop_add_to_cart();
		return;
	}

	$quantities = yusraah_cart_quantities();
	$product_id = $product->get_id();
	$in_cart    = isset( $quantities[ $product_id ] ) ? $quantities[ $product_id ] : 0;
	$min        = max( 1, (float) $product->get_min_purchase_quantity() );
	$max        = $product->is_sold_individually() ? 1 : (float) $product->get_max_purchase_quantity();
	$name       = $product->get_name();
	?>
	<div class="qty-stepper<?php echo $in_cart > 0 ? ' is-active' : ''; ?>"
		data-qty-stepper
		data-product-id="<?php echo esc_attr( $product_id ); ?>"
		data-product-name="<?php echo esc_attr( $name ); ?>"
		data-min="<?php echo esc_attr( $min ); ?>"
		data-max="<?php echo esc_attr( $max ); ?>"
		data-quantity="<?php echo esc_attr( $in_cart ); ?>">
		<a class="button qty-stepper__add"
			href="<?php echo esc_url( $product->add_to_cart_url() ); ?>"
			rel="nofollow"
			data-qty-add
			aria-label="<?php echo esc_attr( sprintf( /* translators: 1: action label, 2: product name */ __( '%1$s %2$s', 'yusraah' ), $product->add_to_cart_text(), $name ) ); ?>"
			<?php echo $in_cart > 0 ? 'hidden' : ''; ?>>
			<span><?php echo esc_html( $product->add_to_cart_text() ); ?></span>
		</a>
		<div class="qty-stepper__controls" role="group"
			aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name */ __( 'Quantity of %s in basket', 'yusraah' ), $name ) ); ?>"
			<?php echo $in_cart > 0 ? '' : 'hidden'; ?>>
			<button class="qty-stepper__btn" type="button" data-qty-step="-1"
				aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name */ __( 'Remove one %s', 'yusraah' ), $name ) ); ?>">&minus;</button>
			<span class="qty-stepper__value" data-qty-value><?php echo esc_html( wc_stock_amount( $in_cart ) ); ?></span>
			<button class="qty-stepper__btn" type="button" data-qty-step="1"
				aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name */ __( 'Add one more %s', 'yusraah' ), $name ) ); ?>"
				<?php disabled( $max > 0 && $in_cart >= $max ); ?>>+</button>
		</div>
	</div>
	<?php
}

/**
 * Hidden element holding the cart quantities; refreshed as a cart fragment so
 * steppers stay correct on cached pages and after side-cart removals.
 */
function yusraah_cart_quantities_markup() {
	$quantities = yusraah_cart_quantities();
	return '<div id="yusraah-cart-quantities" hidden data-quantities="' . esc_attr( wp_json_encode( (object) $quantities ) ) . '"></div>';
}

/**
 * Footer helpers for the stepper.
 */
function yusraah_render_stepper_footer() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	echo yusraah_cart_quantities_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
	echo '<div id="yusraah-cart-status" class="screen-reader-text" role="status" aria-live="polite"></div>';
}
add_action( 'wp_footer', 'yusraah_render_stepper_footer', 6 );

/**
 * AJAX: set the cart quantity of a simple product (0 removes it).
 *
 * Mirrors WooCommerce core's add_to_cart endpoint, which is also nonce-free so
 * it keeps working on full-page-cached shop pages.
 */
function yusraah_ajax_set_cart_quantity() {
	// phpcs:disable WordPress.Security.NonceVerification.Missing
	if ( 'POST' !== $_SERVER['REQUEST_METHOD'] || ! isset( $_POST['product_id'], $_POST['quantity'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Invalid request.', 'yusraah' ) ), 400 );
	}

	$product_id = absint( wp_unslash( $_POST['product_id'] ) );
	$quantity   = max( 0, wc_stock_amount( wp_unslash( $_POST['quantity'] ) ) );
	// phpcs:enable
	$product    = wc_get_product( $product_id );
	$cart_key   = yusraah_find_cart_item_key( $product_id );
	$message    = '';

	wc_clear_notices();

	if ( $quantity <= 0 ) {
		if ( $cart_key ) {
			WC()->cart->remove_cart_item( $cart_key );
		}
	} elseif ( ! yusraah_card_supports_stepper( $product ) ) {
		$message = __( 'This product cannot be added from here. Please open the product page.', 'yusraah' );
	} else {
		$max = $product->is_sold_individually() ? 1 : (float) $product->get_max_purchase_quantity();
		if ( $max > 0 && $quantity > $max ) {
			$quantity = $max;
			/* translators: %s: quantity available */
			$message = sprintf( __( 'Only %s available.', 'yusraah' ), wc_stock_amount( $max ) );
		}

		if ( $cart_key ) {
			$values = WC()->cart->get_cart_item( $cart_key );
			if ( apply_filters( 'woocommerce_update_cart_validation', true, $cart_key, $values, $quantity ) ) {
				WC()->cart->set_quantity( $cart_key, $quantity, true );
			}
		} elseif ( apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity ) ) {
			WC()->cart->add_to_cart( $product_id, $quantity );
		}

		$errors = wc_get_notices( 'error' );
		if ( $errors ) {
			$message = wp_strip_all_tags( is_array( $errors[0] ) ? $errors[0]['notice'] : $errors[0] );
		}
	}

	wc_clear_notices();
	WC()->cart->calculate_totals();

	$quantities = yusraah_cart_quantities();

	wp_send_json(
		array(
			'quantity'  => isset( $quantities[ $product_id ] ) ? $quantities[ $product_id ] : 0,
			'message'   => $message,
			'fragments' => apply_filters(
				'woocommerce_add_to_cart_fragments',
				array( 'div.widget_shopping_cart_content' => yusraah_mini_cart_html() )
			),
			'cart_hash' => WC()->cart->get_cart_hash(),
		)
	);
}
add_action( 'wc_ajax_yusraah_set_cart_quantity', 'yusraah_ajax_set_cart_quantity' );

/**
 * Mini-cart markup as WooCommerce returns it in its own fragments.
 *
 * @return string
 */
function yusraah_mini_cart_html() {
	ob_start();
	woocommerce_mini_cart();
	return '<div class="widget_shopping_cart_content">' . ob_get_clean() . '</div>';
}

/*
 * -------------------------------------------------------------------------
 * Free-delivery progress bar
 * -------------------------------------------------------------------------
 */

/**
 * Free-delivery threshold for the current cart.
 *
 * Uses the Customizer amount when set, otherwise the minimum order amount of
 * the "Free shipping" method in the shipping zone that matches the cart.
 *
 * @return array{amount: float, ignore_discounts: bool}|null
 */
function yusraah_free_delivery_threshold() {
	$threshold = null;
	$custom    = (float) get_theme_mod( 'yusraah_free_delivery_threshold', 0 );

	if ( $custom > 0 ) {
		$threshold = array(
			'amount'           => $custom,
			'ignore_discounts' => false,
		);
	} elseif ( function_exists( 'WC' ) && WC()->cart && class_exists( 'WC_Shipping_Zones' ) ) {
		$packages = WC()->cart->get_shipping_packages();
		$package  = $packages ? reset( $packages ) : array();
		$zone     = WC_Shipping_Zones::get_zone_matching_package( $package );

		foreach ( $zone->get_shipping_methods( true ) as $method ) {
			if ( 'free_shipping' === $method->id
				&& in_array( $method->requires, array( 'min_amount', 'either' ), true )
				&& (float) $method->min_amount > 0 ) {
				$threshold = array(
					'amount'           => (float) $method->min_amount,
					'ignore_discounts' => 'yes' === $method->ignore_discounts,
				);
				break;
			}
		}
	}

	return apply_filters( 'yusraah_free_delivery_threshold', $threshold );
}

/**
 * Free-delivery bar markup. An empty hidden placeholder keeps the fragment
 * target on the page when there is nothing to show.
 *
 * @return string
 */
function yusraah_free_delivery_bar_html() {
	$placeholder = '<div class="free-delivery" data-free-delivery hidden></div>';

	if ( ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() || ! WC()->cart->needs_shipping() ) {
		return $placeholder;
	}

	$threshold = yusraah_free_delivery_threshold();
	if ( ! $threshold ) {
		return $placeholder;
	}

	// Same subtotal WooCommerce's Free shipping method compares against.
	$total = WC()->cart->get_displayed_subtotal();
	if ( ! $threshold['ignore_discounts'] ) {
		$total -= WC()->cart->get_discount_total();
		if ( WC()->cart->display_prices_including_tax() ) {
			$total -= WC()->cart->get_discount_tax();
		}
	}

	$remaining = max( 0, $threshold['amount'] - $total );
	$percent   = (int) min( 100, floor( ( $total / $threshold['amount'] ) * 100 ) );

	if ( $remaining > 0 ) {
		/* translators: %s: amount left to spend */
		$message = sprintf( __( 'Add %s more for free delivery', 'yusraah' ), '<strong>' . wc_price( $remaining ) . '</strong>' );
	} else {
		$message = '<strong>' . esc_html__( 'You’ve unlocked free delivery!', 'yusraah' ) . '</strong>';
	}

	ob_start();
	?>
	<div class="free-delivery<?php echo $remaining > 0 ? '' : ' is-complete'; ?>" data-free-delivery>
		<p class="free-delivery__message"><?php echo wp_kses_post( $message ); ?></p>
		<div class="free-delivery__track" role="progressbar"
			aria-label="<?php esc_attr_e( 'Progress towards free delivery', 'yusraah' ); ?>"
			aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr( $percent ); ?>">
			<span class="free-delivery__fill" style="width: <?php echo esc_attr( $percent ); ?>%"></span>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Echo the free-delivery bar.
 */
function yusraah_free_delivery_bar() {
	echo yusraah_free_delivery_bar_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
}
add_action( 'woocommerce_before_cart_table', 'yusraah_free_delivery_bar', 5 );
add_action( 'woocommerce_review_order_before_payment', 'yusraah_free_delivery_bar', 5 );

/**
 * Cart fragments: free-delivery bar and stepper quantities.
 *
 * @param array $fragments Fragments.
 * @return array
 */
function yusraah_grocery_fragments( $fragments ) {
	$fragments['div.free-delivery']        = yusraah_free_delivery_bar_html();
	$fragments['#yusraah-cart-quantities'] = yusraah_cart_quantities_markup();

	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'yusraah_grocery_fragments' );

/**
 * Refresh the bar when checkout recalculates (address or shipping change).
 *
 * @param array $fragments Checkout fragments.
 * @return array
 */
function yusraah_checkout_free_delivery_fragment( $fragments ) {
	$fragments['div.free-delivery'] = yusraah_free_delivery_bar_html();

	return $fragments;
}
add_filter( 'woocommerce_update_order_review_fragments', 'yusraah_checkout_free_delivery_fragment' );

/*
 * -------------------------------------------------------------------------
 * Bangladesh checkout
 * -------------------------------------------------------------------------
 */

/**
 * Normalise a Bangladeshi mobile number to 01XXXXXXXXX.
 *
 * Accepts Bangla digits, spaces, dashes and +880 / 880 / 0 prefixes.
 *
 * @param string $raw Raw phone input.
 * @return string|false Normalised number, or false when invalid.
 */
function yusraah_normalize_bd_phone( $raw ) {
	$digits = strtr( (string) $raw, array(
		'০' => '0', '১' => '1', '২' => '2', '৩' => '3', '৪' => '4',
		'৫' => '5', '৬' => '6', '৭' => '7', '৮' => '8', '৯' => '9',
	) );
	$digits = preg_replace( '/\D+/', '', $digits );

	if ( 0 === strpos( $digits, '880' ) ) {
		$digits = substr( $digits, 3 );
	}
	if ( 10 === strlen( $digits ) && '1' === $digits[0] ) {
		$digits = '0' . $digits;
	}

	return preg_match( '/^01[3-9]\d{8}$/', $digits ) ? $digits : false;
}

/**
 * Whether to use a single "Full name" field instead of first + last name.
 *
 * @return bool
 */
function yusraah_use_single_name_field() {
	return (bool) apply_filters( 'yusraah_single_name_field', true );
}

/**
 * Bangladesh address layout: District, Area / Thana, full address, landmark.
 *
 * @param array $locale Country locales.
 * @return array
 */
function yusraah_bd_address_locale( $locale ) {
	$bd = isset( $locale['BD'] ) ? $locale['BD'] : array();

	$locale['BD'] = array_replace_recursive( $bd, array(
		'state'     => array(
			'label'    => __( 'District', 'yusraah' ),
			'required' => true,
			'priority' => 42,
		),
		'city'      => array(
			'label'       => __( 'Area / Thana', 'yusraah' ),
			'placeholder' => __( 'e.g. Mirpur, Dhanmondi', 'yusraah' ),
			'priority'    => 44,
		),
		'address_1' => array(
			'label'       => __( 'Full address', 'yusraah' ),
			'placeholder' => __( 'House, road, block or village', 'yusraah' ),
			'priority'    => 50,
		),
		'address_2' => array(
			'label'       => __( 'Landmark', 'yusraah' ),
			'placeholder' => __( 'e.g. Near Mirpur 10 roundabout', 'yusraah' ),
			'label_class' => array(),
			'required'    => false,
			'priority'    => 55,
		),
		'postcode'  => array(
			'required' => false,
			'priority' => 90,
		),
	) );

	return $locale;
}
add_filter( 'woocommerce_get_country_locale', 'yusraah_bd_address_locale' );

/**
 * Keep checkout's address JS from resetting the phone to "Phone (optional)".
 *
 * @param array $fields Default locale fields.
 * @return array
 */
function yusraah_locale_default_phone( $fields ) {
	$fields['phone'] = array_merge( isset( $fields['phone'] ) ? $fields['phone'] : array(), array(
		'label'    => __( 'Mobile number', 'yusraah' ),
		'required' => true,
		'priority' => 22,
	) );

	return $fields;
}
add_filter( 'woocommerce_get_country_locale_default', 'yusraah_locale_default_phone' );

/**
 * Single "Full name" field for all address forms.
 *
 * @param array $fields Default address fields.
 * @return array
 */
function yusraah_default_address_fields( $fields ) {
	if ( ! yusraah_use_single_name_field() ) {
		return $fields;
	}

	if ( isset( $fields['first_name'] ) ) {
		$fields['first_name']['label']        = __( 'Full name', 'yusraah' );
		$fields['first_name']['class']        = array( 'form-row-wide' );
		$fields['first_name']['autocomplete'] = 'name';
	}
	unset( $fields['last_name'] );

	return $fields;
}
add_filter( 'woocommerce_default_address_fields', 'yusraah_default_address_fields' );

/**
 * Mobile number required and first; email optional.
 *
 * @param array  $fields  Billing fields.
 * @param string $country Billing country.
 * @return array
 */
function yusraah_bd_billing_fields( $fields, $country ) {
	if ( isset( $fields['billing_phone'] ) ) {
		$fields['billing_phone'] = array_merge( $fields['billing_phone'], array(
			'label'        => __( 'Mobile number', 'yusraah' ),
			'required'     => true,
			'type'         => 'tel',
			'class'        => array( 'form-row-wide' ),
			'priority'     => 22,
			'autocomplete' => 'tel',
			'placeholder'  => 'BD' === $country || '' === $country ? '01XXXXXXXXX' : '',
			'custom_attributes' => array( 'inputmode' => 'tel' ),
		) );
	}

	if ( isset( $fields['billing_email'] ) ) {
		$fields['billing_email']['required'] = (bool) apply_filters( 'yusraah_require_email', false );
		$fields['billing_email']['priority'] = 24;
		$fields['billing_email']['class']    = array( 'form-row-wide' );
	}

	return $fields;
}
add_filter( 'woocommerce_billing_fields', 'yusraah_bd_billing_fields', 20, 2 );

/**
 * Store BD numbers in one canonical format.
 *
 * @param array $data Posted checkout data.
 * @return array
 */
function yusraah_normalize_checkout_phone( $data ) {
	if ( ! empty( $data['billing_phone'] ) && ( empty( $data['billing_country'] ) || 'BD' === $data['billing_country'] ) ) {
		$normalized = yusraah_normalize_bd_phone( $data['billing_phone'] );
		if ( $normalized ) {
			$data['billing_phone'] = $normalized;
		}
	}

	return $data;
}
add_filter( 'woocommerce_checkout_posted_data', 'yusraah_normalize_checkout_phone' );

/**
 * Reject numbers that are not valid Bangladeshi mobiles.
 *
 * @param array    $data   Posted checkout data.
 * @param WP_Error $errors Validation errors.
 */
function yusraah_validate_checkout_phone( $data, $errors ) {
	if ( empty( $data['billing_phone'] ) || ( ! empty( $data['billing_country'] ) && 'BD' !== $data['billing_country'] ) ) {
		return;
	}

	if ( ! yusraah_normalize_bd_phone( $data['billing_phone'] ) ) {
		$errors->add(
			'billing_phone_validation',
			__( 'Please enter a valid Bangladeshi mobile number, e.g. 01712345678.', 'yusraah' ),
			array( 'id' => 'billing_phone' )
		);
	}
}
add_action( 'woocommerce_after_checkout_validation', 'yusraah_validate_checkout_phone', 10, 2 );

/**
 * Normalise and validate the phone on the My Account address form too.
 *
 * @param string $value Posted phone.
 * @return string
 */
function yusraah_normalize_account_phone( $value ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verifies the nonce before this filter.
	$country = isset( $_POST['billing_country'] ) ? sanitize_text_field( wp_unslash( $_POST['billing_country'] ) ) : 'BD';
	if ( 'BD' !== $country || '' === $value ) {
		return $value;
	}

	$normalized = yusraah_normalize_bd_phone( $value );
	if ( ! $normalized ) {
		wc_add_notice( __( 'Please enter a valid Bangladeshi mobile number, e.g. 01712345678.', 'yusraah' ), 'error' );
		return $value;
	}

	return $normalized;
}
add_filter( 'woocommerce_process_myaccount_field_billing_phone', 'yusraah_normalize_account_phone' );

/*
 * -------------------------------------------------------------------------
 * Re-order / Buy again
 * -------------------------------------------------------------------------
 */

/**
 * Order statuses that can be re-ordered.
 *
 * @return string[]
 */
function yusraah_reorder_statuses() {
	return (array) apply_filters( 'yusraah_reorder_statuses', array( 'completed', 'processing' ) );
}

/**
 * Let customers re-order processing orders too.
 *
 * @param string[] $statuses Statuses.
 * @return string[]
 */
function yusraah_order_again_statuses( $statuses ) {
	return array_values( array_unique( array_merge( $statuses, yusraah_reorder_statuses() ) ) );
}
add_filter( 'woocommerce_valid_order_statuses_for_order_again', 'yusraah_order_again_statuses' );

// Add re-ordered items to the current basket instead of emptying it first.
add_filter( 'woocommerce_empty_cart_when_order_again', '__return_false' );

/**
 * Secure "order again" URL (WooCommerce checks the nonce and order ownership).
 *
 * @param WC_Order $order Order.
 * @return string
 */
function yusraah_order_again_url( $order ) {
	return wp_nonce_url( add_query_arg( 'order_again', $order->get_id(), wc_get_cart_url() ), 'woocommerce-order_again' );
}

/**
 * "Buy again" action in the My Account orders table.
 *
 * @param array    $actions Actions.
 * @param WC_Order $order   Order.
 * @return array
 */
function yusraah_my_orders_buy_again( $actions, $order ) {
	if ( $order->has_status( yusraah_reorder_statuses() ) && count( $order->get_items() ) > 0 ) {
		$actions['order-again'] = array(
			'url'        => yusraah_order_again_url( $order ),
			'name'       => __( 'Buy again', 'yusraah' ),
			/* translators: %s: order number */
			'aria-label' => sprintf( __( 'Buy again: add the items from order %s to your basket', 'yusraah' ), $order->get_order_number() ),
		);
	}

	return $actions;
}
add_filter( 'woocommerce_my_account_my_orders_actions', 'yusraah_my_orders_buy_again', 10, 2 );

/**
 * Products the current customer bought recently and can buy again.
 *
 * @param int $limit Maximum products.
 * @return int[]
 */
function yusraah_buy_again_product_ids( $limit = 8 ) {
	$user_id = get_current_user_id();
	if ( ! $user_id || ! function_exists( 'wc_get_orders' ) ) {
		return array();
	}

	$orders = wc_get_orders( array(
		'customer_id' => $user_id,
		'status'      => array_map( function ( $status ) {
			return 'wc-' . $status;
		}, yusraah_reorder_statuses() ),
		'limit'       => 10,
		'orderby'     => 'date',
		'order'       => 'DESC',
	) );

	$ids = array();
	foreach ( $orders as $order ) {
		foreach ( $order->get_items() as $item ) {
			$product_id = (int) $item->get_product_id();
			if ( ! $product_id || in_array( $product_id, $ids, true ) ) {
				continue;
			}
			$product = wc_get_product( $product_id );
			if ( $product && $product->is_visible() && $product->is_purchasable() && $product->is_in_stock() ) {
				$ids[] = $product_id;
			}
			if ( count( $ids ) >= $limit ) {
				break 2;
			}
		}
	}

	return $ids;
}

/**
 * "Buy again" product row for logged-in customers.
 *
 * @param string $context 'home' or 'account'.
 */
function yusraah_render_buy_again( $context = 'home' ) {
	$ids = yusraah_buy_again_product_ids( 'home' === $context ? 4 : 8 );
	if ( ! $ids ) {
		return;
	}
	$orders_url = wc_get_account_endpoint_url( 'orders' );
	?>
	<section class="buy-again buy-again--<?php echo esc_attr( $context ); ?><?php echo 'home' === $context ? ' section-wrap' : ''; ?>" aria-labelledby="buy-again-title-<?php echo esc_attr( $context ); ?>">
		<div class="buy-again__header">
			<h2 id="buy-again-title-<?php echo esc_attr( $context ); ?>"><?php esc_html_e( 'Buy again', 'yusraah' ); ?></h2>
			<a class="buy-again__link" href="<?php echo esc_url( $orders_url ); ?>"><?php esc_html_e( 'Past orders', 'yusraah' ); ?></a>
		</div>
		<?php echo do_shortcode( '[products ids="' . esc_attr( implode( ',', $ids ) ) . '" orderby="post__in" columns="4" limit="' . count( $ids ) . '"]' ); ?>
	</section>
	<?php
}

/**
 * Buy-again row on the My Account dashboard.
 */
function yusraah_account_dashboard_buy_again() {
	yusraah_render_buy_again( 'account' );
}
add_action( 'woocommerce_account_dashboard', 'yusraah_account_dashboard_buy_again' );
