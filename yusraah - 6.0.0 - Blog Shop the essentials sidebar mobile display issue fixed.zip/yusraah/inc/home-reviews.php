<?php
/**
 * Homepage customer reviews.
 *
 * @package Yusraah
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sanitize the number of homepage reviews.
 *
 * @param mixed $value Raw setting.
 * @return int
 */
function yusraah_sanitize_home_review_count( $value ) {
	return min( 12, max( 1, absint( $value ) ) );
}

/**
 * Sanitize the minimum homepage review rating.
 *
 * @param mixed $value Raw setting.
 * @return int
 */
function yusraah_sanitize_home_review_rating( $value ) {
	return min( 5, max( 0, absint( $value ) ) );
}

/**
 * Add the customer review settings to the homepage Customizer section.
 *
 * @param WP_Customize_Manager $wp_customize Customizer instance.
 */
function yusraah_home_reviews_customize_register( $wp_customize ) {
	$settings = array(
		'yusraah_home_reviews_show' => array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'label'             => __( 'Show customer reviews section', 'yusraah' ),
			'type'              => 'checkbox',
		),
		'yusraah_home_reviews_title' => array(
			'default'           => __( 'What Our Customers Say', 'yusraah' ),
			'sanitize_callback' => 'sanitize_text_field',
			'label'             => __( 'Customer reviews title', 'yusraah' ),
			'type'              => 'text',
		),
		'yusraah_home_reviews_subtitle' => array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_textarea_field',
			'label'             => __( 'Customer reviews subtitle', 'yusraah' ),
			'type'              => 'textarea',
		),
		'yusraah_home_reviews_count' => array(
			'default'           => 6,
			'sanitize_callback' => 'yusraah_sanitize_home_review_count',
			'label'             => __( 'Number of reviews (1–12)', 'yusraah' ),
			'type'              => 'number',
			'input_attrs'       => array( 'min' => 1, 'max' => 12, 'step' => 1 ),
		),
		'yusraah_home_reviews_min_rating' => array(
			'default'           => 0,
			'sanitize_callback' => 'yusraah_sanitize_home_review_rating',
			'label'             => __( 'Minimum review rating (0 = any)', 'yusraah' ),
			'type'              => 'select',
			'choices'           => array(
				0 => __( 'Any rating', 'yusraah' ),
				1 => __( '1 star and up', 'yusraah' ),
				2 => __( '2 stars and up', 'yusraah' ),
				3 => __( '3 stars and up', 'yusraah' ),
				4 => __( '4 stars and up', 'yusraah' ),
				5 => __( '5 stars only', 'yusraah' ),
			),
		),
		'yusraah_home_reviews_autoplay' => array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'label'             => __( 'Automatically slide customer reviews', 'yusraah' ),
			'type'              => 'checkbox',
		),
	);

	foreach ( $settings as $setting_id => $setting ) {
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $setting['default'],
				'sanitize_callback' => $setting['sanitize_callback'],
				'transport'         => 'refresh',
			)
		);

		$control_args = array(
			'label'   => $setting['label'],
			'section' => 'yusraah_homepage',
			'type'    => $setting['type'],
		);

		if ( isset( $setting['choices'] ) ) {
			$control_args['choices'] = $setting['choices'];
		}
		if ( isset( $setting['input_attrs'] ) ) {
			$control_args['input_attrs'] = $setting['input_attrs'];
		}

		$wp_customize->add_control( $setting_id, $control_args );
	}

	$wp_customize->add_control(
		'yusraah_home_reviews_speed',
		array(
			'settings'    => 'yusraah_hero_speed',
			'label'       => __( 'Autoplay speed (shared with hero product card)', 'yusraah' ),
			'section'     => 'yusraah_homepage',
			'type'        => 'number',
			'input_attrs' => array( 'min' => 2000, 'max' => 8000, 'step' => 500 ),
		)
	);
}
add_action( 'customize_register', 'yusraah_home_reviews_customize_register', 11 );

/**
 * Fetch approved WooCommerce reviews, cached by the active display settings.
 *
 * @param int $number Maximum number of reviews.
 * @param int $minimum_rating Minimum star rating, or zero for any rating.
 * @return WP_Comment[]
 */
function yusraah_home_review_comments( $number, $minimum_rating ) {
	$number         = yusraah_sanitize_home_review_count( $number );
	$minimum_rating = yusraah_sanitize_home_review_rating( $minimum_rating );
	$cached         = get_transient( 'yusraah_home_reviews' );

	if (
		is_array( $cached )
		&& isset( $cached['number'], $cached['minimum_rating'], $cached['comments'] )
		&& $number === $cached['number']
		&& $minimum_rating === $cached['minimum_rating']
		&& is_array( $cached['comments'] )
	) {
		return $cached['comments'];
	}

	$args = array(
		'number'      => $number,
		'status'      => 'approve',
		'type'        => 'review',
		'post_type'   => 'product',
		'post_status' => 'publish',
		'orderby'     => 'comment_date_gmt',
		'order'       => 'DESC',
	);

	if ( $minimum_rating > 0 ) {
		$args['meta_query'] = array(
			array(
				'key'     => 'rating',
				'value'   => $minimum_rating,
				'compare' => '>=',
				'type'    => 'NUMERIC',
			),
		);
	}

	$comments = get_comments( $args );
	$comments = is_array( $comments ) ? $comments : array();

	set_transient(
		'yusraah_home_reviews',
		array(
			'number'         => $number,
			'minimum_rating' => $minimum_rating,
			'comments'       => $comments,
		),
		HOUR_IN_SECONDS
	);

	return $comments;
}

/**
 * Clear cached homepage reviews after a review or rating is changed.
 *
 * @param mixed  $meta_id Hook's first argument.
 * @param mixed  $object_id Hook's second argument.
 * @param string $meta_key Comment meta key.
 */
function yusraah_clear_home_review_cache( $meta_id = 0, $object_id = 0, $meta_key = '' ) {
	if ( in_array( current_filter(), array( 'added_comment_meta', 'updated_comment_meta', 'deleted_comment_meta' ), true ) && 'rating' !== $meta_key ) {
		return;
	}

	delete_transient( 'yusraah_home_reviews' );
}
add_action( 'wp_insert_comment', 'yusraah_clear_home_review_cache' );
add_action( 'edit_comment', 'yusraah_clear_home_review_cache' );
add_action( 'delete_comment', 'yusraah_clear_home_review_cache' );
add_action( 'transition_comment_status', 'yusraah_clear_home_review_cache' );
add_action( 'added_comment_meta', 'yusraah_clear_home_review_cache', 10, 4 );
add_action( 'updated_comment_meta', 'yusraah_clear_home_review_cache', 10, 4 );
add_action( 'deleted_comment_meta', 'yusraah_clear_home_review_cache', 10, 4 );
add_action( 'save_post_product', 'yusraah_clear_home_review_cache' );
add_action( 'transition_post_status', 'yusraah_clear_home_review_cache' );

/**
 * Load the homepage-only review carousel assets.
 */
function yusraah_home_review_assets() {
	if ( ! is_front_page() || ! get_theme_mod( 'yusraah_home_reviews_show', true ) || ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	$css_path = get_template_directory() . '/assets/css/home-reviews.css';
	wp_enqueue_style(
		'yusraah-home-reviews',
		get_template_directory_uri() . '/assets/css/home-reviews.css',
		array( 'yusraah-style' ),
		file_exists( $css_path ) ? filemtime( $css_path ) : YUSRAAH_VERSION
	);

	$js_path = get_template_directory() . '/assets/js/home-reviews.js';
	wp_enqueue_script(
		'yusraah-home-reviews',
		get_template_directory_uri() . '/assets/js/home-reviews.js',
		array(),
		file_exists( $js_path ) ? filemtime( $js_path ) : YUSRAAH_VERSION,
		true
	);

	if ( function_exists( 'wp_script_add_data' ) ) {
		wp_script_add_data( 'yusraah-home-reviews', 'strategy', 'defer' );
	}
}
add_action( 'wp_enqueue_scripts', 'yusraah_home_review_assets', 25 );

/**
 * Return the reviewer's initials for the avatar fallback.
 *
 * @param string $name Reviewer display name.
 * @return string
 */
function yusraah_home_review_initials( $name ) {
	$parts    = preg_split( '/\s+/', trim( wp_strip_all_tags( $name ) ) );
	$initials = '';

	foreach ( array_slice( array_filter( (array) $parts ), 0, 2 ) as $part ) {
		$initials .= function_exists( 'mb_substr' ) ? mb_substr( $part, 0, 1 ) : substr( $part, 0, 1 );
	}

	return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $initials ) : strtoupper( $initials );
}

/**
 * Render the homepage customer review carousel.
 */
function yusraah_render_home_reviews() {
	if ( ! class_exists( 'WooCommerce' ) || ! get_theme_mod( 'yusraah_home_reviews_show', true ) ) {
		return;
	}

	$title          = get_theme_mod( 'yusraah_home_reviews_title', __( 'What Our Customers Say', 'yusraah' ) );
	$subtitle       = get_theme_mod( 'yusraah_home_reviews_subtitle', '' );
	$number         = yusraah_sanitize_home_review_count( get_theme_mod( 'yusraah_home_reviews_count', 6 ) );
	$minimum_rating = yusraah_sanitize_home_review_rating( get_theme_mod( 'yusraah_home_reviews_min_rating', 0 ) );
	$autoplay       = (bool) get_theme_mod( 'yusraah_home_reviews_autoplay', true );
	$speed          = yusraah_sanitize_slider_speed( get_theme_mod( 'yusraah_hero_speed', 4500 ) );
	$comments       = yusraah_home_review_comments( $number, $minimum_rating );
	?>
	<section
		class="reviews-section section-wrap"
		data-home-reviews
		data-autoplay="<?php echo $autoplay ? 'true' : 'false'; ?>"
		data-speed="<?php echo esc_attr( $speed ); ?>"
		data-dot-label="<?php esc_attr_e( 'Go to review', 'yusraah' ); ?>"
		role="region"
		aria-roledescription="<?php esc_attr_e( 'carousel', 'yusraah' ); ?>"
		aria-labelledby="yusraah-home-reviews-title"
	>
		<header class="reviews-section__header">
			<div class="reviews-section__intro">
				<h2 id="yusraah-home-reviews-title"><?php echo esc_html( $title ); ?></h2>
				<?php if ( $subtitle ) : ?>
					<p><?php echo esc_html( $subtitle ); ?></p>
				<?php endif; ?>
			</div>
		</header>

		<?php if ( $comments ) : ?>
			<div class="reviews-carousel" data-reviews-carousel>
				<div class="reviews-carousel__viewport">
					<ul class="reviews-carousel__track" data-reviews-track aria-live="off">
						<?php foreach ( $comments as $index => $comment ) : ?>
							<?php
							$rating      = min( 5, absint( get_comment_meta( $comment->comment_ID, 'rating', true ) ) );
							$product     = wc_get_product( $comment->comment_post_ID );
							$verified    = function_exists( 'wc_review_is_from_verified_owner' ) && wc_review_is_from_verified_owner( $comment->comment_ID );
							$reviewer    = $comment->comment_author ? $comment->comment_author : __( 'Customer', 'yusraah' );
							$initials    = yusraah_home_review_initials( $reviewer );
							$product_url = $product && 'publish' === get_post_status( $product->get_id() ) ? get_permalink( $product->get_id() ) : '';
							?>
							<li class="reviews-carousel__slide" data-review-slide aria-hidden="false" role="group" aria-roledescription="<?php esc_attr_e( 'slide', 'yusraah' ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: 1: current review number, 2: total reviews. */ __( '%1$d of %2$d', 'yusraah' ), $index + 1, count( $comments ) ) ); ?>">
								<article class="review-card">
									<svg class="review-card__quote-mark" viewBox="0 0 40 32" aria-hidden="true" focusable="false"><path d="M17 2v13c0 8-4 13-13 15l-2-4c5-2 7-5 7-9H2V2h15zm21 0v13c0 8-4 13-13 15l-2-4c5-2 7-5 7-9h-7V2h15z"/></svg>
									<div class="review-card__top">
										<figure class="review-card__avatar">
											<span class="review-card__initials" aria-hidden="true"><?php echo esc_html( $initials ); ?></span>
											<?php
											echo get_avatar(
												$comment,
												68,
												'404',
												$reviewer,
												array(
													'class'    => 'review-card__avatar-image',
													'width'    => 68,
													'height'   => 68,
													'loading'  => 'lazy',
													'decoding' => 'async',
												)
											); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress get_avatar() escapes attributes and markup.
											?>
										</figure>
										<?php if ( $rating ) : ?>
											<div class="review-card__rating" role="img" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: rating out of five. */ __( 'Rated %d out of 5 stars', 'yusraah' ), $rating ) ); ?>">
												<?php for ( $star = 1; $star <= 5; ++$star ) : ?>
													<svg class="review-card__star<?php echo $star <= $rating ? ' is-filled' : ''; ?>" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m10 1.5 2.6 5.3 5.9.9-4.25 4.15 1 5.85L10 14.95l-5.25 2.75 1-5.85L1.5 7.7l5.9-.9L10 1.5z"/></svg>
												<?php endfor; ?>
											</div>
										<?php endif; ?>
									</div>
									<blockquote class="review-card__quote">
										<p class="review-card__text" data-review-text><?php echo esc_html( $comment->comment_content ); ?></p>
										<button class="review-card__more" type="button" data-review-more data-more-label="<?php esc_attr_e( 'Read more', 'yusraah' ); ?>" data-less-label="<?php esc_attr_e( 'Read less', 'yusraah' ); ?>" aria-expanded="false" hidden><?php esc_html_e( 'Read more', 'yusraah' ); ?></button>
									</blockquote>
									<footer class="review-card__footer">
										<div class="review-card__reviewer">
											<strong><?php echo esc_html( $reviewer ); ?></strong>
											<?php if ( $verified ) : ?>
												<span class="review-card__verified">
													<svg class="review-card__verified-icon" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><circle cx="8" cy="8" r="6.25"/><path d="m5 8 2 2 4-4"/></svg>
													<span class="review-card__verified-label"><?php esc_html_e( 'Verified Buyer', 'yusraah' ); ?></span>
												</span>
											<?php endif; ?>
										</div>
										<?php if ( $product_url ) : ?>
											<p class="review-card__product">
												<?php esc_html_e( 'Reviewed', 'yusraah' ); ?>
												<a href="<?php echo esc_url( $product_url ); ?>"><?php echo esc_html( $product->get_name() ); ?></a>
											</p>
										<?php endif; ?>
									</footer>
								</article>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
				<div class="reviews-carousel__controls" data-reviews-controls role="group" aria-label="<?php esc_attr_e( 'Review carousel controls', 'yusraah' ); ?>" hidden>
					<button class="reviews-carousel__arrow" type="button" data-reviews-prev aria-label="<?php esc_attr_e( 'Previous reviews', 'yusraah' ); ?>">
						<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m12.5 4-6 6 6 6"/></svg>
					</button>
					<div class="reviews-carousel__dots" data-reviews-dots role="group" aria-label="<?php esc_attr_e( 'Choose a review', 'yusraah' ); ?>"></div>
					<button class="reviews-carousel__arrow" type="button" data-reviews-next aria-label="<?php esc_attr_e( 'Next reviews', 'yusraah' ); ?>">
						<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="m7.5 4 6 6-6 6"/></svg>
					</button>
				</div>
			</div>
		<?php else : ?>
			<p class="reviews-section__empty"><?php esc_html_e( 'No reviews yet. Be the first to review our products!', 'yusraah' ); ?></p>
		<?php endif; ?>
	</section>
	<?php
}
