<?php
/**
 * Mobile navigation drawer (below 1024px).
 *
 * The drawer is deliberately independent of the desktop header navigation:
 * header.php keeps #primary-navigation for ≥1024px, while this file renders the
 * off-canvas panel that assets/js/mobile-nav.js drives. Colours resolve from
 * the `--mobile-nav-*` custom properties declared in assets/css/mobile-nav.css
 * and are overridable in the Customizer.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

defined( 'ABSPATH' ) || exit;

/**
 * Default strings for the drawer.
 *
 * Kept in one place so the Customizer, the template and the JavaScript cannot
 * drift apart.
 *
 * @return array<string, string>
 */
function yusraah_mobile_nav_defaults() {
	return array(
		'mobile_menu_title'       => __( 'Menu', 'yusraah' ),
		'mobile_categories_title' => __( 'Shop by category', 'yusraah' ),
		'mobile_view_all_label'   => __( 'View all %s', 'yusraah' ),
		'mobile_quick_title'      => __( 'Your account', 'yusraah' ),
		'mobile_contact_title'    => __( 'Need help?', 'yusraah' ),
	);
}

/**
 * Ordering presets for the automatic category list.
 *
 * @return array<string, array{orderby: string, order: string}>
 */
function yusraah_mobile_category_order_options() {
	return array(
		'menu_order' => array(
			'orderby' => 'menu_order',
			'order'   => 'ASC',
		),
		'name'       => array(
			'orderby' => 'name',
			'order'   => 'ASC',
		),
		'count'      => array(
			'orderby' => 'count',
			'order'   => 'DESC',
		),
	);
}

/**
 * Product categories for the drawer, cached in a signature-guarded transient.
 *
 * The signature contains the theme version and the ordering preset, so a stale
 * transient can never keep showing an old list after either changes. The
 * transient is flushed by yusraah_clear_mobile_nav_cache() whenever a
 * category or product is saved.
 *
 * `hide_empty` is left off on purpose: whether a term is worth showing depends
 * on its descendants, which is decided while the tree is rendered.
 *
 * @return WP_Term[] Flat list of terms, already ordered and without "Uncategorized".
 */
function yusraah_mobile_category_terms() {
	$options = yusraah_mobile_category_order_options();
	$choice  = get_theme_mod( 'yusraah_mobile_cat_orderby', 'menu_order' );

	if ( ! isset( $options[ $choice ] ) ) {
		$choice = 'menu_order';
	}

	$signature = md5( wp_json_encode( array( YUSRAAH_VERSION, $choice ) ) );

	$cached = get_transient( 'yusraah_mobile_category_terms' );
	if (
		is_array( $cached )
		&& isset( $cached['signature'], $cached['terms'] )
		&& $signature === $cached['signature']
	) {
		return $cached['terms'];
	}

	$terms = array();

	if ( taxonomy_exists( 'product_cat' ) ) {
		$fetched = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'orderby'    => $options[ $choice ]['orderby'],
				'order'      => $options[ $choice ]['order'],
				'exclude'    => array( (int) get_option( 'default_product_cat' ) ), // "Uncategorized".
			)
		);

		if ( ! is_wp_error( $fetched ) && ! empty( $fetched ) ) {
			$terms = yusraah_mobile_sort_terms( $fetched, $choice );
		}
	}

	set_transient(
		'yusraah_mobile_category_terms',
		array(
			'signature' => $signature,
			'terms'     => $terms,
		),
		6 * HOUR_IN_SECONDS
	);

	return $terms;
}

/**
 * Sort a flat term list with the selected preset.
 *
 * get_terms() orders the list as a whole, which interleaves branches. Sorting
 * each parent's children again keeps "menu order" and "name" meaningful
 * *within* every branch of the tree that is built from this list.
 *
 * @param WP_Term[] $terms  Flat term list.
 * @param string    $choice Ordering preset key.
 * @return WP_Term[]
 */
function yusraah_mobile_sort_terms( $terms, $choice ) {
	usort(
		$terms,
		static function ( $a, $b ) use ( $choice ) {
			if ( 'name' === $choice ) {
				return strcasecmp( $a->name, $b->name );
			}

			if ( 'count' === $choice ) {
				if ( (int) $a->count !== (int) $b->count ) {
					return (int) $b->count <=> (int) $a->count;
				}

				return strcasecmp( $a->name, $b->name );
			}

			if ( (int) $a->menu_order !== (int) $b->menu_order ) {
				return (int) $a->menu_order <=> (int) $b->menu_order;
			}

			return strcasecmp( $a->name, $b->name );
		}
	);

	return $terms;
}

/**
 * Group a flat term list by parent ID.
 *
 * @param WP_Term[] $terms Flat term list.
 * @return array<int, WP_Term[]> Children keyed by parent term ID.
 */
function yusraah_mobile_group_terms( $terms ) {
	$tree = array();

	foreach ( $terms as $term ) {
		$tree[ (int) $term->parent ][] = $term;
	}

	return $tree;
}

/**
 * Parse a comma-separated Customizer list of category slugs.
 *
 * @param string $setting Theme mod name.
 * @return string[]
 */
function yusraah_mobile_category_slug_list( $setting ) {
	$raw = get_theme_mod( $setting, '' );

	if ( ! is_string( $raw ) || '' === trim( $raw ) ) {
		return array();
	}

	$slugs = array_map( 'sanitize_title', array_map( 'trim', explode( ',', $raw ) ) );

	return array_values( array_filter( $slugs ) );
}

/**
 * Render one level of the category accordion.
 *
 * A term is kept when it is not excluded and either has products itself, owns
 * a visible child branch, or is named in the include list. This means:
 * - an excluded category takes its whole subtree with it,
 * - an include list narrows the list without orphaning the selected children,
 * - a category with no children renders as a plain link (no toggle markup).
 *
 * @param array<int, WP_Term[]> $tree      Terms grouped by parent ID.
 * @param int                   $parent    Parent term ID to render.
 * @param int                   $depth     Current depth (1-based).
 * @param int                   $max_depth Maximum depth to expand.
 * @param array                 $config    Render configuration.
 * @return string
 */
function yusraah_mobile_category_walk( $tree, $parent, $depth, $max_depth, $config ) {
	if ( ! isset( $tree[ $parent ] ) || $depth > $max_depth ) {
		return '';
	}

	$html = '';

	foreach ( $tree[ $parent ] as $term ) {
		if ( in_array( $term->slug, $config['exclude'], true ) ) {
			continue;
		}

		$children_html = $depth < $max_depth
			? yusraah_mobile_category_walk( $tree, $term->term_id, $depth + 1, $max_depth, $config )
			: '';

		if ( $config['include'] && ! in_array( $term->slug, $config['include'], true ) && '' === $children_html ) {
			continue;
		}

		if ( '' === $children_html && (int) $term->count < 1 ) {
			continue; // Hide empty categories.
		}

		$link = get_term_link( $term );

		if ( is_wp_error( $link ) ) {
			continue;
		}

		$has_children = '' !== $children_html;

		$html .= '<li class="mobile-nav__item mobile-nav__cat' . ( $has_children ? ' mobile-nav__item--parent' : '' ) . '">';
		$html .= '<a class="mobile-nav__link" href="' . esc_url( $link ) . '"><span>' . esc_html( $term->name ) . '</span>';

		if ( $config['show_counts'] ) {
			$html .= '<span class="mobile-nav__count">' . esc_html( number_format_i18n( $term->count ) ) . '</span>';
		}

		$html .= '</a>';

		if ( $has_children ) {
			$panel_id      = 'yusraah-mobile-cat-' . (int) $term->term_id;
			$view_all_name = preg_match( '#^https?://#i', $term->name ) ? '' : $term->name;
			$view_all_text = sprintf( $config['view_all'], $view_all_name );

			if ( preg_match( '#https?://\S+#i', $view_all_text ) ) {
				$view_all_text = __( 'View all', 'yusraah' );
			}

			$html .= '<button class="mobile-nav__toggle" type="button" aria-expanded="true" aria-controls="' . esc_attr( $panel_id ) . '">';
			$html .= '<span class="mobile-nav__chevron" aria-hidden="true"></span>';
			$html .= '<span class="screen-reader-text">'
				. esc_html(
					sprintf(
						/* translators: %s: product category name. */
						__( 'Show subcategories of %s', 'yusraah' ),
						$term->name
					)
				)
				. '</span></button>';

			$html .= '<div class="mobile-nav__panel-wrap is-expanded"><ul class="mobile-nav__submenu" id="' . esc_attr( $panel_id ) . '">';
			$html .= '<li class="mobile-nav__item"><a class="mobile-nav__link mobile-nav__link--all" href="' . esc_url( $link ) . '">'
				. esc_html( $view_all_text )
				. '</a></li>';
			$html .= $children_html;
			$html .= '</ul></div>';
		}

		$html .= '</li>';
	}

	return $html;
}

/**
 * Walker that turns nested menu items into accessible disclosures.
 *
 * The toggle is a real button wired to the submenu with aria-expanded and
 * aria-controls, so the "Mobile menu" built in Appearance > Menus — including
 * product categories added as menu items — becomes an accordion.
 */
class Yusraah_Mobile_Nav_Walker extends Walker_Nav_Menu {

	/**
	 * ID of the menu item whose submenu is about to open.
	 *
	 * Walker_Nav_Menu::start_lvl() receives no menu item, so the ID captured in
	 * start_el() is reused to give the <ul> the id its toggle points at.
	 *
	 * @var int
	 */
	private $parent_id = 0;

	/**
	 * Open a submenu wrapper.
	 *
	 * @param string   $output Passed by reference. Used to append additional content.
	 * @param int      $depth  Depth of menu item.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$id = $this->parent_id ? ' id="yusraah-mobile-submenu-' . (int) $this->parent_id . '"' : '';

		$output .= '<div class="mobile-nav__panel-wrap is-expanded"><ul class="mobile-nav__submenu"' . $id . '>';
	}

	/**
	 * Close a submenu wrapper.
	 *
	 * @param string   $output Passed by reference. Used to append additional content.
	 * @param int      $depth  Depth of menu item.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 */
	public function end_lvl( &$output, $depth = 0, $args = null ) {
		$output .= '</ul></div>';
	}

	/**
	 * Start the element output.
	 *
	 * @param string   $output Passed by reference. Used to append additional content.
	 * @param WP_Post  $item   Menu item data object.
	 * @param int      $depth  Depth of menu item.
	 * @param stdClass $args   An object of wp_nav_menu() arguments.
	 * @param int      $id     Current item ID.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$args = is_object( $args ) ? $args : (object) $args;

		$classes   = empty( $item->classes ) || ! is_array( $item->classes ) ? array() : $item->classes;
		$classes[] = 'mobile-nav__item';
		$classes[] = 'menu-item-' . $item->ID;

		if ( $this->has_children ) {
			$classes[] = 'mobile-nav__item--parent';
		}

		$class_names = implode( ' ', array_filter( apply_filters( 'nav_menu_css_class', $classes, $item, $args, $depth ) ) );

		$output .= '<li class="' . esc_attr( $class_names ) . '">';

		$atts = array(
			'title'  => ! empty( $item->attr_title ) ? $item->attr_title : '',
			'target' => ! empty( $item->target ) ? $item->target : '',
			'rel'    => ! empty( $item->xfn ) ? $item->xfn : '',
			'href'   => ! empty( $item->url ) ? $item->url : '',
		);

		if ( in_array( 'current-menu-item', $classes, true ) ) {
			$atts['aria-current'] = 'page';
		}

		$attributes = '';

		foreach ( apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth ) as $attr => $value ) {
			if ( ! is_scalar( $value ) || '' === $value ) {
				continue;
			}

			$value       = 'href' === $attr ? esc_url( $value ) : esc_attr( $value );
			$attributes .= ' ' . $attr . '="' . $value . '"';
		}

		$title = apply_filters( 'the_title', $item->title, $item->ID );
		$title = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );

		$output .= '<a class="mobile-nav__link"' . $attributes . '><span>' . wp_kses_post( $title ) . '</span></a>';

		if ( ! $this->has_children ) {
			return;
		}

		$this->parent_id = (int) $item->ID;

		$output .= '<button class="mobile-nav__toggle" type="button" aria-expanded="true" aria-controls="yusraah-mobile-submenu-' . (int) $item->ID . '">';
		$output .= '<span class="mobile-nav__chevron" aria-hidden="true"></span>';
		$output .= '<span class="screen-reader-text">'
			. esc_html(
				sprintf(
					/* translators: %s: menu item name. */
					__( 'Show submenu for %s', 'yusraah' ),
					wp_strip_all_tags( $title )
				)
			)
			. '</span>';
		$output .= '</button>';
	}
}

/**
 * Fallback list for the "Mobile menu" location.
 *
 * Used only when no menu is assigned. When the site already has a Primary
 * menu, the drawer reuses it so it is never empty.
 *
 * @param array $args wp_nav_menu() arguments.
 */
function yusraah_mobile_nav_menu_fallback( $args = array() ) {
	$menu_class = isset( $args['menu_class'] ) && is_string( $args['menu_class'] ) ? $args['menu_class'] : 'mobile-nav__menu';

	if ( has_nav_menu( 'primary' ) ) {
		wp_nav_menu(
			array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => $menu_class,
				'depth'          => 3,
				'walker'         => new Yusraah_Mobile_Nav_Walker(),
				'fallback_cb'    => 'yusraah_mobile_nav_links',
			)
		);

		return;
	}

	yusraah_mobile_nav_links( $args );
}

/**
 * Last-resort link list so the drawer never renders empty.
 *
 * @param array $args wp_nav_menu() arguments.
 */
function yusraah_mobile_nav_links( $args = array() ) {
	$shop_url   = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
	$menu_class = isset( $args['menu_class'] ) && is_string( $args['menu_class'] ) ? $args['menu_class'] : 'mobile-nav__menu';

	$items = array(
		array( __( 'Shop all', 'yusraah' ), $shop_url ),
		array( __( 'New arrivals', 'yusraah' ), add_query_arg( 'orderby', 'date', $shop_url ) ),
		array( __( 'Our story', 'yusraah' ), home_url( '/' ) ),
	);

	echo '<ul class="' . esc_attr( $menu_class ) . '">';

	foreach ( $items as $item ) {
		echo '<li class="mobile-nav__item"><a class="mobile-nav__link" href="' . esc_url( $item[1] ) . '"><span>' . esc_html( $item[0] ) . '</span></a></li>';
	}

	echo '</ul>';
}

/**
 * Render the off-canvas drawer.
 *
 * Order top to bottom: close header, search, main menu, category accordions,
 * account/wishlist/cart quick links, contact and social links. Submenus ship
 * expanded so the list still works without JavaScript; mobile-nav.js collapses
 * them while the drawer is hidden, so there is no visible jump.
 */
function yusraah_mobile_nav() {
	$defaults = yusraah_mobile_nav_defaults();

	$menu_title    = get_theme_mod( 'yusraah_mobile_menu_title', $defaults['mobile_menu_title'] );
	$cat_title     = get_theme_mod( 'yusraah_mobile_categories_title', $defaults['mobile_categories_title'] );
	$view_all      = get_theme_mod( 'yusraah_mobile_view_all_label', $defaults['mobile_view_all_label'] );
	$quick_title   = get_theme_mod( 'yusraah_mobile_quick_title', $defaults['mobile_quick_title'] );
	$contact_title = get_theme_mod( 'yusraah_mobile_contact_title', $defaults['mobile_contact_title'] );

	$show_search = (bool) get_theme_mod( 'yusraah_mobile_search', true );
	$show_counts = (bool) get_theme_mod( 'yusraah_mobile_cat_counts', true );
	$use_menu    = 'menu' === get_theme_mod( 'yusraah_mobile_cat_source', 'auto' );
	$depth       = min( 3, max( 1, absint( get_theme_mod( 'yusraah_mobile_cat_depth', 3 ) ) ) );

	$site_name = explode( ' ', get_bloginfo( 'name' ), 2 );
	?>
	<div id="yusraah-mobile-drawer" class="mobile-drawer" role="dialog" aria-modal="true" aria-labelledby="yusraah-mobile-drawer-title" aria-hidden="true" hidden data-single-open="<?php echo (bool) get_theme_mod( 'yusraah_mobile_single_open', true ) ? 'true' : 'false'; ?>">
		<button class="mobile-drawer__backdrop" type="button" data-mobile-drawer-close aria-label="<?php esc_attr_e( 'Close menu', 'yusraah' ); ?>"></button>

		<nav class="mobile-drawer__panel" aria-label="<?php esc_attr_e( 'Mobile navigation', 'yusraah' ); ?>" tabindex="-1">
			<h2 id="yusraah-mobile-drawer-title" class="screen-reader-text"><?php echo esc_html( $menu_title ); ?></h2>

			<div class="mobile-drawer__head">
				<a class="wordmark" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php echo esc_html( $site_name[0] ); ?><?php if ( ! empty( $site_name[1] ) ) : ?> <span><?php echo esc_html( $site_name[1] ); ?></span><?php endif; ?></a>
				<button class="icon-button mobile-drawer__close" type="button" data-mobile-drawer-close aria-label="<?php esc_attr_e( 'Close menu', 'yusraah' ); ?>"><?php echo yusraah_icon( 'close' ); ?></button>
			</div>

			<div class="mobile-drawer__scroll">
				<?php if ( $show_search ) : ?>
					<form class="mobile-nav__search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
						<label class="screen-reader-text" for="yusraah-mobile-search"><?php esc_html_e( 'Search products', 'yusraah' ); ?></label>
						<input id="yusraah-mobile-search" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search the collection…', 'yusraah' ); ?>" autocomplete="off">
						<input type="hidden" name="post_type" value="product">
						<button type="submit" aria-label="<?php esc_attr_e( 'Search', 'yusraah' ); ?>"><?php echo yusraah_icon( 'search' ); ?></button>
					</form>
				<?php endif; ?>

				<div class="mobile-nav__group">
					<?php if ( $menu_title ) : ?>
						<p class="mobile-nav__heading" id="yusraah-mobile-menu-heading"><?php echo esc_html( $menu_title ); ?></p>
					<?php endif; ?>
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'mobile',
							'container'      => false,
							'menu_class'     => 'mobile-nav__menu',
							'depth'          => 3,
							'items_wrap'     => '<ul class="%2$s" aria-labelledby="yusraah-mobile-menu-heading">%3$s</ul>',
							'walker'         => new Yusraah_Mobile_Nav_Walker(),
							'fallback_cb'    => 'yusraah_mobile_nav_menu_fallback',
						)
					);
					?>
				</div>

				<?php if ( ! $use_menu && $cat_title ) : ?>
					<?php
					$categories = yusraah_mobile_category_terms();
					$tree       = yusraah_mobile_group_terms( $categories );

					$categories_html = yusraah_mobile_category_walk(
						$tree,
						0,
						1,
						$depth,
						array(
							'include'     => yusraah_mobile_category_slug_list( 'yusraah_mobile_cat_include' ),
							'exclude'     => yusraah_mobile_category_slug_list( 'yusraah_mobile_cat_exclude' ),
							'show_counts' => $show_counts,
							'view_all'    => $view_all,
						)
					);
					?>
					<?php if ( $categories_html ) : ?>
						<div class="mobile-nav__group">
							<p class="mobile-nav__heading" id="yusraah-mobile-categories-heading"><?php echo esc_html( $cat_title ); ?></p>
							<ul class="mobile-nav__menu" aria-labelledby="yusraah-mobile-categories-heading"><?php echo $categories_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in yusraah_mobile_category_walk(). ?></ul>
						</div>
					<?php endif; ?>
				<?php endif; ?>

				<?php
				$quick_links = array();

				if ( get_theme_mod( 'yusraah_mobile_account', true ) ) {
					$quick_links[] = array(
						'icon'  => 'user',
						'label' => __( 'My account', 'yusraah' ),
						'url'   => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_login_url(),
						'count' => null,
						'attr'  => '',
					);
				}

				if ( get_theme_mod( 'yusraah_mobile_wishlist', true ) ) {
					$quick_links[] = array(
						'icon'  => 'heart',
						'label' => __( 'Wishlist', 'yusraah' ),
						'url'   => function_exists( 'yusraah_wishlist_url' ) ? yusraah_wishlist_url() : home_url( '/' ),
						'count' => function_exists( 'yusraah_wishlist_count' ) ? yusraah_wishlist_count() : 0,
						'attr'  => 'data-wishlist-count',
					);
				}

				if ( get_theme_mod( 'yusraah_mobile_cart', true ) ) {
					$quick_links[] = array(
						'icon'  => 'bag',
						'label' => __( 'Basket', 'yusraah' ),
						'url'   => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' ),
						'count' => yusraah_cart_count(),
						'attr'  => 'data-mobile-cart-count',
					);
				}
				?>

				<?php if ( $quick_links && $quick_title ) : ?>
					<div class="mobile-nav__group">
						<p class="mobile-nav__heading" id="yusraah-mobile-quick-heading"><?php echo esc_html( $quick_title ); ?></p>
						<ul class="mobile-nav__menu mobile-nav__quick" aria-labelledby="yusraah-mobile-quick-heading">
							<?php foreach ( $quick_links as $link ) : ?>
								<li class="mobile-nav__item">
									<a class="mobile-nav__link" href="<?php echo esc_url( $link['url'] ); ?>">
										<?php echo yusraah_icon( $link['icon'] ); ?>
										<span><?php echo esc_html( $link['label'] ); ?></span>
										<?php if ( null !== $link['count'] ) : ?>
											<span
												class="mobile-nav__count<?php echo 0 === (int) $link['count'] && 'data-wishlist-count' === $link['attr'] ? ' is-empty' : ''; ?>"
												<?php if ( $link['attr'] ) : ?><?php echo esc_attr( $link['attr'] ); ?><?php endif; ?>
											><?php echo esc_html( number_format_i18n( $link['count'] ) ); ?></span>
										<?php endif; ?>
									</a>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>

				<?php
				$contact_email    = sanitize_email( get_theme_mod( 'yusraah_footer_email', '' ) );
				$contact_phone    = get_theme_mod( 'yusraah_footer_phone', '' );
				$contact_whatsapp = get_theme_mod( 'yusraah_footer_whatsapp', '' );

				$social_links = array(
					'facebook'  => array( __( 'Facebook', 'yusraah' ), get_theme_mod( 'yusraah_social_facebook', '' ) ),
					'instagram' => array( __( 'Instagram', 'yusraah' ), get_theme_mod( 'yusraah_social_instagram', '' ) ),
					'youtube'   => array( __( 'YouTube', 'yusraah' ), get_theme_mod( 'yusraah_social_youtube', '' ) ),
					'whatsapp'  => array( __( 'WhatsApp', 'yusraah' ), get_theme_mod( 'yusraah_social_whatsapp', '' ) ),
					'x'         => array( __( 'X', 'yusraah' ), get_theme_mod( 'yusraah_social_x', '' ) ),
				);

				$social_links = get_theme_mod( 'yusraah_mobile_socials', true )
					? array_filter( $social_links, static function ( $social ) { return '' !== $social[1]; } )
					: array();

				$show_contact = get_theme_mod( 'yusraah_mobile_contact', true )
					&& ( $contact_email || $contact_phone || $contact_whatsapp );
				?>

				<?php if ( $show_contact || $social_links ) : ?>
					<div class="mobile-nav__group mobile-nav__group--contact">
						<?php if ( $show_contact && $contact_title ) : ?>
							<p class="mobile-nav__heading"><?php echo esc_html( $contact_title ); ?></p>
						<?php endif; ?>

						<?php if ( $show_contact ) : ?>
							<ul class="mobile-nav__contact-list">
								<?php if ( $contact_phone ) : ?>
									<li>
										<a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $contact_phone ) ); ?>">
											<?php echo yusraah_footer_icon( 'phone' ); ?>
											<span><?php esc_html_e( 'Call us', 'yusraah' ); ?></span>
										</a>
									</li>
								<?php endif; ?>

								<?php if ( $contact_whatsapp ) : ?>
									<li>
										<a href="<?php echo esc_url( 'https://wa.me/' . preg_replace( '/[^0-9]/', '', $contact_whatsapp ) ); ?>" target="_blank" rel="noopener noreferrer">
											<?php echo yusraah_footer_icon( 'whatsapp' ); ?>
											<span><?php esc_html_e( 'Chat on WhatsApp', 'yusraah' ); ?></span>
										</a>
									</li>
								<?php endif; ?>

								<?php if ( $contact_email ) : ?>
									<li>
										<a href="<?php echo esc_url( 'mailto:' . $contact_email ); ?>">
											<?php echo yusraah_footer_icon( 'mail' ); ?>
											<span><?php echo esc_html( $contact_email ); ?></span>
										</a>
									</li>
								<?php endif; ?>
							</ul>
						<?php endif; ?>

						<?php if ( $social_links ) : ?>
							<ul class="mobile-nav__social" aria-label="<?php esc_attr_e( 'Follow us', 'yusraah' ); ?>">
								<?php foreach ( $social_links as $social_key => $social ) : ?>
									<li>
										<a href="<?php echo esc_url( $social[1] ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $social[0] ); ?>">
											<?php echo yusraah_footer_icon( $social_key ); ?>
										</a>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		</nav>
	</div>
	<?php
}

/**
 * Keep the drawer's basket count in sync with WooCommerce's cart fragments.
 *
 * The header badge is refreshed through the `[data-cart-count]` fragment, which
 * replaces every matching node with header markup. The drawer therefore needs
 * its own attribute and its own fragment entry.
 *
 * @param array $fragments Cart fragments.
 * @return array
 */
function yusraah_mobile_cart_count_fragment( $fragments ) {
	ob_start();
	?>
	<span class="mobile-nav__count" data-mobile-cart-count><?php echo esc_html( yusraah_cart_count() ); ?></span>
	<?php
	$fragments['[data-mobile-cart-count]'] = ob_get_clean();

	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'yusraah_mobile_cart_count_fragment' );

/**
 * Clear the drawer's category cache when categories or products change.
 */
function yusraah_clear_mobile_nav_cache() {
	delete_transient( 'yusraah_mobile_category_terms' );
}
add_action( 'created_product_cat', 'yusraah_clear_mobile_nav_cache' );
add_action( 'edited_product_cat', 'yusraah_clear_mobile_nav_cache' );
add_action( 'delete_product_cat', 'yusraah_clear_mobile_nav_cache' );
add_action( 'save_post_product', 'yusraah_clear_mobile_nav_cache' );

/**
 * Enqueue the drawer stylesheet and script, and print the Customizer colours.
 *
 * Runs after yusraah_assets() (priority 10) and
 * yusraah_footer_assets() (priority 30) so both handles already exist.
 */
function yusraah_mobile_nav_assets() {
	$style_path  = get_template_directory() . '/assets/css/mobile-nav.css';
	$script_path = get_template_directory() . '/assets/js/mobile-nav.js';

	wp_enqueue_style(
		'yusraah-mobile-nav',
		get_template_directory_uri() . '/assets/css/mobile-nav.css',
		array( 'yusraah-style' ),
		file_exists( $style_path ) ? filemtime( $style_path ) : YUSRAAH_VERSION
	);

	wp_enqueue_script(
		'yusraah-mobile-nav',
		get_template_directory_uri() . '/assets/js/mobile-nav.js',
		array(),
		file_exists( $script_path ) ? filemtime( $script_path ) : YUSRAAH_VERSION,
		true
	);

	$palette = array(
		'yusraah_mobile_bg'     => array( '--mobile-nav-bg', '#f8f7f3' ),
		'yusraah_mobile_text'   => array( '--mobile-nav-text', '#18201e' ),
		'yusraah_mobile_accent' => array( '--mobile-nav-accent', '#d47550' ),
	);

	$css = '';

	foreach ( $palette as $setting => list( $property, $fallback ) ) {
		$value = get_theme_mod( $setting, $fallback );

		if ( ! is_string( $value ) || '' === $value || strtolower( $value ) === $fallback ) {
			continue;
		}

		if ( preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{6})$/i', $value ) ) {
			$css .= $property . ':' . $value . ';';
		}
	}

	if ( $css ) {
		wp_add_inline_style( 'yusraah-mobile-nav', ':root{' . $css . '}' );
	}

	wp_localize_script(
		'yusraah-mobile-nav',
		'yusraahMobileNav',
		array(
			'singleOpen' => (bool) get_theme_mod( 'yusraah_mobile_single_open', true ),
			'strings'    => array(
				'open'      => __( 'Open menu', 'yusraah' ),
				'close'     => __( 'Close menu', 'yusraah' ),
				'expanded'  => __( 'Hide submenu for %s', 'yusraah' ),
				'collapsed' => __( 'Show submenu for %s', 'yusraah' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'yusraah_mobile_nav_assets', 45 );

/**
 * Register the "Mobile menu" Customizer section.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function yusraah_mobile_nav_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'yusraah_mobile_nav',
		array(
			'title'       => __( 'Mobile menu', 'yusraah' ),
			'description' => __( 'Off-canvas drawer shown below 1024px. Build its top links in Appearance > Menus → Mobile menu.', 'yusraah' ),
			'priority'    => 43,
		)
	);

	$defaults = yusraah_mobile_nav_defaults();

	// Category source and ordering.
	$wp_customize->add_setting(
		'yusraah_mobile_cat_source',
		array(
			'default'           => 'auto',
			'sanitize_callback' => 'sanitize_key',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'yusraah_mobile_cat_source',
		array(
			'label'       => __( 'Category list', 'yusraah' ),
			'description' => __( '“Auto” builds the accordion from your WooCommerce categories. “Use my menu” hides it and relies on the Mobile menu items instead.', 'yusraah' ),
			'section'     => 'yusraah_mobile_nav',
			'type'        => 'select',
			'choices'     => array(
				'auto' => __( 'Auto from WooCommerce categories', 'yusraah' ),
				'menu' => __( 'Use my menu', 'yusraah' ),
			),
		)
	);

	$wp_customize->add_setting(
		'yusraah_mobile_cat_orderby',
		array(
			'default'           => 'menu_order',
			'sanitize_callback' => 'sanitize_key',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'yusraah_mobile_cat_orderby',
		array(
			'label'   => __( 'Category order', 'yusraah' ),
			'section' => 'yusraah_mobile_nav',
			'type'    => 'select',
			'choices' => array(
				'menu_order' => __( 'Menu order', 'yusraah' ),
				'name'       => __( 'Name', 'yusraah' ),
				'count'      => __( 'Popularity (product count)', 'yusraah' ),
			),
		)
	);

	$wp_customize->add_setting(
		'yusraah_mobile_cat_depth',
		array(
			'default'           => 3,
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'yusraah_mobile_cat_depth',
		array(
			'label'       => __( 'Category depth', 'yusraah' ),
			'description' => __( 'How many levels of subcategories expand inside the drawer.', 'yusraah' ),
			'section'     => 'yusraah_mobile_nav',
			'type'        => 'select',
			'choices'     => array(
				1 => __( '1 level', 'yusraah' ),
				2 => __( '2 levels', 'yusraah' ),
				3 => __( '3 levels', 'yusraah' ),
			),
		)
	);

	// Category include / exclude lists.
	$lists = array(
		'yusraah_mobile_cat_include' => array(
			__( 'Include only these categories', 'yusraah' ),
			__( 'Comma-separated slugs. Leave empty to show every category.', 'yusraah' ),
		),
		'yusraah_mobile_cat_exclude' => array(
			__( 'Exclude these categories', 'yusraah' ),
			__( 'Comma-separated slugs. An excluded category also hides everything beneath it.', 'yusraah' ),
		),
	);

	foreach ( $lists as $setting => $config ) {
		$wp_customize->add_setting(
			$setting,
			array(
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			$setting,
			array(
				'label'       => $config[0],
				'description' => $config[1],
				'section'     => 'yusraah_mobile_nav',
				'type'        => 'text',
			)
		);
	}

	// Toggles.
	$toggles = array(
		'yusraah_mobile_search'      => array( __( 'Show the search field', 'yusraah' ), true ),
		'yusraah_mobile_cat_counts'  => array( __( 'Show product counts', 'yusraah' ), true ),
		'yusraah_mobile_single_open' => array( __( 'Open one category at a time', 'yusraah' ), true ),
		'yusraah_mobile_account'     => array( __( 'Show the account quick link', 'yusraah' ), true ),
		'yusraah_mobile_wishlist'    => array( __( 'Show the wishlist quick link', 'yusraah' ), true ),
		'yusraah_mobile_cart'        => array( __( 'Show the basket quick link', 'yusraah' ), true ),
		'yusraah_mobile_contact'     => array( __( 'Show the contact links', 'yusraah' ), true ),
		'yusraah_mobile_socials'     => array( __( 'Show the social icons', 'yusraah' ), true ),
	);

	foreach ( $toggles as $setting => $config ) {
		$wp_customize->add_setting(
			$setting,
			array(
				'default'           => $config[1],
				'sanitize_callback' => 'rest_sanitize_boolean',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			$setting,
			array(
				'label'   => $config[0],
				'section' => 'yusraah_mobile_nav',
				'type'    => 'checkbox',
			)
		);
	}

	// Editable labels.
	$labels = array(
		'mobile_menu_title'       => array( __( 'Menu group title', 'yusraah' ), 'text' ),
		'mobile_categories_title' => array( __( 'Category group title', 'yusraah' ), 'text' ),
		'mobile_view_all_label'   => array( __( '“View all” link label', 'yusraah' ), 'text', __( 'Use %s for the category name, e.g. “View all %s”.', 'yusraah' ) ),
		'mobile_quick_title'      => array( __( 'Quick links title', 'yusraah' ), 'text' ),
		'mobile_contact_title'    => array( __( 'Contact block title', 'yusraah' ), 'text' ),
	);

	foreach ( $labels as $setting => $config ) {
		$wp_customize->add_setting(
			'yusraah_' . $setting,
			array(
				'default'           => $defaults[ $setting ],
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);

		$control = array(
			'label'   => $config[0],
			'section' => 'yusraah_mobile_nav',
			'type'    => $config[1],
		);

		if ( isset( $config[2] ) ) {
			$control['description'] = $config[2];
		}

		$wp_customize->add_control( 'yusraah_' . $setting, $control );
	}

	// Colours. These override the --mobile-nav-* defaults in mobile-nav.css.
	$colors = array(
		'yusraah_mobile_bg'     => array( __( 'Drawer background', 'yusraah' ), '#f8f7f3' ),
		'yusraah_mobile_text'   => array( __( 'Drawer text', 'yusraah' ), '#18201e' ),
		'yusraah_mobile_accent' => array( __( 'Drawer accent (hover, focus and counts)', 'yusraah' ), '#d47550' ),
	);

	foreach ( $colors as $setting => $config ) {
		$wp_customize->add_setting(
			$setting,
			array(
				'default'           => $config[1],
				'sanitize_callback' => 'sanitize_hex_color',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				$setting,
				array(
					'label'   => $config[0],
					'section' => 'yusraah_mobile_nav',
				)
			)
		);
	}
}
add_action( 'customize_register', 'yusraah_mobile_nav_customize_register', 25 );
