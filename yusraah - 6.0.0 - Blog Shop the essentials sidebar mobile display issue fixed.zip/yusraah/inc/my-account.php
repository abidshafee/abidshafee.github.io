<?php
/**
 * My Account: dashboard summary, recent orders and account notices.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * -------------------------------------------------------------------------
 * Shared helpers
 * -------------------------------------------------------------------------
 */

/**
 * Render a WooCommerce order status as a badge.
 *
 * Reuses the site-wide `.yusraah-badge` component so every badge shares one
 * size, radius and typography.
 *
 * @param WC_Order $order Order.
 * @return string
 */
function yusraah_order_status_badge( $order ) {
	if ( ! $order instanceof WC_Order ) {
		return '';
	}

	$status = $order->get_status();

	return sprintf(
		'<span class="yusraah-badge order-status order-status--%1$s">%2$s</span>',
		esc_attr( $status ),
		esc_html( wc_get_order_status_name( $status ) )
	);
}

/**
 * Order statuses counted as "in progress" on the dashboard.
 *
 * @return string[]
 */
function yusraah_account_in_progress_statuses() {
	return (array) apply_filters(
		'yusraah_account_in_progress_statuses',
		array( 'pending', 'on-hold', 'processing' )
	);
}

/**
 * Number of the customer's orders that are still in progress.
 *
 * @param int $user_id Customer ID.
 * @return int
 */
function yusraah_account_in_progress_order_count( $user_id ) {
	$user_id = absint( $user_id );

	if ( ! $user_id || ! function_exists( 'wc_get_orders' ) ) {
		return 0;
	}

	$statuses = array_map(
		static function ( $status ) {
			return 'wc-' . $status;
		},
		yusraah_account_in_progress_statuses()
	);

	$result = wc_get_orders(
		array(
			'customer_id' => $user_id,
			'status'      => $statuses,
			'limit'       => 1,
			'paginate'    => true,
			'return'      => 'ids',
		)
	);

	return $result && isset( $result->total ) ? (int) $result->total : 0;
}

/*
 * -------------------------------------------------------------------------
 * Dashboard: summary cards
 * -------------------------------------------------------------------------
 */

/**
 * Summary cards linking to each account section.
 */
function yusraah_account_summary_cards() {
	$user_id = get_current_user_id();

	if ( ! $user_id || ! function_exists( 'wc_get_orders' ) ) {
		return;
	}

	$wishlist_count = function_exists( 'yusraah_wishlist_count' ) ? yusraah_wishlist_count() : 0;

	$cards = array(
		array(
			'key'    => 'orders',
			'icon'   => 'box',
			'value'  => (int) wc_get_customer_order_count( $user_id ),
			'label'  => __( 'Orders placed', 'yusraah' ),
			'hint'   => __( 'View all orders', 'yusraah' ),
			'url'    => wc_get_endpoint_url( 'orders' ),
		),
		array(
			'key'    => 'in-progress',
			'icon'   => 'arrow',
			'value'  => yusraah_account_in_progress_order_count( $user_id ),
			'label'  => __( 'In progress', 'yusraah' ),
			'hint'   => __( 'Track current orders', 'yusraah' ),
			'url'    => wc_get_endpoint_url( 'orders' ),
		),
		array(
			'key'    => 'wishlist',
			'icon'   => 'heart',
			'value'  => $wishlist_count,
			'label'  => __( 'Wishlist items', 'yusraah' ),
			'hint'   => __( 'Open your wishlist', 'yusraah' ),
			'url'    => function_exists( 'yusraah_wishlist_url' ) ? yusraah_wishlist_url() : wc_get_endpoint_url( 'edit-account' ),
		),
	);
	?>
	<ul class="account-stats">
		<?php foreach ( $cards as $card ) : ?>
			<li class="account-stats__item">
				<a class="account-stat account-stat--<?php echo esc_attr( $card['key'] ); ?>" href="<?php echo esc_url( $card['url'] ); ?>">
					<span class="account-stat__icon" aria-hidden="true"><?php echo yusraah_icon( $card['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed inline SVG set. ?></span>
					<span class="account-stat__value"><?php echo esc_html( number_format_i18n( $card['value'] ) ); ?></span>
					<span class="account-stat__label"><?php echo esc_html( $card['label'] ); ?></span>
					<span class="account-stat__hint"><?php echo esc_html( $card['hint'] ); ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php
}
add_action( 'woocommerce_account_dashboard', 'yusraah_account_summary_cards', 5 );

/*
 * -------------------------------------------------------------------------
 * Dashboard: recent orders
 * -------------------------------------------------------------------------
 */

/**
 * Recent orders table with status badges, view and re-order actions.
 */
function yusraah_account_recent_orders() {
	$user_id = get_current_user_id();

	if ( ! $user_id || ! function_exists( 'wc_get_orders' ) ) {
		return;
	}

	$orders = wc_get_orders(
		array(
			'customer_id' => $user_id,
			'limit'       => 5,
			'orderby'     => 'date',
			'order'       => 'DESC',
		)
	);

	$orders_url  = wc_get_endpoint_url( 'orders' );
	$shop_url    = wc_get_page_permalink( 'shop' );
	$reorderable = function_exists( 'yusraah_reorder_statuses' ) ? yusraah_reorder_statuses() : array();
	?>
	<section class="account-panel" aria-labelledby="account-recent-orders-title">
		<div class="account-panel__header">
			<h2 class="account-panel__title" id="account-recent-orders-title"><?php esc_html_e( 'Recent orders', 'yusraah' ); ?></h2>
			<?php if ( $orders ) : ?>
				<a class="account-panel__link" href="<?php echo esc_url( $orders_url ); ?>"><?php esc_html_e( 'View all orders', 'yusraah' ); ?></a>
			<?php endif; ?>
		</div>

		<?php if ( ! $orders ) : ?>
			<div class="account-empty">
				<span class="account-empty__icon" aria-hidden="true"><?php echo yusraah_icon( 'box' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed inline SVG set. ?></span>
				<p class="account-empty__text"><?php esc_html_e( 'You have not placed any orders yet.', 'yusraah' ); ?></p>
				<a class="account-empty__cta" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Start shopping', 'yusraah' ); ?></a>
			</div>
		<?php else : ?>
			<table class="account-orders-table">
				<caption class="screen-reader-text"><?php esc_html_e( 'Your most recent orders', 'yusraah' ); ?></caption>
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Order', 'yusraah' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Date', 'yusraah' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Status', 'yusraah' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Total', 'yusraah' ); ?></th>
						<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'yusraah' ); ?></span></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $orders as $order ) :
						$order_url = $order->get_view_order_url();
						?>
						<tr>
							<td data-title="<?php esc_attr_e( 'Order', 'yusraah' ); ?>"><?php echo esc_html( $order->get_order_number() ); ?></td>
							<td data-title="<?php esc_attr_e( 'Date', 'yusraah' ); ?>"><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></td>
							<td data-title="<?php esc_attr_e( 'Status', 'yusraah' ); ?>"><?php echo yusraah_order_status_badge( $order ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?></td>
							<td data-title="<?php esc_attr_e( 'Total', 'yusraah' ); ?>"><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></td>
							<td class="account-orders-table__actions">
								<a
									class="account-orders-table__action"
									href="<?php echo esc_url( $order_url ); ?>"
									aria-label="<?php
									printf(
										/* translators: %s: order number */
										esc_attr__( 'View order %s', 'yusraah' ),
										esc_attr( $order->get_order_number() )
									);
									?>"
								><?php esc_html_e( 'View', 'yusraah' ); ?></a>
								<?php if ( $reorderable && $order->has_status( $reorderable ) && $order->get_items() ) : ?>
									<a
										class="account-orders-table__action account-orders-table__action--ghost"
										href="<?php echo esc_url( yusraah_order_again_url( $order ) ); ?>"
										aria-label="<?php
										printf(
											/* translators: %s: order number */
											esc_attr__( 'Buy again: add the items from order %s to your basket', 'yusraah' ),
											esc_attr( $order->get_order_number() )
										);
										?>"
									><?php esc_html_e( 'Buy again', 'yusraah' ); ?></a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</section>
	<?php
}
add_action( 'woocommerce_account_dashboard', 'yusraah_account_recent_orders', 6 );

/*
 * -------------------------------------------------------------------------
 * Temporary password notice
 * -------------------------------------------------------------------------
 */

/**
 * Rebuild the temporary-password notice into a clean alert.
 *
 * WooCommerce adds `%1$sResend%2$s Your account is using a temporary
 * password...` as a `notice` type notice on the dashboard and account
 * details screens. The message is passed through the
 * `woocommerce_add_notice` filter, so we can add a direct "Change password"
 * link and move the Resend action into a dedicated actions area while keeping
 * the core-generated, nonce-protected resend URL.
 *
 * @param string $message Notice message.
 * @return string
 */
function yusraah_temporary_password_notice( $message ) {
	if ( ! is_string( $message ) || false === strpos( $message, 'wc-resend-set-password' ) ) {
		return $message;
	}

	$resend = '';
	if ( preg_match( '#<a\b[^>]*wc-forward[^>]*>.*?</a>#i', $message, $matches ) ) {
		$resend = $matches[0];
	}

	$change_password_url = wc_get_endpoint_url( 'edit-account', '', wc_get_page_permalink( 'myaccount' ) );

	return sprintf(
		'<span class="account-alert__text">%1$s</span><span class="account-alert__actions"><a class="account-alert__link" href="%2$s">%3$s</a>%4$s</span>',
		esc_html__( 'Your account is using a temporary password. We emailed you a link to change your password.', 'yusraah' ),
		esc_url( $change_password_url ),
		esc_html__( 'Change password', 'yusraah' ),
		$resend
	);
}
add_filter( 'woocommerce_add_notice', 'yusraah_temporary_password_notice' );
