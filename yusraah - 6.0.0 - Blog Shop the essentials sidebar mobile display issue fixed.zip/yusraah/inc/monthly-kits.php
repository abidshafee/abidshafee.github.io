<?php
/**
 * Homepage Monthly Kits banner.
 *
 * @package Yusraah
 */

defined( 'ABSPATH' ) || exit;

/**
 * Get the initial slider category for an existing banner.
 *
 * A saved category selection, including an intentionally empty one, takes
 * precedence over this default.
 *
 * @return int[]
 */
function yusraah_monthly_kits_default_slider_categories() {
	$theme_mods = get_theme_mods();
	if ( is_array( $theme_mods ) && array_key_exists( 'yusraah_monthly_kits_slider_categories', $theme_mods ) ) {
		return array();
	}

	$category_id = absint( get_theme_mod( 'yusraah_monthly_kits_category', 0 ) );
	return $category_id && term_exists( $category_id, 'product_cat' ) ? array( $category_id ) : array();
}

/**
 * Register the Monthly Kits Customizer controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function yusraah_monthly_kits_customize_register( $wp_customize ) {
	if ( ! class_exists( 'Yusraah_Quick_Deal_Categories_Control' ) ) {
		return;
	}

	$wp_customize->add_panel(
		'yusraah_monthly_kits_homepage',
		array(
			'title'       => __( 'Homepage', 'yusraah' ),
			'description' => __( 'Customize homepage promotional sections.', 'yusraah' ),
			'priority'    => 36,
		)
	);
	$wp_customize->add_section(
		'yusraah_monthly_kits',
		array(
			'title'    => __( 'Monthly Kits Banner', 'yusraah' ),
			'panel'    => 'yusraah_monthly_kits_homepage',
			'priority' => 10,
		)
	);

	$categories = array( 0 => __( 'Select a product category', 'yusraah' ) );
	if ( taxonomy_exists( 'product_cat' ) ) {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$categories[ $term->term_id ] = $term->name;
			}
		}
	}

	$settings = array(
		'show'              => array(
			'default'   => true,
			'sanitize'  => 'rest_sanitize_boolean',
			'type'      => 'checkbox',
			'label'     => __( 'Show banner', 'yusraah' ),
			'transport' => 'refresh',
		),
		'eyebrow'           => array(
			'default'  => __( 'Monthly kits', 'yusraah' ),
			'sanitize' => 'sanitize_text_field',
			'type'     => 'text',
			'label'    => __( 'Eyebrow text', 'yusraah' ),
		),
		'badge'             => array(
			'default'  => __( 'Save up to 20%', 'yusraah' ),
			'sanitize' => 'sanitize_text_field',
			'type'     => 'text',
			'label'    => __( 'Savings badge text', 'yusraah' ),
		),
		'image_alt'         => array(
			'default'  => '',
			'sanitize' => 'sanitize_text_field',
			'type'     => 'text',
			'label'    => __( 'Banner image alt text', 'yusraah' ),
		),
		'image_position'    => array(
			'default'  => 'right',
			'sanitize' => 'yusraah_monthly_kits_sanitize_image_position',
			'type'     => 'select',
			'label'    => __( 'Image position', 'yusraah' ),
			'choices'  => array(
				'right' => __( 'Right', 'yusraah' ),
				'left'  => __( 'Left', 'yusraah' ),
			),
		),
		'overlay'           => array(
			'default'  => 20,
			'sanitize' => 'yusraah_monthly_kits_sanitize_overlay',
			'type'     => 'range',
			'label'    => __( 'Image overlay opacity (%)', 'yusraah' ),
		),
		'background'        => array(
			'default'  => 'gradient',
			'sanitize' => 'yusraah_monthly_kits_sanitize_background',
			'type'     => 'select',
			'label'    => __( 'Background style', 'yusraah' ),
			'choices'  => array(
				'solid'    => __( 'Solid', 'yusraah' ),
				'gradient' => __( 'Gradient', 'yusraah' ),
			),
		),
		'accent'            => array(
			'default'  => '',
			'sanitize' => 'yusraah_monthly_kits_sanitize_accent',
			'type'     => 'color',
			'label'    => __( 'Accent color override (blank uses theme accent)', 'yusraah' ),
		),
		'link_type'         => array(
			'default'  => 'category',
			'sanitize' => 'yusraah_monthly_kits_sanitize_link_type',
			'type'     => 'select',
			'label'    => __( 'Button link destination', 'yusraah' ),
			'choices'  => array(
				'category' => __( 'Product category', 'yusraah' ),
				'page'     => __( 'Page', 'yusraah' ),
				'url'      => __( 'Custom URL', 'yusraah' ),
			),
		),
		'category'          => array(
			'default'  => 0,
			'sanitize' => 'yusraah_monthly_kits_sanitize_category',
			'type'     => 'select',
			'label'    => __( 'Button product category', 'yusraah' ),
			'choices'  => $categories,
		),
		'page'              => array(
			'default'  => 0,
			'sanitize' => 'absint',
			'type'     => 'dropdown-pages',
			'label'    => __( 'Button page', 'yusraah' ),
		),
		'url'               => array(
			'default'  => '',
			'sanitize' => 'esc_url_raw',
			'type'     => 'url',
			'label'    => __( 'Button custom URL', 'yusraah' ),
		),
		'secondary_label'   => array(
			'default'  => '',
			'sanitize' => 'sanitize_text_field',
			'type'     => 'text',
			'label'    => __( 'Secondary link label (optional)', 'yusraah' ),
		),
		'secondary_url'     => array(
			'default'  => '',
			'sanitize' => 'esc_url_raw',
			'type'     => 'url',
			'label'    => __( 'Secondary link URL', 'yusraah' ),
		),
		'content_type'      => array(
			'default'  => get_theme_mod( 'yusraah_monthly_kits_products_show', false ) ? 'slider' : 'image',
			'sanitize' => 'yusraah_monthly_kits_sanitize_content_type',
			'type'     => 'select',
			'label'    => __( 'Visual content', 'yusraah' ),
			'choices'  => array(
				'image'  => __( 'Image', 'yusraah' ),
				'slider' => __( 'Product slider', 'yusraah' ),
			),
		),
		'slider_limit'      => array(
			'default'  => 8,
			'sanitize' => 'yusraah_quick_deal_sanitize_limit',
			'type'     => 'number',
			'label'    => __( 'Number of products', 'yusraah' ),
		),
		'slider_order'      => array(
			'default'  => 'latest',
			'sanitize' => 'yusraah_quick_deal_sanitize_order',
			'type'     => 'select',
			'label'    => __( 'Order products by', 'yusraah' ),
			'choices'  => array(
				'latest'      => __( 'Latest', 'yusraah' ),
				'bestselling' => __( 'Best selling', 'yusraah' ),
				'top_rated'   => __( 'Top rated', 'yusraah' ),
				'on_sale'     => __( 'On sale', 'yusraah' ),
				'random'      => __( 'Random', 'yusraah' ),
			),
		),
		'slider_autoplay'   => array(
			'default'  => true,
			'sanitize' => 'rest_sanitize_boolean',
			'type'     => 'checkbox',
			'label'    => __( 'Enable slider autoplay', 'yusraah' ),
		),
		'slider_speed'      => array(
			'default'  => 4500,
			'sanitize' => 'yusraah_sanitize_slider_speed',
			'type'     => 'number',
			'label'    => __( 'Autoplay speed (ms, 2000–8000)', 'yusraah' ),
		),
		'countdown_show'    => array(
			'default'  => false,
			'sanitize' => 'rest_sanitize_boolean',
			'type'     => 'checkbox',
			'label'    => __( 'Show limited-time countdown', 'yusraah' ),
		),
		'countdown_start'   => array(
			'default'  => '',
			'sanitize' => 'yusraah_monthly_kits_sanitize_date',
			'type'     => 'date',
			'label'    => __( 'Offer start date (site timezone)', 'yusraah' ),
		),
		'countdown_end'     => array(
			'default'  => '',
			'sanitize' => 'yusraah_monthly_kits_sanitize_date',
			'type'     => 'date',
			'label'    => __( 'Offer end date (site timezone)', 'yusraah' ),
		),
		'trust_show'        => array(
			'default'  => false,
			'sanitize' => 'rest_sanitize_boolean',
			'type'     => 'checkbox',
			'label'    => __( 'Show trust line', 'yusraah' ),
		),
		'trust_text'        => array(
			'default'  => __( 'Loved by 1,000+ customers', 'yusraah' ),
			'sanitize' => 'sanitize_text_field',
			'type'     => 'text',
			'label'    => __( 'Trust line text', 'yusraah' ),
		),
	);

	$legacy = array(
		'heading' => array(
			'default'  => __( 'Save with Monthly Essentials Kits', 'yusraah' ),
			'sanitize' => 'sanitize_text_field',
			'type'     => 'text',
			'label'    => __( 'Heading', 'yusraah' ),
		),
		'subtext' => array(
			'default'  => __( 'Bundle your favorites and save up to 20% on curated monthly essentials.', 'yusraah' ),
			'sanitize' => 'sanitize_text_field',
			'type'     => 'textarea',
			'label'    => __( 'Supporting text', 'yusraah' ),
		),
		'cta'     => array(
			'default'  => __( 'Shop bundles', 'yusraah' ),
			'sanitize' => 'sanitize_text_field',
			'type'     => 'text',
			'label'    => __( 'Button label', 'yusraah' ),
		),
	);
	foreach ( $legacy as $key => $setting ) {
		$settings[ $key ] = $setting;
	}

	$legacy_ids = array(
		'show'    => 'yusraah_show_offers_banner',
		'heading' => 'yusraah_offers_headline',
		'subtext' => 'yusraah_offers_subtext',
		'cta'     => 'yusraah_offers_cta',
	);
	foreach ( $settings as $key => $setting ) {
		$id = isset( $legacy_ids[ $key ] ) ? $legacy_ids[ $key ] : 'yusraah_monthly_kits_' . $key;
		$wp_customize->add_setting(
			$id,
			array(
				'default'           => $setting['default'],
				'sanitize_callback' => $setting['sanitize'],
				'transport'         => isset( $setting['transport'] ) ? $setting['transport'] : 'postMessage',
			)
		);

		$control = array(
			'label'   => $setting['label'],
			'section' => 'yusraah_monthly_kits',
			'type'    => $setting['type'],
		);
		if ( isset( $setting['choices'] ) ) {
			$control['choices'] = $setting['choices'];
		}
		if ( 'range' === $setting['type'] ) {
			$control['input_attrs'] = array( 'min' => 0, 'max' => 80, 'step' => 5 );
		}
		if ( 'date' === $setting['type'] ) {
			$control['input_attrs'] = array( 'min' => '2020-01-01' );
		}
		if ( 'number' === $setting['type'] ) {
			$control['input_attrs'] = array(
				'min'  => 'slider_limit' === $key ? 1 : ( 'slider_speed' === $key ? 2000 : 1 ),
				'max'  => 'slider_limit' === $key ? 12 : ( 'slider_speed' === $key ? 8000 : 1 ),
				'step' => 'slider_speed' === $key ? 500 : 1,
			);
		}
		$wp_customize->add_control( $id, $control );
	}

	$categories_id = 'yusraah_monthly_kits_slider_categories';
	$wp_customize->add_setting(
		$categories_id,
		array(
			'default'           => array(),
			'sanitize_callback' => 'yusraah_monthly_kits_sanitize_categories',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new Yusraah_Quick_Deal_Categories_Control(
			$wp_customize,
			$categories_id,
			array(
				'label'       => __( 'Bundle categories (up to 6)', 'yusraah' ),
				'description' => __( 'Select up to six product categories. Existing banners without a saved selection use the primary button category by default.', 'yusraah' ),
				'section'     => 'yusraah_monthly_kits',
			)
		)
	);

	$image_id = 'yusraah_monthly_kits_image';
	$wp_customize->add_setting(
		$image_id,
		array(
			'default'           => 0,
			'sanitize_callback' => 'absint',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			$image_id,
			array(
				'label'   => __( 'Banner image', 'yusraah' ),
				'section' => 'yusraah_monthly_kits',
			)
		)
	);

	for ( $index = 1; $index <= 3; ++$index ) {
		$text_id = 'yusraah_monthly_kits_benefit_' . $index;
		$icon_id = 'yusraah_monthly_kits_benefit_icon_' . $index;
		$default_benefit = yusraah_monthly_kits_default_benefits()[ $index - 1 ];
		$wp_customize->add_setting(
			$text_id,
			array(
				'default'           => $default_benefit['text'],
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'postMessage',
			)
		);
		$wp_customize->add_control(
			$text_id,
			array(
				'label'   => sprintf(
					/* translators: %d: benefit number */
					__( 'Benefit %d text', 'yusraah' ),
					$index
				),
				'section' => 'yusraah_monthly_kits',
				'type'    => 'text',
			)
		);
		$wp_customize->add_setting(
			$icon_id,
			array(
				'default'           => $default_benefit['icon'],
				'sanitize_callback' => 'yusraah_monthly_kits_sanitize_benefit_icon',
				'transport'         => 'postMessage',
			)
		);
		$wp_customize->add_control(
			$icon_id,
			array(
				'label'   => sprintf(
					/* translators: %d: benefit number */
					__( 'Benefit %d icon', 'yusraah' ),
					$index
				),
				'section' => 'yusraah_monthly_kits',
				'type'    => 'select',
				'choices' => yusraah_monthly_kits_benefit_icon_choices(),
			)
		);
	}

	if ( isset( $wp_customize->selective_refresh ) ) {
		$partial_settings = array(
			'yusraah_offers_headline',
			'yusraah_offers_subtext',
			'yusraah_offers_cta',
			'yusraah_monthly_kits_eyebrow',
			'yusraah_monthly_kits_badge',
			'yusraah_monthly_kits_image',
			'yusraah_monthly_kits_image_alt',
			'yusraah_monthly_kits_image_position',
			'yusraah_monthly_kits_overlay',
			'yusraah_monthly_kits_background',
			'yusraah_monthly_kits_accent',
			'yusraah_monthly_kits_link_type',
			'yusraah_monthly_kits_category',
			'yusraah_monthly_kits_page',
			'yusraah_monthly_kits_url',
			'yusraah_monthly_kits_secondary_label',
			'yusraah_monthly_kits_secondary_url',
			'yusraah_monthly_kits_content_type',
			'yusraah_monthly_kits_slider_limit',
			'yusraah_monthly_kits_slider_order',
			'yusraah_monthly_kits_slider_autoplay',
			'yusraah_monthly_kits_slider_speed',
			$categories_id,
			'yusraah_monthly_kits_countdown_show',
			'yusraah_monthly_kits_countdown_start',
			'yusraah_monthly_kits_countdown_end',
			'yusraah_monthly_kits_trust_show',
			'yusraah_monthly_kits_trust_text',
		);
		for ( $index = 1; $index <= 3; ++$index ) {
			$partial_settings[] = 'yusraah_monthly_kits_benefit_' . $index;
			$partial_settings[] = 'yusraah_monthly_kits_benefit_icon_' . $index;
		}
		$wp_customize->selective_refresh->add_partial(
			'yusraah_monthly_kits_banner',
			array(
				'selector'            => '.monthly-kits',
				'settings'            => $partial_settings,
				'render_callback'     => 'yusraah_monthly_kits_render',
				'container_inclusive' => true,
			)
		);
	}
}
add_action( 'customize_register', 'yusraah_monthly_kits_customize_register', 30 );

/**
 * Default benefit chip data.
 *
 * @return array
 */
function yusraah_monthly_kits_default_benefits() {
	return array(
		array( 'text' => __( 'Free delivery', 'yusraah' ), 'icon' => 'delivery' ),
		array( 'text' => __( 'Skip or cancel anytime', 'yusraah' ), 'icon' => 'refresh' ),
		array( 'text' => __( 'Curated essentials', 'yusraah' ), 'icon' => 'sparkles' ),
	);
}

/**
 * Available inline benefit icons.
 *
 * @return array
 */
function yusraah_monthly_kits_benefit_icon_choices() {
	return array(
		'delivery' => __( 'Delivery', 'yusraah' ),
		'refresh'  => __( 'Flexible plan', 'yusraah' ),
		'sparkles' => __( 'Curated', 'yusraah' ),
	);
}

/**
 * Sanitize a select value against an allow-list.
 *
 * @param mixed  $value   Raw value.
 * @param string $allowed Allowed values.
 * @param string $default Default.
 * @return string
 */
/**
 * Sanitize a select value against an allow-list.
 *
 * @param mixed  $value   Raw value.
 * @param array  $allowed Allowed values.
 * @param string $default Default value.
 * @return string
 */
function yusraah_monthly_kits_sanitize_choice( $value, $allowed, $default ) {
	return is_string( $value ) && in_array( $value, $allowed, true ) ? $value : $default;
}

/**
 * Sanitize the visual position.
 *
 * @param mixed $value Raw value.
 * @return string
 */
function yusraah_monthly_kits_sanitize_image_position( $value ) {
	return yusraah_monthly_kits_sanitize_choice( $value, array( 'left', 'right' ), 'right' );
}

/**
 * Sanitize the banner background style.
 *
 * @param mixed $value Raw value.
 * @return string
 */
function yusraah_monthly_kits_sanitize_background( $value ) {
	return yusraah_monthly_kits_sanitize_choice( $value, array( 'solid', 'gradient' ), 'gradient' );
}

/**
 * Sanitize the primary button destination type.
 *
 * @param mixed $value Raw value.
 * @return string
 */
function yusraah_monthly_kits_sanitize_link_type( $value ) {
	return yusraah_monthly_kits_sanitize_choice( $value, array( 'category', 'page', 'url' ), 'category' );
}

/**
 * Sanitize the banner visual mode.
 *
 * @param mixed $value Raw value.
 * @return string
 */
function yusraah_monthly_kits_sanitize_content_type( $value ) {
	return yusraah_monthly_kits_sanitize_choice( $value, array( 'image', 'slider' ), 'image' );
}

/**
 * Sanitize a benefit icon identifier.
 *
 * @param mixed $value Raw value.
 * @return string
 */
function yusraah_monthly_kits_sanitize_benefit_icon( $value ) {
	return yusraah_monthly_kits_sanitize_choice( $value, array_keys( yusraah_monthly_kits_benefit_icon_choices() ), 'sparkles' );
}

/**
 * Sanitize the image overlay opacity.
 *
 * @param mixed $value Raw percentage.
 * @return int
 */
function yusraah_monthly_kits_sanitize_overlay( $value ) {
	return max( 0, min( 80, absint( $value ) ) );
}

/**
 * Sanitize the optional accent override and require readable contrast.
 *
 * @param mixed $value Raw hex color.
 * @return string
 */
function yusraah_monthly_kits_sanitize_accent( $value ) {
	if ( '' === $value || null === $value ) {
		return '';
	}
	$color = sanitize_hex_color( $value );
	if ( ! $color ) {
		return '';
	}
	$glow_background = yusraah_monthly_kits_blend_color( $color, '#18201e', 0.08 );
	return yusraah_monthly_kits_contrast_ratio( $color, '#18201e' ) >= 4.5
		&& yusraah_monthly_kits_contrast_ratio( $color, $glow_background ) >= 4.5
		? $color
		: '';
}

/**
 * Blend two six-digit colors for contrast validation.
 *
 * @param string $foreground Foreground hex color.
 * @param string $background Background hex color.
 * @param float  $opacity    Foreground opacity.
 * @return string
 */
function yusraah_monthly_kits_blend_color( $foreground, $background, $opacity ) {
	$foreground = ltrim( $foreground, '#' );
	$background = ltrim( $background, '#' );
	$result     = '#';
	foreach ( array( 0, 2, 4 ) as $offset ) {
		$front  = hexdec( substr( $foreground, $offset, 2 ) );
		$back   = hexdec( substr( $background, $offset, 2 ) );
		$result .= str_pad( dechex( (int) round( ( $front * $opacity ) + ( $back * ( 1 - $opacity ) ) ) ), 2, '0', STR_PAD_LEFT );
	}
	return $result;
}

/**
 * Calculate WCAG contrast ratio for two hex colors.
 *
 * @param string $first  First color.
 * @param string $second Second color.
 * @return float
 */
function yusraah_monthly_kits_contrast_ratio( $first, $second ) {
	$luminance = static function ( $color ) {
		$color = ltrim( $color, '#' );
		$rgb   = strlen( $color ) === 3
			? array( hexdec( $color[0] . $color[0] ), hexdec( $color[1] . $color[1] ), hexdec( $color[2] . $color[2] ) )
			: array( hexdec( substr( $color, 0, 2 ) ), hexdec( substr( $color, 2, 2 ) ), hexdec( substr( $color, 4, 2 ) ) );
		$rgb = array_map(
			static function ( $channel ) {
				$value = $channel / 255;
				return $value <= 0.04045 ? $value / 12.92 : pow( ( $value + 0.055 ) / 1.055, 2.4 );
			},
			$rgb
		);
		return ( 0.2126 * $rgb[0] ) + ( 0.7152 * $rgb[1] ) + ( 0.0722 * $rgb[2] );
	};
	$luminances = array( $luminance( $first ), $luminance( $second ) );
	rsort( $luminances, SORT_NUMERIC );
	return ( $luminances[0] + 0.05 ) / ( $luminances[1] + 0.05 );
}

/**
 * Sanitize a product category ID.
 *
 * @param mixed $value Raw term ID.
 * @return int
 */
function yusraah_monthly_kits_sanitize_category( $value ) {
	$term_id = absint( $value );
	return $term_id && term_exists( $term_id, 'product_cat' ) ? $term_id : 0;
}

/**
 * Sanitize selected Monthly Kits product category IDs.
 *
 * @param mixed $value Raw category IDs.
 * @return int[]
 */
function yusraah_monthly_kits_sanitize_categories( $value ) {
	if ( is_string( $value ) ) {
		$decoded = json_decode( $value, true );
		$value   = is_array( $decoded ) ? $decoded : ( '' !== trim( $value ) ? explode( ',', $value ) : array() );
	}
	if ( ! is_array( $value ) ) {
		return array();
	}

	$ids = array();
	foreach ( $value as $raw_id ) {
		$term_id = is_scalar( $raw_id ) ? absint( $raw_id ) : 0;
		if ( $term_id && term_exists( $term_id, 'product_cat' ) ) {
			$ids[] = $term_id;
		}
	}
	return array_slice( array_values( array_unique( $ids ) ), 0, 6 );
}

/**
 * Sanitize a date in YYYY-MM-DD format.
 *
 * @param mixed $value Raw date.
 * @return string
 */
function yusraah_monthly_kits_sanitize_date( $value ) {
	if ( ! is_string( $value ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
		return '';
	}
	$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $value, wp_timezone() );
	return $date && $date->format( 'Y-m-d' ) === $value ? $value : '';
}

/**
 * Get the destination for the banner primary button.
 *
 * @return string
 */
function yusraah_monthly_kits_cta_url() {
	$type = yusraah_monthly_kits_sanitize_link_type( get_theme_mod( 'yusraah_monthly_kits_link_type', 'category' ) );
	if ( 'category' === $type ) {
		$term_id = absint( get_theme_mod( 'yusraah_monthly_kits_category', 0 ) );
		if ( $term_id ) {
			$term = get_term( $term_id, 'product_cat' );
			if ( $term && ! is_wp_error( $term ) ) {
				$url = get_term_link( $term );
				if ( ! is_wp_error( $url ) ) {
					return $url;
				}
			}
		}
		return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
	}
	if ( 'page' === $type ) {
		$page_id = absint( get_theme_mod( 'yusraah_monthly_kits_page', 0 ) );
		$page_url = $page_id ? get_permalink( $page_id ) : '';
		return $page_url ? $page_url : ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' ) );
	}
	$url = esc_url_raw( get_theme_mod( 'yusraah_monthly_kits_url', '' ) );
	return $url ? $url : ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' ) );
}

/**
 * Print an allowed inline icon.
 *
 * @param string $name Icon identifier.
 */
function yusraah_monthly_kits_icon( $name ) {
	$icons = array(
		'delivery' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
			. '<path d="M3 6h11v11H3zM14 10h4l3 3v4h-7zM7 20a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm11 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/></svg>',
		'refresh'  => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
			. '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.5 9A7 7 0 0 1 18 6l2 2M4 16l2 2a7 7 0 0 0 12.5-3"/></svg>',
		'sparkles' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
			. '<path d="m12 3 1.6 5.4L19 10l-5.4 1.6L12 17l-1.6-5.4L5 10l5.4-1.6L12 3zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16z"/></svg>',
		'arrow'    => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
			. '<path d="M5 12h14M13 6l6 6-6 6"/></svg>',
	);
	if ( isset( $icons[ $name ] ) ) {
		echo $icons[ $name ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Hard-coded, allow-listed SVG icon.
	}
}

/**
 * Render the homepage Monthly Kits banner.
 *
 * @return string
 */
function yusraah_monthly_kits_render() {
	if ( ! get_theme_mod( 'yusraah_show_offers_banner', true ) ) {
		return '';
	}
	$heading      = get_theme_mod( 'yusraah_offers_headline', __( 'Save with Monthly Essentials Kits', 'yusraah' ) );
	$subtext      = get_theme_mod( 'yusraah_offers_subtext', __( 'Bundle your favorites and save up to 20% on curated monthly essentials.', 'yusraah' ) );
	$button_label = get_theme_mod( 'yusraah_offers_cta', __( 'Shop bundles', 'yusraah' ) );
	if ( '' === trim( (string) $heading ) ) {
		$heading = __( 'Save with Monthly Essentials Kits', 'yusraah' );
	}
	$eyebrow      = get_theme_mod( 'yusraah_monthly_kits_eyebrow', __( 'Monthly kits', 'yusraah' ) );
	$badge        = get_theme_mod( 'yusraah_monthly_kits_badge', __( 'Save up to 20%', 'yusraah' ) );
	$image_id     = absint( get_theme_mod( 'yusraah_monthly_kits_image', 0 ) );
	$image_alt    = sanitize_text_field( get_theme_mod( 'yusraah_monthly_kits_image_alt', '' ) );
	$image_side   = yusraah_monthly_kits_sanitize_image_position( get_theme_mod( 'yusraah_monthly_kits_image_position', 'right' ) );
	$overlay      = yusraah_monthly_kits_sanitize_overlay( get_theme_mod( 'yusraah_monthly_kits_overlay', 20 ) ) / 100;
	$background   = yusraah_monthly_kits_sanitize_background( get_theme_mod( 'yusraah_monthly_kits_background', 'gradient' ) );
	$accent       = yusraah_monthly_kits_sanitize_accent( get_theme_mod( 'yusraah_monthly_kits_accent', '' ) );
	$accent       = $accent ? $accent : 'var(--accent)';
	$secondary    = get_theme_mod( 'yusraah_monthly_kits_secondary_label', '' );
	$secondary_url = esc_url_raw( get_theme_mod( 'yusraah_monthly_kits_secondary_url', '' ) );
	$benefits     = yusraah_monthly_kits_default_benefits();
	for ( $index = 1; $index <= 3; ++$index ) {
		$benefits[ $index - 1 ] = array(
			'text' => sanitize_text_field( get_theme_mod( 'yusraah_monthly_kits_benefit_' . $index, $benefits[ $index - 1 ]['text'] ) ),
			'icon' => yusraah_monthly_kits_sanitize_benefit_icon( get_theme_mod( 'yusraah_monthly_kits_benefit_icon_' . $index, $benefits[ $index - 1 ]['icon'] ) ),
		);
	}
	$benefits = array_filter(
		$benefits,
		static function ( $benefit ) {
			return '' !== $benefit['text'];
		}
	);
	$content_type = yusraah_monthly_kits_sanitize_content_type(
		get_theme_mod(
			'yusraah_monthly_kits_content_type',
			get_theme_mod( 'yusraah_monthly_kits_products_show', false ) ? 'slider' : 'image'
		)
	);
	$categories = yusraah_monthly_kits_sanitize_categories(
		get_theme_mod(
			'yusraah_monthly_kits_slider_categories',
			yusraah_monthly_kits_default_slider_categories()
		)
	);
	$slider_limit = yusraah_quick_deal_sanitize_limit( get_theme_mod( 'yusraah_monthly_kits_slider_limit', 8 ) );
	$slider_order = yusraah_quick_deal_sanitize_order( get_theme_mod( 'yusraah_monthly_kits_slider_order', 'latest' ) );
	$products = 'slider' === $content_type
		? yusraah_quick_deal_get_products(
			$categories,
			array(
				'limit'        => $slider_limit,
				'order'        => $slider_order,
				'on_sale_only' => false,
				'cache_context' => 'monthly_kits',
			)
		)
		: array();
	$slider_settings = array(
		'autoplay'    => (bool) get_theme_mod( 'yusraah_monthly_kits_slider_autoplay', true ),
		'speed'       => yusraah_sanitize_slider_speed( get_theme_mod( 'yusraah_monthly_kits_slider_speed', 4500 ) ),
		'desktop'     => 1,
		'tablet'      => 1,
		'mobile'      => 1,
		'label'       => __( 'Monthly Kits bundle products', 'yusraah' ),
		'native_cart' => true,
		'show_rating' => true,
		'bundle_badge' => true,
		'bundle_details' => true,
		'wrapper_class' => 'monthly-kits-slider',
	);
	$slider_html = $products
		? yusraah_render_slider( 'monthly-kits', $products, true, $slider_settings )
		: '';
	$trust    = get_theme_mod( 'yusraah_monthly_kits_trust_show', false )
		? sanitize_text_field( get_theme_mod( 'yusraah_monthly_kits_trust_text', __( 'Loved by 1,000+ customers', 'yusraah' ) ) )
		: '';
	$start    = yusraah_monthly_kits_sanitize_date( get_theme_mod( 'yusraah_monthly_kits_countdown_start', '' ) );
	$end      = yusraah_monthly_kits_sanitize_date( get_theme_mod( 'yusraah_monthly_kits_countdown_end', '' ) );
	$countdown = '';
	if ( get_theme_mod( 'yusraah_monthly_kits_countdown_show', false ) && $end ) {
		$timezone = wp_timezone();
		$start_dt = $start ? new DateTimeImmutable( $start . ' 00:00:00', $timezone ) : null;
		$end_dt   = new DateTimeImmutable( $end . ' 23:59:59', $timezone );
		$now      = current_datetime();
		if ( $now < $end_dt ) {
			$countdown = array(
				'start'  => $start_dt ? $start_dt->getTimestamp() : 0,
				'end'    => $end_dt->getTimestamp(),
				'date'   => $end_dt->format( DATE_W3C ),
				'starts' => $start_dt && $now < $start_dt,
			);
		}
	}

	$has_image = $image_id && wp_attachment_is_image( $image_id );
	$show_image = 'image' === $content_type || ( ! $slider_html && $has_image );
	$classes = array( 'offers-banner', 'monthly-kits', 'monthly-kits--' . $background, 'monthly-kits--image-' . $image_side );
	if ( $show_image && $has_image ) {
		$classes[] = 'monthly-kits--has-image';
	} elseif ( ! $show_image ) {
		if ( $slider_html ) {
			$classes[] = 'monthly-kits--has-slider';
		}
	} elseif ( ! $has_image ) {
		$classes[] = 'monthly-kits--has-fallback';
	}
	if ( ! $slider_html && ! $show_image ) {
		$classes[] = 'monthly-kits--no-visual';
	}
	$style   = '--monthly-kits-accent:' . esc_attr( $accent ) . ';--monthly-kits-overlay:' . esc_attr( $overlay );
	ob_start();
	?>
	<section class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" aria-labelledby="monthly-kits-title" style="<?php echo esc_attr( $style ); ?>" data-monthly-kits>
		<div class="monthly-kits__inner">
			<div class="monthly-kits__content">
				<?php if ( $eyebrow ) : ?><p class="monthly-kits__eyebrow"><?php echo esc_html( $eyebrow ); ?></p><?php endif; ?>
				<?php if ( $badge ) : ?><span class="monthly-kits__badge"><?php echo esc_html( $badge ); ?></span><?php endif; ?>
				<h2 id="monthly-kits-title"><?php echo esc_html( $heading ); ?></h2>
				<?php if ( $subtext ) : ?><p class="monthly-kits__description"><?php echo esc_html( $subtext ); ?></p><?php endif; ?>

				<?php if ( $benefits ) : ?>
					<ul class="monthly-kits__benefits">
						<?php foreach ( $benefits as $benefit ) : ?>
							<li><?php yusraah_monthly_kits_icon( $benefit['icon'] ); ?><span><?php echo esc_html( $benefit['text'] ); ?></span></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>

				<?php if ( $countdown ) : ?>
					<div
						class="monthly-kits__countdown"
						data-countdown-start="<?php echo esc_attr( $countdown['start'] ); ?>"
						data-countdown-end="<?php echo esc_attr( $countdown['end'] ); ?>"
						role="timer"
						aria-live="off"
					>
						<span class="monthly-kits__countdown-label" data-countdown-label>
							<?php echo $countdown['starts'] ? esc_html__( 'Offer starts in', 'yusraah' ) : esc_html__( 'Offer ends in', 'yusraah' ); ?>
						</span>
						<time datetime="<?php echo esc_attr( $countdown['date'] ); ?>" data-countdown-value>
							<?php echo esc_html( wp_date( get_option( 'date_format' ), $end_dt->getTimestamp(), $timezone ) ); ?>
						</time>
					</div>
				<?php endif; ?>

				<div class="monthly-kits__actions">
					<?php if ( $button_label ) : ?>
						<a
							class="button monthly-kits__cta"
							href="<?php echo esc_url( yusraah_monthly_kits_cta_url() ); ?>"
							data-analytics-event="monthly-kits-cta"
							data-analytics-label="<?php echo esc_attr( $button_label ); ?>"
						>
							<span><?php echo esc_html( $button_label ); ?></span><?php yusraah_monthly_kits_icon( 'arrow' ); ?>
						</a>
					<?php endif; ?>
					<?php if ( $secondary && $secondary_url ) : ?>
						<a class="monthly-kits__secondary" href="<?php echo esc_url( $secondary_url ); ?>">
							<?php echo esc_html( $secondary ); ?> <?php yusraah_monthly_kits_icon( 'arrow' ); ?>
						</a>
					<?php endif; ?>
				</div>
				<?php if ( $trust ) : ?><p class="monthly-kits__trust"><?php echo esc_html( $trust ); ?></p><?php endif; ?>
			</div>

			<?php if ( $slider_html || $show_image ) : ?>
				<div class="monthly-kits__visual">
					<?php if ( $slider_html ) : ?>
						<?php echo $slider_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Rendered by the shared slider renderer. ?>
					<?php elseif ( $show_image && $has_image ) : ?>
					<?php
					if ( '' === $image_alt ) {
						$image_alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
					}
					if ( '' === $image_alt ) {
						$image_alt = $heading;
					}
					echo wp_get_attachment_image(
						$image_id,
						'large',
						false,
						array(
							'class'    => 'monthly-kits__image',
							'alt'      => $image_alt,
							'loading'  => 'lazy',
							'decoding' => 'async',
							'sizes'    => '(max-width: 700px) 90vw, 45vw',
						)
					); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress escapes generated image markup.
					?>
					<?php else : ?>
						<div class="monthly-kits__fallback" aria-hidden="true">
							<span class="monthly-kits__fallback-orbit"></span>
							<span class="monthly-kits__fallback-mark"><?php echo esc_html( mb_substr( get_bloginfo( 'name' ), 0, 1 ) ); ?></span>
							<span class="monthly-kits__fallback-caption"><?php esc_html_e( 'A thoughtful edit, delivered monthly', 'yusraah' ); ?></span>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Enqueue Monthly Kits presentation assets on the homepage only.
 */
function yusraah_monthly_kits_assets() {
	if ( ! is_front_page() || ! get_theme_mod( 'yusraah_show_offers_banner', true ) ) {
		return;
	}
	$css_path = get_template_directory() . '/assets/css/monthly-kits.css';
	wp_enqueue_style(
		'yusraah-monthly-kits',
		get_template_directory_uri() . '/assets/css/monthly-kits.css',
		array( 'yusraah-style' ),
		file_exists( $css_path ) ? filemtime( $css_path ) : YUSRAAH_VERSION
	);
	$js_path = get_template_directory() . '/assets/js/monthly-kits.js';
	wp_enqueue_script(
		'yusraah-monthly-kits',
		get_template_directory_uri() . '/assets/js/monthly-kits.js',
		array(),
		file_exists( $js_path ) ? filemtime( $js_path ) : YUSRAAH_VERSION,
		true
	);
	if ( function_exists( 'wp_script_add_data' ) ) {
		wp_script_add_data( 'yusraah-monthly-kits', 'strategy', 'defer' );
	}
	wp_localize_script(
		'yusraah-monthly-kits',
		'yusraahMonthlyKits',
		array(
			'days'    => __( 'd', 'yusraah' ),
			'hours'   => __( 'h', 'yusraah' ),
			'minutes' => __( 'm', 'yusraah' ),
			'seconds' => __( 's', 'yusraah' ),
			'starts'  => __( 'Offer starts in', 'yusraah' ),
			'ends'    => __( 'Offer ends in', 'yusraah' ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'yusraah_monthly_kits_assets', 30 );

/**
 * Load the product category selector behavior in Customizer controls.
 */
function yusraah_monthly_kits_customizer_assets() {
	$path = get_template_directory() . '/assets/js/monthly-kits-customizer.js';
	wp_enqueue_script(
		'yusraah-monthly-kits-customizer',
		get_template_directory_uri() . '/assets/js/monthly-kits-customizer.js',
		array( 'customize-controls' ),
		file_exists( $path ) ? filemtime( $path ) : YUSRAAH_VERSION,
		true
	);
}
add_action( 'customize_controls_enqueue_scripts', 'yusraah_monthly_kits_customizer_assets' );
