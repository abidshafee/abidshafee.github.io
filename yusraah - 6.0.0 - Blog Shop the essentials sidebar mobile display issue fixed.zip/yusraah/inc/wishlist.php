<?php
/**
 * Wishlist: storage, AJAX toggle and the My Account endpoint.
 *
 * Storage strategy:
 *  - Logged-in customers: product IDs in user meta `yusraah_wishlist`.
 *  - Guests: the same JSON payload in an `yusraah_wishlist` cookie,
 *    merged into user meta on login and then cleared.
 *
 * All reads are sanitised to a unique list of positive integers, so deleted
 * or unpublished products are pruned rather than surfaced.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** User meta key holding the wishlist product IDs. */
define( 'YUSRAAH_WISHLIST_META', 'yusraah_wishlist' );

/** Cookie name used to persist a guest wishlist. */
define( 'YUSRAAH_WISHLIST_COOKIE', 'yusraah_wishlist' );

/** Nonce action shared by the wishlist AJAX endpoint. */
define( 'YUSRAAH_WISHLIST_NONCE', 'yusraah_wishlist' );

/*
 * -------------------------------------------------------------------------
 * Storage
 * -------------------------------------------------------------------------
 */

/**
 * Reduce any stored value to a unique list of positive integer IDs.
 *
 * @param mixed $ids Raw value: an array, a JSON string or anything else.
 * @return int[]
 */
function yusraah_wishlist_sanitize_ids( $ids ) {
	if ( is_string( $ids ) ) {
		$ids = json_decode( $ids, true );
	}

	if ( ! is_array( $ids ) ) {
		return array();
	}

	$ids = array_filter( array_map( 'absint', $ids ) );

	return array_values( array_unique( $ids ) );
}

/**
 * The current visitor's wishlist product IDs.
 *
 * @return int[]
 */
function yusraah_wishlist_ids() {
	if ( is_user_logged_in() ) {
		return yusraah_wishlist_sanitize_ids(
			get_user_meta( get_current_user_id(), YUSRAAH_WISHLIST_META, true )
		);
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only cookie, no action is performed.
	if ( empty( $_COOKIE[ YUSRAAH_WISHLIST_COOKIE ] ) ) {
		return array();
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only cookie, no action is performed.
	$raw = wp_unslash( $_COOKIE[ YUSRAAH_WISHLIST_COOKIE ] );

	return yusraah_wishlist_sanitize_ids( $raw );
}

/**
 * Persist a wishlist for the current visitor.
 *
 * @param mixed $ids IDs to store.
 * @return int[] The sanitised IDs that were stored.
 */
function yusraah_wishlist_save( $ids ) {
	$ids = yusraah_wishlist_sanitize_ids( $ids );

	if ( is_user_logged_in() ) {
		update_user_meta( get_current_user_id(), YUSRAAH_WISHLIST_META, $ids );

		return $ids;
	}

	yusraah_wishlist_set_cookie( $ids );

	return $ids;
}

/**
 * Write (or clear) the guest wishlist cookie.
 *
 * @param mixed $ids IDs to store; an empty list expires the cookie.
 * @return void
 */
function yusraah_wishlist_set_cookie( $ids ) {
	if ( headers_sent() ) {
		return;
	}

	$ids      = yusraah_wishlist_sanitize_ids( $ids );
	$value    = $ids ? wp_json_encode( $ids ) : '';
	$lifetime = $ids ? MONTH_IN_SECONDS : -YEAR_IN_SECONDS;

	setcookie(
		YUSRAAH_WISHLIST_COOKIE,
		$value,
		array(
			'expires'  => time() + $lifetime,
			'path'     => COOKIEPATH ? COOKIEPATH : '/',
			'domain'   => COOKIE_DOMAIN ? COOKIE_DOMAIN : '',
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		)
	);

	// Keep the current request consistent with what we just sent.
	if ( $value ) {
		$_COOKIE[ YUSRAAH_WISHLIST_COOKIE ] = $value;
	} else {
		unset( $_COOKIE[ YUSRAAH_WISHLIST_COOKIE ] );
	}
}

/**
 * How many products the current visitor has saved.
 *
 * @return int
 */
function yusraah_wishlist_count() {
	return count( yusraah_wishlist_ids() );
}

/**
 * Whether a product is in the current visitor's wishlist.
 *
 * @param int $product_id Product ID.
 * @return bool
 */
function yusraah_wishlist_has( $product_id ) {
	return in_array( absint( $product_id ), yusraah_wishlist_ids(), true );
}

/**
 * Wishlist product objects, newest saved last.
 *
 * Deleted, unpublished and non-purchasable products are dropped and the
 * stored list is pruned so it cannot grow stale.
 *
 * @return WC_Product[]
 */
function yusraah_wishlist_products() {
	$ids = yusraah_wishlist_ids();

	if ( ! $ids || ! function_exists( 'wc_get_product' ) ) {
		return array();
	}

	$products = array();
	$valid    = array();

	foreach ( $ids as $product_id ) {
		$product = wc_get_product( $product_id );

		if ( ! $product instanceof WC_Product || 'publish' !== $product->get_status() ) {
			continue;
		}

		$products[] = $product;
		$valid[]    = $product_id;
	}

	if ( count( $valid ) !== count( $ids ) ) {
		yusraah_wishlist_save( $valid );
	}

	return $products;
}

/**
 * URL of the wishlist screen.
 *
 * @return string
 */
function yusraah_wishlist_url() {
	if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
		return wc_get_account_endpoint_url( 'wishlist' );
	}

	return home_url( '/' );
}

/*
 * -------------------------------------------------------------------------
 * AJAX toggle
 * -------------------------------------------------------------------------
 */

/**
 * Add or remove a product from the current visitor's wishlist.
 *
 * Guests are supported (their list lives in a cookie) but still require a
 * valid nonce; logged-in customers must additionally pass the capability check.
 *
 * @return void
 */
function yusraah_wishlist_toggle() {
	if ( ! check_ajax_referer( YUSRAAH_WISHLIST_NONCE, 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Your session expired. Please reload the page.', 'yusraah' ) ), 403 );
	}

	if ( ! function_exists( 'wc_get_product' ) ) {
		wp_send_json_error( array( 'message' => __( 'The wishlist is unavailable right now.', 'yusraah' ) ), 503 );
	}

	if ( is_user_logged_in() && ! current_user_can( 'read' ) ) {
		wp_send_json_error( array( 'message' => __( 'You are not allowed to edit this wishlist.', 'yusraah' ) ), 403 );
	}

	$product_id = isset( $_POST['product_id'] ) ? absint( wp_unslash( $_POST['product_id'] ) ) : 0;
	$product    = $product_id ? wc_get_product( $product_id ) : false;

	if ( ! $product instanceof WC_Product || 'publish' !== $product->get_status() ) {
		wp_send_json_error( array( 'message' => __( 'That product is no longer available.', 'yusraah' ) ), 404 );
	}

	$ids   = yusraah_wishlist_ids();
	$index = array_search( $product_id, $ids, true );

	if ( false === $index ) {
		$ids[]  = $product_id;
		$added  = true;
		$notice = __( 'Added to your wishlist.', 'yusraah' );
	} else {
		unset( $ids[ $index ] );
		$added  = false;
		$notice = __( 'Removed from your wishlist.', 'yusraah' );
	}

	$ids = yusraah_wishlist_save( array_values( $ids ) );

	wp_send_json_success(
		array(
			'productId' => $product_id,
			'added'     => $added,
			'count'     => count( $ids ),
			'message'   => $notice,
		)
	);
}
add_action( 'wp_ajax_yusraah_wishlist_toggle', 'yusraah_wishlist_toggle' );
add_action( 'wp_ajax_nopriv_yusraah_wishlist_toggle', 'yusraah_wishlist_toggle' );

/*
 * -------------------------------------------------------------------------
 * Account endpoint
 * -------------------------------------------------------------------------
 */

/**
 * Register the `wishlist` endpoint on My Account.
 *
 * @return void
 */
function yusraah_wishlist_register_endpoint() {
	add_rewrite_endpoint( 'wishlist', EP_ROOT | EP_PAGES );
}
add_action( 'init', 'yusraah_wishlist_register_endpoint' );

/**
 * Flush rewrite rules once per theme version so the endpoint resolves.
 *
 * Runs after the endpoint is registered. If a caching layer blocks the flush,
 * re-saving Settings > Permalinks has the same effect.
 *
 * @return void
 */
function yusraah_wishlist_maybe_flush_rewrite_rules() {
	if ( get_option( 'yusraah_wishlist_rewrite_version' ) === YUSRAAH_VERSION ) {
		return;
	}

	flush_rewrite_rules( false );
	update_option( 'yusraah_wishlist_rewrite_version', YUSRAAH_VERSION );
}
add_action( 'init', 'yusraah_wishlist_maybe_flush_rewrite_rules', 20 );

/*
 * -------------------------------------------------------------------------
 * Guest to customer merge
 * -------------------------------------------------------------------------
 */

/**
 * Merge a guest cookie wishlist into the customer's account on login.
 *
 * @param string  $user_login Username.
 * @param WP_User $user       Logged-in user.
 * @return void
 */
function yusraah_wishlist_merge_on_login( $user_login, $user ) {
	if ( empty( $_COOKIE[ YUSRAAH_WISHLIST_COOKIE ] ) || ! $user instanceof WP_User ) {
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only cookie during login.
	$guest = yusraah_wishlist_sanitize_ids( wp_unslash( $_COOKIE[ YUSRAAH_WISHLIST_COOKIE ] ) );
	$saved = yusraah_wishlist_sanitize_ids( get_user_meta( $user->ID, YUSRAAH_WISHLIST_META, true ) );

	if ( $guest ) {
		$saved = array_values( array_unique( array_merge( $saved, $guest ) ) );
		update_user_meta( $user->ID, YUSRAAH_WISHLIST_META, $saved );
	}

	// The account list is now authoritative.
	yusraah_wishlist_set_cookie( array() );
}
add_action( 'wp_login', 'yusraah_wishlist_merge_on_login', 10, 2 );

/*
 * -------------------------------------------------------------------------
 * My Account integration
 * -------------------------------------------------------------------------
 */

/**
 * Insert the Wishlist item into the My Account menu, right after Orders.
 *
 * @param array $items Account menu items.
 * @return array
 */
function yusraah_wishlist_account_menu_item( $items ) {
	if ( ! is_array( $items ) || isset( $items['wishlist'] ) ) {
		return $items;
	}

	$wishlist = array( 'wishlist' => __( 'Wishlist', 'yusraah' ) );
	$position = array_search( 'orders', array_keys( $items ), true );

	if ( false === $position ) {
		return array_merge( $items, $wishlist );
	}

	return array_slice( $items, 0, $position + 1, true ) + $wishlist + array_slice( $items, $position + 1, null, true );
}
add_filter( 'woocommerce_account_menu_items', 'yusraah_wishlist_account_menu_item' );

/**
 * Render the Wishlist endpoint from the theme's template override.
 *
 * @return void
 */
function yusraah_wishlist_endpoint_content() {
	if ( function_exists( 'wc_get_template' ) ) {
		wc_get_template( 'myaccount/wishlist.php' );
	}
}
add_action( 'woocommerce_account_wishlist_endpoint', 'yusraah_wishlist_endpoint_content' );

/**
 * AJAX: the current visitor's wishlist IDs and count.
 *
 * Read-only and deliberately nonce-free so cached pages can reconcile the
 * heart buttons with the visitor's real list on load.
 *
 * @return void
 */
function yusraah_wishlist_list() {
	$ids = yusraah_wishlist_ids();

	wp_send_json_success(
		array(
			'ids'   => array_map( 'intval', $ids ),
			'count' => count( $ids ),
		)
	);
}
add_action( 'wp_ajax_yusraah_wishlist_list', 'yusraah_wishlist_list' );
add_action( 'wp_ajax_nopriv_yusraah_wishlist_list', 'yusraah_wishlist_list' );

/**
 * AJAX: add every purchasable, in-stock wishlist item to the basket.
 *
 * Variable and out-of-stock items are skipped and reported back, because
 * they need a choice of options (or are unavailable) on the product page.
 *
 * @return void
 */
function yusraah_wishlist_add_all_to_cart() {
	if ( ! check_ajax_referer( YUSRAAH_WISHLIST_NONCE, 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Your session expired. Please reload the page.', 'yusraah' ) ), 403 );
	}

	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		wp_send_json_error( array( 'message' => __( 'The basket is unavailable right now.', 'yusraah' ) ), 503 );
	}

	$added   = 0;
	$skipped = 0;

	foreach ( yusraah_wishlist_products() as $product ) {
		if ( ! $product->is_type( 'simple' ) || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			++$skipped;
			continue;
		}

		if ( WC()->cart->add_to_cart( $product->get_id(), 1 ) ) {
			++$added;
		} else {
			++$skipped;
		}
	}

	if ( ! $added ) {
		wp_send_json_error( array( 'message' => __( 'None of these items can be added to the basket right now.', 'yusraah' ) ), 409 );
	}

	WC()->cart->calculate_totals();

	/* translators: %s: number of items */
	$message = sprintf( _n( '%s item added to your basket.', '%s items added to your basket.', $added, 'yusraah' ), number_format_i18n( $added ) );

	if ( $skipped ) {
		/* translators: %s: number of items that need a choice of options */
		$message .= ' ' . sprintf( _n( '%s item needs a choice of options.', '%s items need a choice of options.', $skipped, 'yusraah' ), number_format_i18n( $skipped ) );
	}

	wp_send_json_success(
		array(
			'added'     => $added,
			'skipped'   => $skipped,
			'message'   => $message,
			'fragments' => apply_filters(
				'woocommerce_add_to_cart_fragments',
				array(
					'div.widget_shopping_cart_content' => function_exists( 'yusraah_mini_cart_html' ) ? yusraah_mini_cart_html() : '',
				)
			),
			'cart_hash' => WC()->cart->get_cart_hash(),
		)
	);
}
add_action( 'wp_ajax_yusraah_wishlist_add_all', 'yusraah_wishlist_add_all_to_cart' );
add_action( 'wp_ajax_nopriv_yusraah_wishlist_add_all', 'yusraah_wishlist_add_all_to_cart' );
