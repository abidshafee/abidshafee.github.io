<?php
/**
 * Blog: archive + single-post templates support, Customizer settings, AJAX
 * load-more, related posts, shop integration and SEO helpers.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

defined( 'ABSPATH' ) || exit;

/**
 * Blog-specific defaults, shared by the Customizer and the templates.
 *
 * @return array<string, mixed>
 */
function yusraah_blog_defaults() {
	return array(
		'blog_hero_title'           => __( 'Notes & Stories', 'yusraah' ),
		'blog_hero_subtitle'        => __( 'Ideas, care tips and everyday inspiration for a simpler home.', 'yusraah' ),
		'blog_featured_post'        => true,
		'blog_columns'              => '3',
		'blog_pagination'           => 'load-more',
		'blog_sidebar'              => true,
		'blog_widget_popular'       => true,
		'blog_widget_categories'    => true,
		'blog_widget_shop'          => true,
		'blog_shop_strip_category'  => 0,
		'blog_shop_strip_count'     => 6,
		'blog_shop_strip_order'     => 'latest',
		'blog_shop_strip_in_stock'  => true,
		'blog_shop_strip_title'     => __( 'Shop the essentials', 'yusraah' ),
		'blog_shop_strip_subtitle'  => __( 'Handpicked daily essentials, delivered fast.', 'yusraah' ),
		'blog_shop_strip_view_all'  => '',
		'blog_shop_strip_autoplay'  => true,
		'blog_shop_strip_speed'     => 4500,
		'blog_share_buttons'        => true,
		'blog_reading_progress'     => true,
		'blog_table_of_contents'    => true,
		'blog_related_count'        => 3,
		'blog_show_author'          => true,
		'blog_show_date'            => true,
		'blog_show_reading_time'    => true,
	);
}

/**
 * Whether the current request is a blog page (posts index, post archives,
 * search or a single post). WooCommerce archives are excluded.
 *
 * @return bool
 */
function yusraah_blog_is_blog_page() {
	if ( is_admin() ) {
		return false;
	}

	return is_home()
		|| is_category()
		|| is_tag()
		|| is_author()
		|| is_search()
		|| is_singular( 'post' );
}

/**
 * Reading time in whole minutes (200 wpm, minimum 1).
 *
 * @param string|null $content Post content override.
 * @return int
 */
function yusraah_blog_reading_time( $content = null ) {
	if ( null === $content ) {
		$content = get_post_field( 'post_content', get_the_ID() );
	}

	$words = str_word_count( wp_strip_all_tags( strip_shortcodes( (string) $content ) ) );

	return max( 1, (int) ceil( $words / 200 ) );
}

/**
 * First post category as array( label, url ), or an empty array.
 *
 * @param int $post_id Post ID.
 * @return array{0: string, 1: string}
 */
function yusraah_blog_first_category( $post_id ) {
	$terms = get_the_category( $post_id );

	if ( ! $terms ) {
		return array( '', '' );
	}

	$term = $terms[0];

	return array( $term->name, get_category_link( $term ) );
}

/**
 * Branded placeholder shown when a post has no featured image.
 *
 * @param int $post_id Post ID.
 * @return string Escaped-safe HTML (contains only theme markup).
 */
function yusraah_blog_placeholder( $post_id = 0 ) {
	$name = get_bloginfo( 'name' );

	return '<span class="blog-card__placeholder" aria-hidden="true"><span class="blog-card__placeholder__mark">' . esc_html( $name ) . '</span></span>';
}

/**
 * Author avatar: real avatar when one exists, otherwise an initials circle
 * in the accent color instead of the generic Gravatar silhouette.
 *
 * @param int $user_id User ID.
 * @param int $size    Pixel size.
 * @return string HTML.
 */
function yusraah_blog_avatar( $user_id, $size = 72 ) {
	if ( ! get_option( 'show_avatars' ) ) {
		return '';
	}

	// Respect locally uploaded avatars (common local-avatar plugins/meta).
	$local = get_user_meta( $user_id, 'wp_user_avatar', true )
		?: get_user_meta( $user_id, 'simple_local_avatar', true )
		?: get_user_meta( $user_id, 'user_avatar', true );

	if ( $local ) {
		// phpcs:ignore WordPress.Security.EscapeOutput -- core avatar markup.
		return get_avatar( $user_id, $size );
	}

	// No local avatar: check for an actual Gravatar (cached 12h to avoid a
	// remote request on every page render).
	$email_hash = md5( strtolower( trim( (string) get_the_author_meta( 'user_email', $user_id ) ) ) );
	$cache_key  = 'yusraah_grav_' . $email_hash;
	$has_grav   = get_transient( $cache_key );
	if ( false === $has_grav ) {
		$code       = wp_remote_retrieve_response_code(
			wp_remote_head( 'https://gravatar.com/avatar/' . $email_hash . '?d=404', array( 'timeout' => 3 ) )
		);
		$has_grav   = 200 === (int) $code ? 'yes' : 'no';
		set_transient( $cache_key, $has_grav, 12 * HOUR_IN_SECONDS );
	}

	// phpcs:ignore WordPress.Security.EscapeOutput -- core avatar markup.
	if ( 'yes' === $has_grav ) {
		return get_avatar( $user_id, $size );
	}

	$initials = '';
	$parts    = preg_split( '/\s+/', trim( (string) get_the_author_meta( 'display_name', $user_id ) ) );
	foreach ( array_slice( $parts, 0, 2 ) as $part ) {
		$initials .= mb_strtoupper( mb_substr( $part, 0, 1 ) );
	}

	return '<span class="blog-avatar-fallback" style="width:' . (int) $size . 'px;height:' . (int) $size . 'px;font-size:' . (int) ( $size / 2.6 ) . 'px" aria-hidden="true">'
		. esc_html( $initials ? $initials : '·' ) . '</span>';
}

/**
 * Render one blog post card. Uses the global $post.
 */
function yusraah_blog_card() {
	$category = yusraah_blog_first_category( get_the_ID() );
	$defaults = yusraah_blog_defaults();
	$show_meta = (bool) get_theme_mod( 'yusraah_blog_show_date', $defaults['blog_show_date'] )
		|| (bool) get_theme_mod( 'yusraah_blog_show_reading_time', $defaults['blog_show_reading_time'] );
	?>
	<article <?php post_class( 'blog-card' ); ?>>
		<a class="blog-card__media" href="<?php the_permalink(); ?>">
			<?php
			if ( has_post_thumbnail() ) {
				the_post_thumbnail(
					'yusraah-blog-card',
					array(
						'alt'      => trim( wp_strip_all_tags( get_the_title() ) ),
						'loading'  => 'lazy',
						'decoding' => 'async',
					)
				);
			} else {
				echo yusraah_blog_placeholder(); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside helper.
			}
			?>
		</a>
		<div class="blog-card__body">
			<?php if ( $category[0] ) : ?>
				<a class="blog-card__category" href="<?php echo esc_url( $category[1] ); ?>"><?php echo esc_html( $category[0] ); ?></a>
			<?php endif; ?>
			<h2 class="blog-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<p class="blog-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22, '…' ) ); ?></p>
			<?php if ( $show_meta ) : ?>
				<div class="blog-card__meta">
					<?php if ( get_theme_mod( 'yusraah_blog_show_date', $defaults['blog_show_date'] ) ) : ?>
						<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
					<?php endif; ?>
					<?php if ( get_theme_mod( 'yusraah_blog_show_reading_time', $defaults['blog_show_reading_time'] ) ) : ?>
						<span aria-hidden="true">·</span>
						<span><?php printf( esc_html__( '%d min read', 'yusraah' ), (int) yusraah_blog_reading_time() ); ?></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</article>
	<?php
}

/**
 * Sidebar widgets: popular posts, categories and the shop strip.
 */
function yusraah_blog_sidebar() {
	$defaults = yusraah_blog_defaults();
	$show     = (bool) get_theme_mod( 'yusraah_blog_sidebar', $defaults['blog_sidebar'] );
	$any      = get_theme_mod( 'yusraah_blog_widget_popular', $defaults['blog_widget_popular'] )
		|| get_theme_mod( 'yusraah_blog_widget_categories', $defaults['blog_widget_categories'] )
		|| get_theme_mod( 'yusraah_blog_widget_shop', $defaults['blog_widget_shop'] );

	if ( ! $show || ! $any || is_search() ) {
		return;
	}
	?>
	<aside class="blog-sidebar">
		<?php if ( get_theme_mod( 'yusraah_blog_widget_popular', $defaults['blog_widget_popular'] ) ) : ?>
			<section class="blog-widget" aria-labelledby="blog-widget-popular">
				<h2 class="blog-widget__title" id="blog-widget-popular"><?php esc_html_e( 'Popular posts', 'yusraah' ); ?></h2>
				<?php
				$popular = new WP_Query(
					array(
						'post_type'           => 'post',
						'posts_per_page'      => 4,
						'ignore_sticky_posts' => true,
						'orderby'             => array( 'comment_count' => 'DESC', 'date' => 'DESC' ),
						'no_found_rows'       => true,
					)
				);
				if ( $popular->have_posts() ) :
					?>
					<ul class="blog-widget__list">
						<?php
						while ( $popular->have_posts() ) :
							$popular->the_post();
							?>
							<li>
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								<span><?php echo esc_html( get_the_date() ); ?></span>
							</li>
						<?php endwhile; ?>
					</ul>
					<?php
					wp_reset_postdata();
				endif;
				?>
			</section>
		<?php endif; ?>

		<?php if ( get_theme_mod( 'yusraah_blog_widget_categories', $defaults['blog_widget_categories'] ) ) : ?>
			<section class="blog-widget" aria-labelledby="blog-widget-cats">
				<h2 class="blog-widget__title" id="blog-widget-cats"><?php esc_html_e( 'Categories', 'yusraah' ); ?></h2>
				<?php
				$categories = get_categories( array( 'number' => 8, 'orderby' => 'count', 'order' => 'DESC' ) );
				if ( $categories ) :
					?>
					<ul class="blog-widget__list">
						<?php foreach ( $categories as $cat ) : ?>
							<li>
								<a href="<?php echo esc_url( get_category_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
								<span><?php echo esc_html( $cat->count ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</section>
		<?php endif; ?>

		<?php
		if ( get_theme_mod( 'yusraah_blog_widget_shop', $defaults['blog_widget_shop'] ) && function_exists( 'wc_get_products' ) ) :
			$strip_products = yusraah_blog_shop_strip_products();
			if ( $strip_products ) :
				$heading   = get_theme_mod( 'yusraah_blog_shop_strip_title', $defaults['blog_shop_strip_title'] );
				$subtitle  = get_theme_mod( 'yusraah_blog_shop_strip_subtitle', $defaults['blog_shop_strip_subtitle'] );
				$view_all  = get_theme_mod( 'yusraah_blog_shop_strip_view_all', $defaults['blog_shop_strip_view_all'] );
				$autoplay  = (bool) get_theme_mod( 'yusraah_blog_shop_strip_autoplay', $defaults['blog_shop_strip_autoplay'] );
				$speed     = absint( get_theme_mod( 'yusraah_blog_shop_strip_speed', $defaults['blog_shop_strip_speed'] ) );
				$per_view  = 3;
				$track_id  = 'blog-shop-strip-track';
				?>
				<section class="blog-widget blog-widget--shop blog-shop-slider" aria-labelledby="blog-widget-shop"
					data-shop-slider data-autoplay="<?php echo $autoplay ? '1' : '0'; ?>" data-speed="<?php echo esc_attr( $speed ); ?>" data-per-view="<?php echo esc_attr( $per_view ); ?>">
					<div class="blog-shop-slider__head">
						<div>
							<h2 class="blog-widget__title" id="blog-widget-shop"><?php echo esc_html( $heading ); ?></h2>
							<?php if ( $subtitle ) : ?>
								<p class="blog-shop-slider__subtitle"><?php echo esc_html( $subtitle ); ?></p>
							<?php endif; ?>
						</div>
						<?php if ( $view_all ) : ?>
							<a class="blog-shop-slider__view-all" href="<?php echo esc_url( $view_all ); ?>"><?php esc_html_e( 'View all', 'yusraah' ); ?></a>
						<?php endif; ?>
					</div>
					<div class="blog-shop-slider__viewport" data-shop-viewport>
						<ul class="blog-shop-slider__track" id="<?php echo esc_attr( $track_id ); ?>" data-shop-track>
							<?php
							global $product;
							foreach ( $strip_products as $product ) :
								?>
								<li class="blog-shop-slider__slide">
									<article class="blog-shop-card">
										<a class="blog-shop-card__media" href="<?php echo esc_url( $product->get_permalink() ); ?>">
											<?php echo $product->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy', 'width' => 144, 'height' => 144 ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
										</a>
										<div class="blog-shop-card__body">
											<a class="blog-shop-card__name" href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo esc_html( $product->get_name() ); ?></a>
											<span class="blog-shop-card__price"><?php echo wp_kses_post( $product->get_price_html() ); ?></span>
											<?php woocommerce_template_loop_add_to_cart(); ?>
										</div>
									</article>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
					<?php if ( count( $strip_products ) > $per_view ) : ?>
						<div class="blog-shop-slider__controls">
							<button type="button" class="blog-shop-slider__arrow" data-shop-prev aria-label="<?php esc_attr_e( 'Previous products', 'yusraah' ); ?>">
								<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 14l6-6 6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
							</button>
							<div class="blog-shop-slider__dots" data-shop-dots role="tablist" aria-label="<?php esc_attr_e( 'Product slides', 'yusraah' ); ?>"></div>
							<button type="button" class="blog-shop-slider__arrow" data-shop-next aria-label="<?php esc_attr_e( 'Next products', 'yusraah' ); ?>">
								<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 10l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
							</button>
						</div>
					<?php endif; ?>
				</section>
			<?php endif; ?>
		<?php endif; ?>
	</aside>
	<?php
}

/**
 * Products for the sidebar "Shop the essentials" slider.
 * IDs are cached in a transient keyed by the Customizer settings and
 * flushed on product/stock/category changes.
 *
 * @return WC_Product[]
 */
function yusraah_blog_shop_strip_products() {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}

	$defaults = yusraah_blog_defaults();
	$count    = max( 1, min( 12, absint( get_theme_mod( 'yusraah_blog_shop_strip_count', $defaults['blog_shop_strip_count'] ) ) ) );
	$cat      = absint( get_theme_mod( 'yusraah_blog_shop_strip_category', $defaults['blog_shop_strip_category'] ) );
	$order    = get_theme_mod( 'yusraah_blog_shop_strip_order', $defaults['blog_shop_strip_order'] );
	$in_stock = (bool) get_theme_mod( 'yusraah_blog_shop_strip_in_stock', $defaults['blog_shop_strip_in_stock'] );

	$key    = 'yusraah_strip_v2_' . md5( wp_json_encode( array( $count, $cat, $order, $in_stock ) ) );
	$cached = get_transient( $key );
	if ( false !== $cached ) {
		$ids = (array) $cached;
	} else {
		$args = array(
			'status'  => 'publish',
			'limit'   => $count,
			'orderby' => 'date',
			'order'   => 'DESC',
		);
		if ( $cat ) {
			$args['category'] = array( $cat );
		}
		if ( 'bestselling' === $order ) {
			$args['orderby'] = 'popularity';
		} elseif ( 'onsale' === $order ) {
			$args['on_sale'] = true;
		}
		if ( $in_stock ) {
			$args['stock_status'] = 'instock';
		}
		$products = wc_get_products( $args );
		$ids      = array_map(
			static function ( $p ) {
				return $p->get_id();
			},
			$products
		);
		if ( $ids ) {
			set_transient( $key, $ids, DAY_IN_SECONDS );
		}
	}

	if ( ! $ids ) {
		return array();
	}

	return wc_get_products(
		array(
			'include' => $ids,
			'limit'   => $count,
			'orderby' => 'include',
		)
	);
}

/**
 * Flush the shop-strip product cache on relevant changes.
 */
function yusraah_blog_flush_strip_cache() {
	global $wpdb;
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_yusraah_strip_%' OR option_name LIKE '_transient_timeout_yusraah_strip_%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}
add_action( 'woocommerce_update_product', 'yusraah_blog_flush_strip_cache' );
add_action( 'woocommerce_product_set_stock', 'yusraah_blog_flush_strip_cache' );
add_action( 'edited_product_cat', 'yusraah_blog_flush_strip_cache' );
add_action( 'create_product_cat', 'yusraah_blog_flush_strip_cache' );
add_action( 'delete_product_cat', 'yusraah_blog_flush_strip_cache' );

/**
 * Product IDs chosen per post via the meta box.
 *
 * @param int $post_id Post ID.
 * @return int[]
 */
function yusraah_blog_product_ids( $post_id ) {
	$raw = get_post_meta( $post_id, '_yusraah_shop_products', true );
	if ( ! is_array( $raw ) ) {
		$raw = $raw ? explode( ',', (string) $raw ) : array();
	}
	$ids = array_map( 'absint', (array) $raw );
	return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * Products for the "Shop this post" block: curated meta first, otherwise
 * products sharing the post's categories or tags.
 *
 * @param int $post_id Post ID.
 * @return WC_Product[]
 */
function yusraah_blog_post_products( $post_id ) {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}

	$ids = yusraah_blog_product_ids( $post_id );
	if ( $ids ) {
		$products = wc_get_products(
			array(
				'include' => $ids,
				'limit'   => 4,
				'orderby' => 'include',
			)
		);
		return $products;
	}

	$tax_query = array( 'relation' => 'OR' );
	$cat_slugs = wp_list_pluck( get_the_category( $post_id ), 'slug' );
	$tag_slugs = wp_list_pluck( get_the_tags( $post_id ), 'slug' );

	if ( $cat_slugs ) {
		$tax_query[] = array(
			'taxonomy' => 'product_cat',
			'field'    => 'slug',
			'terms'    => $cat_slugs,
		);
	}
	if ( $tag_slugs ) {
		$tax_query[] = array(
			'taxonomy' => 'product_tag',
			'field'    => 'slug',
			'terms'    => $tag_slugs,
		);
	}
	if ( 1 === count( $tax_query ) ) {
		return array();
	}

	return wc_get_products(
		array(
			'status'   => 'publish',
			'limit'    => 4,
			'tax_query' => $tax_query, // phpcs:ignore WordPress.DB.SlowDBQuery -- small curated set.
		)
	);
}

/**
 * Related posts by shared category/tag, falling back to latest posts.
 *
 * @param int $post_id Post ID.
 * @return WP_Post[]
 */
function yusraah_blog_related_posts( $post_id ) {
	$defaults = yusraah_blog_defaults();
	$count    = max( 1, min( 6, absint( get_theme_mod( 'yusraah_blog_related_count', $defaults['blog_related_count'] ) ) ) );

	$cat_ids = wp_list_pluck( get_the_category( $post_id ), 'term_id' );
	$tag_ids = wp_list_pluck( get_the_tags( $post_id ), 'term_id' );

	$tax_query = array( 'relation' => 'OR' );
	if ( $cat_ids ) {
		$tax_query[] = array( 'taxonomy' => 'category', 'field' => 'term_id', 'terms' => $cat_ids );
	}
	if ( $tag_ids ) {
		$tax_query[] = array( 'taxonomy' => 'post_tag', 'field' => 'term_id', 'terms' => $tag_ids );
	}

	$query = new WP_Query(
		array(
			'post_type'           => 'post',
			'post__not_in'        => array( $post_id ),
			'posts_per_page'      => $count,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'tax_query'           => count( $tax_query ) > 1 ? $tax_query : null, // phpcs:ignore WordPress.DB.SlowDBQuery -- bounded related set.
		)
	);

	$posts = $query->posts;
	if ( count( $posts ) < $count ) {
		$more = get_posts(
			array(
				'post_type'           => 'post',
				'post__not_in'        => array_merge( array( $post_id ), wp_list_pluck( $posts, 'ID' ) ),
				'posts_per_page'      => $count - count( $posts ),
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);
		$posts = array_merge( $posts, $more );
	}

	return $posts;
}

/**
 * Extract h2/h3 headings from post content for the table of contents.
 *
 * @param string $content Post content.
 * @return array<int, array{level: int, text: string}>
 */
function yusraah_blog_toc_headings( $content ) {
	$headings = array();
	if ( ! preg_match_all( '/<h([23])[^>]*>(.*?)<\/h\1>/is', $content, $matches, PREG_SET_ORDER ) ) {
		return $headings;
	}

	foreach ( $matches as $match ) {
		$text = wp_strip_all_tags( $match[2] );
		if ( '' === trim( $text ) ) {
			continue;
		}
		$headings[] = array(
			'level' => (int) $match[1],
			'text'  => trim( $text ),
		);
	}

	return $headings;
}

/**
 * Whether an SEO plugin handles structured data, so the theme stays quiet.
 *
 * @return bool
 */
function yusraah_blog_has_seo_plugin() {
	return defined( 'WPSEO_VERSION' )
		|| defined( 'RANK_MATH_VERSION' )
		|| defined( 'AIOSEO_VERSION' )
		|| function_exists( 'rank_math' );
}

/**
 * Breadcrumb trail for blog pages.
 *
 * @return array<int, array{label: string, url: string}>
 */
function yusraah_blog_breadcrumbs() {
	$items = array(
		array(
			'label' => __( 'Home', 'yusraah' ),
			'url'   => home_url( '/' ),
		),
	);

	$blog_name = get_theme_mod( 'yusraah_blog_hero_title', yusraah_blog_defaults()['blog_hero_title'] );
	$blog_url  = (int) get_option( 'page_for_posts' ) ? get_permalink( (int) get_option( 'page_for_posts' ) ) : home_url( '/' );

	if ( is_category() || is_tag() || is_author() ) {
		$items[] = array( 'label' => $blog_name, 'url' => $blog_url );
		$items[] = array( 'label' => wp_strip_all_tags( get_the_archive_title() ), 'url' => '' );
	} elseif ( is_search() ) {
		$items[] = array( 'label' => __( 'Search', 'yusraah' ), 'url' => '' );
	} elseif ( is_singular( 'post' ) ) {
		$items[] = array( 'label' => $blog_name, 'url' => $blog_url );
		$category = yusraah_blog_first_category( get_the_ID() );
		if ( $category[0] ) {
			$items[] = array( 'label' => $category[0], 'url' => $category[1] );
		}
		$items[] = array( 'label' => get_the_title(), 'url' => '' );
	} else {
		$items[] = array( 'label' => $blog_name, 'url' => '' );
	}

	return $items;
}

/**
 * Print breadcrumb markup with schema.org microdata.
 */
function yusraah_blog_breadcrumbs_markup() {
	$items = yusraah_blog_breadcrumbs();
	$last  = count( $items ) - 1;
	?>
	<nav class="blog-breadcrumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'yusraah' ); ?>">
		<ol>
			<?php foreach ( $items as $i => $item ) : ?>
				<li>
					<?php if ( $item['url'] && $i < $last ) : ?>
						<a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['label'] ); ?></a>
					<?php else : ?>
						<span aria-current="page"><?php echo esc_html( $item['label'] ); ?></span>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ol>
	</nav>
	<?php
}

/**
 * Product multi-select meta box for "Shop this post".
 */
function yusraah_blog_product_meta_box() {
	add_meta_box(
		'yusraah_shop_products',
		__( 'Shop this post', 'yusraah' ),
		'yusraah_blog_product_meta_box_html',
		'post',
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'yusraah_blog_product_meta_box' );

/**
 * Meta box markup.
 *
 * @param WP_Post $post Current post.
 */
function yusraah_blog_product_meta_box_html( $post ) {
	wp_nonce_field( 'yusraah_blog_products', 'yusraah_blog_products_nonce' );
	$selected = yusraah_blog_product_ids( $post->ID );

	$products = wc_get_products(
		array(
			'status'  => 'publish',
			'limit'   => 100,
			'orderby' => 'title',
			'order'   => 'ASC',
		)
	);

	if ( ! $products ) {
		esc_html_e( 'No products found.', 'yusraah' );
		return;
	}
	?>
	<p class="description"><?php esc_html_e( 'Pick products to feature under this post. Leave empty to auto-match by category/tag.', 'yusraah' ); ?></p>
	<select name="yusraah_shop_products[]" id="yusraah_shop_products" multiple size="8" style="width:100%">
		<?php foreach ( $products as $product ) : ?>
			<option value="<?php echo esc_attr( $product->get_id() ); ?>" <?php selected( in_array( $product->get_id(), $selected, true ) ); ?>>
				<?php echo esc_html( $product->get_name() ); ?>
			</option>
		<?php endforeach; ?>
	</select>
	<?php
}

/**
 * Save the product selection.
 *
 * @param int $post_id Post ID.
 */
function yusraah_blog_save_products( $post_id ) {
	if ( ! isset( $_POST['yusraah_blog_products_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['yusraah_blog_products_nonce'] ) ), 'yusraah_blog_products' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$raw = isset( $_POST['yusraah_shop_products'] ) && is_array( $_POST['yusraah_shop_products'] )
		? array_map( 'absint', wp_unslash( $_POST['yusraah_shop_products'] ) )
		: array();

	update_post_meta( $post_id, '_yusraah_shop_products', array_values( array_unique( array_filter( $raw ) ) ) );
}
add_action( 'save_post_post', 'yusraah_blog_save_products' );

/**
 * AJAX "Load more" for the blog grid.
 */
function yusraah_blog_load_more() {
	check_ajax_referer( 'yusraah_blog_load_more', 'nonce' );

	$paged   = isset( $_POST['paged'] ) ? absint( $_POST['paged'] ) : 2;
	$blog_id = isset( $_POST['blog_id'] ) ? absint( $_POST['blog_id'] ) : 0;
	$search  = isset( $_POST['s'] ) ? sanitize_text_field( wp_unslash( $_POST['s'] ) ) : '';
	$cat     = isset( $_POST['cat'] ) ? absint( $_POST['cat'] ) : 0;

	$args = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'paged'               => $paged,
		'posts_per_page'      => (int) get_option( 'posts_per_page' ),
		'ignore_sticky_posts' => false,
	);

	if ( $search ) {
		$args['s'] = $search;
	}
	if ( $cat ) {
		$args['cat'] = $cat;
	}
	if ( $blog_id ) {
		$args['page_id'] = $blog_id;
	}

	$query = new WP_Query( $args );

	if ( ! $query->have_posts() ) {
		wp_send_json_error( array( 'message' => __( 'No more posts.', 'yusraah' ) ) );
	}

	ob_start();
	while ( $query->have_posts() ) {
		$query->the_post();
		yusraah_blog_card();
	}
	$html = ob_get_clean();
	wp_reset_postdata();

	wp_send_json_success(
		array(
			'html'     => $html,
			'has_more' => $paged < $query->max_num_pages,
			'max'      => (int) $query->max_num_pages,
		)
	);
}
add_action( 'wp_ajax_yusraah_blog_load_more', 'yusraah_blog_load_more' );
add_action( 'wp_ajax_nopriv_yusraah_blog_load_more', 'yusraah_blog_load_more' );

/**
 * Enqueue blog assets only on blog pages.
 */
function yusraah_blog_assets() {
	if ( ! yusraah_blog_is_blog_page() ) {
		return;
	}

	$blog_css_path  = get_template_directory() . '/assets/css/blog.css';
	$blog_js_path   = get_template_directory() . '/assets/js/blog.js';

	wp_enqueue_style(
		'yusraah-blog',
		get_template_directory_uri() . '/assets/css/blog.css',
		array( 'yusraah-style' ),
		file_exists( $blog_css_path ) ? filemtime( $blog_css_path ) : YUSRAAH_VERSION
	);

	wp_enqueue_script(
		'yusraah-blog',
		get_template_directory_uri() . '/assets/js/blog.js',
		array(),
		file_exists( $blog_js_path ) ? filemtime( $blog_js_path ) : YUSRAAH_VERSION,
		true
	);

	wp_localize_script(
		'yusraah-blog',
		'yusraahBlog',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'yusraah_blog_load_more' ),
			'strings' => array(
				'loading' => __( 'Loading…', 'yusraah' ),
				'error'   => __( 'Something went wrong. Please try again.', 'yusraah' ),
			),
		)
	);

	if ( is_singular( 'post' ) ) {
		wp_enqueue_script( 'wc-add-to-cart' );
	}
}
add_action( 'wp_enqueue_scripts', 'yusraah_blog_assets', 30 );

/**
 * Match editor and front-end typography for post content.
 */
function yusraah_blog_editor_styles() {
	add_editor_style( array( 'assets/css/theme.css', 'assets/css/blog.css' ) );
}
add_action( 'after_setup_theme', 'yusraah_blog_editor_styles' );

/**
 * Register the blog card image size.
 */
function yusraah_blog_image_sizes() {
	add_image_size( 'yusraah-blog-card', 800, 534, true );
}
add_action( 'after_setup_theme', 'yusraah_blog_image_sizes' );

/**
 * Blog Customizer section.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function yusraah_blog_customize_register( $wp_customize ) {
	$defaults = yusraah_blog_defaults();

	$wp_customize->add_section(
		'yusraah_blog',
		array(
			'title'       => __( 'Yusraah blog', 'yusraah' ),
			'description' => __( 'Archive hero, layout, widgets and single-post features.', 'yusraah' ),
			'priority'    => 45,
		)
	);

	$controls = array(
		// Text.
		'blog_hero_title'        => array( 'text', __( 'Hero title', 'yusraah' ), 'sanitize_text_field', 'text' ),
		'blog_hero_subtitle'     => array( 'textarea', __( 'Hero subtitle', 'yusraah' ), 'sanitize_textarea_field', 'textarea' ),
		// Selects.
		'blog_columns'           => array( 'select', __( 'Columns', 'yusraah' ), 'yusraah_blog_sanitize_columns', 'select', array( '2' => '2', '3' => '3' ) ),
		'blog_pagination'        => array( 'select', __( 'Pagination style', 'yusraah' ), 'yusraah_blog_sanitize_pagination', 'select', array( 'load-more' => __( 'Load more button', 'yusraah' ), 'numbers' => __( 'Numbered links', 'yusraah' ) ) ),
		'blog_shop_strip_category' => array( 'select', __( 'Shop strip category', 'yusraah' ), 'absint', 'select', yusraah_blog_product_category_choices() ),
		'blog_shop_strip_count'    => array( 'number', __( 'Shop strip product count', 'yusraah' ), function ( $v ) { return max( 1, min( 12, absint( $v ) ) ); }, 'number' ),
		'blog_shop_strip_order'    => array( 'select', __( 'Shop strip order', 'yusraah' ), 'yusraah_blog_sanitize_strip_order', 'select', array( 'latest' => __( 'Latest', 'yusraah' ), 'bestselling' => __( 'Best selling', 'yusraah' ), 'onsale' => __( 'On sale', 'yusraah' ) ) ),
		'blog_shop_strip_in_stock' => array( 'checkbox', __( 'In-stock products only', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_shop_strip_title'    => array( 'text', __( 'Shop strip heading', 'yusraah' ), 'sanitize_text_field', 'text' ),
		'blog_shop_strip_subtitle' => array( 'text', __( 'Shop strip subtitle', 'yusraah' ), 'sanitize_text_field', 'text' ),
		'blog_shop_strip_view_all' => array( 'text', __( 'Shop strip "View all" URL', 'yusraah' ), 'esc_url_raw', 'text' ),
		'blog_shop_strip_autoplay' => array( 'checkbox', __( 'Shop strip autoplay', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_shop_strip_speed'    => array( 'number', __( 'Shop strip slide speed (ms)', 'yusraah' ), function ( $v ) { return max( 2000, min( 10000, absint( $v ) ) ); }, 'number' ),
		// Toggles.
		'blog_featured_post'     => array( 'checkbox', __( 'Show featured post', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_sidebar'           => array( 'checkbox', __( 'Show sidebar widgets', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_widget_popular'    => array( 'checkbox', __( 'Popular posts widget', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_widget_categories' => array( 'checkbox', __( 'Categories widget', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_widget_shop'       => array( 'checkbox', __( 'Shop strip widget', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_share_buttons'     => array( 'checkbox', __( 'Share buttons', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_reading_progress'  => array( 'checkbox', __( 'Reading progress bar', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_table_of_contents' => array( 'checkbox', __( 'Table of contents', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_show_author'       => array( 'checkbox', __( 'Show author', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_show_date'         => array( 'checkbox', __( 'Show date', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
		'blog_show_reading_time' => array( 'checkbox', __( 'Show reading time', 'yusraah' ), 'rest_sanitize_boolean', 'checkbox' ),
	);

	foreach ( $controls as $key => $config ) {
		list( $type, $label, $sanitize, $control_type ) = $config;
		$default = $defaults[ $key ];

		$wp_customize->add_setting(
			'yusraah_' . $key,
			array(
				'default'           => $default,
				'sanitize_callback' => $sanitize,
				'transport'         => 'refresh',
			)
		);

		$control = array(
			'label'   => $label,
			'section' => 'yusraah_blog',
			'type'    => 'checkbox' === $control_type ? 'checkbox' : $control_type,
		);

		if ( 'select' === $control_type && isset( $config[4] ) ) {
			$control['choices'] = $config[4];
		}

		$wp_customize->add_control( 'yusraah_' . $key, $control );
	}

	// Related posts count (number).
	$wp_customize->add_setting(
		'yusraah_blog_related_count',
		array(
			'default'           => $defaults['blog_related_count'],
			'sanitize_callback' => function ( $v ) {
				return max( 1, min( 6, absint( $v ) ) );
			},
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'yusraah_blog_related_count',
		array(
			'label'       => __( 'Related posts count', 'yusraah' ),
			'section'     => 'yusraah_blog',
			'type'        => 'number',
			'input_attrs' => array( 'min' => 1, 'max' => 6, 'step' => 1 ),
		)
	);
}
add_action( 'customize_register', 'yusraah_blog_customize_register', 25 );

/**
 * Sanitize blog columns choice.
 *
 * @param string $value Raw value.
 * @return string
 */
function yusraah_blog_sanitize_columns( $value ) {
	return in_array( $value, array( '2', '3' ), true ) ? $value : '3';
}

/**
 * Sanitize pagination style choice.
 *
 * @param string $value Raw value.
 * @return string
 */
function yusraah_blog_sanitize_pagination( $value ) {
	return 'numbers' === $value ? 'numbers' : 'load-more';
}

/**
 * Sanitize shop strip order choice.
 *
 * @param string $value Raw value.
 * @return string
 */
function yusraah_blog_sanitize_strip_order( $value ) {
	return in_array( $value, array( 'latest', 'bestselling', 'onsale' ), true ) ? $value : 'latest';
}

/**
 * Product category choices for the shop strip select.
 *
 * @return array<int|string, string>
 */
function yusraah_blog_product_category_choices() {
	$choices = array( 0 => __( 'Latest products', 'yusraah' ) );
	if ( ! taxonomy_exists( 'product_cat' ) ) {
		return $choices;
	}
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$choices[ $term->term_id ] = $term->name;
		}
	}
	return $choices;
}

/**
 * Print BlogPosting + BreadcrumbList JSON-LD when no SEO plugin is active.
 */
function yusraah_blog_jsonld() {
	if ( yusraah_blog_has_seo_plugin() || ! yusraah_blog_is_blog_page() ) {
		return;
	}

	$graph = array( '@context' => 'https://schema.org', '@graph' => array() );

	// Breadcrumbs.
	$crumbs = yusraah_blog_breadcrumbs();
	$items   = array();
	foreach ( $crumbs as $i => $crumb ) {
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => $i + 1,
			'name'     => $crumb['label'],
			'item'     => $crumb['url'] ? $crumb['url'] : get_permalink(),
		);
	}
	$graph['@graph'][] = array(
		'@type'           => 'BreadcrumbList',
		'itemListElement' => $items,
	);

	// Single post → BlogPosting.
	if ( is_singular( 'post' ) ) {
		$post = get_post();
		$graph['@graph'][] = array(
			'@type'            => 'BlogPosting',
			'headline'         => get_the_title( $post ),
			'description'      => wp_strip_all_tags( get_the_excerpt( $post ) ),
			'datePublished'    => get_the_date( 'c', $post ),
			'dateModified'     => get_the_modified_date( 'c', $post ),
			'mainEntityOfPage' => get_permalink( $post ),
			'author'           => array(
				'@type' => 'Person',
				'name'  => get_the_author_meta( 'display_name', $post->post_author ),
			),
			'publisher'        => array(
				'@type' => 'Organization',
				'name'  => get_bloginfo( 'name' ),
			),
			'image'            => get_the_post_thumbnail_url( $post, 'large' ),
		);
	}

	echo '<script type="application/ld+json">' . wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'yusraah_blog_jsonld', 20 );
