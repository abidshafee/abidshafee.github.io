<?php
/**
 * Footer helpers: icons, menu columns, Customizer settings and the newsletter
 * subscription handler.
 *
 * All footer colours resolve from the `--footer-*` custom properties in
 * assets/css/theme.css. The first four are exposed in the Customizer and are
 * printed back as a `:root` override on the theme stylesheet, so the theme CSS
 * keeps a single source of truth for the defaults.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

defined( 'ABSPATH' ) || exit;

/**
 * Footer-specific defaults. Kept in one place so the Customizer, the template
 * and the newsletter handler cannot drift apart.
 *
 * @return array<string, string>
 */
function yusraah_footer_defaults() {
	return array(
		'footer_tagline'             => __( 'Everyday essentials, delivered to your door.', 'yusraah' ),
		'footer_copyright'           => __( 'All rights reserved.', 'yusraah' ),
		'footer_claim'               => __( 'Everyday essentials, delivered with care.', 'yusraah' ),
		'footer_contact_title'       => __( 'Contact us', 'yusraah' ),
		'footer_shop_title'          => __( 'Shop', 'yusraah' ),
		'footer_help_title'          => __( 'Help', 'yusraah' ),
		'footer_company_title'       => __( 'Company', 'yusraah' ),
		'footer_newsletter_title'    => __( 'Newsletter', 'yusraah' ),
		'footer_newsletter_intro'    => __( 'Subscribe for offers, new arrivals and restock alerts.', 'yusraah' ),
		'footer_newsletter_button'   => __( 'Subscribe', 'yusraah' ),
		'footer_newsletter_privacy'  => __( 'We use your email only to send occasional updates. Unsubscribe at any time.', 'yusraah' ),
		'footer_trust_delivery'      => __( 'Fast delivery', 'yusraah' ),
		'footer_trust_returns'       => __( 'Easy returns', 'yusraah' ),
		'footer_trust_cod'           => __( 'Cash on delivery', 'yusraah' ),
		'footer_trust_secure'        => __( 'Secure payment', 'yusraah' ),
	);
}

/**
 * Inline SVG set used by the footer only.
 *
 * The theme's shared `yusraah_icon()` helper is limited to the header
 * and account icons, so the footer carries its own monoline set to keep the
 * stroke width and grid consistent.
 *
 * @param string $name Icon key.
 * @return string SVG markup, or an empty string when the key is unknown.
 */
function yusraah_footer_icon( $name ) {
	$icons = array(
		// Trust row.
		'delivery'   => '<path d="M2.5 8h11v7h-11z"/><path d="M13.5 10.5h3.4l3.1 3v1.5h-6.5z"/><circle cx="7" cy="17" r="1.7"/><circle cx="16.5" cy="17" r="1.7"/>',
		'returns'    => '<path d="M4 10.5a8 8 0 0 1 13.6-3.3"/><path d="M20 4.5v5h-5"/><path d="M20 13.5a8 8 0 0 1-13.6 3.3"/><path d="M4 19.5v-5h5"/>',
		'cod'        => '<rect x="2.5" y="6.5" width="19" height="11" rx="1.5"/><circle cx="12" cy="12" r="2.6"/><path d="M6 10v4M18 10v4"/>',
		'secure'     => '<path d="M12 3.5 19.5 6v6c0 4-3.1 7.4-7.5 8.5C7.6 19.4 4.5 16 4.5 12V6z"/><path d="m9 12 2.2 2.2L15.5 10"/>',
		// Contact details.
		'mail'       => '<rect x="2.5" y="5" width="19" height="14" rx="1.5"/><path d="m3.5 7 8.5 6 8.5-6"/>',
		'phone'      => '<path d="M7.5 3.5h3l1.5 4-2 1.5a12 12 0 0 0 5 5l1.5-2 4 1.5v3a1.5 1.5 0 0 1-1.6 1.5A16.5 16.5 0 0 1 6 5.1 1.5 1.5 0 0 1 7.5 3.5Z"/>',
		'whatsapp'   => '<path d="M20.5 11.7a8.4 8.4 0 0 1-12.4 7.4L3.5 20.5l1.4-4.4a8.4 8.4 0 1 1 15.6-4.4Z"/><path d="M8.7 9.4c.2 2.1 2.1 4 4.2 4.2l.9-.9 1.5.7c-.2 1.1-1.3 1.7-2.4 1.5-2.4-.4-4.5-2.5-4.9-4.9-.2-1.1.4-2.2 1.5-2.4l.7 1.5z"/>',
		'pin'        => '<path d="M12 20.5s6-5.4 6-9.7a6 6 0 1 0-12 0c0 4.3 6 9.7 6 9.7Z"/><circle cx="12" cy="10.6" r="2.2"/>',
		'clock'      => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3.2 2"/>',
		// Social.
		'facebook'   => '<path d="M15.5 4.5h-2A4 4 0 0 0 9.5 8.5V11H7v3h2.5v6.5h3.2V14h2.6l.6-3h-3.2V8.6a1 1 0 0 1 1-1h2.3z"/>',
		'instagram'  => '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="3.6"/><path d="M17 6.9h.01"/>',
		'youtube'    => '<path d="M2.5 17a24.1 24.1 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.6 49.6 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.1 24.1 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.6 49.6 0 0 1-16.2 0A2 2 0 0 1 2.5 17Z"/><path d="m10 15 5-3-5-3z"/>',
		'x'          => '<path d="M5 4h3.2l4.1 5.5L17 4h2.4l-6.3 7.9L19.6 20h-3.2l-4.4-5.7L6.8 20H4.4l6.5-8.2z"/>',
		// Payment marks.
		'bkash'      => '<path d="M4 8.5A1.5 1.5 0 0 1 5.5 7h11A1.5 1.5 0 0 1 18 8.5v7A1.5 1.5 0 0 1 16.5 17h-11A1.5 1.5 0 0 1 4 15.5z"/><path d="M18 10.5h2.2a1.3 1.3 0 0 1 1.3 1.3v.4a1.3 1.3 0 0 1-1.3 1.3H18"/><path d="M13.5 12h.01"/>',
		'nagad'      => '<rect x="6.5" y="2.5" width="11" height="19" rx="2"/><path d="M10.5 5.5h3"/><path d="M12 18.5h.01"/>',
		'visa'       => '<rect x="2.5" y="5.5" width="19" height="13" rx="2"/><path d="M2.5 10h19"/><path d="M6 14h5"/>',
		'mastercard' => '<circle cx="9.5" cy="12" r="5.5"/><circle cx="14.5" cy="12" r="5.5"/>',
		// Back to top.
		'up'         => '<path d="M12 19V5"/><path d="m6 11 6-6 6 6"/>',
	);

	if ( ! isset( $icons[ $name ] ) ) {
		return '';
	}

	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $icons[ $name ] . '</svg>';
}

/**
 * Permalink of the first published page that matches one of the given slugs.
 *
 * Used for the footer menu fallbacks so an unfilled menu never renders links
 * that resolve to a 404.
 *
 * @param string[] $slugs Candidate page slugs.
 * @return string Permalink, or an empty string when no page matches.
 */
function yusraah_footer_page_url( array $slugs ) {
	foreach ( $slugs as $slug ) {
		$page = get_page_by_path( $slug );
		if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
			return get_permalink( $page );
		}
	}

	return '';
}

/**
 * Fallback links for a footer menu location, printed only when the matching
 * menu has not been assigned in Appearance > Menus.
 *
 * @param string $location Registered menu location.
 * @return array<int, array{label: string, url: string}>
 */
function yusraah_footer_fallback_items( $location ) {
	// Accept both the menu location ('footer-shop') and the short key ('shop').
	$location = preg_replace( '/^footer-/', '', $location );

	$shop_url     = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
	$account_url  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_login_url();
	if ( ! $account_url ) {
		$account_url = yusraah_footer_page_url( array( 'my-account', 'myaccount' ) );
	}
	if ( ! $account_url ) {
		$account_url = wp_login_url();
	}
	$contact_url  = yusraah_footer_page_url( array( 'contact', 'contact-us' ) );
	$footer_email = sanitize_email( get_theme_mod( 'yusraah_footer_email', '' ) );

	if ( ! $contact_url && $footer_email ) {
		$contact_url = 'mailto:' . $footer_email;
	}

	$shop_fallback = array();

	if ( taxonomy_exists( 'product_cat' ) ) {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => 0,
				'hide_empty' => true,
				'number'     => 5,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);

		if ( ! is_wp_error( $terms ) && $terms ) {
			$shop_fallback[] = array(
				'label' => __( 'Shop all', 'yusraah' ),
				'url'   => $shop_url,
			);

			foreach ( $terms as $term ) {
				$term_link = get_term_link( $term );
				if ( ! is_wp_error( $term_link ) ) {
					$shop_fallback[] = array(
						'label' => $term->name,
						'url'   => $term_link,
					);
				}
			}
		}
	}

	$items = array(
		'shop' => $shop_fallback ? $shop_fallback : array(
			array( 'label' => __( 'Shop all', 'yusraah' ), 'url' => $shop_url ),
			array( 'label' => __( 'New arrivals', 'yusraah' ), 'url' => $shop_url ? add_query_arg( 'orderby', 'date', $shop_url ) : '' ),
			array( 'label' => __( 'Offers', 'yusraah' ), 'url' => $shop_url ? add_query_arg( 'on_sale', '1', $shop_url ) : '' ),
		),
		'help' => array(
			array( 'label' => __( 'Contact', 'yusraah' ), 'url' => $contact_url ),
			array( 'label' => __( 'FAQ', 'yusraah' ), 'url' => yusraah_footer_page_url( array( 'faq', 'frequently-asked-questions' ) ) ),
			array( 'label' => __( 'Track order', 'yusraah' ), 'url' => $account_url ),
			array( 'label' => __( 'Shipping', 'yusraah' ), 'url' => yusraah_footer_page_url( array( 'shipping', 'shipping-policy', 'delivery' ) ) ),
			array( 'label' => __( 'Returns', 'yusraah' ), 'url' => yusraah_footer_page_url( array( 'returns', 'refund-returns', 'refund_returns' ) ) ),
		),
		'company' => array(
			array( 'label' => __( 'About', 'yusraah' ), 'url' => yusraah_footer_page_url( array( 'about', 'about-us' ) ) ),
			array( 'label' => __( 'Journal', 'yusraah' ), 'url' => get_option( 'page_for_posts' ) ? get_permalink( (int) get_option( 'page_for_posts' ) ) : '' ),
			array( 'label' => __( 'Privacy', 'yusraah' ), 'url' => get_privacy_policy_url() ),
			array( 'label' => __( 'Terms', 'yusraah' ), 'url' => yusraah_footer_page_url( array( 'terms', 'terms-and-conditions', 'terms-of-service' ) ) ),
		),
	);

	if ( ! isset( $items[ $location ] ) ) {
		return array();
	}

	return array_values(
		array_filter(
			$items[ $location ],
			static function ( $item ) {
				return '' !== $item['url'];
			}
		)
	);
}

/**
 * Render one footer link column: a landmark nav, an accessible disclosure
 * button for mobile, and either the assigned menu or the fallback list.
 *
 * @param string $location Registered menu location.
 */
/**
 * Resolve a footer menu column's title and content.
 *
 * Returns an empty array when the column should not render: the Customizer
 * toggle is off, the title is empty, the assigned menu has no items and no
 * fallback links exist.
 *
 * @param string $location Registered menu location.
 * @return array{title: string, has_menu: bool, fallback: array<int, array{label: string, url: string}>, panel_id: string}|array{}
 */
function yusraah_footer_menu_data( $location ) {
	static $cache = array();

	if ( isset( $cache[ $location ] ) ) {
		return $cache[ $location ];
	}

	$columns = array(
		'footer-shop'    => array( 'footer_shop_title', 'show_shop' ),
		'footer-help'    => array( 'footer_help_title', 'show_help' ),
		'footer-company' => array( 'footer_company_title', 'show_company' ),
	);

	if ( ! isset( $columns[ $location ] ) ) {
		return array();
	}

	if ( ! get_theme_mod( 'yusraah_footer_' . $columns[ $location ][1], true ) ) {
		return array();
	}

	$defaults = yusraah_footer_defaults();
	$title    = get_theme_mod( 'yusraah_' . $columns[ $location ][0], $defaults[ $columns[ $location ][0] ] );

	if ( ! $title ) {
		return array();
	}

	// Resolve the column content first so an empty menu with no usable
	// fallback never prints a bare heading.
	$locations  = get_nav_menu_locations();
	$menu       = isset( $locations[ $location ] ) ? wp_get_nav_menu_object( $locations[ $location ] ) : null;
	$menu_items = $menu ? wp_get_nav_menu_items( $menu ) : array();
	$has_menu   = is_array( $menu_items ) && ! empty( $menu_items );
	$fallback   = $has_menu ? array() : yusraah_footer_fallback_items( $location );

	if ( ! $has_menu && ! $fallback ) {
		$cache[ $location ] = array();
		return $cache[ $location ];
	}

	$cache[ $location ] = array(
		'title'     => $title,
		'has_menu'  => $has_menu,
		'fallback'  => $fallback,
		'panel_id'  => 'footer-panel-' . $location,
	);

	return $cache[ $location ];
}

/**
 * Whether a footer menu column will render.
 *
 * @param string $location Registered menu location.
 * @return bool
 */
function yusraah_footer_menu_is_visible( $location ) {
	return ! empty( yusraah_footer_menu_data( $location ) );
}

/**
 * Render one footer link column: a landmark nav, an accessible disclosure
 * button for mobile, and either the assigned menu or the fallback list.
 *
 * @param string $location Registered menu location.
 */
function yusraah_footer_menu( $location ) {
	$data = yusraah_footer_menu_data( $location );

	if ( ! $data ) {
		return;
	}
	?>
	<nav class="footer-column" aria-label="<?php echo esc_attr( $data['title'] ); ?>">
		<h2 class="footer-column__title">
			<button class="footer-column__toggle" type="button" aria-expanded="true" aria-controls="<?php echo esc_attr( $data['panel_id'] ); ?>">
				<span><?php echo esc_html( $data['title'] ); ?></span>
				<span class="footer-column__chevron" aria-hidden="true"></span>
			</button>
		</h2>
		<div class="footer-column__panel" id="<?php echo esc_attr( $data['panel_id'] ); ?>">
			<?php if ( $data['has_menu'] ) : ?>
				<?php
				wp_nav_menu( array(
					'theme_location' => $location,
					'container'      => false,
					'menu_class'     => 'footer-menu',
					'depth'          => 1,
					'fallback_cb'    => false,
				) );
				?>
			<?php elseif ( $data['fallback'] ) : ?>
				<ul class="footer-menu footer-menu--fallback">
					<?php foreach ( $data['fallback'] as $item ) : ?>
						<li><a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['label'] ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
	</nav>
	<?php
}

/**
 * Resolve the Contact us column's title and field values.
 *
 * Returns an empty array when the column should not render.
 *
 * @return array{title: string, email: string, phone: string, whatsapp: string, address: string, hours: string}|array{}
 */
function yusraah_footer_contact_data() {
	if ( ! get_theme_mod( 'yusraah_footer_show_contact', true ) ) {
		return array();
	}

	$defaults = yusraah_footer_defaults();
	$title    = get_theme_mod( 'yusraah_footer_contact_title', $defaults['footer_contact_title'] );

	if ( ! $title ) {
		return array();
	}

	$data = array(
		'title'    => $title,
		'email'    => sanitize_email( get_theme_mod( 'yusraah_footer_email', '' ) ),
		'phone'    => get_theme_mod( 'yusraah_footer_phone', '' ),
		'whatsapp' => get_theme_mod( 'yusraah_footer_whatsapp', '' ),
		'address'  => get_theme_mod( 'yusraah_footer_address', '' ),
		'hours'    => get_theme_mod( 'yusraah_footer_hours', '' ),
	);

	if ( ! $data['email'] && ! $data['phone'] && ! $data['whatsapp'] && ! $data['address'] && ! $data['hours'] ) {
		return array();
	}

	return $data;
}

/**
 * Whether the Contact us column will render.
 *
 * @return bool
 */
function yusraah_footer_contact_is_visible() {
	return ! empty( yusraah_footer_contact_data() );
}

/**
 * Render the Contact us footer column from the Customizer contact fields.
 *
 * Each row is hidden when its field is empty; the whole column is skipped
 * when every field is empty or the column toggle is off.
 */
function yusraah_footer_contact() {
	$data = yusraah_footer_contact_data();

	if ( ! $data ) {
		return;
	}
	?>
	<section class="footer-column footer-column--contact" aria-labelledby="footer-contact-title">
		<h2 class="footer-column__title" id="footer-contact-title"><?php echo esc_html( $data['title'] ); ?></h2>
		<div class="footer-column__panel">
			<ul class="footer-contact__list">
				<?php if ( $data['email'] ) : ?>
					<li>
						<?php echo yusraah_footer_icon( 'mail' ); ?>
						<span><a href="<?php echo esc_url( 'mailto:' . $data['email'] ); ?>"><?php echo esc_html( $data['email'] ); ?></a></span>
					</li>
				<?php endif; ?>

				<?php if ( $data['phone'] ) : ?>
					<li>
						<?php echo yusraah_footer_icon( 'phone' ); ?>
						<span><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $data['phone'] ) ); ?>"><?php echo esc_html( $data['phone'] ); ?></a></span>
					</li>
				<?php endif; ?>

				<?php if ( $data['whatsapp'] ) : ?>
					<li>
						<?php echo yusraah_footer_icon( 'whatsapp' ); ?>
						<span><a href="<?php echo esc_url( 'https://wa.me/' . preg_replace( '/[^0-9]/', '', $data['whatsapp'] ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $data['whatsapp'] ); ?></a></span>
					</li>
				<?php endif; ?>

				<?php if ( $data['address'] ) : ?>
					<li>
						<?php echo yusraah_footer_icon( 'pin' ); ?>
						<span><?php echo esc_html( $data['address'] ); ?></span>
					</li>
				<?php endif; ?>

				<?php if ( $data['hours'] ) : ?>
					<li>
						<?php echo yusraah_footer_icon( 'clock' ); ?>
						<span><?php echo esc_html( $data['hours'] ); ?></span>
					</li>
				<?php endif; ?>
			</ul>
		</div>
	</section>
	<?php
}

/**
 * Forward a validated subscriber to the configured email service.
 *
 * Subscriber data is owned by the configured mailing provider; the theme
 * deliberately avoids keeping a second, unsynchronized subscriber database.
 *
 * @param string $raw_email Raw email field value.
 * @param string $honeypot  Hidden spam-trap value.
 * @param bool   $consent   Whether the consent checkbox was checked.
 * @param bool   $home      Whether the request came from the homepage section.
 * @return array|WP_Error Result message or a validation/provider error.
 */
function yusraah_newsletter_forward( $raw_email, $honeypot, $consent, $home ) {
	$success_message = $home
		? get_theme_mod( 'yusraah_home_newsletter_success', __( 'Thanks for subscribing! Please check your inbox to confirm.', 'yusraah' ) )
		: __( 'Thank you — please check your inbox to confirm your subscription.', 'yusraah' );

	if ( ! is_string( $raw_email ) ) {
		$raw_email = '';
	}
	if ( ! is_string( $honeypot ) ) {
		$honeypot = '';
	}

	if ( '' !== $honeypot ) {
		return array( 'message' => $success_message );
	}

	$email = sanitize_email( $raw_email );
	if ( ! $email || ! is_email( $email ) ) {
		return new WP_Error( 'invalid_email', __( 'Please enter a valid email address.', 'yusraah' ) );
	}

	if ( $home && get_theme_mod( 'yusraah_home_newsletter_consent', false ) && ! $consent ) {
		return new WP_Error( 'consent_required', __( 'Please confirm your consent to receive email updates.', 'yusraah' ) );
	}

	$endpoint = esc_url_raw( get_theme_mod( 'yusraah_newsletter_action', '' ) );
	if ( ! $endpoint ) {
		return new WP_Error( 'not_configured', __( 'The newsletter is not configured yet. Please try again later.', 'yusraah' ) );
	}

	if ( $home ) {
		$ip         = isset( $_SERVER['REMOTE_ADDR'] ) && is_string( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$rate_key   = 'yusraah_newsletter_' . substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 32 );
		$rate_count = (int) get_transient( $rate_key );
		if ( $rate_count >= 5 ) {
			return new WP_Error( 'rate_limited', __( 'Too many attempts. Please try again in a few minutes.', 'yusraah' ) );
		}
		set_transient( $rate_key, $rate_count + 1, 10 * MINUTE_IN_SECONDS );
	}

	/**
	 * Fires before the subscriber is forwarded to the mailing service.
	 *
	 * Mailchimp, ConvertKit and similar plugins can hook here instead of the
	 * theme posting to the endpoint itself.
	 *
	 * @param string $email Sanitised subscriber email address.
	 */
	do_action( 'yusraah_newsletter_subscribe', $email );

	$response = wp_remote_post(
		$endpoint,
		array(
			'timeout' => 15,
			'headers' => array( 'Accept' => 'application/json, text/html' ),
			'body'    => array(
				'EMAIL' => $email,
				'email' => $email,
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'provider_error', __( 'Something went wrong. Please try again in a moment.', 'yusraah' ) );
	}

	$status = (int) wp_remote_retrieve_response_code( $response );
	$body   = wp_remote_retrieve_body( $response );
	if ( $home && preg_match( '/already subscribed|already a member|member exists|already on the list|already in the list/i', $body ) ) {
		return new WP_Error( 'already_subscribed', __( 'This email is already subscribed.', 'yusraah' ) );
	}
	if ( $status < 200 || $status >= 400 ) {
		return new WP_Error( 'provider_error', __( 'Something went wrong. Please try again in a moment.', 'yusraah' ) );
	}

	return array( 'message' => $success_message );
}

/**
 * Handle the AJAX newsletter request.
 */
function yusraah_newsletter_subscribe() {
	if ( ! check_ajax_referer( 'yusraah_newsletter', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Your session expired. Please reload the page and try again.', 'yusraah' ) ) );
	}

	$raw_email = isset( $_POST['EMAIL'] ) && is_string( $_POST['EMAIL'] ) ? wp_unslash( $_POST['EMAIL'] ) : ( isset( $_POST['email'] ) && is_string( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '' );
	$honeypot  = isset( $_POST['yusraah_website'] ) && is_string( $_POST['yusraah_website'] ) ? sanitize_text_field( wp_unslash( $_POST['yusraah_website'] ) ) : '';
	$consent   = isset( $_POST['consent'] ) && '1' === wp_unslash( $_POST['consent'] );
	$home      = isset( $_POST['context'] ) && is_string( $_POST['context'] ) && 'home' === sanitize_key( wp_unslash( $_POST['context'] ) );
	$result    = yusraah_newsletter_forward( $raw_email, $honeypot, $consent, $home );

	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => $result->get_error_message(), 'code' => $result->get_error_code() ) );
	}

	wp_send_json_success( $result );
}
add_action( 'wp_ajax_yusraah_newsletter_subscribe', 'yusraah_newsletter_subscribe' );
add_action( 'wp_ajax_nopriv_yusraah_newsletter_subscribe', 'yusraah_newsletter_subscribe' );

/**
 * Provide a regular form POST fallback for browsers without JavaScript.
 */
function yusraah_newsletter_subscribe_fallback() {
	$nonce = isset( $_POST['newsletter_nonce'] ) && is_string( $_POST['newsletter_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['newsletter_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'yusraah_newsletter' ) ) {
		wp_safe_redirect( add_query_arg( 'newsletter', 'error', home_url( '/' ) ) );
		exit;
	}

	$raw_email = isset( $_POST['EMAIL'] ) && is_string( $_POST['EMAIL'] ) ? wp_unslash( $_POST['EMAIL'] ) : '';
	$honeypot  = isset( $_POST['yusraah_website'] ) && is_string( $_POST['yusraah_website'] ) ? sanitize_text_field( wp_unslash( $_POST['yusraah_website'] ) ) : '';
	$consent   = isset( $_POST['consent'] ) && '1' === wp_unslash( $_POST['consent'] );
	$result    = yusraah_newsletter_forward( $raw_email, $honeypot, $consent, true );
	$status    = 'success';

	if ( is_wp_error( $result ) ) {
		$status = 'already_subscribed' === $result->get_error_code() ? 'duplicate' : ( 'invalid_email' === $result->get_error_code() ? 'invalid' : 'error' );
	}

	wp_safe_redirect( add_query_arg( 'newsletter', $status, home_url( '/' ) ) );
	exit;
}
add_action( 'admin_post_yusraah_newsletter_fallback', 'yusraah_newsletter_subscribe_fallback' );
add_action( 'admin_post_nopriv_yusraah_newsletter_fallback', 'yusraah_newsletter_subscribe_fallback' );

/**
 * Print the Customizer colour overrides and hand the newsletter strings to
 * theme.js. Runs after yusraah_assets() (priority 10) so both the style
 * and the script handles already exist.
 */
function yusraah_footer_assets() {
	$palette = array(
		'yusraah_footer_bg'     => array( '--footer-bg', '#18201e' ),
		'yusraah_footer_text'   => array( '--footer-text', '#f5f3ed' ),
		'yusraah_footer_muted'  => array( '--footer-muted', '#b5b8b0' ),
		'yusraah_footer_accent' => array( '--footer-accent', '#d47550' ),
	);

	$css = '';

	foreach ( $palette as $setting => list( $property, $fallback ) ) {
		$value = get_theme_mod( $setting, $fallback );

		if ( ! is_string( $value ) || '' === $value || strtolower( $value ) === $fallback ) {
			continue;
		}

		if ( preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{6})$/i', $value ) ) {
			$css .= $property . ':' . $value . ';';
		}
	}

	if ( $css ) {
		wp_add_inline_style( 'yusraah-style', ':root{' . $css . '}' );
	}

	wp_localize_script(
		'yusraah-script',
		'yusraahNewsletter',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'yusraah_newsletter' ),
			'strings' => array(
				'sending' => __( 'Subscribing…', 'yusraah' ),
				'invalid' => __( 'Please enter a valid email address.', 'yusraah' ),
				'failed'  => __( 'Something went wrong. Please try again in a moment.', 'yusraah' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'yusraah_footer_assets', 30 );

/**
 * Register the footer Customizer settings.
 *
 * Content settings extend the existing "Yusraah footer" section; the
 * newsletter/social and colour settings get their own sections so the panel
 * stays scannable.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function yusraah_footer_customize_register( $wp_customize ) {
	if ( ! $wp_customize->get_section( 'yusraah_footer' ) ) {
		$wp_customize->add_section( 'yusraah_footer', array(
			'title'       => __( 'Yusraah footer', 'yusraah' ),
			'description' => __( 'Footer text, contact details and credit.', 'yusraah' ),
			'priority'    => 40,
		) );
	}

	$wp_customize->add_section( 'yusraah_footer_newsletter', array(
		'title'       => __( 'Yusraah footer — newsletter & social', 'yusraah' ),
		'description' => __( 'Newsletter form, mailing service endpoint and social links.', 'yusraah' ),
		'priority'    => 41,
	) );

	$wp_customize->add_section( 'yusraah_footer_colors', array(
		'title'       => __( 'Yusraah footer — colours', 'yusraah' ),
		'description' => __( 'These colours drive every footer element. Keep the text light on a dark background to stay WCAG AA compliant.', 'yusraah' ),
		'priority'    => 42,
	) );

	// Colours.
	$colors = array(
		'yusraah_footer_bg'     => array( __( 'Footer background', 'yusraah' ), '#18201e' ),
		'yusraah_footer_text'   => array( __( 'Footer text', 'yusraah' ), '#f5f3ed' ),
		'yusraah_footer_muted'  => array( __( 'Footer secondary text and links', 'yusraah' ), '#b5b8b0' ),
		'yusraah_footer_accent' => array( __( 'Footer accent (headings, hover and Subscribe)', 'yusraah' ), '#d47550' ),
	);

	foreach ( $colors as $setting => $config ) {
		$wp_customize->add_setting( $setting, array(
			'default'           => $config[1],
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $setting, array(
			'label'   => $config[0],
			'section' => 'yusraah_footer_colors',
		) ) );
	}

	// Text settings.
	$defaults = yusraah_footer_defaults();
	$texts    = array(
		'footer_tagline'              => array( 'yusraah_footer', __( 'Footer tagline', 'yusraah' ), 'textarea' ),
		'footer_copyright'            => array( 'yusraah_footer', __( 'Copyright text', 'yusraah' ), 'text', __( 'Printed after “© YEAR Site name”. Leave empty to show only the copyright.', 'yusraah' ) ),
		'footer_claim'                => array( 'yusraah_footer', __( 'Secondary bottom line', 'yusraah' ), 'text' ),
		'footer_contact_title'        => array( 'yusraah_footer', __( 'Contact block title', 'yusraah' ), 'text' ),
		'footer_shop_title'           => array( 'yusraah_footer', __( 'Shop column title', 'yusraah' ), 'text' ),
		'footer_help_title'           => array( 'yusraah_footer', __( 'Help column title', 'yusraah' ), 'text' ),
		'footer_company_title'        => array( 'yusraah_footer', __( 'Company column title', 'yusraah' ), 'text' ),
		'footer_trust_delivery'       => array( 'yusraah_footer', __( 'Trust row — fast delivery', 'yusraah' ), 'text' ),
		'footer_trust_returns'        => array( 'yusraah_footer', __( 'Trust row — easy returns', 'yusraah' ), 'text' ),
		'footer_trust_cod'            => array( 'yusraah_footer', __( 'Trust row — cash on delivery', 'yusraah' ), 'text' ),
		'footer_trust_secure'         => array( 'yusraah_footer', __( 'Trust row — secure payment', 'yusraah' ), 'text' ),
		'footer_newsletter_title'     => array( 'yusraah_footer_newsletter', __( 'Newsletter title', 'yusraah' ), 'text' ),
		'footer_newsletter_intro'     => array( 'yusraah_footer_newsletter', __( 'Newsletter description', 'yusraah' ), 'textarea' ),
		'footer_newsletter_button'    => array( 'yusraah_footer_newsletter', __( 'Subscribe button label', 'yusraah' ), 'text' ),
		'footer_newsletter_privacy'   => array( 'yusraah_footer_newsletter', __( 'Privacy note', 'yusraah' ), 'textarea' ),
	);

	foreach ( $texts as $setting => $config ) {
		$wp_customize->add_setting( $setting, array(
			'default'           => $defaults[ $setting ],
			'sanitize_callback' => 'textarea' === $config[2] ? 'sanitize_textarea_field' : 'sanitize_text_field',
			'transport'         => 'refresh',
		) );

		$control = array(
			'label'   => $config[1],
			'section' => $config[0],
			'type'    => $config[2],
		);

		if ( isset( $config[3] ) ) {
			$control['description'] = $config[3];
		}

		$wp_customize->add_control( 'yusraah_' . $setting, $control );
	}

	// Contact details. Empty fields are hidden in the footer.
	$contacts = array(
		'footer_email'    => array( __( 'Email address', 'yusraah' ), 'email' ),
		'footer_phone'    => array( __( 'Phone number', 'yusraah' ), 'text' ),
		'footer_whatsapp' => array( __( 'WhatsApp number', 'yusraah' ), 'text', __( 'Digits only, including the country code (e.g. 8801700000000).', 'yusraah' ) ),
		'footer_address'  => array( __( 'Address', 'yusraah' ), 'textarea' ),
		'footer_hours'    => array( __( 'Support hours', 'yusraah' ), 'text' ),
	);

	foreach ( $contacts as $setting => $config ) {
		$wp_customize->add_setting( 'yusraah_' . $setting, array(
			'default'           => '',
			'sanitize_callback' => 'email' === $config[1] ? 'sanitize_email' : ( 'textarea' === $config[1] ? 'sanitize_textarea_field' : 'sanitize_text_field' ),
			'transport'         => 'refresh',
		) );

		$control = array(
			'label'   => $config[0],
			'section' => 'yusraah_footer',
			'type'    => $config[1],
		);

		if ( isset( $config[2] ) ) {
			$control['description'] = $config[2];
		}

		$wp_customize->add_control( 'yusraah_' . $setting, $control );
	}

	// Newsletter endpoint.
	$wp_customize->add_setting( 'yusraah_newsletter_action', array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_newsletter_action', array(
		'label'       => __( 'Mailing service form action URL', 'yusraah' ),
		'description' => __( 'Paste the form action from your provider (Mailchimp, ConvertKit, Brevo…), e.g. https://example.us1.list-manage.com/subscribe/post?u=…&id=…. The theme forwards the address to this URL and never stores it.', 'yusraah' ),
		'section'     => 'yusraah_footer_newsletter',
		'type'        => 'url',
	) );

	// Social links. An empty field removes the icon.
	$socials = array(
		'facebook'  => __( 'Facebook URL', 'yusraah' ),
		'instagram' => __( 'Instagram URL', 'yusraah' ),
		'youtube'   => __( 'YouTube URL', 'yusraah' ),
		'whatsapp'  => __( 'WhatsApp URL', 'yusraah' ),
		'x'         => __( 'X (Twitter) URL', 'yusraah' ),
	);

	foreach ( $socials as $key => $label ) {
		$wp_customize->add_setting( 'yusraah_social_' . $key, array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( 'yusraah_social_' . $key, array(
			'label'   => $label,
			'section' => 'yusraah_footer_newsletter',
			'type'    => 'url',
		) );
	}

	// Payment marks.
	$payments = array(
		'cod'        => __( 'Show cash on delivery', 'yusraah' ),
		'bkash'      => __( 'Show bKash', 'yusraah' ),
		'nagad'      => __( 'Show Nagad', 'yusraah' ),
		'visa'       => __( 'Show Visa', 'yusraah' ),
		'mastercard' => __( 'Show Mastercard', 'yusraah' ),
	);

	foreach ( $payments as $key => $label ) {
		$wp_customize->add_setting( 'yusraah_payment_' . $key, array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( 'yusraah_payment_' . $key, array(
			'label'   => $label,
			'section' => 'yusraah_footer_newsletter',
			'type'    => 'checkbox',
		) );
	}

	// Brand block and column layout.
	$wp_customize->add_section( 'yusraah_footer_layout', array(
		'title'       => __( 'Yusraah footer — brand & columns', 'yusraah' ),
		'description' => __( 'Footer logo, brand name and which link columns are shown.', 'yusraah' ),
		'priority'    => 43,
	) );

	$wp_customize->add_setting( 'yusraah_footer_brand_name', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_footer_brand_name', array(
		'label'       => __( 'Brand name', 'yusraah' ),
		'description' => __( 'Leave empty to use the site name.', 'yusraah' ),
		'section'     => 'yusraah_footer_layout',
		'type'        => 'text',
	) );

	$wp_customize->add_setting( 'yusraah_footer_brand_mode', array(
		'default'           => 'auto',
		'sanitize_callback' => function ( $value ) {
			return in_array( $value, array( 'auto', 'logo', 'text' ), true ) ? $value : 'auto';
		},
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_footer_brand_mode', array(
		'label'   => __( 'Show logo or text', 'yusraah' ),
		'section' => 'yusraah_footer_layout',
		'type'    => 'select',
		'choices' => array(
			'auto' => __( 'Logo when available, otherwise name', 'yusraah' ),
			'logo' => __( 'Logo only (falls back to name)', 'yusraah' ),
			'text' => __( 'Text name only', 'yusraah' ),
		),
	) );

	$wp_customize->add_setting( 'yusraah_footer_logo', array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'yusraah_footer_logo', array(
		'label'       => __( 'Footer logo', 'yusraah' ),
		'description' => __( 'Optional footer-only logo. Falls back to the Custom Logo from Site Identity, then the brand name.', 'yusraah' ),
		'section'     => 'yusraah_footer_layout',
	) ) );

	$wp_customize->add_setting( 'yusraah_footer_logo_width', array(
		'default'           => 180,
		'sanitize_callback' => function ( $value ) {
			$width = absint( $value );
			return max( 40, min( 400, $width ) );
		},
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_footer_logo_width', array(
		'label'       => __( 'Footer logo width (px)', 'yusraah' ),
		'section'     => 'yusraah_footer_layout',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 40, 'max' => 400, 'step' => 10 ),
	) );

	$wp_customize->add_setting( 'yusraah_footer_column_order', array(
		'default'           => 'contact-first',
		'sanitize_callback' => function ( $value ) {
			return 'contact-last' === $value ? 'contact-last' : 'contact-first';
		},
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_footer_column_order', array(
		'label'   => __( 'Column order', 'yusraah' ),
		'section' => 'yusraah_footer_layout',
		'type'    => 'select',
		'choices' => array(
			'contact-first' => __( 'Contact us first, then Shop, Help, Company', 'yusraah' ),
			'contact-last'  => __( 'Shop, Help, Company, then Contact us', 'yusraah' ),
		),
	) );

	$column_toggles = array(
		'show_contact' => __( 'Show Contact us column', 'yusraah' ),
		'show_shop'    => __( 'Show Shop column', 'yusraah' ),
		'show_help'    => __( 'Show Help column', 'yusraah' ),
		'show_company' => __( 'Show Company column', 'yusraah' ),
	);

	foreach ( $column_toggles as $key => $label ) {
		$wp_customize->add_setting( 'yusraah_footer_' . $key, array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( 'yusraah_footer_' . $key, array(
			'label'   => $label,
			'section' => 'yusraah_footer_layout',
			'type'    => 'checkbox',
		) );
	}
}
add_action( 'customize_register', 'yusraah_footer_customize_register', 20 );
