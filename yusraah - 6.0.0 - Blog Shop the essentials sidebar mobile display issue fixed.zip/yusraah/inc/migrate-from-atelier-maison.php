<?php
/**
 * One-time migration from the previous theme slug `atelier-maison`.
 *
 * WordPress stores Customizer data as `theme_mods_{stylesheet}`. Renaming the
 * theme folder changes the stylesheet, so saved logo, menus, colours and
 * widgets would otherwise appear empty. This file is the only place that may
 * still mention the old identifiers: it READS old option / meta / cookie /
 * transient keys and COPIES them to Yusraah keys. Old data is never deleted.
 *
 * Trigger:
 *  - automatically on `after_switch_theme` and once on `after_setup_theme`
 *  - WP-CLI: wp eval "yusraah_migrate_from_atelier_maison();"
 *
 * Dry-run serialized leftovers on the live site before any search-replace:
 *  wp search-replace 'atelier-maison' 'yusraah' --dry-run --all-tables
 *  wp search-replace 'atelier_maison' 'yusraah' --dry-run --all-tables
 *  wp search-replace 'atelier_' 'yusraah_' --dry-run --all-tables
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Legacy image size names so existing attachment crops keep resolving.
 *
 * Templates request the Yusraah size names; these aliases match the previous
 * dimensions exactly.
 *
 * @return void
 */
function yusraah_register_legacy_image_sizes() {
	add_image_size( 'atelier-product-card', 760, 950, true ); // Legacy size name — intentional.
	add_image_size( 'atelier-editorial', 1200, 1450, true ); // Legacy size name — intentional.
}
add_action( 'after_setup_theme', 'yusraah_register_legacy_image_sizes', 11 );

/**
 * Remap array keys that used the old theme_mod prefixes.
 *
 * @param mixed $value Theme mod value or nested array.
 * @return mixed
 */
function yusraah_remap_legacy_mod_keys( $value ) {
	if ( ! is_array( $value ) ) {
		return $value;
	}

	$out = array();
	foreach ( $value as $key => $item ) {
		if ( is_string( $key ) ) {
			if ( 0 === strpos( $key, 'atelier_maison_' ) ) {
				$key = 'yusraah_' . substr( $key, strlen( 'atelier_maison_' ) );
			} elseif ( 0 === strpos( $key, 'atelier_' ) ) {
				$key = 'yusraah_' . substr( $key, strlen( 'atelier_' ) );
			}
		}
		$out[ $key ] = yusraah_remap_legacy_mod_keys( $item );
	}

	return $out;
}

/**
 * Copy Additional CSS stored against the old stylesheet slug.
 *
 * @return void
 */
function yusraah_migrate_legacy_custom_css() {
	if ( ! function_exists( 'wp_get_custom_css' ) || ! function_exists( 'wp_update_custom_css_post' ) ) {
		return;
	}

	$old_css = wp_get_custom_css( 'atelier-maison' );
	$new_css = wp_get_custom_css( 'yusraah' );
	if ( ! is_string( $old_css ) || '' === trim( $old_css ) || ( is_string( $new_css ) && '' !== trim( $new_css ) ) ) {
		return;
	}

	$rewritten = str_replace(
		array( '.atelier-', '#atelier-', '--atelier-', 'atelier-' ),
		array( '.yusraah-', '#yusraah-', '--yusraah-', 'yusraah-' ),
		$old_css
	);
	wp_update_custom_css_post( $rewritten, 'yusraah' );
}

/**
 * Copy known transients from the old prefix. Dynamic hashed keys rebuild themselves.
 *
 * @return void
 */
function yusraah_migrate_legacy_transients() {
	$map = array(
		'atelier_home_category_data'              => 'yusraah_home_category_data',
		'atelier_home_reviews'                    => 'yusraah_home_reviews',
		'atelier_mobile_category_terms'           => 'yusraah_mobile_category_terms',
		'atelier_quick_deal_fallback_category_ids' => 'yusraah_quick_deal_fallback_category_ids',
	);

	foreach ( $map as $old_key => $new_key ) {
		if ( false !== get_transient( $new_key ) ) {
			continue;
		}
		$old = get_transient( $old_key );
		if ( false !== $old ) {
			set_transient( $new_key, $old, 6 * HOUR_IN_SECONDS );
		}
	}
}

/**
 * Copy wishlist user meta from the old key without deleting it.
 *
 * @return void
 */
function yusraah_migrate_legacy_wishlist_meta() {
	$users = get_users(
		array(
			'meta_key' => 'atelier_maison_wishlist', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one-time migration.
			'fields'   => 'ID',
		)
	);

	foreach ( $users as $user_id ) {
		$existing = get_user_meta( $user_id, 'yusraah_wishlist', true );
		if ( ! empty( $existing ) ) {
			continue;
		}
		$old = get_user_meta( $user_id, 'atelier_maison_wishlist', true );
		if ( ! empty( $old ) ) {
			update_user_meta( $user_id, 'yusraah_wishlist', $old );
		}
	}
}

/**
 * Copy Customizer mods, options, Additional CSS and related keys.
 *
 * Does not delete `theme_mods_atelier-maison` or any old option/meta/cookie.
 *
 * @return void
 */
function yusraah_migrate_from_atelier_maison() {
	if ( get_option( 'yusraah_migrated_from_atelier_maison' ) ) {
		return;
	}

	$old_mods = get_option( 'theme_mods_atelier-maison' );
	if ( is_array( $old_mods ) && $old_mods ) {
		$remapped = yusraah_remap_legacy_mod_keys( $old_mods );
		$current  = get_option( 'theme_mods_yusraah', array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}
		update_option( 'theme_mods_yusraah', array_merge( $current, $remapped ) );
	}

	$old_rewrite = get_option( 'atelier_maison_wishlist_rewrite_version' );
	if ( $old_rewrite && false === get_option( 'yusraah_wishlist_rewrite_version', false ) ) {
		update_option( 'yusraah_wishlist_rewrite_version', $old_rewrite );
	}

	$stylesheet = get_option( 'stylesheet' );
	$template   = get_option( 'template' );
	if ( 'atelier-maison' === $stylesheet && is_dir( get_theme_root() . '/yusraah' ) ) {
		update_option( 'stylesheet', 'yusraah' );
	}
	if ( 'atelier-maison' === $template && is_dir( get_theme_root() . '/yusraah' ) ) {
		update_option( 'template', 'yusraah' );
	}

	yusraah_migrate_legacy_custom_css();
	yusraah_migrate_legacy_transients();
	yusraah_migrate_legacy_wishlist_meta();

	update_option( 'yusraah_migrated_from_atelier_maison', gmdate( 'c' ) );
}
add_action( 'after_switch_theme', 'yusraah_migrate_from_atelier_maison', 1 );
add_action( 'after_setup_theme', 'yusraah_migrate_from_atelier_maison', 1 );

/**
 * Copy a guest wishlist cookie from the old name on first visit.
 *
 * @return void
 */
function yusraah_migrate_legacy_wishlist_cookie() {
	if ( headers_sent() ) {
		return;
	}
	if ( ! empty( $_COOKIE['yusraah_wishlist'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- presence check.
		return;
	}
	if ( empty( $_COOKIE['atelier_maison_wishlist'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- presence check.
		return;
	}

	$raw = wp_unslash( $_COOKIE['atelier_maison_wishlist'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised below.
	$ids = function_exists( 'yusraah_wishlist_sanitize_ids' ) ? yusraah_wishlist_sanitize_ids( $raw ) : array();
	if ( ! $ids || ! function_exists( 'yusraah_wishlist_set_cookie' ) ) {
		return;
	}

	yusraah_wishlist_set_cookie( $ids );
	$_COOKIE['yusraah_wishlist'] = wp_json_encode( $ids );
}
add_action( 'init', 'yusraah_migrate_legacy_wishlist_cookie', 0 );
