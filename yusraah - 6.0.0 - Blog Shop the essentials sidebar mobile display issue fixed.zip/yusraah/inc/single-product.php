<?php
/**
 * Single product page.
 *
 * Gallery, badges, buy box and product sections for the single product
 * template. Everything is wired through standard WooCommerce hooks and
 * filters; no core template or plugin file is modified.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

defined( 'ABSPATH' ) || exit;

/**
 * Rebuild the single product hooks.
 *
 * WooCommerce prints the sale badge on `woocommerce_before_single_product_summary`
 * priority 10, i.e. above `.images` instead of inside it. The theme renders it
 * from the gallery badge stack instead, so the badge sits in the image's
 * top-left corner exactly like the shop product cards.
 *
 * `woocommerce_single_product_summary` is re-ordered to the shop's buy box
 * order: breadcrumb, category, title, rating, price, short description,
 * variations and buttons, stock, delivery and trust, wishlist and share. Only
 * the priorities change; every core callback is reused as-is.
 *
 * The product tabs are moved off `woocommerce_after_single_product_summary`
 * onto `yusraah_product_primary`, which
 * `woocommerce/content-single-product.php` fires inside the gallery's column,
 * so the tabs sit under the gallery instead of under the buy box.
 *
 * Runs on `wp` so the query (and therefore `is_product()`) is available, and
 * well before the template renders.
 *
 * @return void
 */
function yusraah_single_product_hooks() {
	if ( ! is_product() ) {
		return;
	}

	remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );

	$summary = 'woocommerce_single_product_summary';

	// Core callbacks, detached so they can be re-attached in the theme order.
	remove_action( $summary, 'woocommerce_template_single_title', 5 );
	remove_action( $summary, 'woocommerce_template_single_rating', 10 );
	remove_action( $summary, 'woocommerce_template_single_price', 10 );
	remove_action( $summary, 'woocommerce_template_single_excerpt', 20 );
	remove_action( $summary, 'woocommerce_template_single_add_to_cart', 30 );
	remove_action( $summary, 'woocommerce_template_single_meta', 40 );
	remove_action( $summary, 'woocommerce_template_single_sharing', 50 );

	add_action( $summary, 'yusraah_single_product_breadcrumb', 2 );
	add_action( $summary, 'yusraah_single_product_category', 4 );
	add_action( $summary, 'woocommerce_template_single_title', 5 );
	add_action( $summary, 'woocommerce_template_single_rating', 10 );
	add_action( $summary, 'yusraah_single_product_price', 11 );
	add_action( $summary, 'woocommerce_template_single_excerpt', 20 );
	add_action( $summary, 'woocommerce_template_single_add_to_cart', 30 );
	add_action( $summary, 'yusraah_single_product_stock', 35 );
	add_action( $summary, 'yusraah_single_product_reassurance', 36 );
	add_action( $summary, 'woocommerce_template_single_meta', 38 );
	add_action( $summary, 'yusraah_single_product_wishlist', 39 );

	// Tabs live in the gallery's column: WooCommerce prints them on
	// `woocommerce_after_single_product_summary`, which places them beside the
	// buy box, so the callback is detached and re-attached to the action the
	// theme's `woocommerce/content-single-product.php` fires under the gallery.
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
	add_action( 'yusraah_product_primary', 'woocommerce_output_product_data_tabs', 20 );
}
add_action( 'wp', 'yusraah_single_product_hooks' );

/**
 * Pin the product tab order and keep the description tab available.
 *
 * Core only registers the description tab when the product has body copy and
 * the reviews tab when comments are open, so the order of the remaining tabs
 * depends on the product. The theme always registers the description tab —
 * `single-product/tabs/description.php` explains the empty state instead of
 * hiding the tab — and pins the priorities to Description, Additional
 * information, Reviews.
 *
 * @param array $tabs Product tabs.
 * @return array
 */
function yusraah_single_product_tabs( $tabs ) {
	if ( ! is_array( $tabs ) ) {
		return $tabs;
	}

	if ( ! isset( $tabs['description'] ) ) {
		$tabs['description'] = array(
			'title'    => __( 'Description', 'woocommerce' ),
			'priority' => 10,
			'callback' => 'woocommerce_product_description_tab',
		);
	}

	$order = array(
		'description'            => 10,
		'additional_information' => 20,
		'reviews'                => 30,
	);

	foreach ( $order as $key => $priority ) {
		if ( isset( $tabs[ $key ] ) ) {
			$tabs[ $key ]['priority'] = $priority;
		}
	}

	return $tabs;
}
add_filter( 'woocommerce_product_tabs', 'yusraah_single_product_tabs', 20 );

/**
 * Remove the repeated heading from the native Description tab panel.
 *
 * The tab and mobile accordion headers already provide the accessible name.
 *
 * @param string $heading Heading text.
 * @return string
 */
function yusraah_product_description_heading( $heading ) {
	return is_product() ? '' : $heading;
}
add_filter( 'woocommerce_product_description_heading', 'yusraah_product_description_heading' );

/**
 * Remove the repeated heading from the native Additional information panel.
 *
 * @param string $heading Heading text.
 * @return string
 */
function yusraah_product_additional_information_heading( $heading ) {
	return is_product() ? '' : $heading;
}
add_filter( 'woocommerce_product_additional_information_heading', 'yusraah_product_additional_information_heading' );

/**
 * Render the badge stack inside the first native gallery slide.
 *
 * The thumbnail HTML filter keeps the badge inside the image slide without
 * adding a non-image child to FlexSlider's gallery wrapper.
 *
 * Mirrors the product card logic: the sale badge first, then a single
 * secondary badge (sold out > new > featured), so the stack never exceeds two.
 *
 * @return void
 */
function yusraah_single_product_badges() {
	global $product;

	if ( ! $product instanceof WC_Product ) {
		return;
	}

	$is_out_of_stock = ! $product->is_in_stock();
	$is_new          = function_exists( 'yusraah_is_new_product' ) && yusraah_is_new_product( $product->get_id() );
	$is_featured     = $product->is_featured();

	?>
	<div class="yusraah-badges">
		<?php
		// Sale badge markup comes from the woocommerce_sale_flash filter.
		woocommerce_show_product_sale_flash();

		// One secondary badge only, so the stack never exceeds 2 badges.
		if ( $is_out_of_stock ) :
			?>
			<span class="yusraah-badge yusraah-badge--sold-out"><?php esc_html_e( 'Sold out', 'yusraah' ); ?></span>
		<?php elseif ( $is_new ) : ?>
			<span class="yusraah-badge yusraah-badge--new"><?php esc_html_e( 'New', 'yusraah' ); ?></span>
		<?php elseif ( $is_featured ) : ?>
			<span class="yusraah-badge yusraah-badge--featured"><?php esc_html_e( 'Featured', 'yusraah' ); ?></span>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Put the badge stack inside the first image slide without changing its link.
 *
 * @param string $html Gallery image markup.
 * @param int    $attachment_id Gallery attachment ID.
 * @return string
 */
function yusraah_single_product_gallery_image_html( $html, $attachment_id ) {
	static $badges_added = false;

	if ( $badges_added || ! is_product() || false === strrpos( $html, '</div>' ) ) {
		return $html;
	}

	ob_start();
	yusraah_single_product_badges();
	$badges = ob_get_clean();

	if ( $badges ) {
		$closing_div  = strrpos( $html, '</div>' );
		$html         = substr_replace( $html, $badges, $closing_div, 0 );
		$badges_added = true;
	}

	return $html;
}
add_filter( 'woocommerce_single_product_image_thumbnail_html', 'yusraah_single_product_gallery_image_html', 10, 2 );

/**
 * Keep product badges visible over WooCommerce's native placeholder.
 *
 * A placeholder has no image HTML for the gallery image filter to decorate.
 *
 * @return void
 */
function yusraah_single_product_placeholder_badges() {
	global $product;

	if ( ! $product instanceof WC_Product || $product->get_image_id() || $product->get_gallery_image_ids() ) {
		return;
	}

	yusraah_single_product_badges();
}
add_action( 'woocommerce_product_thumbnails', 'yusraah_single_product_placeholder_badges', 30 );

/**
 * Enable native FlexSlider arrows and keyboard navigation.
 *
 * @param array $options WooCommerce FlexSlider options.
 * @return array
 */
function yusraah_gallery_carousel_options( $options ) {
	if ( ! is_array( $options ) ) {
		return $options;
	}

	$options['directionNav'] = true;
	$options['keyboard']     = true;

	return $options;
}
add_filter( 'woocommerce_single_product_carousel_options', 'yusraah_gallery_carousel_options' );

/**
 * Prioritise the gallery's first slide and lazy-load the remaining ones.
 *
 * WooCommerce paints the first slide from `$media_items[0]`, which is not
 * always the product's featured image (a product can have gallery images and no
 * featured image at all), so `get_image_id()` cannot identify the image that
 * ends up being the largest contentful paint. This filter runs inside
 * `wc_get_gallery_image_html()` and receives WooCommerce's own `$main_image`
 * flag, which is the reliable signal. It also runs when WooCommerce rebuilds
 * the gallery for a variation, so a swapped-in image is prioritised as well.
 *
 * Scoped to `is_product()` so the loop, the related products and the
 * cross-sells keep WordPress' lazy-loading defaults.
 *
 * @param array        $params     Attributes for `wp_get_attachment_image()`.
 * @param int          $attachment Attachment ID.
 * @param string|array $image_size Requested image size.
 * @param bool         $main_image Whether this is the gallery's first slide.
 * @return array
 */
function yusraah_gallery_image_priority( $params, $attachment, $image_size, $main_image ) {
	if ( ! is_product() ) {
		return $params;
	}

	if ( $main_image ) {
		$params['fetchpriority'] = 'high';
		$params['loading']       = 'eager';
	} else {
		// Everything after the first slide stays lazy so it cannot compete
		// with the main image for bandwidth.
		$params['loading'] = 'lazy';
	}

	if ( empty( $params['alt'] ) ) {
		global $product;
		if ( $product instanceof WC_Product ) {
			$params['alt'] = $product->get_name();
		}
	}

	return $params;
}
add_filter( 'woocommerce_gallery_image_html_attachment_image_params', 'yusraah_gallery_image_priority', 10, 4 );

/*
 * -------------------------------------------------------------------------
 * Buy box
 * -------------------------------------------------------------------------
 */

/**
 * Find the product's most specific category.
 *
 * Mirrors the logic used by the product card, so the buy box and the card
 * always agree on which category represents the product.
 *
 * @param WC_Product $product Product object.
 * @return WP_Term|null
 */
function yusraah_primary_product_category( $product ) {
	$terms = get_the_terms( $product->get_id(), 'product_cat' );

	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}

	$primary = $terms[0];

	foreach ( $terms as $term ) {
		if ( $term->parent > 0 && $term->parent !== $primary->term_id ) {
			$primary = $term;
		}
	}

	return $primary;
}

/**
 * Render the breadcrumb trail at the top of the buy box.
 *
 * The theme renders the product through `woocommerce_content()`, so
 * `woocommerce_before_main_content` never fires and WooCommerce prints no
 * breadcrumb on product pages. Rendering it inside the summary restores it
 * without touching the template loader.
 *
 * @return void
 */
function yusraah_single_product_breadcrumb() {
	if ( ! function_exists( 'woocommerce_breadcrumb' ) ) {
		return;
	}

	woocommerce_breadcrumb();
}

/**
 * Render the product's category above the title.
 *
 * @return void
 */
function yusraah_single_product_category() {
	global $product;

	if ( ! $product instanceof WC_Product ) {
		return;
	}

	$term = yusraah_primary_product_category( $product );

	if ( ! $term ) {
		return;
	}

	$link = get_term_link( $term );

	if ( is_wp_error( $link ) ) {
		return;
	}
	?>
	<p class="yusraah-product-category">
		<a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $term->name ); ?></a>
	</p>
	<?php
}

/**
 * Discount percentage for the product's headline price.
 *
 * Variable products use their cheapest variation so the badge matches the
 * "from" price that WooCommerce prints.
 *
 * @param WC_Product $product Product object.
 * @return int Percentage between 1 and 100, or 0 when not on sale.
 */
function yusraah_single_product_sale_percentage( $product ) {
	if ( ! $product instanceof WC_Product || ! $product->is_on_sale() ) {
		return 0;
	}

	if ( $product->is_type( 'variable' ) ) {
		$regular = $product->get_variation_regular_price( 'min' );
		$sale    = $product->get_variation_sale_price( 'min' );
	} else {
		$regular = $product->get_regular_price();
		$sale    = $product->get_sale_price();
	}

	$regular = (float) $regular;
	$sale    = (float) $sale;

	if ( $regular <= 0 || $sale <= 0 || $sale >= $regular ) {
		return 0;
	}

	return (int) round( ( ( $regular - $sale ) / $regular ) * 100 );
}

/**
 * Render the buy box price.
 *
 * The struck-through regular price and the emphasised sale price come from
 * WooCommerce's own `get_price_html()`, so the output stays core compatible.
 * The discount tag reuses the theme's rectangular sale badge.
 *
 * `[data-yusraah-selected-price]` is an empty slot the product script fills
 * with the chosen variation's price, so the range is replaced in place
 * instead of pushing the rest of the buy box down.
 *
 * @return void
 */
function yusraah_single_product_price() {
	global $product;

	if ( ! $product instanceof WC_Product ) {
		return;
	}

	$price_html = $product->get_price_html();

	if ( '' === $price_html ) {
		return;
	}

	$percentage = yusraah_single_product_sale_percentage( $product );
	?>
	<div class="yusraah-price" data-yusraah-price>
		<p class="price" data-yusraah-base-price>
			<?php echo wp_kses_post( $price_html ); ?>
			<?php if ( $percentage ) : ?>
				<span class="yusraah-badge yusraah-badge--sale yusraah-price__off">
					<?php
					printf(
						/* translators: %s: discount percentage, e.g. "20%". */
						esc_html__( '%s off', 'yusraah' ),
						esc_html( $percentage . '%' )
					);
					?>
				</span>
			<?php endif; ?>
		</p>
		<p class="price yusraah-price__selected" data-yusraah-selected-price hidden></p>
	</div>
	<?php
}

/**
 * Stock wording for the single product and its variations.
 *
 * Kept filter-wide rather than product-page-wide: WooCommerce generates the
 * variation availability over AJAX, where `is_product()` is false, and the two
 * must read the same. Backorder wording and products WooCommerce excludes from
 * stock management are left untouched.
 *
 * @param string     $text    Availability text.
 * @param WC_Product $product Product object.
 * @return string
 */
function yusraah_availability_text( $text, $product ) {
	if ( ! $product instanceof WC_Product ) {
		return $text;
	}

	if ( ! $product->is_in_stock() ) {
		return __( 'Out of stock', 'yusraah' );
	}

	if ( $product->is_on_backorder() ) {
		return $text;
	}

	if ( $product->managing_stock() ) {
		$quantity = $product->get_stock_quantity();
		$low      = (int) get_option( 'woocommerce_notify_low_stock_amount', 2 );

		if ( null !== $quantity && $quantity > 0 && $quantity <= $low ) {
			return sprintf(
				/* translators: %d: number of items left in stock. */
				__( 'Only %d left in stock', 'yusraah' ),
				(int) $quantity
			);
		}
	}

	return __( 'In stock', 'yusraah' );
}
add_filter( 'woocommerce_get_availability_text', 'yusraah_availability_text', 10, 2 );

/**
 * Add a `low-stock` class next to WooCommerce's availability classes.
 *
 * The core class is preserved so other integrations keep working.
 *
 * @param string     $class   Availability class.
 * @param WC_Product $product Product object.
 * @return string
 */
function yusraah_availability_class( $class, $product ) {
	if ( ! $product instanceof WC_Product || ! $product->is_in_stock() || $product->is_on_backorder() || ! $product->managing_stock() ) {
		return $class;
	}

	$quantity = $product->get_stock_quantity();
	$low      = (int) get_option( 'woocommerce_notify_low_stock_amount', 2 );

	if ( null !== $quantity && $quantity > 0 && $quantity <= $low ) {
		return $class . ' low-stock';
	}

	return $class;
}
add_filter( 'woocommerce_get_availability_class', 'yusraah_availability_class', 10, 2 );

/**
 * Move the simple product's stock message out of the add to cart form.
 *
 * WooCommerce prints it just above the form. The buy box shows it after the
 * buttons instead, which the theme renders itself.
 *
 * @param string          $html    Stock markup.
 * @param WC_Product|null $product Product object.
 * @return string
 */
function yusraah_single_product_stock_html( $html, $product ) {
	if ( is_product() && $product instanceof WC_Product && ! $product->is_type( 'variable' ) ) {
		return '';
	}

	return $html;
}
add_filter( 'woocommerce_get_stock_html', 'yusraah_single_product_stock_html', 10, 2 );

/**
 * Render the stock status under the add to cart buttons.
 *
 * Variable products are skipped: their availability belongs to the chosen
 * variation and WooCommerce prints it in the variation area.
 *
 * @return void
 */
function yusraah_single_product_stock() {
	global $product;

	if ( ! $product instanceof WC_Product || $product->is_type( 'variable' ) || ! $product->is_purchasable() ) {
		return;
	}

	$availability = $product->get_availability();
	$text         = isset( $availability['availability'] ) ? (string) $availability['availability'] : '';

	if ( '' === $text ) {
		return;
	}

	$class = isset( $availability['class'] ) ? (string) $availability['class'] : '';
	?>
	<p class="yusraah-stock stock <?php echo esc_attr( $class ); ?>">
		<span class="screen-reader-text"><?php esc_html_e( 'Availability:', 'yusraah' ); ?></span>
		<span class="yusraah-stock__text"><?php echo esc_html( $text ); ?></span>
	</p>
	<?php
}

/**
 * Render the delivery, returns and trust block under the stock status.
 *
 * The delivery and returns notes used to repeat the trust icons in a second
 * bordered block; they now share one block so the buy box reads as a single
 * reassurance list. All six strings stay editable in the Customizer.
 *
 * @return void
 */
function yusraah_single_product_reassurance() {
	$delivery = trim( (string) get_theme_mod( 'yusraah_product_delivery_text', __( 'Delivery within 2–4 business days.', 'yusraah' ) ) );
	$returns  = trim( (string) get_theme_mod( 'yusraah_product_returns_text', __( 'Free returns within 7 days of delivery.', 'yusraah' ) ) );

	$defaults = array(
		array( __( 'Fast delivery', 'yusraah' ), 'box' ),
		array( __( 'Easy returns', 'yusraah' ), 'arrow' ),
		array( __( 'Cash on delivery', 'yusraah' ), 'pin' ),
		array( __( 'Secure payment', 'yusraah' ), 'card' ),
	);

	$items = array();

	foreach ( $defaults as $index => $item ) {
		$text = trim( (string) get_theme_mod( 'yusraah_product_trust_' . ( $index + 1 ), $item[0] ) );

		if ( '' !== $text ) {
			$items[] = array( $text, $item[1] );
		}
	}

	if ( ! $items && '' === $delivery && '' === $returns ) {
		return;
	}
	?>
	<div class="yusraah-product-reassurance">
		<?php if ( $items ) : ?>
			<ul class="yusraah-reassurance__trust">
				<?php foreach ( $items as $item ) : ?>
					<li>
						<?php echo yusraah_icon( $item[1] ); ?>
						<span><?php echo esc_html( $item[0] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<?php if ( '' !== $delivery || '' !== $returns ) : ?>
			<ul class="yusraah-reassurance__notes">
				<?php if ( '' !== $delivery ) : ?>
					<li>
						<?php echo yusraah_icon( 'box' ); ?>
						<span><?php echo esc_html( $delivery ); ?></span>
					</li>
				<?php endif; ?>
				<?php if ( '' !== $returns ) : ?>
					<li>
						<?php echo yusraah_icon( 'arrow' ); ?>
						<span><?php echo esc_html( $returns ); ?></span>
					</li>
				<?php endif; ?>
			</ul>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Render the wishlist button at the end of the buy box.
 *
 * The saved state is rendered server-side so the heart is already correct
 * before the theme script runs; `#yusraah-wishlist-status` gives the shared
 * wishlist script a live region to announce the result in.
 *
 * @return void
 */
function yusraah_single_product_wishlist() {
	global $product;

	if ( ! $product instanceof WC_Product || ! function_exists( 'yusraah_wishlist_has' ) ) {
		return;
	}

	$product_id = (int) $product->get_id();
	$saved      = yusraah_wishlist_has( $product_id );
	?>
	<div class="yusraah-product-actions">
		<span id="yusraah-wishlist-status" class="screen-reader-text" role="status" aria-live="polite"></span>
		<button
			type="button"
			class="wishlist-toggle"
			data-wishlist="<?php echo esc_attr( $product_id ); ?>"
			aria-pressed="<?php echo $saved ? 'true' : 'false'; ?>"
			aria-label="<?php echo esc_attr( $saved ? __( 'Remove from wishlist', 'yusraah' ) : __( 'Add to wishlist', 'yusraah' ) ); ?>"
		>
			<?php echo yusraah_icon( 'heart' ); ?>
			<span><?php esc_html_e( 'Wishlist', 'yusraah' ); ?></span>
		</button>
	</div>
	<?php
}

/**
 * Render the − / + buttons around the quantity input.
 *
 * `woocommerce_before_quantity_input_field` and
 * `woocommerce_after_quantity_input_field` fire inside `.quantity`, so the
 * stepper wraps the native input for simple and variable products alike. The
 * input keeps its own name, min, max and step, which stay the single source of
 * truth for the form. Attributes are deliberately distinct from the shop
 * card's AJAX stepper, which posts to a different endpoint.
 *
 * @return void
 */
function yusraah_quantity_minus_button() {
	if ( ! is_product() ) {
		return;
	}
	?>
	<button type="button" class="qty-step qty-step--minus" data-product-qty-step="-1" aria-label="<?php esc_attr_e( 'Decrease quantity', 'yusraah' ); ?>">
		<span aria-hidden="true">&minus;</span>
	</button>
	<?php
}
add_action( 'woocommerce_before_quantity_input_field', 'yusraah_quantity_minus_button' );

/**
 * Render the + button after the quantity input.
 *
 * @return void
 */
function yusraah_quantity_plus_button() {
	if ( ! is_product() ) {
		return;
	}
	?>
	<button type="button" class="qty-step qty-step--plus" data-product-qty-step="1" aria-label="<?php esc_attr_e( 'Increase quantity', 'yusraah' ); ?>">
		<span aria-hidden="true">+</span>
	</button>
	<?php
}
add_action( 'woocommerce_after_quantity_input_field', 'yusraah_quantity_plus_button' );

/**
 * Render the Buy Now button next to the add to cart button.
 *
 * `woocommerce_after_add_to_cart_button` fires inside the cart form for both
 * simple and variable products, so the button always shares the form's
 * product, quantity and variation fields. It is disabled until a variation is
 * chosen; the product script mirrors WooCommerce's own button state.
 *
 * @return void
 */
function yusraah_single_product_buy_now_button() {
	global $product;

	if ( ! $product instanceof WC_Product ) {
		return;
	}

	$is_variable = $product->is_type( 'variable' );
	?>
	<button
		type="submit"
		name="yusraah_buy_now"
		value="1"
		class="button alt yusraah-buy-now"
		data-yusraah-buy-now
		<?php echo $is_variable ? 'disabled aria-disabled="true"' : ''; ?>
	><?php echo esc_html( get_theme_mod( 'yusraah_product_buy_now_text', __( 'Buy Now', 'yusraah' ) ) ); ?></button>
	<?php
}
add_action( 'woocommerce_after_add_to_cart_button', 'yusraah_single_product_buy_now_button' );

/**
 * Explain why the add to cart buttons are inactive.
 *
 * @return void
 */
function yusraah_single_product_variations_hint() {
	global $product;

	if ( ! $product instanceof WC_Product || ! $product->is_type( 'variable' ) ) {
		return;
	}
	?>
	<p class="yusraah-variations-hint" data-yusraah-variations-hint>
		<?php esc_html_e( 'Choose the options above to see the price and add this product to your basket.', 'yusraah' ); ?>
	</p>
	<?php
}
add_action( 'woocommerce_after_variations_table', 'yusraah_single_product_variations_hint' );

/**
 * Send the customer straight to checkout when Buy Now was used.
 *
 * @param string $url Redirect URL.
 * @return string
 */
function yusraah_buy_now_redirect( $url ) {
	if ( ! isset( $_POST['yusraah_buy_now'] ) ) {
		return $url;
	}

	return wc_get_checkout_url();
}
add_filter( 'woocommerce_add_to_cart_redirect', 'yusraah_buy_now_redirect', 20 );

/**
 * Decide whether an attribute should render as swatches.
 *
 * @param string $label Attribute label, e.g. "Color".
 * @return bool
 */
function yusraah_attribute_uses_swatches( $label ) {
	$label = function_exists( 'mb_strtolower' ) ? mb_strtolower( $label ) : strtolower( $label );

	return (bool) preg_match( '/colou?r|size|height/', $label );
}

/**
 * Add a swatch control next to a variation dropdown.
 *
 * The original `<select>` stays in the markup as the single source of truth —
 * WooCommerce's variation script, the "Clear" link and the form POST all keep
 * using it. The swatch group starts hidden and is revealed by the product
 * script, so without JavaScript the dropdown is the only control.
 *
 * @param string $html Dropdown markup.
 * @param array  $args Dropdown arguments.
 * @return string
 */
function yusraah_variation_swatches( $html, $args ) {
	if ( ! is_product() || ! function_exists( 'wc_attribute_label' ) ) {
		return $html;
	}

	$attribute = isset( $args['attribute'] ) ? (string) $args['attribute'] : '';
	$options   = isset( $args['options'] ) ? (array) $args['options'] : array();
	$selected  = isset( $args['selected'] ) ? (string) $args['selected'] : '';
	$product   = isset( $args['product'] ) ? $args['product'] : null;

	if ( '' === $attribute || ! $options || ! $product instanceof WC_Product ) {
		return $html;
	}

	$label = wc_attribute_label( $attribute );

	if ( ! yusraah_attribute_uses_swatches( $label ) ) {
		return $html;
	}

	$is_color   = (bool) preg_match( '/colou?r/i', $label );
	$group_name = 'yusraah-swatches-' . sanitize_html_class( $attribute );

	ob_start();
	?>
	<div
		class="yusraah-swatches<?php echo $is_color ? ' yusraah-swatches--color' : ''; ?>"
		data-yusraah-swatches
		role="group"
		aria-label="<?php echo esc_attr( $label ); ?>"
		id="<?php echo esc_attr( $group_name ); ?>"
		hidden
	>
		<?php
		foreach ( $options as $option ) :
			$term_name  = $option;
			$swatch_css = '';

			if ( taxonomy_exists( $attribute ) ) {
				$term = get_term_by( 'slug', $option, $attribute );

				if ( $term && ! is_wp_error( $term ) ) {
					$term_name = $term->name;
				}
			}

			if ( $is_color ) {
				$swatch_css = sanitize_hex_color( $option );

				if ( ! $swatch_css ) {
					$swatch_css = sanitize_hex_color( '#' . ltrim( $option, '#' ) );
				}
			}
			?>
			<button
				type="button"
				class="yusraah-swatch<?php echo $is_color ? ' yusraah-swatch--color' : ''; ?>"
				data-value="<?php echo esc_attr( $option ); ?>"
				aria-pressed="<?php echo $selected === (string) $option ? 'true' : 'false'; ?>"
			>
				<?php if ( $swatch_css ) : ?>
					<span class="yusraah-swatch__chip" style="background-color: <?php echo esc_attr( $swatch_css ); ?>"></span>
					<span class="screen-reader-text"><?php echo esc_html( $term_name ); ?></span>
				<?php else : ?>
					<?php echo esc_html( $term_name ); ?>
				<?php endif; ?>
			</button>
		<?php endforeach; ?>
	</div>
	<?php
	return $html . ob_get_clean();
}
add_filter( 'woocommerce_dropdown_variation_attribute_options_html', 'yusraah_variation_swatches', 10, 2 );
