<?php
/**
 * Category tabs for the homepage story product slider.
 *
 * @package Yusraah
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the Quick Deal Customizer panel.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function yusraah_quick_deal_customize_register( $wp_customize ) {
	yusraah_quick_deal_register_customizer_controls();
	if ( ! class_exists( 'Yusraah_Quick_Deal_Categories_Control' ) || ! class_exists( 'Yusraah_Quick_Deal_Labels_Control' ) ) {
		return;
	}

	$wp_customize->add_section(
		'yusraah_quick_deal',
		array(
			'title'       => __( 'Quick Deal', 'yusraah' ),
			'description' => __( 'Configure the category tabs and products in the homepage story slider.', 'yusraah' ),
			'priority'    => 38,
		)
	);

	$settings = array(
		'show_tabs' => array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'type'              => 'checkbox',
			'label'             => __( 'Show Quick Deal category tabs', 'yusraah' ),
		),
		'title' => array(
			'default'           => __( 'Quick Deal', 'yusraah' ),
			'sanitize_callback' => 'sanitize_text_field',
			'type'              => 'text',
			'label'             => __( 'Section title', 'yusraah' ),
		),
		'subtitle' => array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
			'type'              => 'text',
			'label'             => __( 'Section subtitle (optional)', 'yusraah' ),
		),
		'all_tab' => array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'type'              => 'checkbox',
			'label'             => __( 'Include an “All” tab', 'yusraah' ),
		),
		'limit' => array(
			'default'           => 8,
			'sanitize_callback' => 'yusraah_quick_deal_sanitize_limit',
			'type'              => 'number',
			'label'             => __( 'Products per tab', 'yusraah' ),
		),
		'order' => array(
			'default'           => 'latest',
			'sanitize_callback' => 'yusraah_quick_deal_sanitize_order',
			'type'              => 'select',
			'label'             => __( 'Product order', 'yusraah' ),
			'choices'           => array(
				'latest'      => __( 'Latest', 'yusraah' ),
				'bestselling' => __( 'Best selling', 'yusraah' ),
				'top_rated'   => __( 'Top rated', 'yusraah' ),
				'on_sale'     => __( 'On sale', 'yusraah' ),
				'random'      => __( 'Random', 'yusraah' ),
			),
		),
		'on_sale_only' => array(
			'default'           => false,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'type'              => 'checkbox',
			'label'             => __( 'Show on-sale products only', 'yusraah' ),
		),
		'autoplay' => array(
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'type'              => 'checkbox',
			'label'             => __( 'Enable slider autoplay', 'yusraah' ),
		),
		'speed' => array(
			'default'           => 4500,
			'sanitize_callback' => 'yusraah_sanitize_slider_speed',
			'type'              => 'number',
			'label'             => __( 'Autoplay speed (ms, 2000–8000)', 'yusraah' ),
		),
		'desktop' => array(
			'default'           => 1,
			'sanitize_callback' => 'yusraah_quick_deal_sanitize_view_desktop',
			'type'              => 'number',
			'label'             => __( 'Slides per view — desktop (1–3)', 'yusraah' ),
		),
		'tablet' => array(
			'default'           => 1,
			'sanitize_callback' => 'yusraah_quick_deal_sanitize_view_tablet',
			'type'              => 'number',
			'label'             => __( 'Slides per view — tablet (1–2)', 'yusraah' ),
		),
		'mobile' => array(
			'default'           => 1,
			'sanitize_callback' => 'yusraah_quick_deal_sanitize_view_mobile',
			'type'              => 'number',
			'label'             => __( 'Slides per view — mobile (1–2)', 'yusraah' ),
		),
	);

	foreach ( $settings as $key => $setting ) {
		$id = 'yusraah_quick_deal_' . $key;
		$wp_customize->add_setting(
			$id,
			array(
				'default'           => $setting['default'],
				'sanitize_callback' => $setting['sanitize_callback'],
				'transport'         => 'postMessage',
			)
		);
		$control = array(
			'label'   => $setting['label'],
			'section' => 'yusraah_quick_deal',
			'type'    => $setting['type'],
		);
		if ( isset( $setting['choices'] ) ) {
			$control['choices'] = $setting['choices'];
		}
		if ( 'number' === $setting['type'] ) {
			$control['input_attrs'] = array(
				'min'  => 1,
				'max'  => 'limit' === $key ? 12 : ( 'desktop' === $key ? 3 : ( 'speed' === $key ? 8000 : 2 ) ),
				'step' => 'speed' === $key ? 500 : 1,
			);
			if ( 'speed' === $key ) {
				$control['input_attrs']['min'] = 2000;
			}
		}
		$wp_customize->add_control( $id, $control );
	}

	$wp_customize->add_setting(
		'yusraah_quick_deal_categories',
		array(
			'default'           => array(),
			'sanitize_callback' => 'yusraah_quick_deal_sanitize_categories',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new Yusraah_Quick_Deal_Categories_Control(
			$wp_customize,
			'yusraah_quick_deal_categories',
			array(
				'label'       => __( 'Product categories (up to 6)', 'yusraah' ),
				'description' => __( 'Select up to six categories, then use the arrows below the list to set their tab order. If none are selected, the six highest-count purchasable categories are used.', 'yusraah' ),
				'section'     => 'yusraah_quick_deal',
			)
		)
	);

	$wp_customize->add_setting(
		'yusraah_quick_deal_labels',
		array(
			'default'           => array(),
			'sanitize_callback' => 'yusraah_quick_deal_sanitize_labels',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new Yusraah_Quick_Deal_Labels_Control(
			$wp_customize,
			'yusraah_quick_deal_labels',
			array(
				'label'       => __( 'Custom tab labels', 'yusraah' ),
				'description' => __( 'Optional: one entry per line in “category ID | label” format. Category IDs are listed in Products → Categories.', 'yusraah' ),
				'section'     => 'yusraah_quick_deal',
			)
		)
	);

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial(
			'yusraah_quick_deal_panel',
			array(
				'selector'            => '.story-section__slider',
				'settings'            => array_merge(
					array( 'yusraah_quick_deal_categories', 'yusraah_quick_deal_labels' ),
					array_map(
						static function ( $key ) {
							return 'yusraah_quick_deal_' . $key;
						},
						array_keys( $settings )
					)
				),
				'render_callback'     => 'yusraah_render_quick_deal_panel',
				'container_inclusive'  => false,
			)
		);
	}
}
add_action( 'customize_register', 'yusraah_quick_deal_customize_register', 20 );

/**
 * Declare custom controls after WordPress loads its Customizer control base.
 */
function yusraah_quick_deal_register_customizer_controls() {
	if ( ! class_exists( 'WP_Customize_Control' ) ) {
		return;
	}

	if ( ! class_exists( 'Yusraah_Quick_Deal_Categories_Control' ) ) {
		/**
		 * Category ID checklist control for Quick Deal.
		 */
		class Yusraah_Quick_Deal_Categories_Control extends WP_Customize_Control {
			/**
			 * Control type.
			 *
			 * @var string
			 */
			public $type = 'yusraah_quick_deal_categories';

			/**
			 * Render category checkboxes.
			 */
			public function render_content() {
				$selected = array();
				foreach ( (array) $this->value() as $term_id ) {
					if ( is_scalar( $term_id ) ) {
						$selected[] = absint( $term_id );
					}
				}
				$terms = get_terms(
					array(
						'taxonomy'   => 'product_cat',
						'hide_empty' => false,
						'orderby'    => 'name',
						'order'      => 'ASC',
					)
				);
				?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php if ( $this->description ) : ?>
					<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
				<?php endif; ?>
				<div class="yusraah-quick-deal-category-list">
					<?php if ( ! is_wp_error( $terms ) && $terms ) : ?>
						<?php foreach ( $terms as $term ) : ?>
							<label>
								<input type="checkbox" data-quick-deal-category="<?php echo esc_attr( $term->term_id ); ?>" <?php checked( in_array( (int) $term->term_id, $selected, true ) ); ?>>
								<?php echo esc_html( $term->name ); ?> (#<?php echo esc_html( $term->term_id ); ?>)
							</label>
						<?php endforeach; ?>
					<?php else : ?>
						<p><?php esc_html_e( 'Create product categories to choose Quick Deal tabs.', 'yusraah' ); ?></p>
					<?php endif; ?>
				</div>
				<?php
			}
		}
	}

	if ( ! class_exists( 'Yusraah_Quick_Deal_Labels_Control' ) ) {
		/**
		 * Per-category custom tab label control.
		 */
		class Yusraah_Quick_Deal_Labels_Control extends WP_Customize_Control {
			/**
			 * Control type.
			 *
			 * @var string
			 */
			public $type = 'yusraah_quick_deal_labels';

			/**
			 * Render the ID/label repeater input.
			 */
			public function render_content() {
				$labels = (array) $this->value();
				$lines  = array();
				foreach ( $labels as $term_id => $label ) {
					if ( is_scalar( $label ) ) {
						$lines[] = absint( $term_id ) . ' | ' . sanitize_text_field( $label );
					}
				}
				?>
				<label>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<?php if ( $this->description ) : ?>
						<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
					<?php endif; ?>
					<textarea rows="5" data-quick-deal-labels><?php echo esc_textarea( implode( "\n", $lines ) ); ?></textarea>
				</label>
				<?php
			}
		}
	}
}

/**
 * Sanitize selected product category IDs.
 *
 * @param mixed $value Raw IDs.
 * @return int[]
 */
function yusraah_quick_deal_sanitize_categories( $value ) {
	if ( ! is_array( $value ) ) {
		return array();
	}
	$ids = array();
	foreach ( $value as $raw_id ) {
		if ( is_scalar( $raw_id ) && absint( $raw_id ) ) {
			$ids[] = absint( $raw_id );
		}
	}
	$ids = array_values( array_unique( $ids ) );
	return array_slice( $ids, 0, 6 );
}

/**
 * Sanitize category ID => custom label rows.
 *
 * @param mixed $value Raw label rows.
 * @return array<int,string>
 */
function yusraah_quick_deal_sanitize_labels( $value ) {
	if ( ! is_array( $value ) ) {
		return array();
	}
	$labels = array();
	foreach ( $value as $term_id => $label ) {
		if ( ! is_scalar( $label ) ) {
			continue;
		}
		$term_id = absint( $term_id );
		$label   = sanitize_text_field( $label );
		if ( $term_id && '' !== $label && term_exists( $term_id, 'product_cat' ) ) {
			$labels[ $term_id ] = $label;
		}
	}
	return $labels;
}

/**
 * Sanitize the product order.
 *
 * @param mixed $value Raw order.
 * @return string
 */
function yusraah_quick_deal_sanitize_order( $value ) {
	$allowed = array( 'latest', 'bestselling', 'top_rated', 'on_sale', 'random' );
	return in_array( $value, $allowed, true ) ? $value : 'latest';
}

/**
 * Sanitize product limit.
 *
 * @param mixed $value Raw number.
 * @return int
 */
function yusraah_quick_deal_sanitize_limit( $value ) {
	return max( 1, min( 12, absint( $value ) ) );
}

/**
 * Sanitize the number of visible desktop slides.
 *
 * @param mixed $value Raw number.
 * @return int
 */
function yusraah_quick_deal_sanitize_view_desktop( $value ) {
	return max( 1, min( 3, absint( $value ) ) );
}

/**
 * Sanitize the number of visible tablet slides.
 *
 * @param mixed $value Raw number.
 * @return int
 */
function yusraah_quick_deal_sanitize_view_tablet( $value ) {
	return max( 1, min( 2, absint( $value ) ) );
}

/**
 * Sanitize the number of visible mobile slides.
 *
 * @param mixed $value Raw number.
 * @return int
 */
function yusraah_quick_deal_sanitize_view_mobile( $value ) {
	return max( 1, min( 2, absint( $value ) ) );
}

/**
 * Return the selected category IDs, or top categories when none are selected.
 *
 * @return int[]
 */
function yusraah_quick_deal_category_ids() {
	$ids = yusraah_quick_deal_sanitize_categories( get_theme_mod( 'yusraah_quick_deal_categories', array() ) );
	if ( $ids ) {
		return $ids;
	}

	$cache_key = 'yusraah_quick_deal_fallback_category_ids';
	$cached    = get_transient( $cache_key );
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => true,
			'orderby'    => 'count',
			'order'      => 'DESC',
			'number'     => 18,
		)
	);
	if ( is_wp_error( $terms ) || ! $terms ) {
		return array();
	}
	$ids = array();
	foreach ( $terms as $term ) {
		if ( yusraah_quick_deal_query_products( $term->term_id, 1 ) ) {
			$ids[] = absint( $term->term_id );
		}
		if ( count( $ids ) >= 6 ) {
			break;
		}
	}
	set_transient( $cache_key, $ids, 30 * MINUTE_IN_SECONDS );
	return $ids;
}

/**
 * Build the product query for a Quick Deal category.
 *
 * @param int|int[] $category_id Product category term ID(s); zero means all products.
 * @param int       $limit       Number of products.
 * @param array     $options     Optional explicit order and sale settings.
 * @return WC_Product[]
 */
function yusraah_quick_deal_query_products( $category_id, $limit, $options = array() ) {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}
	$category_ids = is_array( $category_id ) ? array_values( array_unique( array_filter( array_map( 'absint', $category_id ) ) ) ) : ( absint( $category_id ) ? array( absint( $category_id ) ) : array() );
	$category_slugs = array();
	foreach ( $category_ids as $term_id ) {
		$term = get_term( $term_id, 'product_cat' );
		if ( ! $term || is_wp_error( $term ) ) {
			continue;
		}
		$category_slugs[] = $term->slug;
	}
	if ( $category_ids && ! $category_slugs ) {
		return array();
	}

	$order        = yusraah_quick_deal_sanitize_order( isset( $options['order'] ) ? $options['order'] : get_theme_mod( 'yusraah_quick_deal_order', 'latest' ) );
	$on_sale_only = ( isset( $options['on_sale_only'] ) ? (bool) $options['on_sale_only'] : (bool) get_theme_mod( 'yusraah_quick_deal_on_sale_only', false ) ) || 'on_sale' === $order;
	$query_limit = min( 48, max( 12, absint( $limit ) * 3 ) );
	$orderby     = 'date' === $order ? 'date' : ( 'rand' === $order ? 'rand' : 'title' );
	$args        = array(
		'status'            => 'publish',
		'limit'             => $query_limit,
		'return'            => 'objects',
		'stock_status'      => 'instock',
		'visibility'        => 'visible',
		'orderby'           => $orderby,
		'order'             => 'DESC',
	);

	if ( $category_slugs ) {
		$args['category'] = $category_slugs;
	}

	switch ( $order ) {
		case 'bestselling':
			$args['orderby'] = 'popularity';
			break;
		case 'top_rated':
			$args['orderby'] = 'rating';
			break;
		case 'random':
			$args['orderby'] = 'rand';
			break;
		case 'on_sale':
			$args['orderby'] = 'date';
			break;
		case 'latest':
		default:
			$args['orderby'] = 'date';
			break;
	}

	if ( $on_sale_only ) {
		$sale_ids = wc_get_product_ids_on_sale();
		if ( ! $sale_ids ) {
			return array();
		}
		$sale_ids = array_slice( array_map( 'absint', $sale_ids ), 0, 1000 );
		if ( $category_slugs ) {
			$category_products = wc_get_products(
				array(
					'status'       => 'publish',
					'limit'        => -1,
					'return'       => 'ids',
					'category'     => $category_slugs,
					'stock_status' => 'instock',
					'visibility'   => 'visible',
				)
			);
			$sale_ids = array_values( array_intersect( $sale_ids, array_map( 'absint', (array) $category_products ) ) );
		}
		$args['include'] = $sale_ids;
		$args['limit']   = max( 1, min( 48, count( $sale_ids ) ) );
		if ( ! $args['include'] ) {
			return array();
		}
	}

	$wanted        = max( 1, min( 12, absint( $limit ) ) );
	$batch_size    = max( 12, min( 48, absint( $query_limit ) ) );
	$eligible      = array();
	$seen_products = array();
	$page          = 1;

	do {
		$args['page']  = $page;
		$candidates    = wc_get_products( $args );
		$candidates    = is_array( $candidates ) ? $candidates : array();
		foreach ( $candidates as $product ) {
			if ( ! $product instanceof WC_Product || ! $product->is_visible() || ! $product->is_in_stock() || ! $product->is_purchasable() ) {
				continue;
			}
			$product_id = $product->get_id();
			if ( isset( $seen_products[ $product_id ] ) ) {
				continue;
			}
			$seen_products[ $product_id ] = true;
			$eligible[]                   = $product;
			if ( count( $eligible ) >= $wanted ) {
				break;
			}
		}
		++$page;
	} while ( count( $eligible ) < $wanted && count( $candidates ) >= $batch_size && $page <= 10 );

	return $eligible;
}

/**
 * Fetch a cached category product list.
 *
 * @param int|int[] $category_id Product category ID(s) or zero for all.
 * @param array     $options     Optional explicit limit, order, and cache key.
 * @return WC_Product[]
 */
function yusraah_quick_deal_get_products( $category_id, $options = array() ) {
	if ( ! function_exists( 'wc_get_product' ) ) {
		return array();
	}
	$limit         = yusraah_quick_deal_sanitize_limit( isset( $options['limit'] ) ? $options['limit'] : get_theme_mod( 'yusraah_quick_deal_limit', 8 ) );
	$order         = yusraah_quick_deal_sanitize_order( isset( $options['order'] ) ? $options['order'] : get_theme_mod( 'yusraah_quick_deal_order', 'latest' ) );
	$on_sale_only  = isset( $options['on_sale_only'] ) ? (bool) $options['on_sale_only'] : (bool) get_theme_mod( 'yusraah_quick_deal_on_sale_only', false );
	$category_key  = is_array( $category_id ) ? array_values( array_unique( array_filter( array_map( 'absint', $category_id ) ) ) ) : absint( $category_id );
	$cache_context = isset( $options['cache_context'] ) ? sanitize_key( $options['cache_context'] ) : '';
	$key_data      = array( $category_key, $limit, $order, $on_sale_only );
	$key           = 'yusraah_quick_deal_' . ( $cache_context ? $cache_context . '_' : '' ) . md5( wp_json_encode( $key_data ) );
	$ids   = get_transient( $key );
	if ( ! is_array( $ids ) ) {
		$products = yusraah_quick_deal_query_products(
			$category_key,
			$limit,
			array(
				'order'        => $order,
				'on_sale_only' => $on_sale_only,
			)
		);
		$ids      = array_map(
			static function ( $product ) {
				return $product->get_id();
			},
			$products
		);
		set_transient( $key, $ids, 30 * MINUTE_IN_SECONDS );
	} else {
		$products = array_values(
			array_filter(
				array_map( 'wc_get_product', $ids ),
				static function ( $product ) {
					return $product instanceof WC_Product && $product->is_visible() && $product->is_in_stock() && $product->is_purchasable();
				}
			)
		);
		if ( count( $products ) > $limit ) {
			$products = array_slice( $products, 0, $limit );
		}
	}
	return array_slice( $products, 0, $limit );
}

/**
 * Invalidate cached Quick Deal tab results after catalog changes.
 */
function yusraah_quick_deal_clear_cache() {
	global $wpdb;
	$transient_like = $wpdb->esc_like( '_transient_yusraah_quick_deal_' ) . '%';
	$timeout_like  = $wpdb->esc_like( '_transient_timeout_yusraah_quick_deal_' ) . '%';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $transient_like, $timeout_like ) );
	delete_transient( 'yusraah_quick_deal_fallback_category_ids' );
}
add_action( 'save_post_product', 'yusraah_quick_deal_clear_cache' );
add_action( 'woocommerce_update_product', 'yusraah_quick_deal_clear_cache' );
add_action( 'woocommerce_update_product_variation', 'yusraah_quick_deal_clear_cache' );
add_action( 'save_post_product_variation', 'yusraah_quick_deal_clear_cache' );
add_action( 'woocommerce_trash_product', 'yusraah_quick_deal_clear_cache' );
add_action( 'woocommerce_delete_product', 'yusraah_quick_deal_clear_cache' );
add_action( 'woocommerce_delete_product_variation', 'yusraah_quick_deal_clear_cache' );
add_action( 'woocommerce_product_set_stock', 'yusraah_quick_deal_clear_cache' );
add_action( 'woocommerce_variation_set_stock', 'yusraah_quick_deal_clear_cache' );
add_action( 'edited_product_cat', 'yusraah_quick_deal_clear_cache' );
add_action( 'created_product_cat', 'yusraah_quick_deal_clear_cache' );
add_action( 'delete_product_cat', 'yusraah_quick_deal_clear_cache' );
add_action( 'set_object_terms', 'yusraah_quick_deal_terms_changed', 10, 4 );

/**
 * Clear caches when a product's category relationships change.
 *
 * @param int    $object_id Object ID.
 * @param array  $terms     Terms.
 * @param array  $tt_ids    Term taxonomy IDs.
 * @param string $taxonomy  Taxonomy name.
 */
function yusraah_quick_deal_terms_changed( $object_id, $terms, $tt_ids, $taxonomy ) {
	unset( $terms, $tt_ids );
	if ( 'product_cat' === $taxonomy && 'product' === get_post_type( $object_id ) ) {
		yusraah_quick_deal_clear_cache();
	}
}

/**
 * Return eligible tab data with products available for each category.
 *
 * @return array<int,array<string,mixed>>
 */
function yusraah_quick_deal_tabs() {
	$tabs       = array();
	$categories = yusraah_quick_deal_category_ids();
	$labels     = (array) get_theme_mod( 'yusraah_quick_deal_labels', array() );

	foreach ( $categories as $term_id ) {
		$term = get_term( $term_id, 'product_cat' );
		if ( ! $term || is_wp_error( $term ) ) {
			continue;
		}
		$products = yusraah_quick_deal_get_products( $term_id );
		if ( ! $products ) {
			continue;
		}
		$url = get_term_link( $term );
		if ( is_wp_error( $url ) ) {
			continue;
		}
		$tabs[] = array(
			'id'       => $term_id,
			'label'    => isset( $labels[ $term_id ] ) && '' !== $labels[ $term_id ] ? sanitize_text_field( $labels[ $term_id ] ) : $term->name,
			'url'      => $url,
			'products' => $products,
		);
	}

	$all_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
	$all_products = get_theme_mod( 'yusraah_quick_deal_all_tab', true ) && $tabs ? yusraah_quick_deal_get_products( 0 ) : array();
	if ( $all_products ) {
		array_unshift(
			$tabs,
			array(
				'id'       => 0,
				'label'    => __( 'All', 'yusraah' ),
				'url'      => $all_url,
				'products' => $all_products,
			)
		);
	}
	if ( ! $tabs ) {
		$all_products = yusraah_quick_deal_get_products( 0 );
		if ( $all_products ) {
			$tabs[] = array(
				'id'       => 0,
				'label'    => __( 'All', 'yusraah' ),
				'url'      => $all_url,
				'products' => $all_products,
			);
		}
	}
	return $tabs;
}

/**
 * Render the Quick Deal panel and first tab server-side.
 *
 * @return string
 */
function yusraah_render_quick_deal_panel() {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return '';
	}
	$show_tabs = (bool) get_theme_mod( 'yusraah_quick_deal_show_tabs', true );
	$tabs      = $show_tabs ? yusraah_quick_deal_tabs() : array();
	$title     = get_theme_mod( 'yusraah_quick_deal_title', __( 'Quick Deal', 'yusraah' ) );
	$subtitle  = get_theme_mod( 'yusraah_quick_deal_subtitle', '' );
	$has_tabs  = $show_tabs && count( $tabs ) > 0;
	$active    = $tabs ? $tabs[0] : array(
		'id'       => 0,
		'label'    => __( 'All', 'yusraah' ),
		'url'      => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' ),
		'products' => yusraah_quick_deal_get_products( 0 ),
	);
	$slider    = $active['products'] ? yusraah_render_slider( 'story', $active['products'], true ) : '';
	$panel_id  = 'quick-deal-panel-' . absint( $active['id'] );

	ob_start();
	?>
	<div class="quick-deal" data-quick-deal data-active-category="<?php echo esc_attr( absint( $active['id'] ) ); ?>">
		<header class="quick-deal__header">
			<div>
				<h3 class="quick-deal__title"><?php echo esc_html( $title ); ?></h3>
				<?php if ( $subtitle ) : ?>
					<p class="quick-deal__subtitle"><?php echo esc_html( $subtitle ); ?></p>
				<?php endif; ?>
			</div>
			<a class="quick-deal__view-all" data-quick-deal-view-all href="<?php echo esc_url( $active['url'] ); ?>"><?php esc_html_e( 'View all', 'yusraah' ); ?> <span aria-hidden="true">→</span></a>
		</header>

		<?php if ( $has_tabs ) : ?>
			<div class="quick-deal__tabs" role="tablist" aria-label="<?php esc_attr_e( 'Quick Deal product categories', 'yusraah' ); ?>" data-quick-deal-tabs>
				<?php foreach ( $tabs as $index => $tab ) : ?>
					<a
						id="<?php echo esc_attr( 'quick-deal-tab-' . absint( $tab['id'] ) ); ?>"
						class="quick-deal__tab<?php echo 0 === $index ? ' is-active' : ''; ?>"
						role="tab"
						aria-selected="<?php echo 0 === $index ? 'true' : 'false'; ?>"
						aria-controls="<?php echo esc_attr( $panel_id ); ?>"
						tabindex="<?php echo 0 === $index ? '0' : '-1'; ?>"
						href="<?php echo esc_url( $tab['url'] ); ?>"
						data-quick-deal-tab
						data-category-id="<?php echo esc_attr( absint( $tab['id'] ) ); ?>"
						data-category-url="<?php echo esc_url( $tab['url'] ); ?>"
						title="<?php echo esc_attr( $tab['label'] ); ?>"
					><?php echo esc_html( $tab['label'] ); ?></a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<div
			class="quick-deal__panel"
			id="<?php echo esc_attr( $panel_id ); ?>"
			<?php if ( $has_tabs ) : ?>
				role="tabpanel"
				aria-labelledby="<?php echo esc_attr( 'quick-deal-tab-' . absint( $active['id'] ) ); ?>"
			<?php else : ?>
				role="region"
				aria-label="<?php esc_attr_e( 'Quick Deal products', 'yusraah' ); ?>"
			<?php endif; ?>
			tabindex="0"
			data-quick-deal-panel
			data-quick-deal-loaded="<?php echo $slider ? 'true' : 'false'; ?>"
			aria-live="polite"
		>
			<?php
			if ( $slider ) {
				echo $slider; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Rendered by the escaped theme slider renderer.
			} else {
				echo '<p class="quick-deal__empty">' . esc_html__( 'No purchasable products are available in this selection.', 'yusraah' ) . '</p>';
			}
			?>
		</div>
		<p class="screen-reader-text" data-quick-deal-status role="status" aria-live="polite"></p>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Render a category's slider for the lazy tab AJAX request.
 */
function yusraah_quick_deal_load_tab() {
	if ( ! check_ajax_referer( 'yusraah_quick_deal', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => __( 'Your session expired. Reload the page and try again.', 'yusraah' ) ), 403 );
	}
	$raw_category_id = isset( $_POST['category_id'] ) && is_scalar( $_POST['category_id'] ) ? (string) wp_unslash( $_POST['category_id'] ) : '';
	if ( ! preg_match( '/^\d+$/', $raw_category_id ) ) {
		wp_send_json_error( array( 'message' => __( 'That product category is not available.', 'yusraah' ) ), 400 );
	}
	$category_id = absint( $raw_category_id );
	$allowed     = yusraah_quick_deal_category_ids();
	$allow_all   = get_theme_mod( 'yusraah_quick_deal_all_tab', true ) && $allowed;
	if ( ! in_array( $category_id, $allowed, true ) && ! ( 0 === $category_id && $allow_all ) ) {
		wp_send_json_error( array( 'message' => __( 'That product category is not available.', 'yusraah' ) ), 400 );
	}

	$products = yusraah_quick_deal_get_products( $category_id );
	if ( ! $products ) {
		wp_send_json_success( array( 'html' => '<p class="quick-deal__empty">' . esc_html__( 'No purchasable products are available in this selection.', 'yusraah' ) . '</p>' ) );
	}
	wp_send_json_success( array( 'html' => yusraah_render_slider( 'story', $products, true ) ) );
}
add_action( 'wp_ajax_yusraah_quick_deal_load', 'yusraah_quick_deal_load_tab' );
add_action( 'wp_ajax_nopriv_yusraah_quick_deal_load', 'yusraah_quick_deal_load_tab' );

/**
 * Load the small Customizer control script.
 */
function yusraah_quick_deal_customizer_assets() {
	$path = get_template_directory() . '/assets/js/quick-deal-customizer.js';
	wp_enqueue_script(
		'yusraah-quick-deal-customizer',
		get_template_directory_uri() . '/assets/js/quick-deal-customizer.js',
		array( 'customize-controls' ),
		file_exists( $path ) ? filemtime( $path ) : YUSRAAH_VERSION,
		true
	);
	wp_localize_script(
		'yusraah-quick-deal-customizer',
		'yusraahQuickDealCustomizer',
		array(
			'moveUp'   => __( 'Move up: %s', 'yusraah' ),
			'moveDown' => __( 'Move down: %s', 'yusraah' ),
			'order'    => __( 'Selected tab order', 'yusraah' ),
		)
	);
}
add_action( 'customize_controls_enqueue_scripts', 'yusraah_quick_deal_customizer_assets' );
