<?php
/**
 * Reusable Product Slider Component.
 *
 * Provides:
 *  - Customizer sections for multiple sliders (Hero and Story section).
 *  - Cached WC_Product_Query via transient (cleared on product save/trash).
 *  - Accessible ARIA carousel markup with prev/next and dots.
 *  - Lightweight vanilla-JS slider (auto-slide, pause on hover/focus/
 *    visibility change, touch swipe, prefers-reduced-motion, keyboard).
 *  - Performance: first-slide image fetchpriority="high", rest lazy-loaded,
 *    width/height/srcset set, no layout shift.
 *  - Assets loaded only on the front page (is_front_page()).
 *  - Multiple independent slider instances on the same page.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* -----------------------------------------------------------------------
 * 1. CUSTOMIZER SETTINGS
 * --------------------------------------------------------------------- */

/**
 * Register Customizer sections for product sliders.
 *
 * @param WP_Customize_Manager $wp_customize Customizer instance.
 */
function yusraah_product_slider_customize_register( $wp_customize ) {

	/* --------------------------------------------------------
	   HERO SLIDER SECTION
	   -------------------------------------------------------- */
	$wp_customize->add_section( 'yusraah_hero_slider', array(
		'title'       => __( 'Homepage Hero Slider', 'yusraah' ),
		'description' => __( 'Configure the product slider in the homepage hero.', 'yusraah' ),
		'priority'    => 36,
	) );

	/* --- Source -------------------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_hero_source', array(
		'default'           => 'featured',
		'sanitize_callback' => 'yusraah_sanitize_slider_source',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_hero_source', array(
		'label'   => __( 'Product source', 'yusraah' ),
		'section' => 'yusraah_hero_slider',
		'type'    => 'select',
		'choices' => array(
			'featured'   => __( 'Featured products', 'yusraah' ),
			'bestseller' => __( 'Best sellers', 'yusraah' ),
			'onsale'     => __( 'On sale', 'yusraah' ),
			'newest'     => __( 'Newest', 'yusraah' ),
			'category'   => __( 'Specific product category', 'yusraah' ),
		),
	) );

	/* --- Category (shown when source = category) ---------------------- */
	$wp_customize->add_setting( 'yusraah_hero_category', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );

	// Build category choices.
	$cat_choices = array( '' => __( '— Select category —', 'yusraah' ) );
	if ( function_exists( 'get_terms' ) ) {
		$cats = get_terms( array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => true,
		) );
		if ( ! is_wp_error( $cats ) ) {
			foreach ( $cats as $cat ) {
				$cat_choices[ $cat->slug ] = $cat->name;
			}
		}
	}
	$wp_customize->add_control( 'yusraah_hero_category', array(
		'label'           => __( 'Product category', 'yusraah' ),
		'description'     => __( 'Only used when source is "Specific product category".', 'yusraah' ),
		'section'         => 'yusraah_hero_slider',
		'type'            => 'select',
		'choices'         => $cat_choices,
	) );

	/* --- Number of products ------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_hero_limit', array(
		'default'           => 6,
		'sanitize_callback' => 'yusraah_sanitize_slider_limit',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_hero_limit', array(
		'label'       => __( 'Number of products (4 – 12)', 'yusraah' ),
		'section'     => 'yusraah_hero_slider',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 4, 'max' => 12, 'step' => 1 ),
	) );

	/* --- Autoplay on/off ---------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_hero_autoplay', array(
		'default'           => true,
		'sanitize_callback' => 'rest_sanitize_boolean',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_hero_autoplay', array(
		'label'   => __( 'Enable autoplay', 'yusraah' ),
		'section' => 'yusraah_hero_slider',
		'type'    => 'checkbox',
	) );

	/* --- Autoplay speed ----------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_hero_speed', array(
		'default'           => 4500,
		'sanitize_callback' => 'yusraah_sanitize_slider_speed',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_hero_speed', array(
		'label'       => __( 'Autoplay speed (ms, 2000 – 8000)', 'yusraah' ),
		'section'     => 'yusraah_hero_slider',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 2000, 'max' => 8000, 'step' => 500 ),
	) );

	/* --------------------------------------------------------
	   STORY SECTION SLIDER
	   -------------------------------------------------------- */
	$wp_customize->add_section( 'yusraah_story_slider', array(
		'title'       => __( 'Homepage Product Slider (Story Section)', 'yusraah' ),
		'description' => __( 'Configure the product slider in the story section.', 'yusraah' ),
		'priority'    => 37,
	) );

	/* --- Show/hide section --------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_story_slider_show', array(
		'default'           => true,
		'sanitize_callback' => 'rest_sanitize_boolean',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_story_slider_show', array(
		'label'   => __( 'Show product slider in story section', 'yusraah' ),
		'section' => 'yusraah_story_slider',
		'type'    => 'checkbox',
	) );

	/* --- Section heading ----------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_story_heading', array(
		'default'           => __( 'Good things get', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'yusraah_story_heading', array(
		'label'   => __( 'Section heading', 'yusraah' ),
		'section' => 'yusraah_story_slider',
		'type'    => 'text',
	) );

	/* --- Section subtext ----------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_story_subtext', array(
		'default'           => __( 'We believe the best pieces earn their place. Each find is chosen for thoughtful construction, honest materials, and the feeling that it will still be loved years from now.', 'yusraah' ),
		'sanitize_callback' => 'sanitize_textarea_field',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'yusraah_story_subtext', array(
		'label'   => __( 'Section subtext', 'yusraah' ),
		'section' => 'yusraah_story_slider',
		'type'    => 'textarea',
	) );

	/* --- Button text ---------------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_story_button_text', array(
		'default'           => __( 'Find your forever piece', 'yusraah' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'yusraah_story_button_text', array(
		'label'   => __( 'Button text', 'yusraah' ),
		'section' => 'yusraah_story_slider',
		'type'    => 'text',
	) );

	/* --- Button link ---------------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_story_button_link', array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'yusraah_story_button_link', array(
		'label'   => __( 'Button link', 'yusraah' ),
		'section' => 'yusraah_story_slider',
		'type'    => 'url',
	) );

	/* --- Source -------------------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_story_source', array(
		'default'           => 'featured',
		'sanitize_callback' => 'yusraah_sanitize_slider_source',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_story_source', array(
		'label'   => __( 'Product source', 'yusraah' ),
		'section' => 'yusraah_story_slider',
		'type'    => 'select',
		'choices' => array(
			'featured'   => __( 'Featured products', 'yusraah' ),
			'bestseller' => __( 'Best sellers', 'yusraah' ),
			'onsale'     => __( 'On sale', 'yusraah' ),
			'newest'     => __( 'Newest', 'yusraah' ),
			'category'   => __( 'Specific product category', 'yusraah' ),
		),
	) );

	/* --- Category (shown when source = category) ---------------------- */
	$wp_customize->add_setting( 'yusraah_story_category', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_story_category', array(
		'label'           => __( 'Product category', 'yusraah' ),
		'description'     => __( 'Only used when source is "Specific product category".', 'yusraah' ),
		'section'         => 'yusraah_story_slider',
		'type'            => 'select',
		'choices'         => $cat_choices,
	) );

	/* --- Number of products ------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_story_limit', array(
		'default'           => 6,
		'sanitize_callback' => 'yusraah_sanitize_slider_limit',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_story_limit', array(
		'label'       => __( 'Number of products (4 – 12)', 'yusraah' ),
		'section'     => 'yusraah_story_slider',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 4, 'max' => 12, 'step' => 1 ),
	) );

	/* --- Autoplay on/off ---------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_story_autoplay', array(
		'default'           => true,
		'sanitize_callback' => 'rest_sanitize_boolean',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_story_autoplay', array(
		'label'   => __( 'Enable autoplay', 'yusraah' ),
		'section' => 'yusraah_story_slider',
		'type'    => 'checkbox',
	) );

	/* --- Autoplay speed ----------------------------------------------- */
	$wp_customize->add_setting( 'yusraah_story_speed', array(
		'default'           => 4500,
		'sanitize_callback' => 'yusraah_sanitize_slider_speed',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( 'yusraah_story_speed', array(
		'label'       => __( 'Autoplay speed (ms, 2000 – 8000)', 'yusraah' ),
		'section'     => 'yusraah_story_slider',
		'type'        => 'number',
		'input_attrs' => array( 'min' => 2000, 'max' => 8000, 'step' => 500 ),
	) );
}
add_action( 'customize_register', 'yusraah_product_slider_customize_register' );

/* Sanitize callbacks ---------------------------------------------------- */

/**
 * Sanitize slider product source.
 *
 * @param string $value Raw value.
 * @return string
 */
function yusraah_sanitize_slider_source( $value ) {
	$allowed = array( 'featured', 'bestseller', 'onsale', 'newest', 'category' );
	return in_array( $value, $allowed, true ) ? $value : 'featured';
}

/**
 * Sanitize slider product limit (4-12).
 *
 * @param mixed $value Raw value.
 * @return int
 */
function yusraah_sanitize_slider_limit( $value ) {
	$int = absint( $value );
	return max( 4, min( 12, $int ) );
}

/**
 * Sanitize slider autoplay speed (2000-8000).
 *
 * @param mixed $value Raw value.
 * @return int
 */
function yusraah_sanitize_slider_speed( $value ) {
	$int = absint( $value );
	return max( 2000, min( 8000, $int ) );
}

/* -----------------------------------------------------------------------
 * 2. PRODUCT QUERY (cached with transient)
 * --------------------------------------------------------------------- */

/**
 * Transient key for slider products.
 *
 * @param string $slider_id Slider identifier (hero or story).
 * @return string
 */
function yusraah_slider_transient_key( $slider_id ) {
	$source   = get_theme_mod( 'yusraah_' . $slider_id . '_source', 'featured' );
	$category = get_theme_mod( 'yusraah_' . $slider_id . '_category', '' );
	$limit    = get_theme_mod( 'yusraah_' . $slider_id . '_limit', 6 );
	return 'yusraah_slider_products_' . $slider_id . '_' . md5( $source . '_' . $category . '_' . $limit );
}

/**
 * Clear all slider transients when products are saved or deleted.
 */
function yusraah_slider_clear_cache() {
	global $wpdb;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$wpdb->query(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_yusraah_slider_products_%'
		  OR option_name LIKE '_transient_timeout_yusraah_slider_products_%'"
	);
}
add_action( 'save_post_product', 'yusraah_slider_clear_cache' );
add_action( 'woocommerce_trash_product', 'yusraah_slider_clear_cache' );
add_action( 'woocommerce_update_product', 'yusraah_slider_clear_cache' );

/**
 * Fetch slider products, using a 6-hour transient cache.
 *
 * @param string $slider_id Slider identifier (hero or story).
 * @return WC_Product[]
 */
function yusraah_slider_get_products( $slider_id ) {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return array();
	}

	$transient_key = yusraah_slider_transient_key( $slider_id );
	$cached        = get_transient( $transient_key );

	if ( false !== $cached && is_array( $cached ) ) {
		// Hydrate product objects from cached IDs.
		$products = array_filter(
			array_map( 'wc_get_product', $cached ),
			function( $p ) {
				return $p instanceof WC_Product && $p->is_in_stock() && $p->is_visible();
			}
		);
		if ( ! empty( $products ) ) {
			return array_values( $products );
		}
	}

	$source   = get_theme_mod( 'yusraah_' . $slider_id . '_source', 'featured' );
	$category = get_theme_mod( 'yusraah_' . $slider_id . '_category', '' );
	$limit    = yusraah_sanitize_slider_limit( get_theme_mod( 'yusraah_' . $slider_id . '_limit', 6 ) );

	$args = array(
		'status'       => 'publish',
		'limit'        => $limit,
		'return'       => 'objects',
		'stock_status' => 'instock',
	);

	switch ( $source ) {
		case 'bestseller':
			$args['orderby'] = 'popularity';
			$args['order']   = 'DESC';
			break;
		case 'onsale':
			$on_sale_ids = wc_get_product_ids_on_sale();
			if ( empty( $on_sale_ids ) ) {
				return array();
			}
			$args['include'] = $on_sale_ids;
			$args['orderby'] = 'date';
			$args['order']   = 'DESC';
			break;
		case 'newest':
			$args['orderby'] = 'date';
			$args['order']   = 'DESC';
			break;
		case 'category':
			if ( ! empty( $category ) ) {
				$args['category'] = array( sanitize_title( $category ) );
			}
			$args['orderby'] = 'date';
			$args['order']   = 'DESC';
			break;
		case 'featured':
		default:
			$args['featured'] = true;
			$args['orderby']  = 'date';
			$args['order']    = 'DESC';
			break;
	}

	$products = wc_get_products( $args );

	// Fallback to newest if nothing found.
	if ( empty( $products ) && 'newest' !== $source ) {
		$products = wc_get_products( array(
			'status'       => 'publish',
			'limit'        => $limit,
			'return'       => 'objects',
			'stock_status' => 'instock',
			'orderby'      => 'date',
			'order'        => 'DESC',
		) );
	}

	// Filter: in-stock and visible.
	$products = array_values( array_filter(
		(array) $products,
		function( $p ) {
			return $p instanceof WC_Product && $p->is_in_stock() && $p->is_visible();
		}
	) );

	// Cache product IDs for 6 hours.
	$ids = array_map( function( $p ) { return $p->get_id(); }, $products );
	set_transient( $transient_key, $ids, 6 * HOUR_IN_SECONDS );

	return $products;
}

/* -----------------------------------------------------------------------
 * 3. RENDER SLIDER MARKUP (reusable)
 * --------------------------------------------------------------------- */

/**
 * Render a single slide card for a WC_Product.
 *
 * Uses the real WooCommerce product card template via wc_get_template_part
 * so AJAX add-to-cart and all WC hooks apply correctly.
 *
 * @param WC_Product $product   The product.
 * @param int        $index     Slide index (0-based) for lazy-load logic.
 * @param int        $total     Total slide count.
 * @param string     $slider_id Slider identifier for unique IDs.
 * @param bool       $native_cart Whether to use WooCommerce's loop button.
 * @param bool       $show_rating Whether to show the product rating.
 * @param bool       $bundle_badge Whether to identify WPC bundle products.
 * @param bool       $bundle_details Whether to render Monthly Kits bundle details.
 */
function yusraah_slider_render_slide( $product, $index, $total, $slider_id, $native_cart = false, $show_rating = false, $bundle_badge = false, $bundle_details = false ) {
	global $post;
	$previous_post    = isset( $post ) ? $post : null;
	$previous_product = isset( $GLOBALS['product'] ) ? $GLOBALS['product'] : null;

	// Temporarily set up the global $post so WC template functions work.
	$post = get_post( $product->get_id() ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
	$GLOBALS['product'] = $product;
	setup_postdata( $post );

	$product_id   = $product->get_id();
	$image_id     = $product->get_image_id();
	$is_first     = ( 0 === $index );

	// Build the image with correct srcset, sizes, width, height.
	$image_html = '';
	if ( $image_id ) {
		$img_src    = wp_get_attachment_image_url( $image_id, 'medium' );
		$img_srcset = wp_get_attachment_image_srcset( $image_id, 'medium' );
		$img_sizes  = '(max-width: 640px) 100vw, 400px';
		$img_meta   = wp_get_attachment_metadata( $image_id );
		$img_width  = isset( $img_meta['width'] ) ? (int) $img_meta['width'] : 0;
		$img_height = isset( $img_meta['height'] ) ? (int) $img_meta['height'] : 0;
		$img_alt    = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
		if ( empty( $img_alt ) ) {
			$img_alt = $product->get_name();
		}

		$attrs = array(
			'src'   => esc_url( $img_src ),
			'alt'   => esc_attr( $img_alt ),
			'sizes' => esc_attr( $img_sizes ),
		);
		if ( $img_width && $img_height ) {
			$attrs['width']  = $img_width;
			$attrs['height'] = $img_height;
		}
		if ( $img_srcset ) {
			$attrs['srcset'] = esc_attr( $img_srcset );
		}
		if ( $is_first && 'hero' === $slider_id ) {
			$attrs['fetchpriority'] = 'high';
			$attrs['loading']       = 'eager';
			$attrs['decoding']      = 'async';
		} else {
			$attrs['loading']  = 'lazy';
			$attrs['decoding'] = 'async';
		}

		$attr_str = '';
		foreach ( $attrs as $k => $v ) {
			$attr_str .= ' ' . esc_attr( $k ) . '="' . $v . '"';
		}
		$image_html = '<img' . $attr_str . '>';
	} else {
		// Placeholder.
		$placeholder_size = wc_get_image_size( 'medium' );
		$placeholder_width = isset( $placeholder_size['width'] ) ? absint( $placeholder_size['width'] ) : 300;
		$placeholder_height = isset( $placeholder_size['height'] ) ? absint( $placeholder_size['height'] ) : 300;
		$image_html = '<img src="' . esc_url( wc_placeholder_img_src( 'medium' ) ) . '" alt="' . esc_attr( $product->get_name() ) . '" width="' . esc_attr( $placeholder_width ) . '" height="' . esc_attr( $placeholder_height ) . '" loading="lazy" decoding="async">';
	}

	// Price: variable shows "From ৳X".
	if ( $product->is_type( 'variable' ) ) {
		$min_price = $product->get_variation_price( 'min', true );
		/* translators: %s: minimum price */
		$price_html = sprintf( __( 'From %s', 'yusraah' ), wc_price( $min_price ) );
	} else {
		$price_html = $product->get_price_html();
	}
	$bundle_saving = 0;
	if ( $bundle_details && $product->is_on_sale() ) {
		$regular_price = (float) $product->get_regular_price();
		$sale_price    = (float) $product->get_sale_price();
		if ( $regular_price > 0 && $sale_price > 0 && $sale_price < $regular_price ) {
			$bundle_saving = (int) round( ( ( $regular_price - $sale_price ) / $regular_price ) * 100 );
		}
	}

	$bundle_item_count = 0;
	$bundle_description = '';
	if ( $bundle_details && $product->is_type( 'woosb' ) ) {
		$bundle_ids = $product->get_meta( '_woosb_ids', true );
		if ( is_string( $bundle_ids ) && '' !== trim( $bundle_ids ) ) {
			foreach ( explode( ',', $bundle_ids ) as $bundle_item ) {
				$item_parts = explode( '/', trim( $bundle_item ), 2 );
				$item_id    = isset( $item_parts[0] ) ? absint( $item_parts[0] ) : 0;
				if ( $item_id ) {
					$quantity          = isset( $item_parts[1] ) ? absint( $item_parts[1] ) : 1;
					$bundle_item_count += max( 1, $quantity );
				}
			}
		}
	}
	if ( $bundle_details && ! $bundle_item_count ) {
		$description        = wp_strip_all_tags( $product->get_short_description() );
		$bundle_description = trim( wp_trim_words( $description, 18 ) );
	}

	// Cart button: AJAX-compatible with data attrs WC expects.
	$add_to_cart_text = $product->add_to_cart_text();
	$add_to_cart_url  = $product->add_to_cart_url();
	$is_purchasable   = $product->is_purchasable() && $product->is_in_stock();
	$is_variable      = $product->is_type( 'variable' );

	// Badges.
	$badges = '';
	if ( $product->is_on_sale() && ! $bundle_details ) {
		$badges .= '<span class="hcs-badge hcs-badge--sale">' . esc_html__( 'Sale', 'yusraah' ) . '</span>';
	}
	if ( $bundle_details || ( $bundle_badge && $product->is_type( 'woosb' ) ) ) {
		$badges .= '<span class="hcs-badge hcs-badge--bundle">' . esc_html__( 'Bundle', 'yusraah' ) . '</span>';
	}
	if ( $product->is_featured() ) {
		$badges .= '<span class="hcs-badge hcs-badge--featured">' . esc_html__( 'Featured', 'yusraah' ) . '</span>';
	}
	if ( function_exists( 'yusraah_is_new_product' ) && yusraah_is_new_product( $product_id ) ) {
		$badges .= '<span class="hcs-badge hcs-badge--new">' . esc_html__( 'New', 'yusraah' ) . '</span>';
	}

	$hidden = $index > 0 ? ' aria-hidden="true" tabindex="-1"' : '';
	?>
	<div
		class="hcs-slide"
		role="group"
		aria-roledescription="<?php esc_attr_e( 'slide', 'yusraah' ); ?>"
		aria-label="<?php echo esc_attr( sprintf(
			/* translators: 1: current slide number, 2: total slides */
			__( '%1$d of %2$d', 'yusraah' ),
			$index + 1,
			$total
		) ); ?>"
		data-hcs-slide
		<?php echo $hidden; // phpcs:ignore WordPress.Security.EscapeOutput ?>
	>
		<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="hcs-slide__image-link" tabindex="<?php echo $index > 0 ? '-1' : '0'; ?>">
			<div class="hcs-slide__image">
				<?php echo $image_html; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<?php if ( $badges ) : ?>
					<div class="hcs-slide__badges"><?php echo $badges; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
				<?php endif; ?>
				<?php if ( $bundle_saving > 0 ) : ?>
					<span class="monthly-kits-slider__saving"><?php echo esc_html( sprintf( __( 'Save %d%%', 'yusraah' ), $bundle_saving ) ); ?></span>
				<?php endif; ?>
			</div>
		</a>
		<div class="hcs-slide__body">
			<?php if ( $bundle_details ) : ?>
				<div class="monthly-kits-slider__content">
			<?php endif; ?>
			<h3 class="hcs-slide__title">
				<a href="<?php echo esc_url( $product->get_permalink() ); ?>" tabindex="<?php echo $index > 0 ? '-1' : '0'; ?>">
					<?php echo esc_html( $product->get_name() ); ?>
				</a>
			</h3>
			<?php if ( $bundle_description ) : ?>
				<p class="monthly-kits-slider__description"><?php echo esc_html( $bundle_description ); ?></p>
			<?php endif; ?>
			<?php if ( $show_rating && $product->get_rating_count() ) : ?>
				<div class="hcs-slide__rating" aria-label="<?php echo esc_attr( sprintf( /* translators: 1: rating, 2: rating count */ __( 'Rated %1$s out of 5 from %2$d reviews', 'yusraah' ), $product->get_average_rating(), $product->get_rating_count() ) ); ?>">
					<?php echo wp_kses_post( wc_get_rating_html( $product->get_average_rating(), $product->get_rating_count() ) ); ?>
				</div>
			<?php endif; ?>
			<?php if ( $bundle_item_count > 0 ) : ?>
				<p class="monthly-kits-slider__items"><?php echo esc_html( sprintf( _n( '%d item included', '%d items included', $bundle_item_count, 'yusraah' ), $bundle_item_count ) ); ?></p>
			<?php endif; ?>
			<div class="hcs-slide__price"><?php echo wp_kses_post( $price_html ); ?></div>
			<?php if ( $bundle_details ) : ?>
				</div>
			<?php endif; ?>
			<?php if ( $native_cart ) : ?>
				<?php
				$add_to_cart_tabindex = $index > 0 ? '-1' : '0';
				$add_to_cart_args_filter = static function ( $args, $cart_product ) use ( $product, $add_to_cart_tabindex ) {
					if ( $cart_product->get_id() === $product->get_id() ) {
						if ( ! isset( $args['attributes'] ) || ! is_array( $args['attributes'] ) ) {
							$args['attributes'] = array();
						}
						$args['attributes']['tabindex'] = $add_to_cart_tabindex;
					}
					return $args;
				};
				$bundle_text_filter = static function ( $text, $cart_product ) use ( $product_id ) {
					if (
						is_object( $cart_product )
						&& method_exists( $cart_product, 'get_id' )
						&& method_exists( $cart_product, 'is_type' )
						&& $product_id === $cart_product->get_id()
						&& $cart_product->is_type( 'woosb' )
					) {
						return __( 'View bundle', 'yusraah' );
					}
					return $text;
				};
				add_filter( 'woocommerce_loop_add_to_cart_args', $add_to_cart_args_filter, 10, 2 );
				if ( $bundle_details && $product->is_type( 'woosb' ) ) {
					add_filter( 'woocommerce_product_add_to_cart_text', $bundle_text_filter, 99, 2 );
				}
				woocommerce_template_loop_add_to_cart();
				remove_filter( 'woocommerce_loop_add_to_cart_args', $add_to_cart_args_filter, 10 );
				if ( $bundle_details && $product->is_type( 'woosb' ) ) {
					remove_filter( 'woocommerce_product_add_to_cart_text', $bundle_text_filter, 99 );
				}
				?>
			<?php elseif ( $is_purchasable && ! $is_variable ) : ?>
				<a
					href="<?php echo esc_url( $add_to_cart_url ); ?>"
					class="hcs-slide__atc button add_to_cart_button ajax_add_to_cart"
					data-product_id="<?php echo esc_attr( $product_id ); ?>"
					data-product_sku="<?php echo esc_attr( $product->get_sku() ); ?>"
					data-quantity="1"
					rel="nofollow"
					tabindex="<?php echo $index > 0 ? '-1' : '0'; ?>"
					aria-label="<?php echo esc_attr( sprintf(
						/* translators: %s: product name */
						__( 'Add %s to cart', 'yusraah' ),
						$product->get_name()
					) ); ?>"
				><?php echo esc_html( $add_to_cart_text ); ?></a>
			<?php elseif ( $is_variable ) : ?>
				<a
					href="<?php echo esc_url( $product->get_permalink() ); ?>"
					class="hcs-slide__atc button"
					tabindex="<?php echo $index > 0 ? '-1' : '0'; ?>"
					aria-label="<?php echo esc_attr( sprintf(
						/* translators: %s: product name */
						__( 'Select options for %s', 'yusraah' ),
						$product->get_name()
					) ); ?>"
				><?php echo esc_html( $add_to_cart_text ); ?></a>
			<?php else : ?>
				<span class="hcs-slide__atc hcs-slide__atc--out-of-stock" aria-disabled="true"><?php echo esc_html( $add_to_cart_text ); ?></span>
			<?php endif; ?>
		</div>
	</div>
	<?php
	wp_reset_postdata();
	$post               = $previous_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
	$GLOBALS['product'] = $previous_product;
}

/**
 * Render a complete slider HTML.
 *
 * @param string      $slider_id Slider identifier (hero or story).
 * @param WC_Product[] $products Optional pre-fetched product list.
 * @param bool        $quick_deal Whether to use Quick Deal slider settings.
 * @return string HTML or empty string.
 */
function yusraah_render_slider( $slider_id, $products = null, $quick_deal = false, $options = array() ) {
	if ( null === $products ) {
		$products = yusraah_slider_get_products( $slider_id );
	}
	if ( empty( $products ) ) {
		return '';
	}

	$autoplay = array_key_exists( 'autoplay', $options )
		? (bool) $options['autoplay']
		: ( $quick_deal
		? (bool) get_theme_mod( 'yusraah_quick_deal_autoplay', true )
		: (bool) get_theme_mod( 'yusraah_' . $slider_id . '_autoplay', true ) );
	$speed    = isset( $options['speed'] )
		? yusraah_sanitize_slider_speed( $options['speed'] )
		: ( $quick_deal
		? yusraah_sanitize_slider_speed( get_theme_mod( 'yusraah_quick_deal_speed', 4500 ) )
		: yusraah_sanitize_slider_speed( get_theme_mod( 'yusraah_' . $slider_id . '_speed', 4500 ) ) );
	$count    = count( $products );
	$desktop  = isset( $options['desktop'] ) ? absint( $options['desktop'] ) : ( $quick_deal ? yusraah_quick_deal_sanitize_view_desktop( get_theme_mod( 'yusraah_quick_deal_desktop', 1 ) ) : 1 );
	$tablet   = isset( $options['tablet'] ) ? absint( $options['tablet'] ) : ( $quick_deal ? yusraah_quick_deal_sanitize_view_tablet( get_theme_mod( 'yusraah_quick_deal_tablet', 1 ) ) : 1 );
	$mobile   = isset( $options['mobile'] ) ? absint( $options['mobile'] ) : ( $quick_deal ? yusraah_quick_deal_sanitize_view_mobile( get_theme_mod( 'yusraah_quick_deal_mobile', 1 ) ) : 1 );
	$label    = isset( $options['label'] ) ? sanitize_text_field( $options['label'] ) : ( $quick_deal ? __( 'Quick Deal products', 'yusraah' ) : __( 'Featured products', 'yusraah' ) );
	$native_cart = ! empty( $options['native_cart'] );
	$show_rating = ! empty( $options['show_rating'] );
	$bundle_badge = ! empty( $options['bundle_badge'] );
	$bundle_details = ! empty( $options['bundle_details'] );
	$wrapper_class = isset( $options['wrapper_class'] ) ? sanitize_html_class( $options['wrapper_class'] ) : '';

	ob_start();
	?>
	<div
		class="hcs-wrapper<?php echo $native_cart ? ' hcs-wrapper--native-cart' : ''; ?><?php echo $wrapper_class ? ' ' . esc_attr( $wrapper_class ) : ''; ?>"
		aria-label="<?php echo esc_attr( $label ); ?>"
		role="region"
		aria-roledescription="<?php esc_attr_e( 'carousel', 'yusraah' ); ?>"
		id="<?php echo esc_attr( $slider_id . '-product-slider' ); ?>"
		data-hcs-autoplay="<?php echo $autoplay ? 'true' : 'false'; ?>"
		data-hcs-speed="<?php echo esc_attr( $speed ); ?>"
		data-hcs-slides-desktop="<?php echo esc_attr( $desktop ); ?>"
		data-hcs-slides-tablet="<?php echo esc_attr( $tablet ); ?>"
		data-hcs-slides-mobile="<?php echo esc_attr( $mobile ); ?>"
	>
		<!-- Track + slides -->
		<div class="hcs-track-outer" aria-live="<?php echo $autoplay ? 'off' : 'polite'; ?>" aria-atomic="false">
			<div class="hcs-track" data-hcs-track>
				<?php
				foreach ( $products as $index => $product ) {
					yusraah_slider_render_slide( $product, $index, $count, $slider_id, $native_cart, $show_rating, $bundle_badge, $bundle_details );
				}
				?>
			</div>
		</div>

		<?php if ( $count > 1 ) : ?>
		<!-- Prev / Next arrows -->
		<button
			class="hcs-btn hcs-btn--prev"
			type="button"
			aria-label="<?php esc_attr_e( 'Previous product', 'yusraah' ); ?>"
			data-hcs-prev
		>
			<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 18l-6-6 6-6"/></svg>
		</button>
		<button
			class="hcs-btn hcs-btn--next"
			type="button"
			aria-label="<?php esc_attr_e( 'Next product', 'yusraah' ); ?>"
			data-hcs-next
		>
			<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 18l6-6-6-6"/></svg>
		</button>

		<!-- Dot indicators -->
		<div class="hcs-dots" role="tablist" aria-label="<?php esc_attr_e( 'Slide indicators', 'yusraah' ); ?>">
			<?php foreach ( $products as $index => $product ) : ?>
				<button
					class="hcs-dot<?php echo 0 === $index ? ' hcs-dot--active' : ''; ?>"
					type="button"
					role="tab"
					aria-selected="<?php echo 0 === $index ? 'true' : 'false'; ?>"
					aria-label="<?php echo esc_attr( sprintf(
						/* translators: 1: slide number, 2: total */
						__( 'Go to slide %1$d of %2$d', 'yusraah' ),
						$index + 1,
						$count
					) ); ?>"
					data-hcs-dot="<?php echo esc_attr( $index ); ?>"
					tabindex="<?php echo 0 === $index ? '0' : '-1'; ?>"
				></button>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Render hero slider (backward compatibility).
 *
 * @return string   HTML or empty string.
 */
function yusraah_render_hero_slider() {
	return yusraah_render_slider( 'hero' );
}

/**
 * Render story section slider.
 *
 * @return string   HTML or empty string.
 */
function yusraah_render_story_slider() {
	return yusraah_render_slider( 'story' );
}

/* -----------------------------------------------------------------------
 * 4. ENQUEUE ASSETS (homepage only)
 * --------------------------------------------------------------------- */

/**
 * Enqueue slider CSS + JS on the front page only.
 */
function yusraah_slider_assets() {
	if ( ! is_front_page() ) {
		return;
	}

	// CSS.
	$css_path = get_template_directory() . '/assets/css/hero-slider.css';
	wp_enqueue_style(
		'yusraah-slider',
		get_template_directory_uri() . '/assets/css/hero-slider.css',
		array( 'yusraah-style' ),
		file_exists( $css_path ) ? filemtime( $css_path ) : YUSRAAH_VERSION
	);

	// JS.
	$js_path = get_template_directory() . '/assets/js/hero-slider.js';
	wp_enqueue_script(
		'yusraah-slider',
		get_template_directory_uri() . '/assets/js/hero-slider.js',
		array(), // No jQuery dependency — vanilla JS.
		file_exists( $js_path ) ? filemtime( $js_path ) : YUSRAAH_VERSION,
		true  // Footer.
	);
	wp_script_add_data( 'yusraah-slider', 'strategy', 'defer' );

	// Pass config for each slider to JS.
	$sliders = array(
		'hero' => array(
			'autoplay' => (bool) get_theme_mod( 'yusraah_hero_autoplay', true ),
			'speed'    => yusraah_sanitize_slider_speed( get_theme_mod( 'yusraah_hero_speed', 4500 ) ),
		),
		'story' => array(
			'autoplay' => (bool) get_theme_mod( 'yusraah_story_autoplay', true ),
			'speed'    => yusraah_sanitize_slider_speed( get_theme_mod( 'yusraah_story_speed', 4500 ) ),
		),
	);

	wp_localize_script(
		'yusraah-slider',
		'yusraahSliderConfig',
		array(
			'sliders' => $sliders,
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'yusraah_add_to_cart' ),
			'quickDeal' => array(
				'nonce'   => wp_create_nonce( 'yusraah_quick_deal' ),
				'loading' => __( 'Loading products…', 'yusraah' ),
				'failed'  => __( 'Products could not be loaded. Please try again.', 'yusraah' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'yusraah_slider_assets', 25 );
