<?php
/**
 * Blog post card.
 *
 * @package Yusraah
 * @author  Shafekul Abid
 */

defined( 'ABSPATH' ) || exit;

yusraah_blog_card();
